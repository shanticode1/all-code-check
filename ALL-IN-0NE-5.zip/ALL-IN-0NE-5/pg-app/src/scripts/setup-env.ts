import fs from 'fs';
import path from 'path';

const envPath = path.resolve(process.cwd(), '.env');
const examplePath = path.resolve(process.cwd(), '.env.example');

try {
  if (!fs.existsSync(envPath)) {
    if (!fs.existsSync(examplePath)) {
      console.error('.env.example file not found!');
      process.exit(1);
    }

    fs.copyFileSync(examplePath, envPath);
    console.log('✅ .env file created from .env.example');
  } else {
    console.log('ℹ️ .env already exists');
  }
} catch (error) {
  console.error('❌ Error while setting up .env:', error);
  process.exit(1);
}
