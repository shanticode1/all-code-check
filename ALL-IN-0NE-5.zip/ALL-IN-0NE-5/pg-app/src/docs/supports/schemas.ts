import { supportHandler } from '@utils';

const supportshemas = {
  // Category
  AddCategoryRequest: {
    type: 'object',
    properties: supportHandler.supportRandomData('categoryRequest'),
  },

  CategoryList: {
    type: 'object',
    properties: supportHandler.supportRandomData('categoryListResponse'),
  },

  CategoryAddedResponse: {
    type: 'object',
    properties: supportHandler.supportRandomData('categoryAddedResponse'),
  },

  // Support Ticket Request
  AddTicketRequest: {
    type: 'object',
    properties: supportHandler.supportRandomData('ticketRequest'),
  },

  SupportTicketDetails: {
    type: 'object',
    properties: supportHandler.supportRandomData('supportTicketDetailsResponse'),
  },

  UpdateTicketRequest: {
    type: 'object',
    properties: supportHandler.supportRandomData('supportTicketStatusUpdateRequest'),
  },
  SupportCreateRequest: {
    type: 'object',
    properties: supportHandler.supportRandomData('supportCreateRequest'),
  },

  // chats
  TicketChatRequest: {
    type: 'object',
    properties: supportHandler.supportRandomData('ticketChatRequest'),
  },
};
export default supportshemas;
