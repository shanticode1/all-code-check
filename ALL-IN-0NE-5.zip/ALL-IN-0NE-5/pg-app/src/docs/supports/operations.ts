// Swagger documentation components for Support configuration
/**
 * @swagger
 * /support:
 *   put:
 *     summary: Create or update support configuration
 *     tags: [Support Configuration]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *          schema:
 *            $ref: '#/components/schemas/SupportCreateRequest'
 *     responses:
 *       200:
 *         description: Support configuration saved/updated successfully
 *       400:
 *         description: Empty or invalid payload
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support:
 *   get:
 *     summary: Get support configuration
 *     tags: [Support Configuration]
 *     responses:
 *       200:
 *         description: Support configuration fetched successfully
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */

// swagger documentation components for Support tickets
/**
 * @swagger
 * /support/ticket:
 *  post:
 *    summary: Create support ticket
 *    description: Create a new support ticket based on enabled support form configuration.
 *    tags: [Support Tickets]
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/AddTicketRequest'
 *    responses:
 *      201:
 *        description: Ticket created successfully
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      422:
 *        $ref: '#/components/responses/UnprocessableEntity'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/ticket:
 *  get:
 *    summary: Get support tickets
 *    description: Fetch list of support tickets with pagination and filters.
 *    tags: [Support Tickets]
 *    parameters:
 *      - in: query
 *        name: status
 *        schema:
 *          type: string
 *          enum: [OPEN, IN_PROGRESS, RESOLVED, CLOSED]
 *      - in: query
 *        name: page
 *        schema:
 *          type: number
 *          example: 1
 *      - in: query
 *        name: limit
 *        schema:
 *          type: number
 *          example: 10
 *      - in: query
 *        name: search
 *        schema:
 *         type: string
 *    responses:
 *      200:
 *        $ref: '#/components/responses/SupportTicketFetchedList'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/ticket/{id}:
 *  get:
 *    summary: Get support ticket details
 *    description: Fetch single support ticket by ID.
 *    tags: [Support Tickets]
 *    parameters:
 *      - in: path
 *        name: id
 *        required: true
 *        schema:
 *          type: string
 *    responses:
 *      200:
 *        $ref: '#/components/responses/SupportTicketFetched'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/ticket/{id}:
 *   delete:
 *     summary: Delete ticket by ticket ID
 *     tags: [Support Tickets]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: slug
 *         required: true
 *         schema:
 *           type: string
 *         description: The id of the ticket to delete
 *     responses:
 *       200:
 *         description: Ticket deleted successfully
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         $ref: '#/components/responses/ContentNotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/ticket/{id}/status:
 *  patch:
 *    summary: Update support ticket status
 *    description: Update status of a support ticket.
 *    tags: [Support Tickets]
 *    parameters:
 *      - in: path
 *        name: id
 *        required: true
 *        schema:
 *          type: string
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/UpdateTicketRequest'
 *    responses:
 *      200:
 *        description: Support ticket status updated successfully!
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      409:
 *        $ref: '#/components/responses/Conflict'
 *      422:
 *        $ref: '#/components/responses/UnprocessableEntity'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/settings:
 *   get:
 *     summary: Get support settings
 *     tags: [Support Configuration]
 *     responses:
 *       200:
 *         description: Support settings fetched successfully
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */

// Swagger documentation for Support Category operations
/**
 * @swagger
 * /support/categories:
 *  post:
 *    summary: Add a new category
 *    description: Use can add new category.
 *    tags: [Support Category]
 *    security:
 *      - bearerAuth: []
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/AddCategoryRequest'
 *    responses:
 *      201:
 *        $ref: '#/components/responses/CategoryAddedResponse'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      409:
 *        $ref: '#/components/responses/Conflict'
 *      422:
 *        $ref: '#/components/responses/UnprocessableEntity'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/categories:
 *  get:
 *    summary: Get all Categories
 *    description: Fetch a list of categories with pagination using `page` and `limit` query parameters.
 *    tags: [Support Category]
 *    parameters:
 *      - in: query
 *        name: page
 *        required: true
 *        schema:
 *          type: integer
 *          minimum: 1
 *          default: 1
 *      - in: query
 *        name: limit
 *        required: true
 *        schema:
 *          type: integer
 *          minimum: 1
 *          maximum: 100
 *          default: 10
 *      - in: query
 *        name: search
 *        required: false
 *        schema:
 *          type: string
 *    responses:
 *      200:
 *        $ref: '#/components/responses/CategoryListResponse'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      409:
 *        $ref: '#/components/responses/Conflict'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

// chat

/**
 * @swagger
 * /support/tickets/{ticketId}/chat:
 *  post:
 *    summary: Send a message in ticket chat
 *    description: Sends a message for a specific support ticket. Sender is determined from JWT token. `isRead` is automatically true for sender.
 *    tags: [Support Ticket Chat]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: path
 *        name: ticketId
 *        required: true
 *        schema:
 *          type: string
 *        description: ID of the support ticket
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/TicketChatRequest'
 *    responses:
 *      201:
 *        description: Message sent successfully
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      422:
 *        $ref: '#/components/responses/UnprocessableEntity'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /support/tickets/{ticketId}/chat:
 *  get:
 *    summary: Get ticket chat messages
 *    description: Retrieves all messages for a ticket with pagination. Unread messages from other users will be marked as read automatically.
 *    tags: [Support Ticket Chat]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: path
 *        name: ticketId
 *        required: true
 *        schema:
 *          type: string
 *        description: ID of the support ticket
 *      - in: query
 *        name: page
 *        schema:
 *          type: number
 *          default: 1
 *        description: Page number for pagination
 *      - in: query
 *        name: limit
 *        schema:
 *          type: number
 *          default: 20
 *        description: Number of messages per page
 *    responses:
 *      200:
 *         description: List of ticket chat messages
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */
