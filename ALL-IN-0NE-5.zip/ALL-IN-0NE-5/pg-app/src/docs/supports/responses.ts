// constants
import { supportMessages } from '@constants';

// utils
import { swaggerHandler } from '@utils';

const supportsResponses = {
  CategoryListResponse: swaggerHandler.createSuccessResponse(supportMessages.GET_CATEGORY_LIST, {
    $ref: '#/components/schemas/CategoryList',
  }),

  CategoryAddedResponse: swaggerHandler.createSuccessResponse(supportMessages.ADD_CATEGORY, {
    $ref: '#/components/schemas/CategoryAddedResponse',
  }),
  SupportTicketFetched: swaggerHandler.createSuccessResponse(supportMessages.TICKET_FETCH_SUCCESS, {
    $ref: '#/components/schemas/SupportTicketDetails',
  }),
  SupportTicketFetchedList: swaggerHandler.createSuccessResponse(supportMessages.TICKETS_FETCH_SUCCESS, {
    type: 'object',
    properties: {
      message: { type: 'string', example: supportMessages.TICKETS_FETCH_SUCCESS },
      data: {
        type: 'object',
        properties: {
          list: {
            type: 'array',
            items: { $ref: '#/components/schemas/SupportTicketDetails' },
          },
          pagination: {
            type: 'object',
            properties: {
              offset: { type: 'integer', example: 0 },
              limit: { type: 'integer', example: 10 },
              total: { type: 'integer', example: 50 },
              totalPages: { type: 'integer', example: 5 },
            },
          },
        },
      },
    },
  }),
};

export default supportsResponses;
