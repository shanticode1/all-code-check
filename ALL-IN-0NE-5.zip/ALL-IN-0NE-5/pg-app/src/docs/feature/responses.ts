// constants
import { featureMessages } from '@constants';

// utils
import { swaggerHandler } from '@utils';

const featureResponses = {
  FeatureCreated: swaggerHandler.createSuccessResponse(featureMessages.FEATURE_CREATED_SUCCESS, {
    $ref: '#/components/schemas/Feature',
  }),
  FeatureUpdated: swaggerHandler.createSuccessResponse(featureMessages.FEATURE_UPDATED_SUCCESS, {
    $ref: '#/components/schemas/Feature',
  }),
  FeatureDeleted: swaggerHandler.createSuccessResponse(featureMessages.FEATURE_DELETE_SUCCESS, null),
  FeatureListResponse: swaggerHandler.createSuccessResponse(
    featureMessages.FEATURES_FETCH_SUCCESS,
    swaggerHandler.createListResponse(
      {
        $ref: '#/components/schemas/Feature',
      },
      featureMessages.FEATURES_FETCH_SUCCESS,
    ),
  ),
  FeatureResponse: swaggerHandler.createSuccessResponse(featureMessages.FEATURE_FETCH_SUCCESS, {
    $ref: '#/components/schemas/Feature',
  }),
};

export default featureResponses;
