// constants
import { featureVariables } from '@constants';

const featureSchemas = {
  CreateFeatureRequest: {
    type: 'object',
    required: ['value', 'label'],
    properties: {
      value: {
        type: 'string',
        minLength: featureVariables.FEATURE_VALUE_MIN_LENGTH,
        maxLength: featureVariables.FEATURE_VALUE_MAX_LENGTH,
        description: 'Unique identifier/slug for the feature',
        example: 'search-best-odds',
      },
      label: {
        type: 'string',
        minLength: featureVariables.FEATURE_LABEL_MIN_LENGTH,
        maxLength: featureVariables.FEATURE_LABEL_MAX_LENGTH,
        description: 'Display label for the feature',
        example: 'Search the best odds instantly',
      },
      position: {
        type: 'number',
        description: 'Display position/order',
        example: 0,
      },
      isCore: {
        type: 'boolean',
        description: 'Whether this is a core feature',
        example: false,
      },
      isActive: {
        type: 'boolean',
        description: 'Whether the feature is active',
        example: true,
      },
    },
  },
  UpdateFeatureRequest: {
    type: 'object',
    properties: {
      value: {
        type: 'string',
        minLength: featureVariables.FEATURE_VALUE_MIN_LENGTH,
        maxLength: featureVariables.FEATURE_VALUE_MAX_LENGTH,
        description: 'Unique identifier/slug for the feature',
      },
      label: {
        type: 'string',
        minLength: featureVariables.FEATURE_LABEL_MIN_LENGTH,
        maxLength: featureVariables.FEATURE_LABEL_MAX_LENGTH,
        description: 'Display label for the feature',
      },
      position: {
        type: 'number',
        description: 'Display position/order',
      },
      isCore: {
        type: 'boolean',
        description: 'Whether this is a core feature',
      },
      isActive: {
        type: 'boolean',
        description: 'Whether the feature is active',
      },
    },
  },
  ChangeFeatureStatusRequest: {
    type: 'object',
    required: ['isActive'],
    properties: {
      isActive: {
        type: 'boolean',
        description: 'New active status',
        example: true,
      },
    },
  },
  ReorderFeaturesRequest: {
    type: 'object',
    required: ['featureIds'],
    properties: {
      featureIds: {
        type: 'array',
        items: { type: 'string' },
        description: 'Array of feature IDs in desired order',
        example: ['feat-id-1', 'feat-id-2', 'feat-id-3'],
      },
    },
  },
  Feature: {
    type: 'object',
    properties: {
      id: {
        type: 'string',
        description: 'Feature ID',
      },
      value: {
        type: 'string',
        description: 'Feature unique identifier/slug',
      },
      label: {
        type: 'string',
        description: 'Feature display label',
      },
      position: {
        type: 'number',
        description: 'Display position',
      },
      isCore: {
        type: 'boolean',
        description: 'Core feature flag',
      },
      isActive: {
        type: 'boolean',
        description: 'Active status',
      },
      createdAt: {
        type: 'string',
        format: 'date-time',
        description: 'Creation date',
      },
      updatedAt: {
        type: 'string',
        format: 'date-time',
        description: 'Last update date',
      },
    },
  },
};

export default featureSchemas;
