/**
 * @swagger
 * /feature:
 *  post:
 *    summary: Create a new feature
 *    description: Allows admin to create a new feature for subscription plans
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/CreateFeatureRequest'
 *    responses:
 *      201:
 *        $ref: '#/components/responses/FeatureCreated'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      409:
 *        $ref: '#/components/responses/Conflict'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /feature:
 *  get:
 *    summary: Get all features
 *    description: Fetch a list of features with pagination, search, and sort parameters
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: query
 *        name: page
 *        schema:
 *          type: integer
 *          default: 1
 *        description: Page number
 *      - in: query
 *        name: limit
 *        schema:
 *          type: integer
 *          default: 100
 *        description: Items per page
 *      - in: query
 *        name: search
 *        schema:
 *          type: string
 *        description: Search by value or label
 *      - in: query
 *        name: sortBy
 *        schema:
 *          type: string
 *          enum: [value, label, position, createdAt, updatedAt]
 *          default: position
 *        description: Field to sort by
 *      - in: query
 *        name: orderBy
 *        schema:
 *          type: string
 *          enum: [asc, desc]
 *          default: asc
 *        description: Sort order
 *    responses:
 *      200:
 *        $ref: '#/components/responses/FeatureListResponse'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /feature/{featureId}:
 *  get:
 *    summary: Get a specific feature by ID
 *    description: Fetch a specific feature by its ID
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: path
 *        name: featureId
 *        required: true
 *        schema:
 *          type: string
 *        description: Feature ID
 *    responses:
 *      200:
 *        $ref: '#/components/responses/FeatureResponse'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /feature/{featureId}:
 *  put:
 *    summary: Update a feature
 *    description: Allows admin to update an existing feature
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: path
 *        name: featureId
 *        required: true
 *        schema:
 *          type: string
 *        description: Feature ID
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/UpdateFeatureRequest'
 *    responses:
 *      200:
 *        $ref: '#/components/responses/FeatureUpdated'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      409:
 *        $ref: '#/components/responses/Conflict'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /feature/{featureId}:
 *  delete:
 *    summary: Delete a feature
 *    description: Allows admin to soft delete a feature
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: path
 *        name: featureId
 *        required: true
 *        schema:
 *          type: string
 *        description: Feature ID
 *    responses:
 *      200:
 *        $ref: '#/components/responses/FeatureDeleted'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /feature/change-status/{featureId}:
 *  put:
 *    summary: Change feature status
 *    description: Allows admin to activate or deactivate a feature
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    parameters:
 *      - in: path
 *        name: featureId
 *        required: true
 *        schema:
 *          type: string
 *        description: Feature ID
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/ChangeFeatureStatusRequest'
 *    responses:
 *      200:
 *        $ref: '#/components/responses/FeatureUpdated'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /feature/reorder:
 *  put:
 *    summary: Reorder features
 *    description: Allows admin to bulk update feature positions for drag & drop functionality
 *    tags: [Features]
 *    security:
 *      - bearerAuth: []
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/ReorderFeaturesRequest'
 *    responses:
 *      200:
 *        description: Features reordered successfully
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                success:
 *                  type: boolean
 *                  example: true
 *                message:
 *                  type: string
 *                  example: Feature updated successfully.
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

export {};
