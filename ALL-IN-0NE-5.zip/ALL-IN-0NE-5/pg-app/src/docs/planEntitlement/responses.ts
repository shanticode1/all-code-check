import { planEntitlementMessages } from '@constants';
import { swaggerHandler } from '@utils';

const planEntitlementResponses = {
  PlanEntitlementResponse: swaggerHandler.createSuccessResponse(
    planEntitlementMessages.PLAN_ENTITLEMENT_FETCH_SUCCESS,
    {
      $ref: '#/components/schemas/PlanEntitlement',
    },
  ),
  PlanEntitlementBatchResponse: swaggerHandler.createSuccessResponse(
    planEntitlementMessages.PLAN_ENTITLEMENT_BATCH_FETCH_SUCCESS,
    swaggerHandler.createListResponse(
      {
        $ref: '#/components/schemas/PlanEntitlement',
      },
      planEntitlementMessages.PLAN_ENTITLEMENT_BATCH_FETCH_SUCCESS,
    ),
  ),
};

export default planEntitlementResponses;
