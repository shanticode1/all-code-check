const planEntitlementSchemas = {
  FeatureEntitlement: {
    type: 'object',
    properties: {
      featureId: {
        type: 'string',
        description: 'Feature ID',
        example: '507f1f77bcf86cd799439011',
      },
      featureValue: {
        type: 'string',
        description: 'Feature value/slug',
        example: 'api-requests-per-month',
      },
      type: {
        type: 'string',
        enum: ['boolean', 'numeric', 'unlimited'],
        description: 'Feature type',
        example: 'numeric',
      },
      limit: {
        oneOf: [
          { type: 'number', example: 10000 },
          { type: 'string', enum: ['unlimited'], example: 'unlimited' },
          { type: 'boolean', example: true },
        ],
        description: 'Feature limit (number, "unlimited", or boolean)',
      },
      unit: {
        type: 'string',
        description: 'Unit for numeric features',
        example: 'requests',
      },
    },
  },
  PlanEntitlement: {
    type: 'object',
    properties: {
      id: {
        type: 'string',
        description: 'Plan entitlement document ID',
        example: '507f1f77bcf86cd799439011',
      },
      priceId: {
        type: 'string',
        description: 'Stripe price ID',
        example: 'price_1234567890',
      },
      entitlements: {
        type: 'array',
        items: {
          $ref: '#/components/schemas/FeatureEntitlement',
        },
        description: 'Array of feature entitlements',
      },
      createdAt: {
        type: 'string',
        format: 'date-time',
        description: 'Creation date',
      },
      updatedAt: {
        type: 'string',
        format: 'date-time',
        description: 'Last update date',
      },
    },
  },
  BatchPlanEntitlementsRequest: {
    type: 'object',
    required: ['priceIds'],
    properties: {
      priceIds: {
        type: 'array',
        items: {
          type: 'string',
        },
        description: 'Array of Stripe price IDs',
        example: ['price_1234567890', 'price_0987654321'],
      },
    },
  },
};

export default planEntitlementSchemas;
