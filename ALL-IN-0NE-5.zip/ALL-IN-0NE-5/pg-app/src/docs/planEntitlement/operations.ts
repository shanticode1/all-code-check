/**
 * @swagger
 * /plan-entitlements/{priceId}:
 *  get:
 *    summary: Get plan entitlements by price ID
 *    description: Fetch entitlements for a specific Stripe price ID
 *    tags: [Plan Entitlements]
 *    parameters:
 *      - in: path
 *        name: priceId
 *        required: true
 *        schema:
 *          type: string
 *        description: Stripe price ID
 *        example: price_1234567890
 *    responses:
 *      200:
 *        $ref: '#/components/responses/PlanEntitlementResponse'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /plan-entitlements/batch:
 *  post:
 *    summary: Get plan entitlements by multiple price IDs (batch)
 *    description: Fetch entitlements for multiple Stripe price IDs in a single request
 *    tags: [Plan Entitlements]
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/BatchPlanEntitlementsRequest'
 *    responses:
 *      200:
 *        $ref: '#/components/responses/PlanEntitlementBatchResponse'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

export {};
