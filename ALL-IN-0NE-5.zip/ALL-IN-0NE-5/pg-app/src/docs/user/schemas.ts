import { userHandler } from '@utils';

const userSchemas = {
  // User
  User: {
    type: 'object',
    properties: userHandler.userRandomData('userSchema'),
  },

  // User Creation
  CreateUserRequest: {
    type: 'object',
    required: ['firstName', 'email'],
    properties: userHandler.userRandomData('createUserRequest'),
  },
  UpdateUserRequest: {
    type: 'object',
    properties: userHandler.userRandomData('updateUserRequest'),
  },
  ChangeStatusRequest: {
    type: 'object',
    required: ['status'],
    properties: userHandler.userRandomData('changeStatusRequest'),
  },
  SetPasswordRequest: {
    type: 'object',
    required: ['token', 'password'],
    properties: userHandler.userRandomData('setPasswordRequest'),
  },
  ResendInvitationRequest: {
    type: 'object',
    required: ['userId'],
    properties: {
      userId: {
        type: 'string',
        description: 'The ID of the user to resend the invitation email',
        example: '64f8a2c9e1234567890abcde',
      },
    },
  },
};
export default userSchemas;
