import { exampleEntitlementsMessages } from '@constants';
import { swaggerHandler } from '@utils';

const exampleEntitlementsResponses = {
  ApiDataResponse: {
    description: 'API data with usage statistics',
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: true,
            },
            data: {
              type: 'object',
              properties: {
                message: {
                  type: 'string',
                  example: 'This is protected API data',
                },
              },
            },
            meta: {
              $ref: '#/components/schemas/UsageMeta',
            },
          },
        },
      },
    },
  },
  DataExportResponse: {
    description: exampleEntitlementsMessages.DATA_EXPORT_SUCCESS,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: true,
            },
            message: {
              type: 'string',
              example: exampleEntitlementsMessages.DATA_EXPORT_SUCCESS,
            },
            downloadUrl: {
              type: 'string',
              example: '/downloads/data.csv',
            },
          },
        },
      },
    },
  },
  TeamMemberCreatedResponse: {
    description: exampleEntitlementsMessages.TEAM_MEMBER_ADDED_SUCCESS,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: true,
            },
            message: {
              type: 'string',
              example: exampleEntitlementsMessages.TEAM_MEMBER_ADDED_SUCCESS,
            },
          },
        },
      },
    },
  },
  UserEntitlementsResponse: {
    description: exampleEntitlementsMessages.USER_ENTITLEMENTS_FETCH_SUCCESS,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: true,
            },
            data: {
              type: 'array',
              items: {
                $ref: '#/components/schemas/FormattedEntitlement',
              },
            },
          },
        },
      },
    },
  },
  FileUploadResponse: {
    description: exampleEntitlementsMessages.FILE_UPLOAD_SUCCESS,
    content: {
      'application/json': {
        schema: {
          type: 'object',
          properties: {
            success: {
              type: 'boolean',
              example: true,
            },
            message: {
              type: 'string',
              example: exampleEntitlementsMessages.FILE_UPLOAD_SUCCESS,
            },
          },
        },
      },
    },
  },
};

export default exampleEntitlementsResponses;
