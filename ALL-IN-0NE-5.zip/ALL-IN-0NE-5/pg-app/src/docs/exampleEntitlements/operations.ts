/**
 * @swagger
 * /example-entitlements/api-data:
 *  get:
 *    summary: Example 1 - Protected API endpoint with usage tracking
 *    description: |
 *      Example endpoint demonstrating usage tracking for 'api-requests-per-month' feature.
 *      - Checks if user has 'api-requests-per-month' feature
 *      - Automatically tracks usage against the limit
 *      - Returns usage statistics in response
 *    tags: [Example Entitlements]
 *    security:
 *      - bearerAuth: []
 *    responses:
 *      200:
 *        $ref: '#/components/responses/ApiDataResponse'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /example-entitlements/export-data:
 *  get:
 *    summary: Example 2 - Export data endpoint with boolean feature check
 *    description: |
 *      Example endpoint demonstrating boolean feature check for 'data-export' feature.
 *      - Checks if user has 'data-export' feature enabled
 *      - Tracks usage automatically
 *    tags: [Example Entitlements]
 *    security:
 *      - bearerAuth: []
 *    responses:
 *      200:
 *        $ref: '#/components/responses/DataExportResponse'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /example-entitlements/team/members:
 *  post:
 *    summary: Example 3 - Team member creation with count limit check
 *    description: |
 *      Example endpoint demonstrating count limit validation for 'team-members' feature.
 *      - Validates current team member count before allowing creation
 *      - Increments usage count after successful creation
 *    tags: [Example Entitlements]
 *    security:
 *      - bearerAuth: []
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/CreateTeamMemberRequest'
 *    responses:
 *      200:
 *        $ref: '#/components/responses/TeamMemberCreatedResponse'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /example-entitlements/my-entitlements:
 *  get:
 *    summary: Example 4 - Get user's entitlements and usage stats
 *    description: |
 *      Example endpoint to fetch all user entitlements with detailed usage statistics.
 *      Returns formatted entitlements including:
 *      - Feature details (type, limit, unit)
 *      - Current usage and remaining quota
 *      - Usage percentage
 *      - Reset period information
 *    tags: [Example Entitlements]
 *    security:
 *      - bearerAuth: []
 *    responses:
 *      200:
 *        $ref: '#/components/responses/UserEntitlementsResponse'
 *      404:
 *        $ref: '#/components/responses/NotFound'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

/**
 * @swagger
 * /example-entitlements/upload:
 *  post:
 *    summary: Example 5 - File upload with storage limit check
 *    description: |
 *      Example endpoint demonstrating manual feature check and storage validation.
 *      - Checks if user has 'file-uploads' feature
 *      - Validates available storage space before upload
 *      - Increments storage usage after successful upload
 *    tags: [Example Entitlements]
 *    security:
 *      - bearerAuth: []
 *    requestBody:
 *      required: true
 *      content:
 *        application/json:
 *          schema:
 *            $ref: '#/components/schemas/FileUploadRequest'
 *    responses:
 *      200:
 *        $ref: '#/components/responses/FileUploadResponse'
 *      403:
 *        $ref: '#/components/responses/Forbidden'
 *      401:
 *        $ref: '#/components/responses/Unauthorized'
 *      400:
 *        $ref: '#/components/responses/BadRequest'
 *      500:
 *        $ref: '#/components/responses/InternalServerError'
 */

export {};
