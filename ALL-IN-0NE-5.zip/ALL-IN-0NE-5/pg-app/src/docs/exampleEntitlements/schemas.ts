const exampleEntitlementsSchemas = {
  CreateTeamMemberRequest: {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        description: 'Team member name',
        example: 'John Doe',
      },
      email: {
        type: 'string',
        format: 'email',
        description: 'Team member email',
        example: 'john@example.com',
      },
      role: {
        type: 'string',
        description: 'Team member role',
        example: 'developer',
      },
    },
  },
  FileUploadRequest: {
    type: 'object',
    required: ['fileSize'],
    properties: {
      fileSize: {
        type: 'number',
        description: 'File size in MB',
        example: 100,
      },
      fileName: {
        type: 'string',
        description: 'File name',
        example: 'document.pdf',
      },
    },
  },
  UsageMeta: {
    type: 'object',
    properties: {
      usage: {
        type: 'number',
        description: 'Current usage count',
        example: 150,
      },
      limit: {
        oneOf: [
          { type: 'number', example: 10000 },
          { type: 'string', enum: ['unlimited'], example: 'unlimited' },
        ],
        description: 'Usage limit',
      },
      remaining: {
        oneOf: [
          { type: 'number', example: 9850 },
          { type: 'string', enum: ['unlimited'], example: 'unlimited' },
        ],
        description: 'Remaining usage',
      },
    },
  },
  FormattedEntitlement: {
    type: 'object',
    properties: {
      feature: {
        type: 'string',
        description: 'Feature value/slug',
        example: 'api-requests-per-month',
      },
      label: {
        type: 'string',
        description: 'Formatted feature label',
        example: 'Api Requests Per Month',
      },
      type: {
        type: 'string',
        enum: ['boolean', 'numeric', 'unlimited'],
        description: 'Feature type',
        example: 'numeric',
      },
      limit: {
        oneOf: [
          { type: 'number', example: 10000 },
          { type: 'string', enum: ['unlimited'], example: 'unlimited' },
          { type: 'boolean', example: true },
        ],
        description: 'Feature limit',
      },
      currentUsage: {
        type: 'number',
        description: 'Current usage count',
        example: 150,
      },
      unit: {
        type: 'string',
        description: 'Unit for numeric features',
        example: 'requests',
      },
      resetPeriod: {
        type: 'string',
        description: 'Usage reset period',
        example: 'monthly',
      },
      percentage: {
        type: 'number',
        description: 'Usage percentage (0-100)',
        example: 15,
      },
      remaining: {
        oneOf: [
          { type: 'number', example: 9850 },
          { type: 'string', enum: ['unlimited'], example: 'unlimited' },
        ],
        description: 'Remaining quota',
      },
    },
  },
};

export default exampleEntitlementsSchemas;
