import { Router } from 'express';
import { planEntitlementController } from '@controllers';
import { authenticate } from '@middlewares';

const router = Router();

/**
 * @route GET /api/plan-entitlements/:priceId
 * @desc Get plan entitlements by price ID
 * @access Public (can be made private if needed)
 */
router.get('/:priceId', planEntitlementController.getPlanEntitlementsByPriceId);

/**
 * @route POST /api/plan-entitlements/batch
 * @desc Get plan entitlements by multiple price IDs
 * @access Public (can be made private if needed)
 */
router.post('/batch', planEntitlementController.getPlanEntitlementsByPriceIds);

export default router;
