import express from 'express';

import { supportController } from '@controllers';
import { authenticate, authorize, validate } from '@middlewares';
import { Role } from '@enums';
import { supportValidations } from '@validations';

const router = express.Router();

router.get('/', authenticate, authorize(Role.Admin, Role.User), supportController.getSupportConfig);

router.put(
  '/',
  authenticate,
  authorize(Role.Admin),
  validate(supportValidations.supportConfigUpdateValidator),
  supportController.updateSupportConfig,
);
router.post(
  '/ticket',
  validate(supportValidations.supportTicketValidator),
  authenticate,
  supportController.createTicket,
);
router.get('/ticket/:ticketId?', authenticate, authorize(Role.Admin, Role.User), supportController.getAllTickets);

router.patch('/ticket/:ticketId/status', authenticate, authorize(Role.Admin), supportController.updateTicketStatus);
router.delete('/ticket/:ticketId', authenticate, authorize(Role.Admin), supportController.deleteTicketById);

router.get('/settings', supportController.getSupportSetting);

// category
router.post('/categories', supportController.addCategory);
router.get('/categories', supportController.getCategories);

// chat
router.post(
  '/tickets/:ticketId/chat',
  authenticate,
  authorize(Role.Admin, Role.User),
  supportController.createTicketChat,
);
router.get(
  '/tickets/:ticketId/chat/:chatId?',
  authenticate,
  authorize(Role.Admin, Role.User),
  supportController.getTicketChats,
);

export default router;
