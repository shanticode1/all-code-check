import express from 'express';
import authRoute from './auth.route';
import dataManagementRoute from './dataManagement.route';
import localFileHandlerRoute from './localFileHandler.route';
import notificationRoute from './notification.route';
import paymentRoute from './payment.route';
import s3FileHandlerRoute from './s3FileHandler.route';
import ssoRoute from './sso.route';
import twoFARoute from './twoFA.route';
import userRoute from './user.route';
import redisRoute from './redis.route';
import subscriptionRoute from './subscription.route';
import featureRoute from './feature.route';
import savedCardRoute from './savedCard.route';
import planEntitlementRoute from './planEntitlement.route';
import exampleEntitlementsRoute from './example-entitlements.route';
import supportRoute from './support.route';

const indexRoute = express.Router();

indexRoute.use('/auth', authRoute);
indexRoute.use('/user', userRoute);
indexRoute.use('/local-files', localFileHandlerRoute);
indexRoute.use('/s3-files', s3FileHandlerRoute);
indexRoute.use('/sso', ssoRoute);
indexRoute.use('/two-factor-auth', twoFARoute);
indexRoute.use('/data-management', dataManagementRoute);
indexRoute.use('/payment', paymentRoute);
indexRoute.use('/notification', notificationRoute);
indexRoute.use('/redis', redisRoute);
indexRoute.use('/support', supportRoute);

indexRoute.use('/subscription', subscriptionRoute);
indexRoute.use('/feature', featureRoute);
indexRoute.use('/saved-cards', savedCardRoute);
indexRoute.use('/plan-entitlements', planEntitlementRoute);
indexRoute.use('/example-entitlements', exampleEntitlementsRoute);

export default indexRoute;
