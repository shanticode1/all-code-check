//Controllers
import { savedCardController } from '@controllers';
//Enums
import { Role } from '@enums';
//Middlewares
import { authenticate, authorize, validate } from '@middlewares';
//Validations
import { paymentValidations } from '@validations';
//Third-party modules
import { Router } from 'express';

const router = Router();

// Saved card routes (tokenization)
router.post(
  '/setup-intent',
  authenticate,
  authorize(Role.User),
  validate(paymentValidations.createSavedCardSetupIntentValidator),
  savedCardController.createSavedCardSetupIntent,
);

router.post(
  '/',
  authenticate,
  authorize(Role.User),
  validate(paymentValidations.saveCardValidator),
  savedCardController.saveCard,
);

router.get('/', authenticate, authorize(Role.User), savedCardController.listSavedCards);

router.delete('/:cardId', authenticate, authorize(Role.User), savedCardController.deleteSavedCard);

export default router;
