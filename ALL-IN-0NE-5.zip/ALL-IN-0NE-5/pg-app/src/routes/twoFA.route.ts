import { twoFAController } from '@controllers';
import { authenticate, authenticateForTwoFARoute, validate } from '@middlewares';
import { twoFAValidations } from '@validations';
import express from 'express';
const router = express.Router();

router.post('/active', validate(twoFAValidations.activeValidator), twoFAController.enableTwoFA);

// email /sms/app
router.post(
  '/send-otp',
  authenticateForTwoFARoute,
  validate(twoFAValidations.generateSecretValidator),
  twoFAController.sendTwoFACode,
);

router.patch(
  '/verify-otp',
  authenticateForTwoFARoute,
  validate(twoFAValidations.verifyCodeValidator),
  twoFAController.verifyTwoFACode,
);

router.get('/recovery-codes', authenticate, twoFAController.getRecoveryCodes);
router.patch('/recovery-codes/regenerate', authenticate, twoFAController.regenerateRecoveryCodes);
router.post(
  '/recovery-codes/verify',
  authenticateForTwoFARoute,
  validate(twoFAValidations.verifyRecoveryCodeValidator),
  twoFAController.validateRecoveryCode,
);

router.patch(
  '/preferred-method',
  authenticateForTwoFARoute,
  validate(twoFAValidations.preferredTwoFaMethodValidator),
  twoFAController.updatePreferredTwoFaMethod,
);

export default router;
