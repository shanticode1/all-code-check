import { exampleEntitlementsController } from '@controllers';
import { authenticate, requireAndTrackFeature } from '@middlewares';
import express from 'express';

const exampleEntitlementsRoute = express.Router();

/**
 * Example 1: Protected API endpoint with usage tracking
 * - Checks if user has 'api-access' feature
 * - Tracks usage against 'api-requests-per-month' limit
 */
exampleEntitlementsRoute.get(
  '/api-data',
  authenticate,
  requireAndTrackFeature('api-requests-per-month'),
  exampleEntitlementsController.getApiData,
);

/**
 * Example 2: Export data endpoint with boolean feature check
 * - Checks if user has 'data-export' feature
 */
exampleEntitlementsRoute.get(
  '/export-data',
  authenticate,
  requireAndTrackFeature('data-export'),
  exampleEntitlementsController.exportData,
);

/**
 * Example 3: Team member creation with count limit check
 * - Checks if user can add more team members
 * - Updates currentUsage in subscription collection
 */
exampleEntitlementsRoute.post('/team/members', authenticate, exampleEntitlementsController.addTeamMember);

/**
 * Example 4: Get user's entitlements and usage stats
 */
exampleEntitlementsRoute.get('/my-entitlements', authenticate, exampleEntitlementsController.getMyEntitlements);

/**
 * Example 5: File upload with size check
 * - Just returns success message (no storage tracking)
 */
exampleEntitlementsRoute.post('/upload', authenticate, exampleEntitlementsController.uploadFile);

export default exampleEntitlementsRoute;
