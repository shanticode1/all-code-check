//Controllers
import { subscriptionController } from '@controllers';
//Enums
import { Role } from '@enums';
//Middlewares
import { authenticate, authorize, validate } from '@middlewares';
//Validations
import { paymentValidations } from '@validations';
//Third-party modules
import { Router } from 'express';

const router = Router();

// User subscription routes
router.get('/user', authenticate, subscriptionController.getUserSubscription);
router.get('/billing-history', authenticate, subscriptionController.getUserBillingHistory);
router.get('/customer-portal', authenticate, subscriptionController.getCustomerPortalUrl);

// Admin subscription routes
router.get('/all', authenticate, authorize(Role.Admin), subscriptionController.getAllUserSubscriptions);

// Stripe subscription related routes
// post (usage) paid
router.post(
  '/usage/session/:customerId',
  authenticate,
  authorize(Role.User),
  validate(paymentValidations.createSubscriptionValidator),
  subscriptionController.createPostPaidSubscriptionSession,
);

router.post(
  '/create/free-trial',
  authenticate,
  authorize(Role.User),
  validate(paymentValidations.createSubscriptionValidator),
  subscriptionController.createPostPaymentSubcription,
);

router.get('/:subscriptionId', authenticate, authorize(Role.User), subscriptionController.getSubcriptionById);

router.delete('/:subscriptionId', authenticate, authorize(Role.User), subscriptionController.deleteSubcriptionById);

router.put(
  '/',
  authenticate,
  validate(paymentValidations.updateSubscriptionValidator),
  subscriptionController.updateSubscription,
);

// Create subscription from intent (after payment method is confirmed)
router.post(
  '/create-from-intent',
  authenticate,
  authorize(Role.User),
  subscriptionController.createSubscriptionFromIntent,
);

export default router;
