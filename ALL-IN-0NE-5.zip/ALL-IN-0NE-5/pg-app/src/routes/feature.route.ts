import express from 'express';
import { authenticate, authorize, validate } from '@middlewares';
import { featureValidations } from '@validations';
import { featureController } from '@controllers';
import { Role } from '@enums';

const featureRoute = express.Router();

// Create feature
featureRoute.post(
  '/',
  authenticate,
  authorize(Role.Admin),
  validate(featureValidations.createFeatureSchema),
  featureController.createFeature,
);

// Get all features or specific feature (PUBLIC - no auth required)
featureRoute.get('/', validate(featureValidations.getFeaturesSchema), featureController.getFeatures);

featureRoute.get('/:featureId', validate(featureValidations.featureIdSchema), featureController.getFeatures);

// Update feature
featureRoute.put(
  '/:featureId',
  authenticate,
  authorize(Role.Admin),
  validate(featureValidations.updateFeatureSchema),
  featureController.updateFeature,
);

// Change feature status
featureRoute.put(
  '/change-status/:featureId',
  authenticate,
  authorize(Role.Admin),
  validate(featureValidations.changeStatusSchema),
  featureController.changeFeatureStatus,
);

// Reorder features (bulk update positions)
featureRoute.put(
  '/reorder',
  authenticate,
  authorize(Role.Admin),
  validate(featureValidations.reorderFeaturesSchema),
  featureController.reorderFeatures,
);

// Delete feature
featureRoute.delete(
  '/:featureId',
  authenticate,
  authorize(Role.Admin),
  validate(featureValidations.featureIdSchema),
  featureController.deleteFeature,
);

export default featureRoute;
