import {
  FORBIDDEN,
  SERVER_ERROR,
  TOO_MANY_REQUESTS,
  UNAUTHORIZE,
  commonMessages,
  entitlementMessages,
  paymentVariables,
} from '@constants';
import { entitlementService } from '@services';
import { ErrorHandler } from '@utils';
import type { NextFunction, Request, Response } from 'express';

/**
 * Middleware to check if user has access to a specific feature
 * @param featureValue - The feature value to check (e.g., 'api-requests-per-month')
 */
export const requireFeature = (featureValue: string) => {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
      const userId = req.user?.id?.toString();

      if (!userId) {
        next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
        return;
      }

      // Check if user has this feature in their plan
      const hasAccess = await entitlementService.hasFeature(userId, featureValue);

      if (!hasAccess) {
        next(new ErrorHandler(entitlementMessages.ENTITLEMENT_FEATURE_NOT_AVAILABLE(featureValue), FORBIDDEN, null));
        return;
      }

      // Check if usage limit is exceeded
      const canUse = await entitlementService.canUseFeature(userId, featureValue);

      if (!canUse) {
        const usage = await entitlementService.getCurrentUsage(userId, featureValue);
        next(
          new ErrorHandler(
            entitlementMessages.ENTITLEMENT_FEATURE_LIMIT_EXCEEDED(
              featureValue,
              usage?.current || 0,
              usage?.limit || 0,
            ),
            TOO_MANY_REQUESTS,
            null,
          ),
        );
        return;
      }

      next();
    } catch (_error) {
      next(new ErrorHandler(entitlementMessages.ENTITLEMENT_ERROR_CHECKING_ACCESS, SERVER_ERROR, null));
    }
  };
};

/**
 * Middleware to track feature usage (increment counter)
 * @param featureValue - The feature value to track
 * @param amount - Amount to increment (default: 1)
 */
export const trackFeatureUsage = (featureValue: string, amount = 1) => {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
      const userId = req.user?.id?.toString();

      if (!userId) {
        next();
        return;
      }

      // Increment usage counter asynchronously (don't block the request)
      entitlementService.incrementUsage(userId, featureValue, amount).catch((error) => {
        console.error(`Error tracking feature usage for ${featureValue}:`, error);
      });

      next();
    } catch (error) {
      // Don't fail the request if usage tracking fails
      console.error('Error in trackFeatureUsage middleware:', error);
      next();
    }
  };
};

/**
 * Combined middleware: check access and track usage
 * @param featureValue - The feature value to check and track
 * @param amount - Amount to increment (default: 1)
 */
export const requireAndTrackFeature = (featureValue: string, amount = 1) => {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
      const userId = req.user?.id?.toString();

      if (!userId) {
        next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
        return;
      }

      // Check if user has this feature in their plan
      const hasAccess = await entitlementService.hasFeature(userId, featureValue);

      if (!hasAccess) {
        next(new ErrorHandler(entitlementMessages.ENTITLEMENT_FEATURE_NOT_AVAILABLE(featureValue), FORBIDDEN, null));
        return;
      }

      // Check if usage limit is exceeded
      const canUse = await entitlementService.canUseFeature(userId, featureValue);

      if (!canUse) {
        const usage = await entitlementService.getCurrentUsage(userId, featureValue);
        next(
          new ErrorHandler(
            entitlementMessages.ENTITLEMENT_FEATURE_LIMIT_EXCEEDED(
              featureValue,
              usage?.current || 0,
              usage?.limit || 0,
            ),
            TOO_MANY_REQUESTS,
            null,
          ),
        );
        return;
      }

      // Increment usage counter asynchronously
      entitlementService.incrementUsage(userId, featureValue, amount).catch((error) => {
        console.error(`Error tracking feature usage for ${featureValue}:`, error);
      });

      next();
    } catch (_error) {
      next(new ErrorHandler(entitlementMessages.ENTITLEMENT_ERROR_CHECKING_ACCESS, SERVER_ERROR, null));
    }
  };
};

/**
 * Middleware to check count-based feature limits (e.g., team members, projects)
 * @param featureValue - The feature value to check
 * @param getCurrentCount - Function to get current count
 */
export const checkCountLimit = (featureValue: string, getCurrentCount: (userId: string) => Promise<number>) => {
  return async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
    try {
      const userId = req.user?.id?.toString();

      if (!userId) {
        next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
        return;
      }

      // Check if user has this feature
      const hasAccess = await entitlementService.hasFeature(userId, featureValue);

      if (!hasAccess) {
        next(new ErrorHandler(entitlementMessages.ENTITLEMENT_FEATURE_NOT_AVAILABLE(featureValue), FORBIDDEN, null));
        return;
      }

      // Get the limit
      const limit = await entitlementService.getFeatureLimit(userId, featureValue);

      if (limit === paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED) {
        next();
        return;
      }

      // Get current count
      const currentCount = await getCurrentCount(userId);

      if (currentCount >= (limit as number)) {
        next(
          new ErrorHandler(
            entitlementMessages.ENTITLEMENT_FEATURE_LIMIT_REACHED(featureValue, currentCount, limit as number),
            FORBIDDEN,
            null,
          ),
        );
        return;
      }

      next();
    } catch (_error) {
      next(new ErrorHandler(entitlementMessages.ENTITLEMENT_ERROR_CHECKING_COUNT_LIMIT, SERVER_ERROR, null));
    }
  };
};
