import path from 'path';
import { commonHandler } from '@utils';
import type { NextFunction, Request, Response } from 'express';
// Third-party modules
import multer from 'multer';
import fs from 'node:fs';

import { fileHandlerMessages, fileHandlerVariables, NOT_FOUND } from '@constants';
import { ErrorHandler, catchHandler } from '@utils';
import { localFileHandlerService } from '@services';

/**
 * Local file storage configuration.
 */
const localFileStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    const destinationPath = path.join(fileHandlerVariables.UPLOAD_DIR, fileHandlerVariables.UPLOAD_FOLDER); // uploads/documents
    if (!fs.existsSync(destinationPath)) {
      fs.mkdirSync(destinationPath, { recursive: true });
    }
    cb(null, destinationPath);
  },
  filename: (_req, file, cb) => {
    const fileName = `${Date.now().toString()}-${file.originalname}`;
    cb(null, fileName);
  },
});

/**
 * Middleware to handle local file upload.
 * @param {Request} req - Express request object.
 * @param {Response} res - Express response object.
 * @param {NextFunction} next - Express next function.
 * @returns {void}
 * @throws {ErrorHandler} An error handler with a 400 status code if the file upload fails.
 */
const localUploadMiddleware = multer({
  storage: localFileStorage,
  limits: {
    fileSize: fileHandlerVariables.FILE_SIZE,
  },
  fileFilter: (_req, file, cb) => {
    const extname = path.extname(file.originalname).toLowerCase();
    if (fileHandlerVariables.FILE_FORMATS.includes(extname.slice(1))) {
      cb(null, true);
    } else {
      cb(new Error(fileHandlerMessages.FILE_TYPE_ERROR));
    }
  },
}).fields([
  {
    name: fileHandlerVariables.FILE_UPLOAD_FIELD,
    maxCount: fileHandlerVariables.FILE_UPLOAD_LIMIT,
  },
]);

/**
 * Handles local file uploading.
 * @param {Request} req - Express request object.
 * @param {Response} res - Express response object.
 * @param {NextFunction} next - Express next function.
 * @throws {ErrorHandler} An error handler with a 400 status code if the file upload fails.
 */
export const uploadFileLocal = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const convertedFileSize = await commonHandler.convertFileSize(fileHandlerVariables.FILE_SIZE, 'Byte', 'MB');
    localUploadMiddleware(req, res, (error) => {
      if (error) {
        if (error.code === fileHandlerVariables.LIMIT_FILE_SIZE_ERROR_CODE) {
          return next(
            new ErrorHandler(
              `${error.field} ${fileHandlerMessages.FILE_SIZE_ERROR} ${convertedFileSize}MB`,
              400,
              error,
            ),
          );
        }
        if (error.code === fileHandlerVariables.ENOENT_ERROR_CODE) {
          return next(
            new ErrorHandler(
              `${fileHandlerMessages.DIRECTORY_FOUND_ERROR} ${fileHandlerVariables.UPLOAD_DIR}.`,
              400,
              error,
            ),
          );
        }
        if (error.code === fileHandlerVariables.LIMIT_UNEXPECTED_FILE_ERROR_CODE) {
          return next(
            new ErrorHandler(`${fileHandlerMessages.FILE_UPLOAD_LIMIT_ERROR} for ${error.field} `, 400, error),
          );
        }
        if (error.name === 'Error') {
          return next(new ErrorHandler(error.message, 400, error));
        }
        return next(new ErrorHandler(`${fileHandlerMessages.UPLOAD_FILE_ERROR} ${error.field}.`, 400, error));
      }
      //Normalize paths in all uploaded files
      if (req.files) {
        const filesMap = req.files as { [fieldname: string]: Express.Multer.File[] };
        Object.keys(filesMap).forEach((fieldName) => {
          filesMap[fieldName].forEach((file) => {
            file.path = file.path.replace(/^public[\\/]/, '');
          });
        });
      }
      next();
    });
  } catch (error) {
    catchHandler(error, next);
  }
};

export const addUploadsPrefix = (filePath: string) => {
  if (!filePath.startsWith('uploads/')) {
    return `uploads${filePath.startsWith('/') ? '' : '/'}${filePath}`;
  }
  return filePath;
};
/**
 * Middleware to delete a locally uploaded file.
 *
 * This middleware:
 * - Resolves the local file path
 * - Checks if the file exists
 * - Deletes the file from disk
 * - Does NOT interact with database or services
 *
 * Expected:
 * - File path should be available in `req.file?.path`
 *   OR `req.body.filePath`
 *
 * @param req Express request object
 * @param res Express response object
 * @param next Express next middleware
 */
export const deleteLocalUploadedFile = async (req: any, _res: Response, next: NextFunction) => {
  try {
    if (!req.query.filePath) {
      return next(); // Nothing to delete
    }
    const formatPath = req.query.filePath?.split('uploads')[1];
    const pathParam = addUploadsPrefix(formatPath);
    const fileDoc = await localFileHandlerService.getFileById(pathParam);
    if (!fileDoc) {
      return next(
        new ErrorHandler(`${fileHandlerMessages.FILE_NOT_FOUND}`, NOT_FOUND, `${fileHandlerMessages.FILE_NOT_FOUND}`),
      );
    }
    const filePath = fileDoc?.paths?.[0]?.path;

    if (!filePath) {
      return next(); // Nothing to delete
    }

    // ✅ absolute path
    const absolutePath = path.join(process.cwd(), 'public', filePath);

    try {
      fs.access(absolutePath, (err) => {
        if (!err) {
          fs.unlink(absolutePath, () => {});
        }
      });
    } catch {
      // File does not exist → ignore safely
    }
    req.fileId = fileDoc.id;
    next();
  } catch (error) {
    next(error);
  }
};

export const deleteLocalUploadedFileV2 = async (filePathName: string) => {
  try {
    const formatPath = filePathName?.split('uploads')[1];
    const pathParam = addUploadsPrefix(formatPath);
    const fileDoc = await localFileHandlerService.getFileById(pathParam);
    if (!fileDoc) {
      return new ErrorHandler(
        `${fileHandlerMessages.FILE_NOT_FOUND}`,
        NOT_FOUND,
        `${fileHandlerMessages.FILE_NOT_FOUND}`,
      );
    }

    const filePath = fileDoc.path?.[0];

    if (!filePath) {
      return; // Nothing to delete
    }

    // ✅ absolute path
    const absolutePath = path.join(process.cwd(), 'public', filePath);

    try {
      // await fs.access(absolutePath);
      // await fs.unlink(absolutePath);
      fs.access(absolutePath, (err) => {
        if (!err) {
          fs.unlink(absolutePath, () => {});
        }
      });
    } catch {
      // File does not exist → ignore safely
    }
    return;
  } catch (error) {
    return error;
  }
};
