import env from '@config/envVar';
import { logger } from '@config/logger';
import { ssoMessages } from '@constants';
import type { IUser } from '@customTypes';
//Enums
import { Role, Strategy, UserStatus } from '@enums';
//Third-party modules
import { faker } from '@faker-js/faker';
import { prismaService } from '@services';
//Third-party modules
import passport from 'passport';
import { Strategy as FacebookStrategy } from 'passport-facebook';
import { type Profile, Strategy as GoogleStrategy } from 'passport-google-oauth20';

/** Google Strategy
 * This strategy is used to authenticate users using their Google account.
 * It requires a client ID, client secret, and callback URL.
 * The callback function receives the profile and calls `done` to pass the user to the next middleware.
 * If the user does not exist, a new user is created.
 * If the user exists but has a different email, the email is updated.
 * If an error occurs, it is passed to `done`.
 */
passport.use(
  new GoogleStrategy(
    {
      clientID: env.GOOGLE_CLIENT_ID || '',
      clientSecret: env.GOOGLE_CLIENT_SECRET || '',
      callbackURL: env.GOOGLE_CALLBACK_URL,
    },
    async (_accessToken: string, _refreshToken: string, profile: Profile, done) => {
      try {
        const email = profile.emails?.[0]?.value?.toLowerCase();
        if (!email) throw new Error(ssoMessages.EMAIL_IS_REQUIRED);

        // 1️⃣ Try to find user by Google ID
        let user = await prismaService.getRecord('user', {
          where: { googleId: profile.id },
        });

        // 2️⃣ If not found, try by email (prevents duplicate accounts)
        if (!user) {
          user = await prismaService.getRecord('user', {
            where: { email },
          });
        }

        // 3️⃣ Create new user if none exists
        if (!user) {
          user = await prismaService.createRecord('user', {
            googleId: profile.id,
            email,
            firstName: profile.name?.givenName || '',
            lastName: profile.name?.familyName || '',
            role: Role.User,
            status: UserStatus.Active,
          });
        }

        // 4️⃣ If user exists but Google ID not linked, attach it
        else if (!user.googleId) {
          user = await prismaService.updateRecord(
            'user',
            { googleId: profile.id },
            { id: user.id }, // use user_id if your schema uses that
          );
        }
        logger.log(`GoogleStrategy user: ${user.id}`);
        done(null, user);
      } catch (error) {
        logger.error(`Google auth error: ${error}`);
        done(error as Error);
      }
    },
  ),
);

/** Facebook Strategy
 * This strategy is used to authenticate users using their Facebook account.
 * It requires a client ID, client secret, and callback URL.
 * The callback function receives the profile and calls `done` to pass the user to the next middleware.
 * If the user does not exist, a new user is created.
 * If the user exists but has a different email, the email is updated.
 * If an error occurs, it is passed to `done`.
 */
passport.use(
  new FacebookStrategy(
    {
      clientID: env.FACEBOOK_CLIENT_ID || '',
      clientSecret: env.FACEBOOK_CLIENT_SECRET || '',
      callbackURL: env.FACEBOOK_CALLBACK_URL,
      profileFields: ['id', 'emails', 'name'],
    },
    async (_accessToken, _refreshToken, profile, done) => {
      const email = profile.emails?.[0]?.value?.toLowerCase() || '';

      try {
        // 1️⃣ Check user by Facebook ID
        let user = await prismaService.getRecord('user', {
          where: { facebookId: profile.id },
        });

        // 2️⃣ If not found, optionally check by email (avoid duplicate accounts)
        if (!user && email) {
          user = await prismaService.getRecord('user', {
            where: { email },
          });
        }

        // 3️⃣ Create new user if still not found
        if (!user) {
          user = await prismaService.createRecord('user', {
            facebookId: profile.id,
            email,
            firstName: profile.name?.givenName || '',
            lastName: profile.name?.familyName || '',
            role: Role.User, // default role
            status: UserStatus.Active,
          });
        }

        return done(null, user);
      } catch (error) {
        logger.error(`Facebook auth error: ${error}`);
        done(error as Error);
      }
    },
  ),
);

/** Serialize and Deserialize User
 * The user ID is serialized to the session and deserialized when subsequent requests are made.
 * This allows the user to be retrieved from the database and used in the request.
 */
passport.serializeUser((user, done) => {
  const userId = (user as IUser).id;
  logger.log(`Serialized user ID: ${userId}`);
  done(null, userId);
});

/** Deserialize User
 * The user ID is deserialized from the session and used to retrieve the user from the database.
 * This allows the user to be retrieved from the database and used in the request.
 */
passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await prismaService.getRecord('user', {
      where: { id: Number(id) }, // use user_id if that's your PK
    });

    if (!user) {
      throw new Error(ssoMessages.USER_FOUND_DURING_DESERIALIZE);
    }

    done(null, user);
  } catch (error) {
    logger.error(`Deserialization error: ${error}`);
    done(error);
  }
});

/**
 * Generates random data for a SSO schema based on the provided type.
 * @param {string} type - The type of SSO schema to generate data for.
 * @returns {Record<string, unknown>} - The random data for the SSO schema.
 * @throws {Error} If the type is not supported.
 */
export const ssoRandomData = (type: string) => {
  switch (type) {
    case 'ssoSchema':
      return {
        id: { type: 'string', example: faker.string.uuid() },
        name: { type: 'string', example: faker.person.fullName() },
        email: { type: 'string', example: faker.internet.email() },
        createdAt: { type: 'string', example: faker.date.past() },
        updatedAt: { type: 'string', example: faker.date.recent() },
      };

    case 'ssoLoginRequest':
      return {
        strategy: {
          type: 'string',
          enum: [Strategy.Google, Strategy.Facebook],
          example: Strategy.Google,
        },
      };
    case 'ssoUserResponse':
      return {
        token: { type: 'string', example: faker.string.uuid() },
        message: { type: 'string', example: ssoMessages.SSO_LOGIN_SUCCESS },
      };
    default:
      throw new Error(`Unsupported type: ${type}`);
  }
};
