import * as crypto from 'node:crypto';
import env from '@config/envVar';
import { logger } from '@config/logger';
import { twoFAMessages, twoFAVariables } from '@constants';
import type { IAppSecret, IRecoveryCode } from '@customTypes';
//Third-party modules
import { TwoFAMethod, TwoFAFlow } from '@enums';
import { faker } from '@faker-js/faker';
import * as qrcode from 'qrcode';
import * as speakeasy from 'speakeasy';
// third party api
import { Twilio } from 'twilio';
import { defaultRole, roles } from '@config/role';

// Twilio Credentials
const accountSid = env.TWILIO_ACCOUNT_SID; // Replace with your Twilio Account SID
const authToken = env.TWILIO_AUTH_TOKEN; // Replace with your Twilio Auth Token
// Verification Service SID
const serviceSid = env.TWILIO_SERVICE_SID;
const client = new Twilio(accountSid, authToken);
/**
 * Generates random data for a twoFactorAuth schema based on the provided type.
 * @param {string} type - The type of twoFactorAuth schema to generate data for.
 * @returns {Record<string, unknown>} - The random data for the twoFactorAuth schema.
 * @throws {Error} If the type is not supported.
 */
export const twoFactorAuthRandomData = (type: string) => {
  switch (type) {
    case 'activeTwoFactorAuthRequest':
      return {
        email: { type: 'string', example: faker.internet.email() },
        password: { type: 'string', example: faker.internet.password() },
        isTwoAuthEnabled: { type: 'boolean', example: 'true' },
        twoFAMethodType: { type: 'string', example: TwoFAMethod.EMAIL },
      };
    case 'sendEmailRequest':
      return {
        email: { type: 'string', example: faker.internet.email() },
        password: { type: 'string', example: faker.internet.password() },
        phoneNumber: { type: 'string', example: '769386759' },
        twoFAMethodType: { type: 'string', example: TwoFAMethod.EMAIL },
        twoFAFlow: { type: 'string', example: TwoFAFlow.SETUP },
      };
    case 'sendPhoneRequest':
      return {
        phone: { type: 'string', example: faker.internet.email() },
        password: { type: 'string', example: faker.internet.password() },
      };
    case 'sendAppRequest':
      return {
        email: { type: 'string', example: faker.internet.email() },
      };
    case 'verifyOtpRequest':
      return {
        email: { type: 'string', example: faker.internet.email() },
        otp: { type: 'string', example: 123456 },
        twoFAMethodType: { type: 'string', example: TwoFAMethod.EMAIL },
        twoFAFlow: { type: 'string', example: TwoFAFlow.SETUP },
      };
    case 'verifyOtpResponse':
      return {
        token: { type: 'string', example: faker.internet.jwt() },
        role: { type: 'integer', example: defaultRole, enum: roles },
      };
    case 'verifyCodeRequest':
      return {
        email: { type: 'string', example: faker.internet.email() },
        code: { type: 'string', example: '4DD2D217' },
      };
    case 'updatePreferredTwoFaMethodRequest':
      return {
        email: { type: 'string', example: faker.internet.email() },
        preferredTwoFAMethod: { type: 'string', example: TwoFAMethod.EMAIL },
      };
    default:
      throw new Error(`Unsupported type: ${type}`);
  }
};

/**
 * Generates a custom OTP (One-Time Password).
 * @param {number} length - Length of the OTP to generate.
 * @param {string} charset - Characters allowed in the OTP (default: digits).
 * @description Generate a 6-digit numeric OTP
 * @returns {string} - The generated OTP.
 */
export const generateTwoFAEmailOTP = async (length: number, charset: string) => {
  if (length <= 0) {
    throw new Error('OTP length must be greater than zero.');
  }
  let otp = '';
  const charsetLength = charset.length;

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charsetLength);
    otp += charset[randomIndex];
  }
  return otp;
};

// Utility to Generate Recovery Codes
export const generateRecoveryCodes = async (): Promise<{
  plainCodes: string[];
  encryptedCodes: IRecoveryCode[];
}> => {
  const plainCodes: string[] = [];
  const encryptedCodes: IRecoveryCode[] = [];
  const RECOVERY_CODE_COUNT = Number(env.TWO_FA_RECOVERY_CODE_COUNT) || 10;
  for (let i = 0; i < RECOVERY_CODE_COUNT; i++) {
    const code = crypto.randomBytes(4).toString('hex').toUpperCase();
    plainCodes.push(code);
    encryptedCodes.push(encryptRecoveryCode(code));
  }
  return { plainCodes, encryptedCodes };
};

export const encryptRecoveryCode = (code: string) => {
  const iv = crypto.randomBytes(12);
  const SECRET_KEY = crypto.createHash('sha256').update(env.ENCRYPTION_SECRET_KEY_RECOVER_CODE).digest();
  const cipher = crypto.createCipheriv('aes-256-gcm', SECRET_KEY, iv);

  let encrypted = cipher.update(code, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  return {
    code: encrypted,
    iv: iv.toString('hex'),
    tag: cipher.getAuthTag().toString('hex'),
    used: false,
  };
};

export const decryptRecoveryCodes = async (codes: IRecoveryCode[]): Promise<string[]> => {
  const SECRET_KEY = crypto.createHash('sha256').update(env.ENCRYPTION_SECRET_KEY_RECOVER_CODE).digest();
  return codes.map(({ code, iv, tag }) => {
    const decipher = crypto.createDecipheriv('aes-256-gcm', SECRET_KEY, Buffer.from(iv, 'hex'));

    decipher.setAuthTag(Buffer.from(tag, 'hex'));

    let decrypted = decipher.update(code, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  });
};

/**
 * This method is for generate otp secret token for verify user
 *
 * @returns
 */
export const generateAppTokenSecret = async (email: string): Promise<any> => {
  const secret = speakeasy.generateSecret({
    name: `${env.AUTH_TOKEN_APP_NAME} (${email})`, //The application name
    length: twoFAVariables.TOKEN_LENGTH,
  });
  /** save secret token for verify user which MFA process */
  return secret;
};

/**
 * This method is for generate otpQR for verify user
 *
 * @returns
 */
export const generateAppQR = async (secretToken: IAppSecret): Promise<string> => {
  // Generate a QR code for the otpauth URL
  return qrcode.toDataURL(secretToken.otpauth_url);
};

/**
 * This method is use for  verify user with given code(otp) is correct or not
 *
 * @returns
 */
export const verifyAppOtp = async (otp: string, secret: IAppSecret): Promise<{ success: boolean; message: string }> => {
  try {
    const isVerifiedUser = speakeasy.totp.verify({
      secret: secret.base32,
      encoding: 'base32',
      token: otp,
      window: 1,
    });
    if (isVerifiedUser) {
      return { success: true, message: twoFAMessages.SUCCESS };
    }
    return { success: false, message: twoFAMessages.INVALID_OTP };
  } catch (err) {
    const error = err instanceof Error;
    logger.error(`Error in verifying app OTP: ${error}`);
    return { success: false, message: twoFAMessages.SOMETHING_WRONG };
  }
};

/**
 * Send SMS using Twilio
 * @param {string} to - Recipient phone number (e.g., +1234567890)
 * @param {string} channel - SMS channel
 * @returns {Promise} - Promise resolving the SMS response
 */
export const sendSmsToUser = async (to: string, channel: string) => {
  try {
    const verification = await client.verify.v2.services(serviceSid).verifications.create({ to, channel });
    logger.info(`SMS sent successfully: ${verification.sid}`);
    return verification;
  } catch (error) {
    logger.error(`Error sending SMS: ${error}`);
    throw error;
  }
};

/**
 * Verify SMS OTP
 * @param {string} to - Recipient phone number (e.g., +1234567890)
 * @param {string} code - OTP code to verify
 * @returns {Promise} - Promise resolving the verification result
 * @throws {Error} - If the OTP is invalid
 */
export const verifySmsOTP = async (to: string, code: string) => {
  try {
    const verificationCheck = await client.verify.v2.services(serviceSid).verificationChecks.create({ to, code });

    if (verificationCheck.status === 'approved') {
      return { success: true, message: twoFAMessages.SUCCESS };
    } else {
      return { success: false, message: twoFAMessages.INVALID_OTP };
    }
  } catch (error) {
    logger.error(`Error sending SMS: ${error}`);
    return { success: false, message: twoFAMessages.SOMETHING_WRONG };
  }
};

/**
 * Validates the phone number is in E.164 format
 * @param phoneNumber - Phone number to validate
 * @returns Boolean indicating if the phone number is valid
 */
export const isValidPhoneNumber = (phoneNumber: string): boolean => {
  const e164Regex = /^\+[1-9]\d{1,14}$/; // E.164 regex pattern
  return e164Regex.test(phoneNumber);
};

/**
 * Masks all digits of a number/string except the last 4 characters.
 *
 * @param value - Number or string to be masked
 * @returns Masked string with only last 4 characters visible
 *
 * Example:
 * maskNumber(4564564569089) => "xxxxxxxxx9089"
 */
export const maskNumber = (value: string | number): string => {
  const str: string = value.toString();
  // If length is 4 or less, return as-is (nothing to mask)
  if (str.length <= 4) {
    return str;
  }
  const maskedPart: string = 'x'.repeat(str.length - 4);
  const visiblePart: string = str.slice(-4);
  return maskedPart + visiblePart;
};

export const hashEmailOtp = (otp: string): string => {
  // As the ENCRYPTION_SECRET_KEY is used only in a couple of places and to avoid overhead
  // of maintaining separate keys for different modules we are using the same variable
  return crypto.createHmac('sha256', env.ENCRYPTION_SECRET_KEY).update(otp).digest('hex');
};

export const verifyEmailOtp = (inputOtp: string, storedHash: string): boolean => {
  if (storedHash?.length > 0) {
    const inputHash = hashEmailOtp(inputOtp);
    return crypto.timingSafeEqual(Buffer.from(inputHash), Buffer.from(storedHash));
  }
  return false;
};
