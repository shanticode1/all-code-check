import env from '@config/envVar';
import { logger } from '@config/logger';
import { commonVariables, emailTemplatesVariables, twoFAVariables } from '@constants';
import type { IEmailData, ITemplateData } from '@customTypes';
import nodemailer from 'nodemailer';
import fs from 'node:fs/promises';
import path from 'node:path';
import Handlebars from 'handlebars';
import { stripeHandler } from '@utils';
import { userCommonService } from '@services';
import Stripe from 'stripe';
import { commonHandler } from '@utils';
import { FRONTEND_RESET_PASSWORD_PATH, FRONTEND_SET_PASSWORD_PATH, FRONTEND_VERIFY_PATH } from '@config/paths';

/**
 * Create a transporter object using your SMTP provider details
 */
const transporter = nodemailer.createTransport({
  service: env.SMTP_MAIL_SERVICE,
  host: env.SMTP_HOST,
  port: Number(env.SMTP_PORT),
  secure: Boolean(env.SMTP_IS_SECURE),
  auth: {
    user: env.SMTP_SENDER_EMAIL,
    pass: env.SMTP_SENDER_PASSWORD,
  },
});

/**
 * Sends an email using the configured SMTP transporter.
 * @param {string} email - The recipient's email address.
 * @param {string} subject - The subject of the email.
 * @param {string} message - The HTML message to be sent in the email body.
 * @returns {Promise<{ success: boolean, data?: object, error?: any }>}
 *          An object indicating success status, with additional data or error information.
 */

export const sendEmail = async (
  email: string,
  subject: string,
  message: string,
  attachments?: Array<{
    filename: string;
    content: Buffer | string;
    contentType?: string;
  }>,
) => {
  try {
    const mailOptions: {
      from: string;
      to: string;
      subject: string;
      html: string;
      attachments?: Array<{
        filename: string;
        content: Buffer | string;
        contentType?: string;
      }>;
    } = {
      from: env.SMTP_SENDER_EMAIL,
      to: email,
      subject,
      html: message,
    };

    if (attachments && attachments.length > 0) {
      mailOptions.attachments = attachments.map((att) => ({
        filename: att.filename,
        content: att.content,
        contentType: att.contentType,
      }));
    }

    const info = await transporter.sendMail(mailOptions);

    return { success: true, data: info };
  } catch (error) {
    logger.error(`Error sending email: ${error}`);
    return { success: false, error };
  }
};

/**
 * Sends an email using a template slug and replacing placeholders with actual data values.
 * Currently supported templates are:
 * - forgot-password
 * - reset-password
 * - verify-email
 * - verify-otp
 *
 * @param {IEmailData} data - An object containing the email recipient, name, template slug, and additional data to replace placeholders.
 * @returns {Promise<boolean>} - A promise that resolves to true if the email is sent successfully, or false if an error occurs.
 */
export const sendEmailBySlug = async ({
  toEmail,
  toName,
  templateName,
  data,
  attachments,
}: IEmailData): Promise<boolean> => {
  try {
    let templateData: ITemplateData;

    switch (templateName) {
      case emailTemplatesVariables.emailTemplates[0].slug: {
        templateData = {
          name: toName,
          link: commonHandler.buildFrontendLink(FRONTEND_SET_PASSWORD_PATH as string, data?.token as string),
          expire: emailTemplatesVariables.RESET_TOKEN_EXPIRE, // Example default value
          unit: emailTemplatesVariables.RESET_TOKEN_UNIT, // Example default value
          plural: emailTemplatesVariables.RESET_TOKEN_EXPIRE > 1 ? 's' : '',
          projectName: commonVariables.PROJECT_NAME,
        };
        break;
      }
      case emailTemplatesVariables.emailTemplates[1].slug: {
        templateData = {
          name: toName,
          link: commonHandler.buildFrontendLink(FRONTEND_RESET_PASSWORD_PATH as string, data?.token as string),
          expire: emailTemplatesVariables.RESET_TOKEN_EXPIRE, // Example default value
          unit: emailTemplatesVariables.RESET_TOKEN_UNIT, // Example default value
          plural: emailTemplatesVariables.RESET_TOKEN_EXPIRE > 1 ? 's' : '',
          projectName: commonVariables.PROJECT_NAME,
        };
        break;
      }
      case emailTemplatesVariables.emailTemplates[2].slug: {
        templateData = {
          name: toName,
          link: commonHandler.buildFrontendLink(FRONTEND_VERIFY_PATH as string, data?.token as string),
          projectName: commonVariables.PROJECT_NAME,
        };

        break;
      }
      case emailTemplatesVariables.emailTemplates[3].slug: {
        templateData = {
          otp: data?.otp,
          otpValidTime: twoFAVariables.OTP_VALID_TIME,
          projectName: commonVariables.PROJECT_NAME,
        };
        break;
      }
      case emailTemplatesVariables.emailTemplates[4].slug: {
        templateData = {
          name: data?.name,
          email: data?.email,
        };

        break;
      }
      case emailTemplatesVariables.emailTemplates[8].slug: {
        templateData = {
          nameText: data?.name ? `, ${data.name}` : '',
          title: data?.title || '🎉 Your Subscription is Active!',
          greeting: data?.greeting || 'Thank you for subscribing!',
          planName: data?.planName || 'N/A',
          status: data?.status || 'Active',
          expiryLabel: data?.expiryLabel || 'Next Billing',
          expiryDate: data?.expiryDate || 'N/A',
          projectName: commonVariables.PROJECT_NAME,
          message:
            data?.message ||
            'You now have access to all features included in your plan. If you have any questions, please do not hesitate to contact our support team.',
        };
        break;
      }
      case emailTemplatesVariables.emailTemplates[9].slug: {
        templateData = {
          nameText: data?.name ? `, ${data.name}` : '',
          title: data?.title || 'Subscription Cancelled',
          message: data?.message || 'Your subscription has been cancelled.',
          expiryInfo: data?.expiryInfo || '',
          additionalMessage: data?.additionalMessage || '',
          projectName: commonVariables.PROJECT_NAME,
        };
        break;
      }
      case emailTemplatesVariables.emailTemplates[10].slug: {
        templateData = {
          nameText: data?.name ? `, ${data.name}` : '',
          planInfo: data?.planInfo || '',
          status: data?.status || 'Active',
          expiryDate: data?.expiryDate || 'N/A',
          name: data?.firstName,
          email: data?.email,
          projectName: commonVariables.PROJECT_NAME,
        };
        break;
      }
      case emailTemplatesVariables.emailTemplates[5].slug: {
        templateData = {
          name: data?.name,
          email: data?.email,
        };

        break;
      }
      case emailTemplatesVariables.emailTemplates[6].slug: {
        templateData = {
          isApproved: data?.isApproved,
          name: toName,
        };

        break;
      }
      case emailTemplatesVariables.emailTemplates[7].slug: {
        templateData = {
          name: data?.name,
          email: data?.email,
        };

        break;
      }
      default:
        throw new Error(`Unhandled email template slug: ${templateName}`);
    }
    // Resolve subject from metadata
    const meta = emailTemplatesVariables.emailTemplates.find((t) => t.slug === templateName);
    if (!meta) throw new Error(`Template metadata not found for slug: ${templateName}`);

    const possiblePaths = [
      path.resolve(process.cwd(), 'src', 'templates', 'emails', `${templateName}.hbs`),
      path.resolve(process.cwd(), 'dist', 'templates', 'emails', `${templateName}.hbs`),
    ];

    let emailContent = '';
    for (const p of possiblePaths) {
      try {
        // Load and compile the email template from src or dist, whichever exists
        const file = await fs.readFile(p, { encoding: 'utf8' });
        const compiled = Handlebars.compile(file);
        emailContent = compiled(templateData as Record<string, unknown>);
        break;
      } catch (_err) {
        // ignore
      }
    }

    if (!emailContent) {
      throw new Error(`Template file not found for slug: ${templateName}`);
    }
    const emailResult = await sendEmail(toEmail, meta.subject, emailContent, attachments);

    return emailResult.success;
  } catch (error) {
    logger.error(`Error sending email by slug: ${error}`);
    return false;
  }
};

/**
 * Sends subscription-related emails asynchronously using email templates
 * This function doesn't block webhook processing
 * @param stripe - Stripe instance
 * @param userId - User ID (optional)
 * @param customerId - Stripe customer ID (optional)
 * @param customerEmail - Customer email from Stripe (optional)
 * @param templateSlug - Email template slug
 * @param templateData - Template data for placeholders
 * @param subscriptionId - Stripe subscription ID (optional, for invoice attachment)
 */
export const sendSubscriptionEmailAsync = (
  stripe: Stripe,
  userId?: string,
  customerId?: string,
  customerEmail?: string,
  templateSlug = emailTemplatesVariables.emailTemplates[10].slug,
  templateData?: Record<string, any>,
  subscriptionId?: string,
): void => {
  // Use setImmediate to ensure it runs asynchronously without blocking
  setImmediate(async () => {
    try {
      let userEmail: string | undefined;
      let userName: string | undefined;

      // Try to get user email from database first
      if (userId) {
        try {
          const user = await userCommonService.getUserById(Number(userId));
          if (user) {
            userEmail = user.email;
            userName = user.firstName || user.name;
          }
        } catch (error) {
          logger.warn(`Error fetching user ${userId} for email: ${error}`);
        }
      }

      // Fallback to Stripe customer email if user not found
      if (!userEmail && customerId) {
        try {
          const customer = await stripe.customers.retrieve(customerId);
          if (customer && !customer.deleted && typeof customer === 'object' && 'email' in customer) {
            userEmail = (customer as Stripe.Customer).email || undefined;
            userName = (customer as Stripe.Customer).name || undefined;
          }
        } catch (error) {
          logger.warn(`Error fetching customer ${customerId} for email: ${error}`);
        }
      }

      // Last fallback to provided customerEmail
      if (!userEmail && customerEmail) {
        userEmail = customerEmail;
      }

      // Send email if we have an email address
      if (userEmail) {
        // Add name to template data if available
        const finalTemplateData = {
          ...templateData,
          name: userName,
        };

        // Fetch invoice PDF for subscription-created emails
        let attachments:
          | Array<{
              filename: string;
              content: Buffer | string;
              contentType?: string;
            }>
          | undefined;

        if (templateSlug === emailTemplatesVariables.emailTemplates[8].slug && subscriptionId) {
          try {
            const invoicePdf = await stripeHandler.fetchSubscriptionInvoicePdf(stripe, subscriptionId);
            if (invoicePdf) {
              attachments = [
                {
                  filename: `invoice-${subscriptionId}.pdf`,
                  content: invoicePdf,
                  contentType: 'application/pdf',
                },
              ];
              logger.info(`Invoice PDF attached for subscription ${subscriptionId}`);
            } else {
              logger.warn(`Could not fetch invoice PDF for subscription ${subscriptionId}`);
            }
          } catch (error) {
            logger.error(`Error fetching invoice PDF for subscription ${subscriptionId}: ${error}`);
            // Continue without attachment if PDF fetch fails
          }
        }

        const emailSent = await sendEmailBySlug({
          toEmail: userEmail,
          toName: userName || 'Valued Customer',
          templateName: templateSlug,
          data: finalTemplateData || {},
          attachments,
        });

        if (emailSent) {
          logger.info(`Subscription email sent successfully to ${userEmail} using template: ${templateSlug}`);
        } else {
          logger.error(`Failed to send subscription email to ${userEmail} using template: ${templateSlug}`);
        }
      } else {
        logger.warn(`No email address found for userId=${userId || 'N/A'}, customerId=${customerId || 'N/A'}`);
      }
    } catch (error) {
      logger.error(`Error sending subscription email asynchronously: ${error}`);
      // Don't throw - email failures shouldn't break webhook processing
    }
  });
};
