//Third-party modules
import type { Response } from 'express';
import jwt from 'jsonwebtoken';

//Config
import env from '@config/envVar';

//Constants
import { authVariables, commonVariables } from '@constants';
//Utils
import { commonHandler } from '@utils';
import { Tokens } from '@customTypes';

export const clearToken = (res: Response) => {
  res.cookie(env.AUTH_COOKIE_NAME, '', {
    httpOnly: true,
    expires: new Date(0),
  });
};

/**
 * Generates an authentication token and sets it as a cookie in the response.
 * @param {Response} res - The response object
 * @param {object} payload - The payload to be signed in the token
 * @returns {Promise<string>} - The generated token
 */
export const generateAuthToken = async (res: Response, payload: object): Promise<string> => {
  const jwtSecret = env.JWT_SECRET;
  const expireIn = await commonHandler.convertTime(
    Number(commonVariables.TOKEN_EXPIRE),
    String(commonVariables.TOKEN_EXPIRE_UNIT),
    commonVariables.MILLISECOND, //Supported units: year, month, day, hour, minute, second, millisecond.
  );

  const token = jwt.sign(payload, jwtSecret as string, {
    expiresIn: commonVariables.JWT_TOKEN_EXPIRE,
  });

  res.cookie(env.AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    secure: !commonHandler.isLogger,
    sameSite: commonVariables.COOKIE_SAME_SITE,
    maxAge: expireIn,
  });
  return token;
};

/**
 * Generates an authentication token and sets it as a cookie in the FastifyReply.
 * @param {FastifyReply} res - The FastifyReply object
 * @param {object} payload - The payload to be signed in the token
 * @returns {Promise<string>} - The generated token
 */
export const generateAuthTokenV2 = async (res: Response, payload: object): Promise<Tokens> => {
  // --- Access token ---
  const accessToken = jwt.sign(payload, env.JWT_SECRET!, {
    expiresIn: authVariables.ACCESS_TOKEN_EXPIRESIN, // e.g., "15m"
  });

  // Optional: set cookie
  const accessExpireMs = await commonHandler.convertTime(
    Number(authVariables.ACCESS_TOKEN_EXPIRE),
    authVariables.ACCESS_TOKEN_EXPIRE_UNIT,
    commonVariables.MILLISECOND,
  );

  res.cookie(env.ACCESS_COOKIE_NAME, accessToken, {
    httpOnly: true,
    secure: !commonHandler.isLogger,
    sameSite: commonVariables.COOKIE_SAME_SITE,
    maxAge: accessExpireMs,
  });

  // --- Refresh token ---
  const refreshToken = jwt.sign({ ...payload, isRefreshToken: true }, env.JWT_REFRESH_SECRET!, {
    expiresIn: authVariables.REFRESH_TOKEN_EXPIRESIN, // e.g., "30d"
  });

  const refreshExpireMs = await commonHandler.convertTime(
    Number(authVariables.REFRESH_TOKEN_EXPIRE),
    authVariables.REFRESH_TOKEN_EXPIRE_UNIT,
    commonVariables.MILLISECOND,
  );

  res.cookie(env.REFRESH_COOKIE_NAME, refreshToken, {
    httpOnly: true,
    secure: !commonHandler.isLogger,
    sameSite: commonVariables.COOKIE_SAME_SITE,
    maxAge: refreshExpireMs,
  });

  return new Tokens(accessToken, refreshToken);
};
