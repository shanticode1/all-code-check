import { logger } from '@config/logger';
import { paymentVariables } from '@constants';
import type { IFeatureEntitlement } from '@customTypes';
// import { planEntitlementService } from '@services';
import type Stripe from 'stripe';
import http from 'node:http';
import https from 'node:https';
import { URL } from 'node:url';
import { planEntitlementService } from '@services';

const {
  BILLING_INTERVAL_MONTH,
  BILLING_INTERVAL_YEAR,
  INTERVAL_TEXT_MONTHLY,
  INTERVAL_TEXT_YEARLY,
  DEFAULT_PRODUCT_NAME,
  METADATA_KEY_PLAN_NAME,
  METADATA_KEY_PRODUCT_NAME,
  METADATA_KEY_FEATURES,
  METADATA_KEY_IMAGE,
  METADATA_KEY_USER_ID,
  STRIPE_FIELD_METADATA,
  ENTITLEMENT_LIMIT_UNLIMITED,
  ENTITLEMENT_RESET_PERIOD_MONTHLY,
} = paymentVariables;

/**
 * Parses features string from metadata into an array
 * Supports JSON array format or comma-separated string
 */
export const parseFeatures = (features: string): string[] => {
  if (!features) return [];

  try {
    const parsed = JSON.parse(features);
    return Array.isArray(parsed) ? parsed : [features];
  } catch {
    const cleaned = features.trim().replace(/^\[|\]$/g, '');
    if (cleaned.includes(',')) {
      return cleaned
        .split(',')
        .map((f) => f.trim().replace(/^["']|["']$/g, ''))
        .filter((f) => f.length > 0);
    }
    return [features];
  }
};

/**
 * Fetches price details and extracts metadata
 * @param stripe - Stripe instance
 * @param priceId - Stripe Price ID
 */
export const fetchPriceDetails = async (stripe: Stripe, priceId: string) => {
  try {
    const priceDetails = await stripe.prices.retrieve(priceId);
    const metadata = priceDetails[STRIPE_FIELD_METADATA] || {};

    return {
      priceDetails,
      productName: metadata[METADATA_KEY_PLAN_NAME] || metadata[METADATA_KEY_PRODUCT_NAME] || DEFAULT_PRODUCT_NAME,
      features: metadata[METADATA_KEY_FEATURES] || '',
      imageUrl: metadata[METADATA_KEY_IMAGE] || '',
      billingInterval: priceDetails.recurring?.interval || BILLING_INTERVAL_MONTH,
      intervalText:
        priceDetails.recurring?.interval === BILLING_INTERVAL_YEAR ? INTERVAL_TEXT_YEARLY : INTERVAL_TEXT_MONTHLY,
    };
  } catch (error) {
    logger.warn(`Failed to fetch price details: ${error}`);
    return null;
  }
};

/**
 * Builds product description with features
 */
export const buildProductDescription = (productName: string, intervalText: string, featuresList: string[]): string => {
  let description = `${productName} - ${intervalText}`;
  if (featuresList.length > 0) {
    const featuresText = featuresList.map((f) => `• ${f}`).join('  •  ');
    description = `${productName} - ${intervalText}\n\nIncludes:\n${featuresText}`;
  }
  return description;
};

/**
 * Builds line items for checkout session
 */
export const buildLineItems = (
  priceId: string,
  _priceDetails: Stripe.Price | null,
  _productName: string,
  _productDescription: string,
  _imageUrl: string,
  _currency: string,
  quantity: number,
): Stripe.Checkout.SessionCreateParams.LineItem[] => {
  return [{ price: priceId, quantity }];
};

/**
 * Updates customer information with name, email, and userId metadata
 */
export const updateCustomerForCompliance = async (
  stripe: Stripe,
  customerId: string,
  customerName: string | undefined,
  customerEmail: string | undefined,
  userId: string | undefined,
  defaultCustomerName: string,
): Promise<void> => {
  try {
    const customerData = await stripe.customers.retrieve(customerId);
    if (!customerData || customerData.deleted) return;

    const cust = customerData as Stripe.Customer;
    const updateData: Stripe.CustomerUpdateParams = {};

    // Update name if missing or different
    if (!cust.name || (customerName && cust.name !== customerName)) {
      updateData.name = customerName || customerEmail?.split('@')[0] || defaultCustomerName;
    }

    // Update email if missing
    if (customerEmail && !cust.email) {
      updateData.email = customerEmail;
    }

    // Add userId to metadata if missing
    if (userId && (!cust[STRIPE_FIELD_METADATA] || !cust[STRIPE_FIELD_METADATA][METADATA_KEY_USER_ID])) {
      updateData[STRIPE_FIELD_METADATA] = {
        ...cust[STRIPE_FIELD_METADATA],
        [METADATA_KEY_USER_ID]: userId,
      };
    }

    if (Object.keys(updateData).length > 0) {
      await stripe.customers.update(customerId, updateData);
      logger.info(`Updated customer ${customerId} information`);
    }
  } catch (err) {
    logger.error(`Failed to update customer info: ${err}`);
  }
};

/**
 * Converts plan entitlements to user subscription entitlements format
 * @param planEntitlements - Array of plan entitlements
 * @returns Array of user subscription entitlements with default values
 */
export const convertPlanEntitlementsToUserEntitlements = (
  planEntitlements: Array<{
    featureId: string;
    featureValue: string;
    type: 'boolean' | 'numeric' | 'unlimited';
    limit: number | 'unlimited' | boolean;
    unit?: string;
  }>,
): IFeatureEntitlement[] => {
  return planEntitlements.map((ent): IFeatureEntitlement => {
    // Convert limit: handle boolean, 'unlimited', and number cases
    let limit: number | 'unlimited';
    if (ent.limit === ENTITLEMENT_LIMIT_UNLIMITED) {
      limit = ENTITLEMENT_LIMIT_UNLIMITED;
    } else if (typeof ent.limit === 'boolean') {
      // For boolean features, true means unlimited, false means 0
      limit = ent.limit ? ENTITLEMENT_LIMIT_UNLIMITED : 0;
    } else {
      limit = ent.limit;
    }

    return {
      featureId: ent.featureId,
      featureValue: ent.featureValue,
      type: ent.type,
      limit,
      currentUsage: 0,
      unit: ent.unit,
      resetPeriod: ENTITLEMENT_RESET_PERIOD_MONTHLY,
      lastReset: new Date(),
    };
  });
};

/**
 * Fetches entitlements for a plan and converts them to user subscription format
 * @param planId - The Stripe price ID
 * @returns Array of user subscription entitlements or empty array if not found
 */
// export const fetchAndConvertPlanEntitlements = async (planId: string): Promise<IFeatureEntitlement[]> => {
//   try {
//     const result = await planEntitlementService.getPlanEntitlementsByPriceId(planId);
//     if (result.success && result.data && result.data.entitlements) {
//       return convertPlanEntitlementsToUserEntitlements(result.data.entitlements);
//     }
//     logger.warn(`No entitlements found for plan ${planId}`);
//     return [];
//   } catch (error) {
//     logger.error(`Error fetching entitlements for plan ${planId}: ${error}`);
//     return [];
//   }
// };

/**
 * Fetches the latest invoice PDF for a subscription
 * @param stripe - Stripe instance
 * @param subscriptionId - The Stripe subscription ID
 * @returns Promise<Buffer | null> - The invoice PDF as a Buffer, or null if not found/error
 */
export const fetchSubscriptionInvoicePdf = async (stripe: Stripe, subscriptionId: string): Promise<Buffer | null> => {
  try {
    // Get the latest invoice for this subscription
    const invoices = await stripe.invoices.list({
      subscription: subscriptionId,
      limit: 1,
    });

    if (!invoices.data || invoices.data.length === 0) {
      logger.warn(`No invoices found for subscription ${subscriptionId}`);
      return null;
    }

    const invoice = invoices.data[0];

    // Check if invoice has a PDF
    if (!invoice.invoice_pdf) {
      logger.warn(`Invoice ${invoice.id} does not have a PDF available`);
      return null;
    }

    // Download the PDF from Stripe (handles redirects)
    const pdfUrl = invoice.invoice_pdf;

    const downloadPdf = (url: string, maxRedirects = 5): Promise<Buffer> => {
      return new Promise((resolve, reject) => {
        if (maxRedirects <= 0) {
          reject(new Error('Too many redirects'));
          return;
        }

        const urlObj = new URL(url);
        const client = urlObj.protocol === 'https:' ? https : http;

        client
          .get(url, (response) => {
            // Handle redirects
            if (
              response.statusCode &&
              (response.statusCode === 301 ||
                response.statusCode === 302 ||
                response.statusCode === 303 ||
                response.statusCode === 307 ||
                response.statusCode === 308)
            ) {
              const redirectUrl = response.headers.location;
              if (!redirectUrl) {
                reject(new Error('Redirect location not found'));
                return;
              }
              // Resolve relative URLs
              const absoluteUrl = redirectUrl.startsWith('http') ? redirectUrl : new URL(redirectUrl, url).toString();
              // Follow redirect
              downloadPdf(absoluteUrl, maxRedirects - 1)
                .then(resolve)
                .catch(reject);
              return;
            }

            // Handle successful response
            if (response.statusCode !== 200) {
              reject(new Error(`Failed to download invoice PDF: ${response.statusCode}`));
              return;
            }

            const chunks: Buffer[] = [];
            response.on('data', (chunk: Buffer) => {
              chunks.push(chunk);
            });

            response.on('end', () => {
              resolve(Buffer.concat(chunks));
            });

            response.on('error', (error) => {
              reject(error);
            });
          })
          .on('error', (error) => {
            reject(error);
          });
      });
    };

    return downloadPdf(pdfUrl);
  } catch (error) {
    logger.error(`Error fetching invoice PDF for subscription ${subscriptionId}: ${error}`);
    return null;
  }
};

/**
 * Fetches entitlements for a plan and converts them to user subscription format
 * @param planId - The Stripe price ID
 * @returns Array of user subscription entitlements or empty array if not found
 */
export const fetchAndConvertPlanEntitlements = async (planId: string): Promise<IFeatureEntitlement[]> => {
  try {
    const result = await planEntitlementService.getPlanEntitlementsByPriceId(planId);
    if (result.success && result.data && result.data.entitlements) {
      return convertPlanEntitlementsToUserEntitlements(result.data.entitlements);
    }
    logger.warn(`No entitlements found for plan ${planId}`);
    return [];
  } catch (error) {
    logger.error(`Error fetching entitlements for plan ${planId}: ${error}`);
    return [];
  }
};
