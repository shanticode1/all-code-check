import { supportMessages } from '@constants';
import { faker } from '@faker-js/faker';

/**
 * Generates random data for Support Config schema based on the provided type.
 * @param {string} type - The type of support schema to generate data for.
 * @returns {Record<string, unknown>} - The random data for the support schema.
 * @throws {Error} If the type is not supported.
 */
export const supportRandomData = (type: string) => {
  switch (type) {
    case 'supportCreateRequest':
      return {
        emailSettings: {
          type: 'object',
          example: {
            primaryEmail: faker.internet.email(),
            ccEmails: [faker.internet.email(), faker.internet.email()],
          },
        },
        formConfig: {
          type: 'object',
          example: {
            enabled: true,
            fields: [
              {
                key: 'fullName',
                enabled: true,
                required: true,
              },
              {
                key: 'email',
                enabled: true,
                required: true,
              },
              {
                key: 'subject',
                enabled: true,
                required: false,
              },
              {
                key: 'message',
                enabled: true,
                required: true,
              },
            ],
          },
        },
        autoReply: {
          type: 'object',
          example: {
            enabled: true,
            message: faker.lorem.sentence(),
          },
        },
        createdAt: {
          type: 'string',
          example: faker.date.past().toISOString(),
        },
        updatedAt: {
          type: 'string',
          example: faker.date.recent().toISOString(),
        },
      };
    case 'supportTicketStatusUpdateRequest':
      return {
        status: {
          type: 'string',
          example: 'IN_PROGRESS',
        },
      };
    case 'categoryRequest':
      return {
        name: {
          type: 'string',
          example: faker.commerce.department(),
        },
        description: {
          type: 'string',
          example: faker.lorem.sentence(),
        },
      };
    case 'categoryListResponse':
      return {
        message: { type: 'string', example: supportMessages.GET_CATEGORY_LIST },
      };
    case 'categoryAddedResponse':
      return {
        message: { type: 'string', example: supportMessages.ADD_CATEGORY },
      };
    case 'ticketRequest':
      return {
        fullName: {
          type: 'string',
          example: faker.lorem.sentence(),
        },
        email: {
          type: 'string',
          example: faker.internet.email(),
        },
        title: {
          type: 'string',
          example: faker.lorem.sentence(),
        },
        subject: {
          type: 'string',
          example: faker.lorem.sentence(),
        },
        description: {
          type: 'string',
          example: faker.lorem.paragraph(),
        },
        message: {
          type: 'string',
          example: faker.lorem.sentence(),
        },
        category: {
          type: 'string',
          example: '6943d9300b52a6dc62503287',
        },
        priority: {
          type: 'string',
          example: 'HIGH',
        },
        attachments: { type: 'string', format: 'binary', example: faker.system.fileName() },
      };
    case 'supportTicketDetailsResponse':
      return {
        message: { type: 'string', example: supportMessages.TICKET_FETCH_SUCCESS },
      };
    case 'ticketChatRequest':
      return {
        message: {
          type: 'string',
          example: faker.lorem.sentence(),
        },
      };

    default:
      throw new Error(`Unsupported type: ${type}`);
  }
};
