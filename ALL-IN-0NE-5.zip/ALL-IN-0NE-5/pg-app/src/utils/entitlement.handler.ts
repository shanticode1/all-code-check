import type { IFeatureEntitlement } from '@customTypes';
import { paymentVariables } from '@constants';

const { ENTITLEMENT_LIMIT_UNLIMITED } = paymentVariables;

/**
 * Check if a limit is unlimited
 */
export const isUnlimited = (
  limit: number | typeof ENTITLEMENT_LIMIT_UNLIMITED | boolean | null | undefined,
): boolean => {
  return limit === ENTITLEMENT_LIMIT_UNLIMITED || limit === true;
};

/**
 * Check if usage is within limit
 */
export const isWithinLimit = (
  currentUsage: number,
  limit: number | typeof ENTITLEMENT_LIMIT_UNLIMITED | boolean,
): boolean => {
  if (isUnlimited(limit)) return true;
  if (typeof limit === 'boolean') return limit;
  if (typeof limit === 'number') {
    return currentUsage < limit;
  }
  return false;
};

/**
 * Find entitlement by feature value in an array
 */
export const findEntitlementByFeatureValue = (
  entitlements: IFeatureEntitlement[],
  featureValue: string,
): IFeatureEntitlement | undefined => {
  return entitlements.find((ent) => ent.featureValue === featureValue);
};

/**
 * Check if user has access to a feature (from entitlements array)
 */
export const hasFeatureAccess = (entitlements: IFeatureEntitlement[], featureValue: string): boolean => {
  return entitlements.some((ent) => ent.featureValue === featureValue);
};

/**
 * Get feature limit from entitlements array
 */
export const getLimitFromEntitlements = (
  entitlements: IFeatureEntitlement[],
  featureValue: string,
): number | 'unlimited' | null => {
  const entitlement = findEntitlementByFeatureValue(entitlements, featureValue);
  return entitlement?.limit ?? null;
};

/**
 * Check if user can use a feature based on current usage and limit
 */
export const canUseFeatureFromEntitlements = (entitlements: IFeatureEntitlement[], featureValue: string): boolean => {
  const entitlement = findEntitlementByFeatureValue(entitlements, featureValue);
  if (!entitlement) return false;
  if (isUnlimited(entitlement.limit)) return true;
  const currentUsage = entitlement.currentUsage || 0;
  return isWithinLimit(currentUsage, entitlement.limit);
};

/**
 * Get current usage from entitlements array
 */
export const getCurrentUsageFromEntitlements = (
  entitlements: IFeatureEntitlement[],
  featureValue: string,
): { current: number; limit: number | typeof ENTITLEMENT_LIMIT_UNLIMITED } | null => {
  const entitlement = findEntitlementByFeatureValue(entitlements, featureValue);
  if (!entitlement) return null;

  return {
    current: entitlement.currentUsage || 0,
    limit: entitlement.limit,
  };
};
