import type { IFeature } from '@customTypes';

/**
 * Helper function to format feature documents
 */
export const featureModelToDomain = (featureDoc: IFeature) => {
  return {
    id: featureDoc.id?.toString() || '',
    value: featureDoc.value,
    label: featureDoc.label,
    type: featureDoc.type,
    unit: featureDoc.unit,
    position: featureDoc.position,
    isCore: featureDoc.isCore,
    isActive: featureDoc.isActive,
    createdAt: featureDoc.createdAt,
    updatedAt: featureDoc.updatedAt,
  };
};
