// Enum for TwoFA methods
export enum TwoFAMethod {
  EMAIL = 'email',
  PHONE = 'phone',
  APP = 'app',
}

export enum TwoFAFlow {
  SETUP = 'setup',
  VERIFY = 'verify',
}
