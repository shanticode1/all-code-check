export enum FeatureType {
  BOOLEAN = 'boolean',
  NUMERIC = 'numeric',
  UNLIMITED = 'unlimited',
}
