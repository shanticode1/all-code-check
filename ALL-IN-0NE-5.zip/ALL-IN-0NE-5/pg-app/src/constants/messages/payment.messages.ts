// webhook
export const WEBHOOK_CALL = 'Webhook calling.';
// product
export const CREATE_PRODUCT = 'Product created successfully.';
export const GET_PRODUCT = 'Your product has been successfully fetched.';
export const GET_PRODUCT_LIST = 'Successfully fetched the list of products.';
export const UPDATE_PRODUCT = 'Product updated successfully.';
export const DELETE_PRODUCT = 'Product deleted successfully.';
export const PRODUCT_NOT_FOUND = 'Product not found.';

// plan
export const CREATE_PLAN = 'Plan created successfully.';
export const GET_PLAN = 'Your plan has been successfully fetched.';
export const GET_PLAN_LIST = 'Successfully fetched the list of plans.';
export const UPDATE_PLAN = 'Plan updated successfully.';
export const DELETE_PLAN = 'Plan deleted successfully.';
export const PLAN_NOT_FOUND = 'Plan not found.';

// customer
export const CREATE_CUSTOMER = 'Customer created successfully.';
export const GET_CUSTOMER = 'Customer has been successfully fetched.';
export const UPDATE_CUSTOMER = 'Customer updated successfully.';
export const DELETE_CUSTOMER = 'Customer deleted successfully.';
export const CUSTOMER_NOT_FOUND = 'Customer not found.';

// Subscription
export const CREATE_SUBSCRIPTION = 'Subscription created successfully.';
export const GET_SUBSCRIPTION = 'Your subscription has been successfully fetched.';
export const UPDATE_SUBSCRIPTION = 'Subscription updated successfully.';
export const DELETE_SUBSCRIPTION = 'Subscription deleted successfully.';
export const SUBSCRIPTION_NOT_FOUND = 'Subscription not found.';
export const INVALID_USER_ID = 'Invalid user ID.';

// one time payment
export const ONE_TIME_PAYMENT = 'One time Payment session created successfully.';

// saved cards
export const CREATE_SETUP_INTENT = 'Setup intent created successfully.';
export const SAVE_CARD = 'Card saved successfully.';
export const LIST_SAVED_CARDS = 'Saved cards fetched successfully.';
export const DELETE_SAVED_CARD = 'Saved card deleted successfully.';
export const SAVED_CARD_NOT_FOUND = 'Saved card not found.';
export const DUPLICATE_CARD = 'This card has already been saved.';

// validation errors
export const USAGE_TYPE_REQUIRED = 'Provide usageType.';
export const SUCCESS_URL_AND_CANCEL_URL_REQUIRED = 'successUrl and cancelUrl are required in options.';
export const RETURN_URL_REQUIRED = 'returnUrl is required.';
export const CUSTOMER_EMAIL_REQUIRED = 'Customer email is required to create subscription.';
export const COULD_NOT_CREATE_OR_FIND_CUSTOMER = 'Could not create or find customer for Setup Intent.';
export const FAILED_TO_CREATE_SETUP_INTENT = 'Failed to create setup intent: missing client secret.';
export const FAILED_TO_CREATE_CUSTOMER_PORTAL_SESSION = 'Failed to create customer portal session: missing URL.';

// Subscription email content (sendSubscriptionEmailAsync)
export const SUBSCRIPTION_EMAIL_TRIAL_STARTED_TITLE = '🎉 Your Free Trial Has Started!';
export const SUBSCRIPTION_EMAIL_TRIAL_STARTED_GREETING = 'Great news! Your free trial has started.';
export const SUBSCRIPTION_EMAIL_ACTIVE_TITLE = '🎉 Your Subscription is Active!';
export const SUBSCRIPTION_EMAIL_ACTIVE_GREETING = 'Thank you for subscribing!';
export const SUBSCRIPTION_EMAIL_ACTIVE_MESSAGE =
  'You now have access to all features included in your plan. If you have any questions, please do not hesitate to contact our support team.';
export const SUBSCRIPTION_EMAIL_CANCELLED_TITLE = 'Subscription Cancelled';
export const SUBSCRIPTION_EMAIL_CANCELLED_MESSAGE = 'Your subscription has been cancelled.';
export const SUBSCRIPTION_EMAIL_CANCELLATION_SCHEDULED_TITLE = 'Subscription Cancellation Scheduled';
export const SUBSCRIPTION_EMAIL_CANCELLATION_SCHEDULED_MESSAGE = 'Your subscription will remain active until';
export const SUBSCRIPTION_EMAIL_END_OF_BILLING_PERIOD = 'the end of the billing period';
export const SUBSCRIPTION_EMAIL_DELETED_MESSAGE =
  'Your subscription has been cancelled and you no longer have access to premium features.';
export const SUBSCRIPTION_EMAIL_DELETED_ADDITIONAL_MESSAGE =
  'We are sorry to see you go! If you have any feedback or would like to reactivate your subscription, please contact our support team.';
