import {
  FEATURE_VALUE_MIN_LENGTH,
  FEATURE_VALUE_MAX_LENGTH,
  FEATURE_LABEL_MIN_LENGTH,
  FEATURE_LABEL_MAX_LENGTH,
} from '../variables/feature.variables';

// Feature Messages
export const FEATURE_CREATED_SUCCESS = 'Feature created successfully.';
export const FEATURE_FETCH_SUCCESS = 'Feature fetched successfully.';
export const FEATURES_FETCH_SUCCESS = 'Features fetched successfully.';
export const FEATURE_UPDATED_SUCCESS = 'Feature updated successfully.';
export const FEATURE_DELETE_SUCCESS = 'Feature deleted successfully.';
export const FEATURE_NOT_FOUND = 'Feature not found.';
export const FEATURE_ALREADY_EXISTS = 'Feature with this value already exists.';
export const FEATURE_VALUE_REQUIRED = 'Feature value is required.';
export const FEATURE_LABEL_REQUIRED = 'Feature label is required.';
export const FEATURE_VALUE_MIN_LENGTH_ERROR = `Feature value must be at least ${FEATURE_VALUE_MIN_LENGTH} characters long.`;
export const FEATURE_VALUE_MAX_LENGTH_ERROR = `Feature value cannot exceed ${FEATURE_VALUE_MAX_LENGTH} characters.`;
export const FEATURE_LABEL_MIN_LENGTH_ERROR = `Feature label must be at least ${FEATURE_LABEL_MIN_LENGTH} characters long.`;
export const FEATURE_LABEL_MAX_LENGTH_ERROR = `Feature label cannot exceed ${FEATURE_LABEL_MAX_LENGTH} characters.`;
export const INVALID_FEATURE_ID = 'Invalid feature ID format.';
export const FEATURE_STATUS_UPDATED = 'Feature status updated successfully.';
export const FEATURE_IN_USE = 'Feature is being used by plans and cannot be deleted.';
export const FEATURE_POSITION_REQUIRED = 'Feature position is required.';
export const FEATURE_POSITION_INVALID = 'Feature position must be a valid number.';
