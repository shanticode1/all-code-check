export const SUCCESS = 'Welcome! Your login was successful.';
export const TOKEN_GENERATED = 'Secret token generated successfully.';
export const TOKEN_SENT = 'Secret token sent successfully.';
export const SOMETHING_WRONG = 'Something went wrong please try again.';
export const VERIFICATION_MAIL_SUBJECT = 'Your Verification Code.';
export const OTP_VERIFIED = 'OTP verified successfully.';
export const USER_UPDATED = 'User updated successfully';
// otp
export const INVALID_OTP = 'Invalid OTP.';

// auth factor
export const USER_TWOFA_ACTIVATED = 'TwoFA activated successfully. Keep your authentication device accessible.';
export const USER_TWOFA_DEACTIVATED =
  'TwoFA deactivated successfully. Your account is no longer protected by two-factor authentication.';
export const VERIFICATION_CODE_TO_EMAIL =
  'An OTP has been sent to your registered email address. Please check your inbox and use the code to complete verification.';
export const VERIFICATION_NOT_ACTIVE = 'TwoFA is not activated on your account. Please enable it for added security.';
export const INVALID_TWOFA_METHOD = 'Invalid twoFA method';
export const INVALID_TWOFA = 'Invalid TwoFA method';
export const VERIFICATION_CODE_TO_PHONE =
  'An OTP has been sent to your registered phone number. Please check your sms and use the code to complete verification.';
export const VERIFICATION_CODE_TO_APP =
  'Please open your authenticator app to retrieve the verification code and complete the login process.';
export const PHONE_2FA_ACTIVATION_ERROR =
  'To enable phone-based 2FA, please update your profile with a valid phone number and country code.';

export const USER_TWO_FA_SELECTED_METHOD_NOT_CONFIGURED =
  'This two-factor authentication method is not set up for your account.';
export const SELECTED_TWO_FA_METHOD_NOT_ENABLED =
  'Selected two-factor authentication method is not enabled. Please enable it before proceeding.';
export const TWOFA_VERIFICATION_REQUIRED = 'TwoFA authentication is required. Please verify TwoFA to continue.';

// sms
export const SMS_TEXT = 'Your verification code is:';
export const INVALID_PHONE_FORMAT = 'Invalid phone number format.';

// recovery
export const INVAILD_RECOVERY_CODE = 'Invalid recovery code.';
export const VAILD_RECOVERY_CODE = 'Valid recovery code.';
export const RECOVERY_CODE_NOT_GENERATED =
  'Recovery codes are not available yet. Complete the App Authentication setup to generate your recovery codes.';
export const INVALID_RECOVERY_CODE = 'Invalid recovery code.';
export const VALID_RECOVERY_CODE = 'Valid recovery code.';
export const RECOVERY_CODES_RETRIEVED = 'Recovery codes retrieved successfully. Please keep them secure.';
export const PREFERRED_TWO_FA_METHOD_UPDATED_SUCCESSFULLY =
  'Preferred two-factor authentication method updated successfully.';
