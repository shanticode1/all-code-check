// Plan Entitlement Messages
export const PLAN_ENTITLEMENT_FETCH_SUCCESS = 'Plan entitlements fetched successfully.';
export const PLAN_ENTITLEMENT_NOT_FOUND = 'Plan entitlements not found.';
export const PLAN_ENTITLEMENT_CREATED_SUCCESS = 'Plan entitlements created successfully.';
export const PLAN_ENTITLEMENT_UPDATED_SUCCESS = 'Plan entitlements updated successfully.';
export const PLAN_ENTITLEMENT_DELETED_SUCCESS = 'Plan entitlements deleted successfully.';
export const PLAN_ENTITLEMENT_BATCH_FETCH_SUCCESS = 'Plan entitlements batch fetched successfully.';
export const INVALID_PRICE_ID = 'Invalid price ID format.';
export const PRICE_IDS_REQUIRED = 'Price IDs array is required.';
export const PRICE_IDS_MUST_BE_ARRAY = 'Price IDs must be an array.';
