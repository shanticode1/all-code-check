export const SUPPORT_CONFIG_NOT_FOUND = 'Support configuration not found.';
export const SUPPORT_CONFIG_FETCH_SUCCESS = 'Support configuration fetched successfully.';
export const SUPPORT_CONFIG_FETCH_ERROR = 'Error fetching support configuration.';
export const SUPPORT_CONFIG_UPDATE_SUCCESS = 'Support configuration updated successfully.';
export const SUPPORT_CONFIG_UPDATE_ERROR = 'Error updating support configuration.';

export const TICKET_NOT_FOUND = 'Ticket not found.';
export const TICKETS_NOT_FOUND = 'No tickets found.';
export const TICKET_FETCH_SUCCESS = 'Ticket fetched successfully.';
export const TICKETS_FETCH_SUCCESS = 'Tickets fetched successfully.';
export const TICKETS_FETCH_ERROR = 'Error fetching tickets.';
export const INVALID_TICKET_ID = 'Invalid ticket ID provided.';
export const TICKET_UPDATE_SUCCESS = 'Ticket updated successfully.';
export const TICKET_UPDATE_ERROR = 'Error updating ticket.';
export const TICKET_CREATE_SUCCESS = 'Ticket created successfully.';
export const TICKET_CREATE_ERROR = 'Error creating ticket.';

export const SUPPORT_CONFIG_EMPTY_PAYLOAD = 'At least one support configuration field must be provided to update.';

export const TICKET_INVALID_STATUS = 'Invalid ticket status provided.';
export const CATEGORY_CREATE_SUCCESS = 'Support ticket category created successfully.';
export const CATEGORY_CREATE_ERROR = 'Error creating support ticket category.';
export const CATEGORY_NOT_FOUND = 'Support ticket category not found.';
export const CATEGORY_FETCH_SUCCESS = 'Support ticket category fetched successfully.';
export const CATEGORY_FETCH_ERROR = 'Error fetching support ticket category.';

export const GET_CATEGORY_LIST = 'Successfully fetched the list of categories.';
export const ADD_CATEGORY = 'Category added successfully.';

export const TICKET_DELETE_SUCCESS = 'Ticket deleted successfully';

export const FROM_CONFIG_DELETE_SUCCESS = 'Form deleted successfully';
export const FROM_CONFIG_CREATE_SUCCESS = 'Form created successfully';
export const FROM_CONFIG_TITLE_ALREADY_EXISTS = 'Form with this title already exists.';
export const FROM_CONFIG_GET = 'Form fetched successfully';
export const SUPPORT_FROM_EMPTY_PAYLOAD = 'At least one from configuration field must be provided to update.';
export const FROM_CONFIG_NOT_FOUND = 'Form not found.';
export const FROM_CONFIG_UPDATE_SUCCESS = 'Form updated successfully';
export const FROM_CONFIG_CREATE_ERROR = 'Form configuration Error.';

// chat
export const MESSAGE_SENT_SUCCESS = 'Message send successfully.';
export const CHAT_LIST_FETCH_SUCCESS = 'Fetch Chat list successfully.';
export const CHAT_NOT_FOUND = 'Chat not found.';
