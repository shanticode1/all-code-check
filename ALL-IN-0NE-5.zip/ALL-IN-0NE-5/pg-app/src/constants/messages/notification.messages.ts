export const NOTIFICATION_FETCH_SUCCESS = 'Notifications fetched successfully.';
export const NOTIFICATION_NEW_REGISTRATION = 'New User Registered';
export const NOTIFICATION_NEW_USER_ACTIVATED = 'New User Activated';
export const NOTIFICATION_UPDATE_SUCCESS = 'Notifications updated successfully.';
