// Example Entitlements Messages
export const API_DATA_FETCH_SUCCESS = 'API data fetched successfully.';
export const DATA_EXPORT_SUCCESS = 'Data exported successfully.';
export const TEAM_MEMBER_ADDED_SUCCESS = 'Team member added successfully.';
export const USER_ENTITLEMENTS_FETCH_SUCCESS = 'User entitlements fetched successfully.';
export const FILE_UPLOAD_SUCCESS = 'File uploaded successfully.';
export const NO_ACTIVE_SUBSCRIPTION = 'No active subscription found.';
export const FILE_UPLOAD_NOT_AVAILABLE = 'File upload is not available in your plan.';
export const INSUFFICIENT_STORAGE = 'Insufficient storage.';
export const TEAM_MEMBER_LIMIT_REACHED = 'Team member limit reached.';
export const FAILED_TO_UPDATE_TEAM_MEMBER_COUNT = 'Failed to update team member count.';
