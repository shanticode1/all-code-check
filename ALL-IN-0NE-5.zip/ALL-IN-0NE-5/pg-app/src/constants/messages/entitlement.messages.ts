// Entitlement Error Messages
export const ENTITLEMENT_UNAUTHORIZED = 'Unauthorized';
export const ENTITLEMENT_ERROR_CHECKING_ACCESS = 'Error checking feature access';
export const ENTITLEMENT_ERROR_CHECKING_COUNT_LIMIT = 'Error checking count limit';
export const ENTITLEMENT_FEATURE_NOT_AVAILABLE = (featureValue: string) =>
  `Feature '${featureValue}' is not available in your plan. Please upgrade to access this feature.`;
export const ENTITLEMENT_FEATURE_LIMIT_EXCEEDED = (
  featureValue: string,
  current: number,
  limit: number | 'unlimited',
) => `Feature limit exceeded for '${featureValue}'. Current usage: ${current}/${limit}`;
export const ENTITLEMENT_FEATURE_LIMIT_REACHED = (featureValue: string, current: number, limit: number) =>
  `Feature limit reached for '${featureValue}'. Current: ${current}/${limit}`;
