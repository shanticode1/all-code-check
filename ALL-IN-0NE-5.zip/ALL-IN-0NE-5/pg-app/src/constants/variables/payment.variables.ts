export const PAYMENT_MODULE_SWAGGER_OPERATIONS_PATH = 'src/docs/payment/operations.ts';

// ============================================================================
// STRIPE CHECKOUT MODES
// ============================================================================
export const STRIPE_MODE_PAYMENT = 'payment';
export const STRIPE_MODE_SUBSCRIPTION = 'subscription';

// ============================================================================
// PAYMENT METHOD TYPES
// ============================================================================
export const PAYMENT_METHOD_TYPE_CARD = 'card';
export const PAYMENT_METHOD_TYPE_AMAZON_PAY = 'amazon_pay';

// ============================================================================
// USAGE TYPES
// ============================================================================
export const USAGE_TYPE_LICENSED = 'licensed';
export const USAGE_TYPE_METERED = 'metered';

// ============================================================================
// BILLING INTERVALS
// ============================================================================
export const BILLING_INTERVAL_MONTH = 'month';
export const BILLING_INTERVAL_YEAR = 'year';

// ============================================================================
// INTERVAL TEXT DISPLAY
// ============================================================================
export const INTERVAL_TEXT_MONTHLY = 'Monthly';
export const INTERVAL_TEXT_YEARLY = 'Yearly';

// ============================================================================
// DEFAULT VALUES
// ============================================================================
export const DEFAULT_CUSTOMER_NAME = 'Customer';
export const DEFAULT_PRODUCT_NAME = 'Subscription Plan';
export const DEFAULT_PLAN_NAME_FALLBACK = 'Unknown Plan';
export const DEFAULT_CURRENCY = 'USD';
export const DEFAULT_COUNTRY_CODE = 'IN';

// ============================================================================
// STRIPE METADATA VALUES
// ============================================================================
export const METADATA_VALUE_TRUE = 'true';
export const METADATA_VALUE_FALSE = 'false';
export const EXPORT_COMPLIANCE_INDIA = 'india';

// ============================================================================
// STRIPE SETUP INTENT SETTINGS
// ============================================================================
export const SETUP_INTENT_USAGE_OFF_SESSION = 'off_session';
export const SETUP_INTENT_ALLOW_REDIRECTS_NEVER = 'never';

// ============================================================================
// STRIPE SUBSCRIPTION SETTINGS
// ============================================================================
export const SUBSCRIPTION_COLLECTION_METHOD_CHARGE_AUTOMATICALLY = 'charge_automatically';
export const SUBSCRIPTION_PAYMENT_BEHAVIOR_DEFAULT_INCOMPLETE = 'default_incomplete';
export const SUBSCRIPTION_END_BEHAVIOR_CANCEL = 'cancel';
export const SUBSCRIPTION_SAVE_DEFAULT_PAYMENT_METHOD_ON_SUBSCRIPTION = 'on_subscription';
export const SUBSCRIPTION_PAYMENT_METHOD_COLLECTION_IF_REQUIRED = 'if_required';
export const SUBSCRIPTION_BILLING_ADDRESS_COLLECTION_REQUIRED = 'required';

// ============================================================================
// STRIPE SUBSCRIPTION STATUSES
// ============================================================================
export const SUBSCRIPTION_STATUS_INCOMPLETE = 'incomplete';
export const SUBSCRIPTION_STATUS_INCOMPLETE_EXPIRED = 'incomplete_expired';

// ============================================================================
// STRIPE INVOICE STATUSES
// ============================================================================
export const INVOICE_STATUS_PAID = 'paid';
export const INVOICE_STATUS_OPEN = 'open';
export const INVOICE_STATUS_VOID = 'void';
export const INVOICE_STATUS_UNCOLLECTIBLE = 'uncollectible';

// ============================================================================
// PAYMENT STATUS MAPPINGS (for display)
// ============================================================================
export const PAYMENT_STATUS_SUCCESS = 'Success';
export const PAYMENT_STATUS_PROCESSING = 'Processing';
export const PAYMENT_STATUS_CANCELLED = 'Cancelled';
export const PAYMENT_STATUS_FAILED = 'Failed';
export const PAYMENT_STATUS_UNKNOWN = 'Unknown';

// ============================================================================
// LOG PLACEHOLDERS
// ============================================================================
export const LOG_PLACEHOLDER_MISSING = 'MISSING';

// ============================================================================
// PAYMENT TYPES
// ============================================================================
export const PAYMENT_TYPE_ONE_TIME = 'one-time';

// ============================================================================
// STRIPE QUERY VALUES
// ============================================================================
export const STRIPE_QUERY_ACTIVE_TRUE = `active:'true'`;

// ============================================================================
// DEFAULT QUANTITY
// ============================================================================
export const DEFAULT_SUBSCRIPTION_QUANTITY = 1;

// ============================================================================
// INVOICE FETCH LIMIT
// ============================================================================
export const MAX_INVOICE_FETCH_LIMIT = 1000;

// ============================================================================
// STRIPE WEBHOOK EVENT TYPES
// ============================================================================
export const WEBHOOK_EVENT_CHECKOUT_SESSION_COMPLETED = 'checkout.session.completed';
export const WEBHOOK_EVENT_CUSTOMER_SUBSCRIPTION_CREATED = 'customer.subscription.created';
export const WEBHOOK_EVENT_CUSTOMER_SUBSCRIPTION_UPDATED = 'customer.subscription.updated';
export const WEBHOOK_EVENT_CUSTOMER_SUBSCRIPTION_DELETED = 'customer.subscription.deleted';
export const WEBHOOK_EVENT_INVOICE_PAYMENT_SUCCEEDED = 'invoice.payment_succeeded';
export const WEBHOOK_EVENT_INVOICE_PAID = 'invoice.paid';
export const WEBHOOK_EVENT_INVOICE_UPCOMING = 'invoice.upcoming';

// ============================================================================
// STRIPE API HEADERS AND FIELD NAMES
// ============================================================================
export const STRIPE_WEBHOOK_SIGNATURE_HEADER = 'stripe-signature';

// ============================================================================
// STRIPE API EXPAND PATHS
// ============================================================================
export const STRIPE_EXPAND_DATA_PRICE = 'data.price';
export const STRIPE_EXPAND_ITEMS_DATA_PRICE = 'items.data.price';
export const STRIPE_EXPAND_LATEST_INVOICE_PAYMENT_INTENT = 'latest_invoice.payment_intent';
export const STRIPE_EXPAND_DATA_SUBSCRIPTION = 'data.subscription';
export const STRIPE_EXPAND_DATA_LINES_DATA_PRICE = 'data.lines.data.price';

// ============================================================================
// STRIPE METADATA KEYS
// ============================================================================
export const METADATA_KEY_USER_ID = 'userId';
export const METADATA_KEY_PLAN_NAME = 'planName';
export const METADATA_KEY_PRICE = 'price';
export const METADATA_KEY_USAGE_TYPE = 'usage_type';
export const METADATA_KEY_ORDER_ID = 'order_id';
export const METADATA_KEY_FEATURES = 'features';
export const METADATA_KEY_IMAGE = 'image';
export const METADATA_KEY_PRODUCT_NAME = 'productName';
export const METADATA_KEY_TRIAL_DAYS = 'trialDays';

// ============================================================================
// STRIPE OBJECT FIELD NAMES
// ============================================================================
export const STRIPE_FIELD_ID = 'id';
export const STRIPE_FIELD_CUSTOMER = 'customer';
export const STRIPE_FIELD_SUBSCRIPTION = 'subscription';
export const STRIPE_FIELD_METADATA = 'metadata';
export const STRIPE_FIELD_STATUS = 'status';
export const STRIPE_FIELD_DELETED = 'deleted';
export const STRIPE_FIELD_CURRENT_PERIOD_END = 'current_period_end';
export const STRIPE_FIELD_PAYMENT_INTENT = 'payment_intent';
export const STRIPE_FIELD_CLIENT_SECRET = 'client_secret';

// ============================================================================
// ENTITLEMENT AND FEATURE VALUES
// ============================================================================
export const ENTITLEMENT_LIMIT_UNLIMITED = 'unlimited';
export const ENTITLEMENT_RESET_PERIOD_MONTHLY = 'monthly';

// ============================================================================
// TYPE CHECK VALUES
// ============================================================================
export const TYPE_STRING = 'string';
export const TYPE_OBJECT = 'object';

// ============================================================================
// DISPLAY VALUES
// ============================================================================
export const DISPLAY_VALUE_UNCHANGED = 'unchanged';
