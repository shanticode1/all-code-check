export const SUPPORTS_MODULE_SWAGGER_OPERATIONS_PATH = 'src/docs/supports/operations.ts';
// Keep for demo
export const CATEGORIES = [
  {
    name: 'General Inquiry',
    description: 'General questions and inquiries',
  },
  {
    name: 'Billing & Subscription',
    description: 'Billing, payment, and subscription related issues',
  },
  {
    name: 'Technical Issue',
    description: 'Technical problems and system errors',
  },
  {
    name: 'PRIME AI',
    description: 'Issues related to PRIME AI',
  },
  {
    name: 'EDGE / PULSE Tools',
    description: 'EDGE and PULSE tools related support',
  },
  {
    name: 'Account & Login',
    description: 'Account access and login related issues',
  },
];
