// Swagger documentation path
export const PLAN_ENTITLEMENT_MODULE_SWAGGER_OPERATIONS_PATH = 'src/docs/planEntitlement/operations.ts';
