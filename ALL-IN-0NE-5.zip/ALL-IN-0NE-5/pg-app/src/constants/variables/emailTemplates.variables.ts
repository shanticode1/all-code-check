export const RESET_TOKEN_EXPIRE = 60; // default expire value (minutes)
export const RESET_TOKEN_UNIT = 'minute'; // Supported units: year, month, day, hour, minute, second, millisecond

export const emailTemplates = [
  {
    slug: 'set-password',
    subject: 'Password set request',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'reset-password',
    subject: 'Password Reset Request',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'verify-email',
    subject: 'Verify Your Email Address',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'verify-otp',
    subject: 'Verify Your OTP',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'new-user',
    subject: 'New User Registration',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'user-activated',
    subject: 'User Account Activated',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'account-status',
    subject: 'User Account Update',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'purchase-subscription',
    subject: 'User Purchased Subscription',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'subscription-created',
    subject: 'Subscription Activated - Welcome!',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'subscription-cancelled',
    subject: 'Subscription Cancelled',
    isActive: true,
    isDeleted: false,
  },
  {
    slug: 'subscription-updated',
    subject: 'Subscription Updated',
    isActive: true,
    isDeleted: false,
  },
];
