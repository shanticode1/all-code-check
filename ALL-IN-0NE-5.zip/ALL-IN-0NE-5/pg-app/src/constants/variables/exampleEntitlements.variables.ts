// Swagger documentation path
export const EXAMPLE_ENTITLEMENTS_MODULE_SWAGGER_OPERATIONS_PATH = 'src/docs/exampleEntitlements/operations.ts';

// ============================================================================
// FEATURE VALUES (Entitlement Identifiers)
// ============================================================================
export const FEATURE_VALUE_API_REQUESTS_PER_MONTH = 'api-requests-per-month';
export const FEATURE_VALUE_TEAM_MEMBERS = 'team-members';
export const FEATURE_VALUE_FILE_UPLOADS = 'file-uploads';
export const FEATURE_VALUE_STORAGE_LIMIT = 'storage-limit';
