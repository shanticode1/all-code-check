// Feature validation constants
export const FEATURE_VALUE_MIN_LENGTH = 2;
export const FEATURE_VALUE_MAX_LENGTH = 100;
export const FEATURE_LABEL_MIN_LENGTH = 2;
export const FEATURE_LABEL_MAX_LENGTH = 200;
export const DEFAULT_FEATURE_POSITION = 0;

// Feature pagination constants
export const FEATURE_PAGE_MIN = 1;
export const FEATURE_PAGE_MAX = 10000;
export const FEATURE_PAGE_DEFAULT = 1;
export const FEATURE_LIMIT_MIN = 1;
export const FEATURE_LIMIT_MAX = 1000;
export const FEATURE_LIMIT_DEFAULT = 100;

// Feature sorting constants
export const FEATURE_SORT_FIELDS = ['value', 'label', 'position', 'createdAt', 'updatedAt'];
export const FEATURE_ORDER_OPTIONS = ['asc', 'desc'];
export const FEATURE_DEFAULT_SORT_BY = 'position';
export const FEATURE_DEFAULT_ORDER_BY = 'asc';

// Swagger documentation path
export const FEATURE_MODULE_SWAGGER_OPERATIONS_PATH = 'src/docs/feature/operations.ts';
