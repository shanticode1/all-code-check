// ============================================================================
// ENTITLEMENT RESET PERIODS
// ============================================================================
export const ENTITLEMENT_RESET_PERIOD_DAILY = 'daily';
export const ENTITLEMENT_RESET_PERIOD_MONTHLY = 'monthly';
export const ENTITLEMENT_RESET_PERIOD_YEARLY = 'yearly';

// ============================================================================
// FIELD PATHS FOR ENTITLEMENTS
// ============================================================================
export const ENTITLEMENT_FIELD_FEATURE_VALUE = 'entitlements.featureValue';
export const ENTITLEMENT_FIELD_CURRENT_USAGE = 'entitlements.currentUsage';
export const ENTITLEMENT_FIELD_RESET_PERIOD = 'entitlements.resetPeriod';
export const ENTITLEMENT_FIELD_LAST_RESET = 'entitlements.lastReset';
export const ENTITLEMENT_FIELD_ARRAY_ELEMENT = 'entitlements.$';
export const ENTITLEMENT_FIELD_ARRAY_ELEMENT_CURRENT_USAGE = 'entitlements.$[elem].currentUsage';
export const ENTITLEMENT_FIELD_ARRAY_ELEMENT_LAST_RESET = 'entitlements.$[elem].lastReset';

// ============================================================================
// ENTITLEMENT ARRAY FILTER KEYS
// ============================================================================
export const ENTITLEMENT_ARRAY_FILTER_ELEMENT = 'elem';
