import type { SupportTicketStatus } from '@enums';

export interface ISupportTicket extends Document {
  userId?: string;
  fullName?: string;
  email?: string;
  subject?: string;
  category?: string;
  message?: string;
  attachment?: string;
  status?: SupportTicketStatus;
  createdAt?: Date;
  updatedAt?: Date;
  ticketNumber?: string;
}

export interface ISupportCategory extends Document {
  id?: number;
  name?: string;
  description?: string;
  isActive: boolean;
  isDeleted: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface ITicketChat {
  ticketId: number;
  senderId: number;
  senderRole: number;
  message: string;
  readByUser?: boolean;
  readByAdmin?: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}
