export interface ISupportEmailSettings {
  primaryEmail: string;
  ccEmails: string[];
}

export interface ISupportFormField {
  id?: number;
  supportConfigId?: number;

  key?: string;
  enabled?: boolean;
  required?: boolean;
}

export interface ISupportFormConfig {
  enabled: boolean;
  fields: ISupportFormField[];
}

export interface ISupportAutoReply {
  enabled: boolean;
  message: string;
}

export interface ISupportConfig {
  id?: number;

  userId: number;

  primaryEmail?: string;
  ccEmails?: string[] | null; // if using Json in Prisma

  formEnabled?: boolean;
  formFields?: ISupportFormField[];

  autoReplyEnabled?: boolean;
  autoReplyMessage?: string;

  createdAt?: Date;
  updatedAt?: Date;
}

/**
 * Form field configuration interface
 */
export interface IFormFieldConfig {
  key: string;
  label?: string;
  type?: string;
  enabled: boolean;
  required: boolean;
}

/**
 * Form config interface
 */
export interface IFormConfig extends Document {
  title: string;
  file?: string;
  config: any;
  isActive: boolean;
  isDeleted: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface IEmailSettings {
  primaryEmail: string;
  ccEmails: string[];
}

export interface IFormFieldConfig {
  key: string;
  enabled: boolean;
  required: boolean;
}

export interface IFormConfig {
  enabled: boolean;
  fields: IFormFieldConfig[];
}

export interface IAutoReply {
  enabled: boolean;
  message: string;
}

export interface IContactFormSettings {
  emailSettings: IEmailSettings;
  formConfig: IFormConfig;
  autoReply: IAutoReply;
  createdAt: string; // or Date if you parse it
  updatedAt: string; // or Date if you parse it
}
