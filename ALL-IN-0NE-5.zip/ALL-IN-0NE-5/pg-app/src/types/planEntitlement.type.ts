export interface IPlanEntitlement {
  id?: number;
  priceId: string;
  entitlements: Array<{
    featureId: string;
    featureValue: string;
    type: 'boolean' | 'numeric' | 'unlimited';
    limit: number | 'unlimited' | boolean;
    unit?: string;
  }>;
  isDeleted: boolean;
  deletedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface ICreatePlanEntitlementRequest {
  priceId: string;
  entitlements: Array<{
    featureId: string;
    featureValue: string;
    type: 'boolean' | 'numeric' | 'unlimited';
    limit: number | 'unlimited' | boolean;
    unit?: string;
  }>;
}

export interface IUpdatePlanEntitlementRequest {
  entitlements?: Array<{
    featureId: string;
    featureValue: string;
    type: 'boolean' | 'numeric' | 'unlimited';
    limit: number | 'unlimited' | boolean;
    unit?: string;
  }>;
}

export interface IPlanEntitlementResponse {
  id: string;
  priceId: string;
  entitlements: Array<{
    featureId: string;
    featureValue: string;
    type: 'boolean' | 'numeric' | 'unlimited';
    limit: number | 'unlimited' | boolean;
    unit?: string;
  }>;
  createdAt: Date;
  updatedAt: Date;
}
