export interface IFeature {
  id?: number;
  value: string;
  label: string;
  type: 'boolean' | 'numeric' | 'unlimited';
  unit?: string;
  position: number;
  isCore: boolean;
  isActive: boolean;
  isDeleted: boolean;
  deletedAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface ICreateFeatureRequest {
  value: string;
  label: string;
  type?: 'boolean' | 'numeric' | 'unlimited';
  unit?: string;
  position?: number;
  isCore?: boolean;
  isActive?: boolean;
}

export interface IUpdateFeatureRequest {
  value?: string;
  label?: string;
  type?: 'boolean' | 'numeric' | 'unlimited';
  unit?: string;
  position?: number;
  isCore?: boolean;
  isActive?: boolean;
}

export interface IFeatureResponse {
  id: string;
  value: string;
  label: string;
  type: 'boolean' | 'numeric' | 'unlimited';
  unit?: string;
  position: number;
  isCore: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface IFeatureListResponse {
  total: number;
  features: IFeatureResponse[];
}
