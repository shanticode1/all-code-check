import type { SubscriptionStatus } from '@enums';

export interface IFeatureEntitlement {
  featureId: string;
  featureValue: string;
  type: 'boolean' | 'numeric' | 'unlimited';
  limit: number | 'unlimited';
  currentUsage: number;
  unit?: string;
  resetPeriod?: 'daily' | 'monthly' | 'yearly' | 'never';
  lastReset?: Date;
}

export interface IUserSubscription {
  id: number;
  userId: number;
  customerId: string;
  planId: string;
  planName?: string;
  expiry: Date;
  status: SubscriptionStatus;
  stripeSubscriptionId?: string;
  entitlements: IFeatureEntitlement[];
  isDeleted: boolean;
  deletedAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface ICreateUserSubscriptionRequest {
  userId: string;
  customerId: string;
  planId: string;
  planName?: string;
  expiry: Date;
  status?: SubscriptionStatus;
  stripeSubscriptionId?: string;
  entitlements?: IFeatureEntitlement[];
}

export interface IUpdateUserSubscriptionRequest {
  status?: SubscriptionStatus;
  expiry?: Date;
  planId?: string;
  planName?: string;
  stripeSubscriptionId?: string | null;
  entitlements?: any;
  stripeEventCreated?: number;
  cancelScheduled?: boolean;
  cancelAt?: Date | null;
}

export interface IUserSubscriptionResponse {
  id: string;
  userId: string;
  customerId: string;
  planId: string;
  planName?: string;
  expiry: Date;
  status: SubscriptionStatus;
  stripeSubscriptionId?: string;
  entitlements: IFeatureEntitlement[];
  createdAt: Date;
  updatedAt: Date;
}
