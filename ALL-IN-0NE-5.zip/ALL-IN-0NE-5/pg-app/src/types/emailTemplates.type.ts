export interface IEmailTemplate {
  slug: string;
  subject: string;
  template: string;
  isActive: boolean;
  isDeleted: boolean;
}
export interface ITemplateData {
  [key: string]: string | number | boolean | Record<string, unknown> | undefined;
}

export interface IEmailData {
  toEmail: string;
  toName: string;
  templateName: string;
  data?: ITemplateData;
  attachments?: Array<{
    filename: string;
    content: Buffer | string;
    contentType?: string;
  }>;
}
