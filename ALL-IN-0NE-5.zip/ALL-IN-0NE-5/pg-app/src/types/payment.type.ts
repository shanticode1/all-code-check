// Define 'Interval' type manually or use Stripe's predefined types
type Interval = 'day' | 'week' | 'month' | 'year';

// Define 'UsageType' type manually or use Stripe's predefined types
type UsageType = 'metered' | 'licensed';

export interface IProduct {
  productId: string;
  name: string;
  description?: string;
}

export interface IPlan {
  productId: string;
  currency: string;
  amount: number;
  recurring: {
    interval: Interval;
    usage_type: UsageType;
    interval_count?: number; // For quarterly plans (3 months)
  };
  usageType: UsageType;
  interval: Interval;
  interval_count?: number; // For quarterly plans (3 months) - top level for easy access
  imageUrl?: string; // Image URL to be stored in price metadata with key 'image'
  metadata?: Record<string, string>;
}

export interface IPlanUpdate {
  description: string | undefined;
  email: string | undefined;
  customerId: string;
  priceId: string;
  orderId: string;
  imageUrl?: string; // Image URL to be stored in price metadata with key 'image'
  metadata?: Record<string, string>;
}

export interface SubscriptionSessionOptions {
  successUrl: string;
  cancelUrl: string;
  submitButtonText?: string;
  usageType?: string;
  defaultProductName?: string;
  additionalMetadata?: Record<string, string>;
  defaultCustomerName?: string;
}

/**
 * Parsed entitlement from compressed format (f, v, t, l, u)
 */
export interface IParsedEntitlementCompressed {
  f: string; // featureId
  v: string; // featureValue
  t: 'boolean' | 'numeric' | 'unlimited'; // type
  l: number | 'unlimited' | boolean; // limit
  u?: string; // unit
}

/**
 * Entitlement input type (can be compressed or full format)
 */
export type IEntitlementInput =
  | IParsedEntitlementCompressed
  | {
      featureId: string;
      featureValue: string;
      type: 'boolean' | 'numeric' | 'unlimited';
      limit: number | 'unlimited' | boolean;
      unit?: string;
    };

/**
 * Billing address for subscription
 */
export interface IBillingAddress {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
}

/**
 * Setup Intent result
 */
export interface ISetupIntentResult {
  clientSecret: string;
  customerId: string;
}
