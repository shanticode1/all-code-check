export interface ISavedCard {
  id: number;
  userId: number;
  customerId: string;
  paymentMethodId: string;
  cardFingerprint: string;
  brand: string;
  last4: string;
  expMonth: number;
  expYear: number;
  isDefault: boolean;
  isDeleted: boolean;
  deletedAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface ISavedCardResponse {
  id: string;
  userId: string;
  customerId: string;
  paymentMethodId: string;
  cardFingerprint: string;
  brand: string;
  last4: string;
  expMonth: number;
  expYear: number;
  isDefault: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ICreateSavedCardRequest {
  paymentMethodId: string;
  customerId?: string;
}

export interface ISaveCardFilter {
  userId?: number;
  id?: number;
  paymentMethodId?: string;
  isDeleted?: boolean;
  cardFingerprint?: string;
}
