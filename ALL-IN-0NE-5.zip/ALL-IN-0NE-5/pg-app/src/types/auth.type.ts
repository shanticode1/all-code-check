export interface IRegisterBody {
  firstName: string;
  lastName?: string;
  email: string;
  password: string;
  phoneNumber?: string; // Optional field
  countryCode?: string; // Optional field
}

export interface ILoginBody {
  email: string;
  password: string;
  shouldSendOtp: boolean;
}

export interface IUpdateProfile {
  firstName: string;
  lastName?: string;
  email: string;
  phoneNumber?: string; // Optional field
  countryCode?: string; // Optional field
}

export interface IForgetPasswordBody {
  email: string;
}

export interface IResetPasswordBody {
  token: string;
  password: string;
}

export interface IChangePasswordBody {
  currentPassword: string;
  newPassword: string;
}
