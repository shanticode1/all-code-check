/**
 * Formatted entitlement response interface
 */
export interface IFormattedEntitlement {
  feature: string;
  label: string;
  type: 'boolean' | 'numeric' | 'unlimited';
  limit: number | 'unlimited';
  currentUsage: number;
  unit?: string;
  resetPeriod?: 'daily' | 'monthly' | 'yearly' | 'never';
  percentage: number;
  remaining: number | 'unlimited';
}

/**
 * Usage metadata interface
 */
export interface IUsageMeta {
  usage: number | undefined;
  limit: number | 'unlimited' | undefined;
  remaining: number | 'unlimited';
}
