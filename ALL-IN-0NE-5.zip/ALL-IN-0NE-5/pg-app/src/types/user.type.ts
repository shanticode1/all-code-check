interface ITwoFactorMethod {
  [key: string]: string;
}
export interface IUser {
  id: number;
  firstName: string;
  email: string;
  password: string;
  phoneNumber: string;
  countryCode: string;
  role: number;
  status: number;
  googleId?: string;
  facebookId?: string;
  resetPasswordToken?: string;
  resetPasswordExpire?: Date;
  generateResetToken: () => string;
  comparePassword: (enteredPassword: string) => Promise<boolean>;
  isDeleted: boolean;
  twoFAOtp: string;
  isTwoAuthEnabled: boolean;
  appToken: IAppSecret;
  createdAt: Date;
  updatedAt: Date;
  preferredTwoFAMethods?: ITwoFactorMethod[];
  recoveryCodes: IRecoveryCode[];
  [key: string]: any;
  lastName?: string;
}

export interface UnifiedUserServiceResponse {
  status: number;
  success: boolean;
  message: string;
  data: any | null;
}

export interface SetPasswordTokenResult {
  token: string;
  hashedToken: string;
  expireDate: Date;
}

export interface IAppSecret {
  ascii: string;
  hex: string;
  base32: string;
  otpauth_url: string;
}

export interface IRecoveryCode {
  code: string; // AES-GCM encrypted value
  iv: string; //Initialization Vector (a random starting value used by encryption algorithms)
  tag: string; // Ensures encrypted data hasn’t been altered and confirms correct key/IV during decryption
  used: boolean; // Whether the code is already used
}
