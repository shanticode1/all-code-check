import type { Express } from 'express';

// Define the structure of the file upload database
export interface IFileUpload {
  userId: number;
  path: string[];
  isDeleted: boolean;
}
export interface IFileUploadType {
  [fieldname: string]: Express.Multer.File[];
}
