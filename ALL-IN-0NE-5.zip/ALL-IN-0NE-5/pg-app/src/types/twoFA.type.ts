import type { TwoFAMethod, TwoFAFlow } from '@enums';
import type { Response } from 'express';

export interface ISendSmsCodeBody {
  phoneNumber?: string;
  twoFAFlow: TwoFAFlow;
  email: string;
  countryCode?: string;
}

export interface IVerifyOtpBody {
  email: string;
  inputOTP: string;
  twoFAMethodType: TwoFAMethod;
  twoFAFlow: TwoFAFlow;
  res: Response;
}
