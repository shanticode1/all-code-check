//Third-party modules
import type { NextFunction, Request, Response } from 'express';

//Middlewares
import { responseHandler } from '@middlewares';

//Constants
import { BAD_REQUEST, paymentMessages } from '@constants';

//Utils
import { ErrorHandler, catchHandler } from '@utils';

//Services
import { cardService } from '@services';

/**
 * Creates a Setup Intent for saving cards
 */
export const createSavedCardSetupIntent = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { customerId, customerEmail, customerName } = req.body;
    const userId = req.user?.id?.toString();

    if (!userId) {
      next(new ErrorHandler(paymentMessages.INVALID_USER_ID, BAD_REQUEST));
      return;
    }

    const { status, success, message, data } = await cardService.createSavedCardSetupIntent(
      userId,
      customerEmail || req.user?.email || '',
      customerName || req.user?.name || '',
      customerId,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Saves a card token for a user
 */
export const saveCard = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(paymentMessages.INVALID_USER_ID, BAD_REQUEST));
      return;
    }

    const { status, success, message, data } = await cardService.saveCard(userId, req.body);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Lists saved cards for a user
 */
export const listSavedCards = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(paymentMessages.INVALID_USER_ID, BAD_REQUEST));
      return;
    }

    const { status, success, message, data } = await cardService.listSavedCards(userId);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Deletes a saved card
 */
export const deleteSavedCard = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(paymentMessages.INVALID_USER_ID, BAD_REQUEST));
      return;
    }

    const { status, success, message, data } = await cardService.deleteSavedCard(userId, req.params.cardId as string);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
