import type { NextFunction, Request, Response } from 'express';
import { responseHandler } from '@middlewares';
import { ErrorHandler, catchHandler } from '@utils';
import { planEntitlementService } from '@services';
import { BAD_REQUEST, planEntitlementMessages } from '@constants';

/**
 * Gets plan entitlements by price ID
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getPlanEntitlementsByPriceId = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { priceId } = req.params;
    const { status, success, message, data } = await planEntitlementService.getPlanEntitlementsByPriceId(
      priceId as string,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Gets plan entitlements by multiple price IDs (batch)
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getPlanEntitlementsByPriceIds = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { priceIds } = req.body; // Expects { priceIds: string[] }

    if (!Array.isArray(priceIds)) {
      return next(new ErrorHandler(planEntitlementMessages.PRICE_IDS_MUST_BE_ARRAY, BAD_REQUEST, null));
    }

    const { status, success, message, data } = await planEntitlementService.getPlanEntitlementsByPriceIds(priceIds);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
