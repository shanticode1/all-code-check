import type { NextFunction, Request, Response } from 'express';

import { UNAUTHORIZE, commonMessages } from '@constants';
import { ErrorHandler, catchHandler } from '@utils';
import { responseHandler } from '@middlewares';
import { exampleEntitlementsService } from '@services';

/**
 * Handles getting API data with usage tracking
 */
export const getApiData = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
      return;
    }

    const { status, success, message, data, meta } = await exampleEntitlementsService.getApiData(userId);

    if (success) {
      responseHandler(res, message, status, { ...data, meta });
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles exporting data
 */
export const exportData = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { status, success, message, data } = await exampleEntitlementsService.exportData();

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles adding a team member
 */
export const addTeamMember = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
      return;
    }

    const { status, success, message, data } = await exampleEntitlementsService.addTeamMember(userId);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles getting user's entitlements
 */
export const getMyEntitlements = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
      return;
    }

    const { status, success, message, data } = await exampleEntitlementsService.getMyEntitlements(userId);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles file upload
 */
export const uploadFile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();
    if (!userId) {
      next(new ErrorHandler(commonMessages.UNAUTHORIZED, UNAUTHORIZE, null));
      return;
    }

    const fileSize = req.body.fileSize || 0; // in MB

    const { status, success, message, data } = await exampleEntitlementsService.uploadFile(userId, fileSize);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
