//third party imports
import type { NextFunction, Request, Response } from 'express';

//utils
import { ErrorHandler, catchHandler, commonHandler } from '@utils';

//middlewares
import { responseHandler } from '@middlewares';
import { supportService } from '@services';
import { commonVariables } from '@constants';

/**
 * Retrieves the support configuration.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getSupportConfig = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { status, success, message, data } = await supportService.getSupportConfig();

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Updates the support configuration.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const updateSupportConfig = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { body } = req;
    const userId = req.user?.id;

    const { status, success, message, data } = await supportService.updateSupportConfig(body, userId as number);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Retrieves all support tickets.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getAllTickets = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  const { user } = req;
  const { ticketId } = req.params;
  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 10;
  const { search } = req.query;
  const filter = commonHandler.parseJsonFilter(req.query.filter);

  try {
    const { status, success, message, data } = await supportService.getAllTickets(
      ticketId as string,
      page,
      limit,
      search as string,
      filter,
      user,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Updates the status of a support ticket.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const updateTicketStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { ticketId } = req.params;
    const { status: newStatus } = req.body;

    const { status, success, message, data } = await supportService.updateTicketStatus(ticketId as string, newStatus);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Creates a new support ticket.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const createTicket = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { body, user } = req;
    body.userId = user?.id;
    const { status, success, message, data } = await supportService.createTicket(body);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

export const deleteTicketById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { ticketId } = req.params;

    const { status, success, message, data } = await supportService.deleteTicket(ticketId as string);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Retrieves the support form setting.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getSupportSetting = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { status, success, message, data } = await supportService.getEnabledRequiredSupportConfig();

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Creates a new category.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const addCategory = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { body } = req;

    const { status, success, message, data } = await supportService.addCategory(body);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Fetch category list.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getCategories = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const page = Number(req.query.page) || commonVariables.PAGE;
    const limit = Number(req.query.limit) || commonVariables.LIMIT;
    const { search } = req.query;
    const { status, success, message, data } = await supportService.getCategories(page, limit, search as string);
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Create ticket chat message.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const createTicketChat = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { ticketId } = req.params;
    const payload = {
      ...req.body,
      senderId: req.user?.id, // assuming auth middleware
      senderRole: req.user?.role,
    };

    const { status, success, message, data } = await supportService.createTicketChat(ticketId as string, payload);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Fetch ticket chat messages.
 * @param {Request} req - The incoming request object.
 * @param {Response} res - The outgoing response object.
 * @param {NextFunction} next - The next middleware function.
 */
export const getTicketChats = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userRole = req.user?.role;
    const { ticketId } = req.params;
    const page = Number(req.query.page) || commonVariables.PAGE;
    const limit = Number(req.query.limit) || commonVariables.LIMIT;

    const { status, success, message, data } = await supportService.getTicketChats(
      ticketId as string,
      page,
      limit,
      userRole,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
