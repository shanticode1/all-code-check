import { responseHandler } from '@middlewares';
import { ErrorHandler, catchHandler } from '@utils';
import type { NextFunction, Request, Response } from 'express';
import type { IApiResponse } from '@customTypes';
import { TwoFAMethod } from '@enums';
import { twoFAService } from '@services';
import { commonMessages, UNAUTHORIZE } from '@constants';

/**
 * Handles enable two factor authentication
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const enableTwoFA = async (request: Request, response: Response, next: NextFunction): Promise<void> => {
  try {
    const { email, password, isTwoAuthEnabled, twoFAMethodType } = request.body;
    const result = await twoFAService.activeTwoFAAuthentication(email, password, isTwoAuthEnabled, twoFAMethodType);
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles sending the two factor authentication code
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
// not use at the moment
export const sendTwoFACode = async (request: Request, response: Response, next: NextFunction): Promise<void> => {
  try {
    let result: IApiResponse = {
      status: 0,
      success: false,
      message: '',
      data: null,
    };
    const user = request.user;
    if (!user) {
      return next(new ErrorHandler(commonMessages.USER_NOT_FOUND, UNAUTHORIZE, null));
    }
    const { password, twoFAMethodType, phoneNumber, countryCode, twoFAFlow } = request.body;
    if (twoFAMethodType === TwoFAMethod.EMAIL) {
      result = await twoFAService.sendOtpToMail(user.email, password);
    }
    if (twoFAMethodType === TwoFAMethod.PHONE) {
      result = await twoFAService.sendSmsCode({
        phoneNumber,
        email: user.email,
        twoFAFlow,
        countryCode,
      });
    }
    if (twoFAMethodType === TwoFAMethod.APP) {
      result = await twoFAService.createQRCode(user.email);
    }
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles verifying the two factor authentication code
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const verifyTwoFACode = async (request: Request, response: Response, next: NextFunction): Promise<void> => {
  try {
    const user = request.user;
    if (!user) {
      return next(new ErrorHandler(commonMessages.USER_NOT_FOUND, UNAUTHORIZE, null));
    }
    const { otp, twoFAMethodType, twoFAFlow } = request.body;
    const result = await twoFAService.verifyTwoFaCode({
      email: user.email,
      inputOTP: otp,
      twoFAMethodType,
      twoFAFlow,
      res: response,
    });
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles validating the recovery code
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const validateRecoveryCode = async (request: Request, response: Response, next: NextFunction): Promise<void> => {
  try {
    const user = request.user;
    if (!user) {
      return next(new ErrorHandler(commonMessages.USER_NOT_FOUND, UNAUTHORIZE, null));
    }
    const { code: recoveryCode } = request.body;
    const result = await twoFAService.validateRecoveryCode(user.email, recoveryCode, response);
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles fetching recovery codes
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getRecoveryCodes = async (request: Request, response: Response, next: NextFunction): Promise<void> => {
  try {
    const user = request.user;
    if (!user) {
      return next(new ErrorHandler(commonMessages.USER_NOT_FOUND, UNAUTHORIZE, null));
    }
    const result = await twoFAService.getRecoveryCodes(user.recoveryCodes);
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles regenerate recovery codes
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const regenerateRecoveryCodes = async (
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const user = request.user;
    if (!user) {
      return next(new ErrorHandler(commonMessages.USER_NOT_FOUND, UNAUTHORIZE, null));
    }
    const result = await twoFAService.regenerateRecoveryCodes(user);
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles updating preferredTwoFaMethod
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
// not use at the moment
export const updatePreferredTwoFaMethod = async (
  request: Request,
  response: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const user = request.user;
    if (!user) {
      return next(new ErrorHandler(commonMessages.USER_NOT_FOUND, UNAUTHORIZE, null));
    }
    const { preferredTwoFAMethod } = request.body;
    const result = await twoFAService.setPreferredTwoFaMethod(user.email, preferredTwoFAMethod);
    const { success, message, status, data } = result;
    if (success) {
      responseHandler(response, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
