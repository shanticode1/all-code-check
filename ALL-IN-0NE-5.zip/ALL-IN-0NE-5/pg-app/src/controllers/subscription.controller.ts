//Third-party modules
import type { NextFunction, Request, Response } from 'express';

//Middlewares
import { responseHandler } from '@middlewares';

//Constants
import { OK, UNAUTHORIZE, BAD_REQUEST, paymentMessages, commonMessages } from '@constants';

//Utils
import { ErrorHandler, catchHandler } from '@utils';

//Services
import { paymentService, userSubscriptionService } from '@services';

/**
 * Handles get user subscription
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction}     next
 */
export const getUserSubscription = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();

    if (!userId) {
      next(new ErrorHandler(commonMessages.USER_NOT_AUTHENTICATED, UNAUTHORIZE, null));
      return;
    }

    const { status, success, message, data } = await userSubscriptionService.getUserSubscriptionByUserId(userId);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles get all user subscriptions (Admin only)
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getAllUserSubscriptions = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { page, limit, search } = req.query;

    const { status, success, message, data } = await userSubscriptionService.getAllUserSubscriptions(
      Number(page),
      Number(limit),
      search as string,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles get user billing history
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getUserBillingHistory = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();

    if (!userId) {
      next(new ErrorHandler(commonMessages.USER_NOT_AUTHENTICATED, UNAUTHORIZE, null));
      return;
    }

    const { page, limit, search } = req.query;

    const { status, success, message, data } = await userSubscriptionService.getUserBillingHistory(
      userId,
      Number(page),
      Number(limit),
      search as string | undefined,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles get customer portal URL
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getCustomerPortalUrl = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id?.toString();

    if (!userId) {
      next(new ErrorHandler(commonMessages.USER_NOT_AUTHENTICATED, UNAUTHORIZE, null));
      return;
    }

    const { returnUrl } = req.query;

    if (!returnUrl || typeof returnUrl !== 'string') {
      next(new ErrorHandler(paymentMessages.RETURN_URL_REQUIRED, BAD_REQUEST, null));
      return;
    }

    const { status, success, message, data } = await userSubscriptionService.getCustomerPortalUrl(userId, returnUrl);

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles post paid subscription
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const createPostPaymentSubcription = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { customerId, priceId, currency, trialDays } = req.body;
    const { status, success, message, data } = await paymentService.createPostSubscription(
      customerId,
      priceId,
      currency,
      trialDays,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles get subscription
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getSubcriptionById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { status, success, message, data } = await paymentService.fetchSubscriptionById(
      req.params.subscriptionId as string,
    );
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles delete subscription
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const deleteSubcriptionById = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { status, success, message, data } = await paymentService.deleteBysubscriptionId(
      req.params.subscriptionId as string,
    );
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles update subscription
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const updateSubscription = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { subscriptionId, discription } = req.body;
    const { status, success, message, data } = await paymentService.updatePrepaidSubscription(
      subscriptionId,
      discription,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles create post paid subscription session
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const createPostPaidSubscriptionSession = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const { status, success, message, data } = await paymentService.createUsagesSubscriptionSession(
      req.params.customerId as string,
      req.body.priceId,
      req.body.currency,
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Creates a subscription after payment method is confirmed
 */
export const createSubscriptionFromIntent = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { customerId, priceId, paymentMethodId, address, metadata } = req.body;
    const userId = req.user?.id?.toString();

    const { status, success, message, data } = await paymentService.createSubscriptionAfterPayment(
      customerId,
      priceId,
      paymentMethodId,
      {
        userId: userId || '',
        ...metadata,
      },
      address, // Pass address to update customer BEFORE subscription creation
    );

    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
