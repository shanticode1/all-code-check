//Third-party modules
import type { NextFunction, Request, Response } from 'express';

//Services
import { featureService } from '@services';

//Middlewares
import { responseHandler } from '@middlewares';

//Utils
import { ErrorHandler, catchHandler } from '@utils';

//Constants
import { featureVariables } from '@constants';

//Custom types
import type { ICreateFeatureRequest, IUpdateFeatureRequest } from '@customTypes';

/**
 * Handles creating a new feature
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const createFeature = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const featureData: ICreateFeatureRequest = req.body;

    const response = await featureService.createFeature(featureData);
    const { success, message, status, data } = response;
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles retrieving features.
 * If a featureId is provided, fetch that specific feature; otherwise, fetch all features.
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const getFeatures = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { featureId } = req.params;
    const {
      page = featureVariables.FEATURE_PAGE_DEFAULT,
      limit = featureVariables.FEATURE_LIMIT_DEFAULT,
      search,
      sortBy = featureVariables.FEATURE_DEFAULT_SORT_BY,
      orderBy = featureVariables.FEATURE_DEFAULT_ORDER_BY,
    } = req.query;

    if (featureId) {
      // Get specific feature
      const response = await featureService.getFeatureById(featureId as string);
      const { success, message, status, data } = response;
      if (success) {
        responseHandler(res, message, status, data);
      } else {
        next(new ErrorHandler(message, status, data));
      }
    } else {
      // Get all features with pagination
      const response = await featureService.getFeatures(
        Number(page),
        Number(limit),
        search as string,
        sortBy as string,
        orderBy as string,
      );
      const { success, message, status, data } = response;
      if (success) {
        responseHandler(res, message, status, data);
      } else {
        next(new ErrorHandler(message, status, data));
      }
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles updating a feature
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const updateFeature = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { featureId } = req.params;
    const updateData: IUpdateFeatureRequest = req.body;

    const response = await featureService.updateFeature(featureId as string, updateData);
    const { success, message, status, data } = response;
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles deleting a feature
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const deleteFeature = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { featureId } = req.params;

    const response = await featureService.deleteFeature(featureId as string);
    const { success, message, status, data } = response;
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles changing feature status
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const changeFeatureStatus = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { featureId } = req.params;
    const { isActive } = req.body;

    const response = await featureService.changeStatus(featureId as string, isActive);
    const { success, message, status, data } = response;
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};

/**
 * Handles reordering features
 * @param {Request} req
 * @param {Response} res
 * @param {NextFunction} next
 */
export const reorderFeatures = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const { featureIds } = req.body;

    const response = await featureService.reorderFeatures(featureIds);
    const { success, message, status, data } = response;
    if (success) {
      responseHandler(res, message, status, data);
    } else {
      next(new ErrorHandler(message, status, data));
    }
  } catch (error) {
    catchHandler(error, next);
  }
};
