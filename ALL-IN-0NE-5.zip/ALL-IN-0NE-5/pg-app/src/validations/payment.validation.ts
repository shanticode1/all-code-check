//Third-party modules
import Joi from 'joi';

// product
export const createProductionValidator = {
  body: Joi.object({
    name: Joi.string().required(),
    description: Joi.string().optional().allow(null).allow(''),
  }),
};
export const updateProductionValidator = {
  body: Joi.object({
    name: Joi.string().optional().allow(null).allow(''),
    description: Joi.string().optional().allow(null).allow(''),
  }),
};

// price/plan
export const createPriceValidator = {
  body: Joi.object({
    priceId: Joi.string().optional(), // Optional - not always provided
    productId: Joi.string().optional(), // Optional - can come from env
    name: Joi.string().optional(), // Optional - not always provided
    description: Joi.string().optional().allow(null).allow(''),
    currency: Joi.string().required(),
    amount: Joi.number().required(),
    interval: Joi.string().valid('day', 'week', 'month', 'year').required(), // Interval validation
    interval_count: Joi.number().optional(), // For quarterly (3 months)
    usageType: Joi.string().valid('metered', 'licensed').optional().default('licensed'),
    recurring: Joi.object({
      interval: Joi.string().valid('day', 'week', 'month', 'year').optional(),
      interval_count: Joi.number().optional(),
      usage_type: Joi.string().valid('metered', 'licensed').optional(),
    }).optional(),
    imageUrl: Joi.string().uri().optional().allow(null).allow(''), // Image URL to be stored in price metadata
    metadata: Joi.object().pattern(Joi.string(), Joi.string()).optional(), // Allow metadata object with string values
  }),
};

export const updatePriceValidator = {
  body: Joi.object({
    priceId: Joi.string().required(),
    name: Joi.string().optional(), // Optional - not always provided
    description: Joi.string().optional().allow(null).allow(''),
    currency: Joi.string().optional(), // Optional - may be immutable
    amount: Joi.number().optional(), // Optional - may be immutable
    imageUrl: Joi.string().uri().optional().allow(null).allow(''), // Image URL to be stored in price metadata
    metadata: Joi.object().pattern(Joi.string(), Joi.string()).optional(), // Allow metadata object with string values
  }),
};

// Customer
export const createCustomerValidator = {
  body: Joi.object({
    email: Joi.string().email().required(),
    name: Joi.string().required(),
    description: Joi.string().optional().allow(null).allow(''),
  }),
};
export const updateCustomerValidator = {
  body: Joi.object({
    customerId: Joi.string().email().required(),
    email: Joi.string().email().allow(null),
    name: Joi.string().optional().allow(null).allow(''),
    description: Joi.string().optional().allow(null).allow(''),
  }),
};

// Recurring Subscription (prepayment) - for checkout session
export const createCheckoutSessionValidator = {
  body: Joi.object({
    customerId: Joi.string().optional().allow(null).allow(''), // Optional - backend will check for existing
    priceId: Joi.string().required(),
    currency: Joi.string().required(),
    quantity: Joi.number().optional().default(1), // Optional, defaults to 1
    customerEmail: Joi.string().email().optional(), // Optional - for customer identification
    customerName: Joi.string().optional(), // Optional - for customer identification
    metadata: Joi.object({
      userId: Joi.string().optional(),
      planName: Joi.string().optional(),
      email: Joi.string().email().optional(), // Optional - fallback for email
      name: Joi.string().optional(), // Optional - fallback for name
    }).optional(),
    options: Joi.object({
      successUrl: Joi.string().required(),
      cancelUrl: Joi.string().required(),
      submitButtonText: Joi.string().optional(),
      usageType: Joi.string().optional(),
      defaultProductName: Joi.string().optional(),
      additionalMetadata: Joi.object().pattern(Joi.string(), Joi.string()).optional(),
      defaultCustomerName: Joi.string().optional(),
    }).required(), // Options object is required
  }),
};

// Recurring Subscription (prepayment) - for direct subscription creation
export const createSubscriptionValidator = {
  body: Joi.object({
    customerId: Joi.string().required(),
    priceId: Joi.string().required(),
    currency: Joi.string().required(),
    trialDays: Joi.number().required(),
  }),
};
export const updateSubscriptionValidator = {
  body: Joi.object({
    subscriptionId: Joi.string().optional().allow(null).allow(''),
    description: Joi.string().optional().allow(null).allow(''),
    quantity: Joi.number().optional().allow(null).allow(''),
  }),
};

// Recurring Subscription (postpayment)
export const createUsageSubscriptionValidator = {
  body: Joi.object({
    name: Joi.string().required(),
    description: Joi.string().optional().allow(null).allow(''),
  }),
};
export const updateUsageSubscriptionValidator = {
  body: Joi.object({
    name: Joi.string().optional().allow(null).allow(''),
    description: Joi.string().optional().allow(null).allow(''),
  }),
};

// one time payment
export const createOneTimePaymentValidator = {
  body: Joi.object({
    customerId: Joi.string().required(),
    priceId: Joi.string().required(),
    currency: Joi.string().required(),
    quantity: Joi.number().optional(),
  }),
};

// saved cards
export const createSavedCardSetupIntentValidator = {
  body: Joi.object({
    customerId: Joi.string().optional().allow(null).allow(''),
    customerEmail: Joi.string().email().optional().allow(null).allow(''),
    customerName: Joi.string().optional().allow(null).allow(''),
  }),
};

export const saveCardValidator = {
  body: Joi.object({
    paymentMethodId: Joi.string().required(),
    customerId: Joi.string().optional().allow(null).allow(''),
  }),
};
