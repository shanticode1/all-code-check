import { commonVariables, twoFAVariables } from '@constants';
import { TwoFAMethod, TwoFAFlow } from '@enums';
import Joi from 'joi';

export const activeValidator = {
  body: Joi.object({
    email: Joi.string().email().required(),
    isTwoAuthEnabled: Joi.boolean().required(),
    password: Joi.string().required(),
    twoFAMethodType: Joi.string()
      .valid(...Object.values(TwoFAMethod)) // Ensure the methodType is one of the allowed values
      .required(),
  }),
};

export const generateSecretValidator = {
  body: Joi.object({
    password: Joi.string().optional().default(null),
    twoFAMethodType: Joi.string()
      .valid(...Object.values(TwoFAMethod)) // Ensure the methodType is one of the allowed values
      .required(),
    phoneNumber: Joi.string().optional(),
    twoFAFlow: Joi.string()
      .valid(...Object.values(TwoFAFlow))
      .default(TwoFAFlow.VERIFY)
      .optional(),
    countryCode: Joi.string().max(commonVariables.COUNTRY_CODE_MAX_LENGTH).optional(),
  })
    .custom((value, helpers) => {
      if (value.twoFAMethodType === TwoFAMethod.PHONE && value.twoFAFlow === TwoFAFlow.SETUP) {
        if (!value.phoneNumber) {
          return helpers.error('any.custom', {
            message: 'phoneNumber is required.',
          });
        }

        if (!value.countryCode) {
          return helpers.error('any.custom', {
            message: 'countryCode is required',
          });
        }
      }
      return value;
    })
    .messages({
      'any.custom': '{{#message}}',
    }),
};

export const smsValidator = {
  body: Joi.object({
    phoneNumber: Joi.string().required(),
  }),
};

export const verifyCodeValidator = {
  body: Joi.object({
    otp: Joi.string().length(twoFAVariables.otpLength).required(),
    twoFAMethodType: Joi.string()
      .valid(...Object.values(TwoFAMethod))
      .default(TwoFAMethod.APP),
    phoneNumber: Joi.string().optional(),
    countryCode: Joi.string().optional(),
    twoFAFlow: Joi.string()
      .valid(...Object.values(TwoFAFlow))
      .default(TwoFAFlow.VERIFY)
      .optional(),
  }),
};

export const verifyRecoveryCodeValidator = {
  body: Joi.object({
    code: Joi.string().required(),
  }),
};

export const preferredTwoFaMethodValidator = {
  body: Joi.object({
    preferredTwoFAMethod: Joi.string().valid(...Object.values(TwoFAMethod)),
  }),
};
