import { SupportTicketStatus } from '@enums';
import Joi from 'joi';

const emailSettingsValidator = Joi.object({
  primaryEmail: Joi.string().email().required(),
  ccEmails: Joi.array().items(Joi.string().email()).default([]),
});

const formFieldValidator = Joi.object({
  key: Joi.string().trim().required(),
  enabled: Joi.boolean().required(),
  required: Joi.boolean().required(),
});

const formConfigValidator = Joi.object({
  enabled: Joi.boolean().required(),
  fields: Joi.array().items(formFieldValidator).min(1).required(),
});

const autoReplyValidator = Joi.object({
  enabled: Joi.boolean().required(),
  message: Joi.string().trim().allow('').optional(),
}).custom((value, helpers) => {
  if (value.enabled && !value.message) {
    return helpers.error('any.required', { key: 'message' });
  }
  return value;
});

export const supportConfigUpdateValidator = Joi.object({
  emailSettings: emailSettingsValidator.optional(),
  formConfig: formConfigValidator.optional(),
  autoReply: autoReplyValidator.optional(),
}).optional();

export const supportTicketValidator = Joi.object({
  fullName: Joi.string().trim().min(2),
  email: Joi.string().email(),
  subject: Joi.string().trim().min(3),
  category: Joi.string().trim(),
  message: Joi.string().trim().min(5),
  attachment: Joi.string().uri(), // or file id
});

export const updateTicketStatusValidator = Joi.object({
  status: Joi.string()
    .valid(...Object.values(SupportTicketStatus))
    .required(),
});
