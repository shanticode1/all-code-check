import Joi from 'joi';
//Constants
import { featureMessages, featureVariables } from '@constants';

// Feature validation schemas
export const createFeatureSchema = {
  body: Joi.object({
    value: Joi.string()
      .min(featureVariables.FEATURE_VALUE_MIN_LENGTH)
      .max(featureVariables.FEATURE_VALUE_MAX_LENGTH)
      .required()
      .trim()
      .messages({
        'string.min': featureMessages.FEATURE_VALUE_MIN_LENGTH_ERROR,
        'string.max': featureMessages.FEATURE_VALUE_MAX_LENGTH_ERROR,
        'any.required': featureMessages.FEATURE_VALUE_REQUIRED,
      }),
    label: Joi.string()
      .min(featureVariables.FEATURE_LABEL_MIN_LENGTH)
      .max(featureVariables.FEATURE_LABEL_MAX_LENGTH)
      .required()
      .trim()
      .messages({
        'string.min': featureMessages.FEATURE_LABEL_MIN_LENGTH_ERROR,
        'string.max': featureMessages.FEATURE_LABEL_MAX_LENGTH_ERROR,
        'any.required': featureMessages.FEATURE_LABEL_REQUIRED,
      }),
    type: Joi.string().valid('boolean', 'numeric', 'unlimited').optional().default('boolean').messages({
      'any.only': 'Feature type must be one of: boolean, numeric, unlimited',
    }),
    unit: Joi.string().max(50).optional().trim(),
    position: Joi.number().integer().min(0).optional(),
    isCore: Joi.boolean().optional(),
    isActive: Joi.boolean().optional(),
  }).unknown(false),
};

export const updateFeatureSchema = {
  params: Joi.object({
    featureId: Joi.string().required(),
  }).unknown(false),
  body: Joi.object({
    value: Joi.string()
      .min(featureVariables.FEATURE_VALUE_MIN_LENGTH)
      .max(featureVariables.FEATURE_VALUE_MAX_LENGTH)
      .optional()
      .trim()
      .messages({
        'string.min': featureMessages.FEATURE_VALUE_MIN_LENGTH_ERROR,
        'string.max': featureMessages.FEATURE_VALUE_MAX_LENGTH_ERROR,
      }),
    label: Joi.string()
      .min(featureVariables.FEATURE_LABEL_MIN_LENGTH)
      .max(featureVariables.FEATURE_LABEL_MAX_LENGTH)
      .optional()
      .trim()
      .messages({
        'string.min': featureMessages.FEATURE_LABEL_MIN_LENGTH_ERROR,
        'string.max': featureMessages.FEATURE_LABEL_MAX_LENGTH_ERROR,
      }),
    type: Joi.string().valid('boolean', 'numeric', 'unlimited').optional().messages({
      'any.only': 'Feature type must be one of: boolean, numeric, unlimited',
    }),
    unit: Joi.string().max(50).optional().trim(),
    position: Joi.number().integer().min(0).optional(),
    isCore: Joi.boolean().optional(),
    isActive: Joi.boolean().optional(),
  }).unknown(false),
};

export const updateFeatureStatusSchema = {
  body: Joi.object({
    isActive: Joi.boolean().required(),
  }).unknown(false),
};

export const getFeatureByIdSchema = {
  params: Joi.object({
    featureId: Joi.string().required(),
  }).unknown(false),
};

export const deleteFeatureSchema = {
  params: Joi.object({
    featureId: Joi.string().required(),
  }).unknown(false),
};

export const featureIdSchema = Joi.object({
  featureId: Joi.string().required(),
});

export const getFeaturesSchema = {
  query: Joi.object({
    page: Joi.number()
      .integer()
      .min(featureVariables.FEATURE_PAGE_MIN)
      .max(featureVariables.FEATURE_PAGE_MAX)
      .default(featureVariables.FEATURE_PAGE_DEFAULT),
    limit: Joi.number()
      .integer()
      .min(featureVariables.FEATURE_LIMIT_MIN)
      .max(featureVariables.FEATURE_LIMIT_MAX)
      .default(featureVariables.FEATURE_LIMIT_DEFAULT),
    search: Joi.string().optional(),
    sortBy: Joi.string()
      .valid(...featureVariables.FEATURE_SORT_FIELDS)
      .default(featureVariables.FEATURE_DEFAULT_SORT_BY),
    orderBy: Joi.string()
      .valid(...featureVariables.FEATURE_ORDER_OPTIONS)
      .default(featureVariables.FEATURE_DEFAULT_ORDER_BY),
  }).unknown(false),
};

export const changeStatusSchema = {
  params: Joi.object({
    featureId: Joi.string().required(),
  }).unknown(false),
  body: Joi.object({
    isActive: Joi.boolean().required(),
  }).unknown(false),
};

export const reorderFeaturesSchema = {
  body: Joi.object({
    featureIds: Joi.array().items(Joi.string()).min(1).required().messages({
      'array.min': 'At least one feature ID is required',
      'any.required': 'Feature IDs array is required',
    }),
  }).unknown(false),
};
