import chalk from 'chalk';
import { commonHandler } from '@utils';

export const logger = {
  log: (message: string) => {
    if (commonHandler.isLogger) {
      console.log(chalk.gray(`[LOG]: ${message}`));
    }
  },

  info: (info: string) => {
    if (commonHandler.isLogger) {
      console.info(chalk.blue(`[INFO]: ${info}`));
    }
  },

  error: (error: Error | string) => {
    if (commonHandler.isLogger) {
      const message = error instanceof Error ? error.message : error;
      console.error(chalk.red(`[ERROR]: ${message}`));
    }
  },

  success: (message: string) => {
    if (commonHandler.isLogger) {
      console.log(chalk.green(`[SUCCESS]: ${message}`));
    }
  },

  warn: (message: string) => {
    if (commonHandler.isLogger) {
      console.warn(chalk.yellow(`[WARN]: ${message}`));
    }
  },
};
