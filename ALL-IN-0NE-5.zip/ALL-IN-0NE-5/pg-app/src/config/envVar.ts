import { commonMessages } from '@constants';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

const requiredEnvVars = [
  'NODE_ENV',
  'PORT',
  'HOST',
  'API_URL',
  'JWT_SECRET',
  'AUTH_COOKIE_NAME',
  'CORS_ORIGIN',
  'REQUEST_BODY_LIMIT',
  'AWS_REGION',
  'AWS_ACCESS_KEY_ID',
  'AWS_SECRET_ACCESS_KEY',
  'BUCKET_NAME',
  'GOOGLE_CLIENT_ID',
  'GOOGLE_CLIENT_SECRET',
  'GOOGLE_CALLBACK_URL',
  'FACEBOOK_CLIENT_ID',
  'FACEBOOK_CLIENT_SECRET',
  'FACEBOOK_CALLBACK_URL',
  'SMTP_MAIL_SERVICE',
  'SMTP_SENDER_EMAIL',
  'SMTP_SENDER_PASSWORD',
  'SMTP_HOST',
  'SMTP_PORT',
  'SMTP_IS_SECURE',
  'TWILIO_ACCOUNT_SID',
  'TWILIO_AUTH_TOKEN',
  'TWILIO_SERVICE_SID',
  'AUTH_TOKEN_APP_NAME',
  'STRIPE_SECRET_KEY',
  'STRIPE_WEBHOOK_SECRET',
  'REDIS_URL',
  'DATABASE_URL',
  'TWOFA_REQUIRED',
  'ENCRYPTION_SECRET_KEY_RECOVER_CODE',
  'TWO_FA_RECOVERY_CODE_COUNT',
  'FRONTEND_BASE_URL',
  'FRONTEND_VERIFY_PATH',
  'FRONTEND_SET_PASSWORD_PATH',
  'FRONTEND_RESET_PASSWORD_PATH',
  'BASE_URL',
  'ENCRYPTION_SECRET_KEY',
];
// Object to hold exported environment variables
const env: Record<string, string> = {};
// Ensure all required variables are present and add them to `env`
requiredEnvVars.forEach((key) => {
  const value = process.env[key];
  if (!value) {
    throw new Error(`${commonMessages.MISSING_ENV_VARIABLES}: ${key}`);
  }
  env[key] = value; // Dynamically add to the export object
});
export default env;
