import type {
  ICreatePlanEntitlementRequest,
  IUpdatePlanEntitlementRequest,
  IPlanEntitlementResponse,
} from '@customTypes';
import { NOT_FOUND, OK, SERVER_ERROR, commonMessages, planEntitlementMessages } from '@constants';
import { prismaService } from '@services';
import { logger } from '@config/logger';

export const getPlanEntitlementByFilter = async (filter: any) => {
  try {
    // return await prismaService.findFirstRecord('planEntitlement', filter);

    const planEntitlements = await prismaService.getRecords('planEntitlement', {
      where: filter,
      include: {
        entitlements: {
          select: {
            id: true,
            planEntitlementId: true,
            featureId: true,
            featureValue: true,
            type: true,
            limit: true,
            unit: true,
            createdAt: true,
            updatedAt: true,
          },
        },
      },
    });
    return planEntitlements.length > 0 ? planEntitlements[0] : null;
  } catch (error) {
    logger.error(`Error fetching plan entitlement: ${error}`);
    return null;
  }
};

export const planEntitlementModelToDomain = (doc: any): IPlanEntitlementResponse => {
  return {
    id: doc.id?.toString() || '',
    priceId: doc.priceId,
    entitlements: doc.entitlements || [],
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt,
  };
};

export const createOrUpdatePlanEntitlements = async (
  data: ICreatePlanEntitlementRequest,
): Promise<{ status: number; success: boolean; message: string; data: null | IPlanEntitlementResponse }> => {
  try {
    const planEntitlement = await prismaService.upsertRecord(
      'planEntitlement',
      { priceId: data.priceId },
      {
        priceId: data.priceId,
        entitlements: {
          create: data.entitlements.map((item: any) => ({
            featureId: item.featureId,
            featureValue: item.featureValue,
            type: item.type,
            limit: item.limit,
            unit: item.unit,
          })),
        },
      },
      {
        isDeleted: false,
        deletedAt: null,
        entitlements: {
          deleteMany: {},
          create: data.entitlements.map((item: any) => ({
            featureId: item.featureId,
            featureValue: item.featureValue,
            type: item.type,
            limit: item.limit,
            unit: item.unit,
          })),
        },
      },
    );

    return {
      status: OK,
      success: true,
      message: planEntitlementMessages.PLAN_ENTITLEMENT_CREATED_SUCCESS,
      data: planEntitlementModelToDomain(planEntitlement),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Gets plan entitlements by price ID
 * @param {string} priceId - The Stripe price ID
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | IPlanEntitlementResponse}>}
 */
export const getPlanEntitlementsByPriceId = async (
  priceId: string,
): Promise<{ status: number; success: boolean; message: string; data: null | IPlanEntitlementResponse }> => {
  try {
    const planEntitlement = await getPlanEntitlementByFilter({
      priceId,
      isDeleted: false,
    });

    if (!planEntitlement) {
      return {
        status: NOT_FOUND,
        success: false,
        message: planEntitlementMessages.PLAN_ENTITLEMENT_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: planEntitlementMessages.PLAN_ENTITLEMENT_FETCH_SUCCESS,
      data: planEntitlementModelToDomain(planEntitlement),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Gets plan entitlements by multiple price IDs (batch)
 * @param {string[]} priceIds - Array of Stripe price IDs
 * @returns {Promise<{status: number, success: boolean, message: string, data: IPlanEntitlementResponse[]}>}
 */
export const getPlanEntitlementsByPriceIds = async (
  priceIds: string[],
): Promise<{ status: number; success: boolean; message: string; data: IPlanEntitlementResponse[] }> => {
  try {
    const where = {
      priceId: {
        in: priceIds,
      },
      isDeleted: false,
    };

    const planEntitlements = await prismaService.getRecords('planEntitlement', {
      where: where,
      include: {
        entitlements: {
          select: {
            id: true,
            planEntitlementId: true,
            featureId: true,
            featureValue: true,
            type: true,
            limit: true,
            unit: true,
            createdAt: true,
            updatedAt: true,
          },
        },
      },
    });

    return {
      status: OK,
      success: true,
      message: planEntitlementMessages.PLAN_ENTITLEMENT_FETCH_SUCCESS,
      data: planEntitlements.map(planEntitlementModelToDomain),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: [],
    };
  }
};

/**
 * Updates plan entitlements
 * @param {string} priceId - The Stripe price ID
 * @param {IUpdatePlanEntitlementRequest} data - The update data
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | IPlanEntitlementResponse}>}
 */
export const updatePlanEntitlements = async (
  priceId: string,
  data: IUpdatePlanEntitlementRequest,
): Promise<{ status: number; success: boolean; message: string; data: null | IPlanEntitlementResponse }> => {
  try {
    const planEntitlement = await getPlanEntitlementByFilter({ priceId, isDeleted: false });

    if (!planEntitlement) {
      return {
        status: NOT_FOUND,
        success: false,
        message: planEntitlementMessages.PLAN_ENTITLEMENT_NOT_FOUND,
        data: null,
      };
    }

    const updateData = {
      ...(data.entitlements !== undefined && { entitlements: data.entitlements }),
    };
    const planEntitlementUpdatedRecord = await prismaService.updateRecord('planEntitlement', updateData, {
      priceId,
      isDeleted: false,
    });

    return {
      status: OK,
      success: true,
      message: planEntitlementMessages.PLAN_ENTITLEMENT_UPDATED_SUCCESS,
      data: planEntitlementModelToDomain(planEntitlementUpdatedRecord),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Deletes plan entitlements (soft delete)
 * @param {string} priceId - The Stripe price ID
 * @returns {Promise<{status: number, success: boolean, message: string, data: null}>}
 */
export const deletePlanEntitlements = async (
  priceId: string,
): Promise<{ status: number; success: boolean; message: string; data: null }> => {
  try {
    const updateData = {
      isDeleted: true,
      deletedAt: new Date(),
    };
    await prismaService.updateRecord('planEntitlement', updateData, { priceId, isDeleted: false });

    return {
      status: OK,
      success: true,
      message: planEntitlementMessages.PLAN_ENTITLEMENT_DELETED_SUCCESS,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};
