import bcrypt from 'bcryptjs';

import { logger } from '@config/logger';
import { BAD_REQUEST, OK, commonMessages, emailTemplatesVariables, twoFAMessages, twoFAVariables } from '@constants';
import type { IApiResponse, IRecoveryCode, ISendSmsCodeBody, IUser, IVerifyOtpBody } from '@customTypes';
import { TwoFAMethod, TwoFAFlow } from '@enums';
import { prismaService, userCommonService } from '@services';
import { emailHandler, generateTokenHandler, twoFAHandler } from '@utils';
import type { Response } from 'express';
import {
  SELECTED_TWO_FA_METHOD_NOT_ENABLED,
  TOKEN_SENT,
  USER_TWO_FA_SELECTED_METHOD_NOT_CONFIGURED,
} from '../constants/messages/twoFA.message';
import { charSet, otpLength } from '../constants/variables/twoFA.variables';

/**
 * Handles enabling or disabling two factor authentication.
 * @param {string} email - Email of the user
 * @param {string} password - Password of the user
 * @param {boolean} isTwoAuthEnabled - Two factor authentication status
 * @param {TwoFAMethod} twoFAMethodType - Two factor authentication method type
 * @returns {Promise<IApiResponse>} - The response
 */
export const activeTwoFAAuthentication = async (
  email: string,
  password: string,
  isTwoAuthEnabled: boolean,
  twoFAMethodType: TwoFAMethod,
): Promise<IApiResponse> => {
  try {
    // Check if the methodType is valid
    if (!Object.values(TwoFAMethod).includes(twoFAMethodType)) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: twoFAMessages.INVALID_TWOFA_METHOD,
        data: null,
      };
    }
    const userDoc = await userCommonService.getUserByEmail(email);
    if (!userDoc || !(await bcrypt.compare(password, userDoc.password)))
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };

    // Additional check for PHONE method: user must have phone number
    if (isTwoAuthEnabled && twoFAMethodType === TwoFAMethod.PHONE && (!userDoc.phoneNumber || !userDoc.countryCode)) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: twoFAMessages.PHONE_2FA_ACTIVATION_ERROR,
        data: null,
      };
    }

    const currentTwoFaMethodConfig = userDoc?.configuredTwoFAMethods?.find(
      (configuredTwoFAMethod: { methodType: TwoFAMethod }) => {
        return configuredTwoFAMethod.methodType === twoFAMethodType;
      },
    );

    const updates = {
      configuredTwoFAMethods: [
        {
          methodType: twoFAMethodType,
          isEnabled: isTwoAuthEnabled,
          isPreferredTwoFAMethod:
            currentTwoFaMethodConfig?.isPreferredTwoFAMethod && isTwoAuthEnabled
              ? currentTwoFaMethodConfig?.isPreferredTwoFAMethod
              : false,
        },
      ],
    };

    // save generated otp in db for verification
    const updatedUserDoc = await userCommonService.updateUserByEmail(email, updates);
    return {
      status: OK,
      success: true,
      message: isTwoAuthEnabled ? twoFAMessages.USER_TWOFA_ACTIVATED : twoFAMessages.USER_TWOFA_DEACTIVATED,
      data: {
        isTwoAuthEnabled: updatedUserDoc ? updatedUserDoc.isTwoAuthEnabled : null,
        token: null,
        role: updatedUserDoc?.role,
      },
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error while active TwoFA: ${errorMessage}`);
  }
};

/**
 * Handles sending the two factor authentication code to the user's registered email.
 * @param {string} email - Email of the user
 * @param {string | null} password - Password of the user
 * @returns {Promise<IApiResponse>} - The response
 */
export const sendOtpToMail = async (email: string, password: string | null): Promise<IApiResponse> => {
  try {
    const userDoc = await userCommonService.getUserByEmail(email);
    if (!userDoc)
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };
    if (password && !(await bcrypt.compare(password, userDoc.password))) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };
    }
    /** save secret token for verify user which TwoFA process */
    const rawOtp = await twoFAHandler.generateTwoFAEmailOTP(otpLength, charSet);
    // send generated otp in user registered mail
    await emailHandler.sendEmailBySlug({
      toEmail: email,
      toName: `${userDoc.name}`,
      templateName: emailTemplatesVariables.emailTemplates[3].slug,
      data: { otp: rawOtp },
    });
    // save generated otp in db for verification
    const updates = {
      emailOtp: twoFAHandler.hashEmailOtp(rawOtp),
    };
    await userCommonService.updateUserByEmail(email, updates);
    return {
      status: OK,
      success: true,
      message: TOKEN_SENT,
      data: null,
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error verifying token: ${errorMessage}`);
  }
};

/**
 * Sends the two-factor authentication code to the user's registered phone number.
 * @param {ISendSmsCodeBody} sendSmsCodeBody - The phone number, email, isInSetupProcess of the user.
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */

export const sendSmsCode = async (sendSmsCodeBody: ISendSmsCodeBody): Promise<IApiResponse> => {
  try {
    let phoneNumberWithCode = '';
    if (sendSmsCodeBody.twoFAFlow === TwoFAFlow.VERIFY) {
      const user = await userCommonService.getUserByEmail(sendSmsCodeBody.email);
      if (!user)
        return {
          status: BAD_REQUEST,
          success: false,
          message: commonMessages.INVALID_CREDENTIALS,
          data: null,
        };
      const isMethodConfigured = user.configuredTwoFAMethods?.some(
        (dt: { methodType: TwoFAMethod }) => dt.methodType === TwoFAMethod.PHONE,
      );
      if (!isMethodConfigured) {
        return {
          status: BAD_REQUEST,
          success: false,
          message: USER_TWO_FA_SELECTED_METHOD_NOT_CONFIGURED,
          data: null,
        };
      }
      phoneNumberWithCode = `${user.countryCode}${user.phoneNumber}`;
    } else {
      phoneNumberWithCode = `${sendSmsCodeBody.countryCode}${sendSmsCodeBody.phoneNumber}`;
      await userCommonService.updateUserByEmail(sendSmsCodeBody.email, {
        countryCode: sendSmsCodeBody.countryCode,
        phoneNumber: sendSmsCodeBody.phoneNumber,
      });
    }
    await twoFAHandler.sendSmsToUser(phoneNumberWithCode, twoFAVariables.TWILO_CHANNEL);
    return {
      status: OK,
      success: true,
      message: twoFAMessages.VERIFICATION_CODE_TO_PHONE,
      data: null,
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error verifying token: ${errorMessage}`);
  }
};

/**
 * Generates a QR code for the two-factor authentication setup process.
 * @param {string} email - The email of the user.
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */
export const createQRCode = async (email: string): Promise<IApiResponse> => {
  try {
    const userDoc = await userCommonService.getUserByEmail(email);
    if (!userDoc)
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };
    const secretToken = await twoFAHandler.generateAppTokenSecret(email);
    const recoveryCodes = await twoFAHandler.generateRecoveryCodes();
    const updates = {
      appToken: secretToken,
      recoveryCodes: recoveryCodes.encryptedCodes,
    };

    await userCommonService.updateUserByEmail(email, updates);
    /** save secret token for verify user which TwoFA process */
    const qrCodeUrl = await twoFAHandler.generateAppQR(secretToken);
    return {
      status: OK,
      success: true,
      message: twoFAMessages.VERIFICATION_CODE_TO_APP,
      data: { qrCodeUrl: qrCodeUrl, setupKey: secretToken.base32, recoveryCodes: recoveryCodes.plainCodes },
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error verifying token: ${errorMessage}`);
  }
};

/**
 * Handles verifying the two factor authentication code
 * @param {IVerifyOtpBody} verifyOtpBody
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */
export const verifyTwoFaCode = async (verifyOtpBody: IVerifyOtpBody): Promise<IApiResponse> => {
  try {
    const user = await prismaService.findFirstRecord(
      'user',
      {
        email: verifyOtpBody.email.toLowerCase(),
        isDeleted: false,
      },
      {
        select: {
          firstName: true,
          email: true,
          role: true,
          phoneNumber: true,
          countryCode: true,
          avatar: true,
          status: true,
          isVerified: true,
          isDeleted: true,
          emailOtp: true,
          isTwoAuthEnabled: true,
          hasAcceptedTerms: true,
          lastLogin: true,
          configuredTwoFAMethods: true,
          recoveryCodes: true,
          createdAt: true,
          updatedAt: true,
          id: true,
          appToken: true,
        },
      },
    );
    if (!user)
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };
    if (verifyOtpBody.twoFAFlow === TwoFAFlow.VERIFY) {
      if (!user.isTwoAuthEnabled) {
        return {
          status: OK,
          success: true,
          message: twoFAMessages.VERIFICATION_NOT_ACTIVE,
          data: null,
        };
      }

      let isMethodConfigured = false;
      let isMethodEnable = false;
      if (user.configuredTwoFAMethods && user.configuredTwoFAMethods.length > 0) {
        for (const configuredMethod of user.configuredTwoFAMethods) {
          if (configuredMethod.methodType === verifyOtpBody.twoFAMethodType) {
            isMethodConfigured = true;
            if (configuredMethod.isEnabled) {
              isMethodEnable = true;
            }
            break;
          }
        }
      }
      if (!isMethodConfigured) {
        return {
          status: BAD_REQUEST,
          success: false,
          message: USER_TWO_FA_SELECTED_METHOD_NOT_CONFIGURED,
          data: null,
        };
      }
      if (!isMethodEnable) {
        return {
          status: BAD_REQUEST,
          success: false,
          message: SELECTED_TWO_FA_METHOD_NOT_ENABLED,
          data: null,
        };
      }
    }
    let verifyResp = { success: false, message: '' };
    switch (verifyOtpBody.twoFAMethodType) {
      case TwoFAMethod.EMAIL: {
        const verifyEmailOTPResult = await verifyTwoFAOTPGatewayForEmail(
          verifyOtpBody.email,
          verifyOtpBody.inputOTP,
          user.emailOtp,
        );
        verifyResp = {
          success: verifyEmailOTPResult.success,
          message: verifyEmailOTPResult.message,
        };
        break;
      }
      case TwoFAMethod.PHONE: {
        const verifySMSOTPResult = await twoFAHandler.verifySmsOTP(
          `${user.countryCode}${user.phoneNumber}`,
          verifyOtpBody.inputOTP,
        );
        verifyResp = {
          success: verifySMSOTPResult.success,
          message: verifySMSOTPResult.message,
        };
        break;
      }
      case TwoFAMethod.APP: {
        const verifyAPPOTPResult = await twoFAHandler.verifyAppOtp(verifyOtpBody.inputOTP, user.appToken);
        verifyResp = {
          success: verifyAPPOTPResult.success,
          message: verifyAPPOTPResult.message,
        };
        break;
      }
    }

    if (verifyResp.success) {
      // This code is will update otp to '' & if it is called in setup process then it will also enable preferred method
      const update = { emailOtp: '', configuredTwoFAMethods: user.configuredTwoFAMethods };
      if (verifyOtpBody.twoFAFlow === TwoFAFlow.SETUP) {
        update.configuredTwoFAMethods = [
          { methodType: verifyOtpBody.twoFAMethodType, isEnabled: true, isPreferredTwoFAMethod: false },
        ];
      }
      await userCommonService.updateUserByEmail(verifyOtpBody.email, update);
    }
    const payload = {
      id: user.id,
      email: user.email,
      role: user.role,
      isTWOFaVerified: true,
    };
    return {
      status: verifyResp.success ? OK : BAD_REQUEST,
      success: verifyResp.success,
      message: verifyResp.message || twoFAMessages.SOMETHING_WRONG,
      data: verifyResp.success
        ? { token: await generateTokenHandler.generateAuthToken(verifyOtpBody.res, payload), role: user.role }
        : null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    logger.error(errorMessage);
    throw new Error(`Error verifying token: ${errorMessage}`);
  }
};

/**
 * Handles verifying the recovery code
 * @param {string} email
 * @param {string} providedCode - Recovery code entered by the user
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */
export const validateRecoveryCode = async (
  email: string,
  providedCode: string,
  res: Response,
): Promise<IApiResponse> => {
  try {
    const userDoc = await userCommonService.getUserByEmail(email);
    if (!userDoc) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };
    }

    if (userDoc.recoveryCodes.length === 0) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: twoFAMessages.RECOVERY_CODE_NOT_GENERATED,
        data: null,
      };
    }

    const decryptedRecoveryCodes = await twoFAHandler.decryptRecoveryCodes(userDoc.recoveryCodes);

    const payload = {
      id: userDoc.id,
      email: userDoc.email,
      role: userDoc.role,
      isTWOFAVerified: true,
    };

    for (const [index, decryptedCode] of decryptedRecoveryCodes.entries()) {
      const recovery = userDoc.recoveryCodes[index];
      if (recovery.used) continue;

      if (decryptedCode === providedCode) {
        await prismaService.updateRecord('user', { lastLogin: new Date() }, { id: userDoc.id });

        return {
          status: OK,
          success: true,
          message: twoFAMessages.VALID_RECOVERY_CODE,
          data: {
            token: await generateTokenHandler.generateAuthToken(res, payload),
            role: userDoc.role,
          },
        };
      }
    }
    return {
      status: BAD_REQUEST,
      success: false,
      message: twoFAMessages.INVALID_RECOVERY_CODE,
      data: null,
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error verifying token: ${errorMessage}`);
  }
};

/**
 * Handles fetching recovery code
 * @param {IRecoveryCode[]} recoveryCodes - Recovery code stored in db
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */
export const getRecoveryCodes = async (recoveryCodes: IRecoveryCode[]): Promise<IApiResponse> => {
  try {
    if (recoveryCodes.length === 0) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: twoFAMessages.RECOVERY_CODE_NOT_GENERATED,
        data: null,
      };
    }
    const decryptedRecoveryCodes = await twoFAHandler.decryptRecoveryCodes(recoveryCodes);
    return {
      status: OK,
      success: true,
      message: twoFAMessages.RECOVERY_CODES_RETRIEVED,
      data: { recoveryCodes: decryptedRecoveryCodes },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error retrieving recovery code: ${errorMessage}`);
  }
};

/**
 * Handles regenerate recovery code
 * @param {IUser[]} user
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */
export const regenerateRecoveryCodes = async (user: IUser): Promise<IApiResponse> => {
  try {
    const generatedRecoveryCodes = await twoFAHandler.generateRecoveryCodes();

    await prismaService.updateRecord('user', { recoveryCodes: generatedRecoveryCodes.encryptedCodes }, { id: user.id });

    return {
      status: OK,
      success: true,
      message: twoFAMessages.RECOVERY_CODES_RETRIEVED,
      data: { recoveryCodes: generatedRecoveryCodes.plainCodes },
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error regenerate recovery code: ${errorMessage}`);
  }
};

/**
 * It's gateway for handle verifying the two factor email authentication code
 * @param {string} email - Email of the user
 * @param {string} inputOTP - code entered by the user
 * @param {string} generatedOTP - code which was generated earlier & stored in db.
 * @returns {Promise<{success: boolean, message: string}>} - The response indicating the success or failure of the operation.
 */
export const verifyTwoFAOTPGatewayForEmail = async (email: string, inputOTP: string, storedOtpHash: string) => {
  try {
    console.log('otp------', storedOtpHash);

    if (!twoFAHandler.verifyEmailOtp(inputOTP, storedOtpHash)) {
      return {
        success: false,
        message: twoFAMessages.INVALID_OTP,
      };
    }
    await userCommonService.updateUserByEmail(email, { emailOtp: '' });
    return {
      success: true,
      message: twoFAMessages.SUCCESS,
    };
  } catch (error) {
    logger.error(`Error in verifyTwoFAOTPGatewayForEmail: ${error}`);
    return {
      success: false,
      message: twoFAMessages.SOMETHING_WRONG,
    };
  }
};

/**
 * Handles updating user PreferredTwoFaMethod
 * @param {string} email - Email of the user
 * @param {string} providedCode - Recovery code entered by the user
 * @returns {Promise<IApiResponse>} - The response indicating the success or failure of the operation.
 */
export const setPreferredTwoFaMethod = async (
  email: string,
  preferredTwoFAMethod: TwoFAMethod,
): Promise<IApiResponse> => {
  try {
    const userDoc = await userCommonService.getUserByEmail(email);
    if (!userDoc)
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.INVALID_CREDENTIALS,
        data: null,
      };

    const methodConfigured = userDoc.configuredTwoFAMethods?.find(
      (configuredTwoFAMethod: { methodType: TwoFAMethod }) => configuredTwoFAMethod.methodType === preferredTwoFAMethod,
    );
    if (!methodConfigured) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: USER_TWO_FA_SELECTED_METHOD_NOT_CONFIGURED,
        data: null,
      };
    }
    if (!methodConfigured.isEnabled) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: SELECTED_TWO_FA_METHOD_NOT_ENABLED,
        data: null,
      };
    }

    const update = {
      configuredTwoFAMethods: [
        {
          methodType: methodConfigured.methodType,
          isEnabled: methodConfigured.isEnabled,
          isPreferredTwoFAMethod: true,
        },
      ],
    };
    await userCommonService.updateUserByEmail(email, update);

    return {
      status: OK,
      success: true,
      message: twoFAMessages.PREFERRED_TWO_FA_METHOD_UPDATED_SUCCESSFULLY,
      data: null,
    };
  } catch (error) {
    /** add log for verify response */
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    throw new Error(`Error updating preferred TwoFA method: ${errorMessage}`);
  }
};
