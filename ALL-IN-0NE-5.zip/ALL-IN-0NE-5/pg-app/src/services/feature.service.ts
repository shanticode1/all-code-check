import { logger } from '@config/logger';
import { BAD_REQUEST, CONFLICT, CREATED, OK, SERVER_ERROR, commonMessages, featureMessages } from '@constants';
import type { IApiResponse, ICreateFeatureRequest, IFeature, IUpdateFeatureRequest } from '@customTypes';
import { prismaService } from '@services';
import { featureHandler } from '@utils';

/**
 * Get Feature
 * @param featureFilter
 * @returns
 */
export const getPlanFeatures = async (filter: any) => {
  try {
    // userSubscription
    return await prismaService.findFirstRecord('feature', filter);
  } catch (error) {
    logger.error(`Error fetching active subscription: ${error}`);
    return null;
  }
};

/**
 * Create a new feature
 */
export const createFeature = async (featureData: ICreateFeatureRequest): Promise<IApiResponse> => {
  try {
    // Check if feature with same value already exists (case-insensitive, excluding soft-deleted)
    const featureFilter = {
      value: {
        equals: featureData.value,
        mode: 'insensitive',
      },
      isDeleted: false,
    };
    const existingFeature = await getPlanFeatures(featureFilter);

    if (existingFeature) {
      return {
        status: CONFLICT,
        success: false,
        message: featureMessages.FEATURE_ALREADY_EXISTS,
        data: null,
      };
    }

    // Get the highest position and increment by 1 for new feature
    const highestPositionFeature = await prismaService.findFirstRecord(
      'feature',
      {
        isDeleted: false,
      },
      {
        orderBy: {
          position: 'desc',
        },
        select: {
          position: true,
        },
      },
    );
    const nextPosition = highestPositionFeature ? highestPositionFeature.position + 1 : 0;

    // Create feature
    const savedFeature = await prismaService.createRecord('feature', {
      ...featureData,
      position: featureData.position ?? nextPosition,
      isCore: featureData.isCore ?? false,
      isActive: featureData.isActive ?? true,
    });
    const result = featureHandler.featureModelToDomain(savedFeature);

    return {
      status: CREATED,
      success: true,
      message: featureMessages.FEATURE_CREATED_SUCCESS,
      data: result,
    };
  } catch (error) {
    logger.error(`Error creating feature: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Get all features with pagination and search
 */
export const getFeatures = async (
  page = 1,
  limit = 100,
  search?: string,
  sortBy = 'position',
  orderBy = 'asc',
): Promise<IApiResponse> => {
  try {
    const skip = (page - 1) * limit;

    /* =============================
       🔎 Build Where Condition
    ============================== */

    const where: any = {
      isDeleted: false,
    };

    if (search) {
      where.OR = [
        {
          value: {
            contains: search,
            mode: 'insensitive',
          },
        },
        {
          label: {
            contains: search,
            mode: 'insensitive',
          },
        },
      ];
    }

    /* =============================
       📦 Fetch Count + Records
    ============================== */

    const [total, features] = await Promise.all([
      prismaService.getCounts('feature', where),
      prismaService.getRecords('feature', {
        where,
        orderBy: {
          [sortBy]: orderBy,
        },
        skip,
        take: limit,
      }),
    ]);

    /* =============================
       🎨 Format Response
    ============================== */
    const data = {
      total,
      features: features.map((feature: IFeature) => featureHandler.featureModelToDomain(feature)),
    };

    return {
      status: OK,
      success: true,
      message: featureMessages.FEATURES_FETCH_SUCCESS,
      data,
    };
  } catch (error) {
    logger.error(`Error fetching features: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Get a specific feature by ID
 */
export const getFeatureById = async (featureId: string): Promise<IApiResponse> => {
  try {
    const feature = await getPlanFeatures({ id: Number(featureId), isDeleted: false });

    if (!feature) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: featureMessages.FEATURE_NOT_FOUND,
        data: null,
      };
    }

    const result = featureHandler.featureModelToDomain(feature);

    return {
      status: OK,
      success: true,
      message: featureMessages.FEATURE_FETCH_SUCCESS,
      data: result,
    };
  } catch (error) {
    logger.error(`Error fetching feature by ID: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Update a feature
 */
export const updateFeature = async (featureId: string, updateData: IUpdateFeatureRequest): Promise<IApiResponse> => {
  try {
    // Check if feature exists
    const existingFeature = await getPlanFeatures({ id: Number(featureId), isDeleted: false });

    if (!existingFeature) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: featureMessages.FEATURE_NOT_FOUND,
        data: null,
      };
    }

    // If value is being updated, check for duplicates (case-insensitive, excluding soft-deleted)
    if (updateData.value && updateData.value.toLowerCase() !== existingFeature.value.toLowerCase()) {
      const featureFilter = {
        value: {
          equals: updateData.value,
          mode: 'insensitive',
        },
        isDeleted: false,
        id: {
          not: Number(featureId),
        },
      };
      const duplicateFeature = await getPlanFeatures(featureFilter);

      if (duplicateFeature) {
        return {
          status: CONFLICT,
          success: false,
          message: featureMessages.FEATURE_ALREADY_EXISTS,
          data: null,
        };
      }
    }

    // feature
    const updatedFeature = await prismaService.updateRecord('feature', { ...updateData }, { id: Number(featureId) });
    const result = featureHandler.featureModelToDomain(updatedFeature);

    return {
      status: OK,
      success: true,
      message: featureMessages.FEATURE_UPDATED_SUCCESS,
      data: result,
    };
  } catch (error) {
    logger.error(`Error updating feature: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Delete a feature (soft delete)
 */
export const deleteFeature = async (featureId: string): Promise<IApiResponse> => {
  try {
    // Check if feature exists
    const feature = await getPlanFeatures({ id: Number(featureId), isDeleted: false });

    if (!feature) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: featureMessages.FEATURE_NOT_FOUND,
        data: null,
      };
    }
    // Soft delete
    const updateData = {
      isDeleted: true,
      deletedAt: new Date(),
    };
    // feature
    await prismaService.updateRecord('feature', updateData, { id: Number(featureId) });

    return {
      status: OK,
      success: true,
      message: featureMessages.FEATURE_DELETE_SUCCESS,
      data: null,
    };
  } catch (error) {
    logger.error(`Error deleting feature: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Change feature status
 */
export const changeStatus = async (featureId: string, isActive: boolean): Promise<IApiResponse> => {
  try {
    // Check if feature exists
    const feature = await getPlanFeatures({ id: Number(featureId), isDeleted: false });

    if (!feature) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: featureMessages.FEATURE_NOT_FOUND,
        data: null,
      };
    }

    // Update status
    await prismaService.updateRecord('feature', { isActive: isActive }, { id: feature.id });

    const result = featureHandler.featureModelToDomain(feature);

    return {
      status: OK,
      success: true,
      message: featureMessages.FEATURE_STATUS_UPDATED,
      data: result,
    };
  } catch (error) {
    logger.error(`Error changing feature status: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Reorder features (bulk update positions)
 */
export const reorderFeatures = async (featureIds: string[]): Promise<IApiResponse> => {
  try {
    // Validate all feature IDs
    const featIdas: number[] = featureIds.map(Number);

    // Update positions in bulk
    await Promise.all(
      featIdas.map((featureId, index) =>
        prismaService.updateRecord('feature', { position: index }, { id: featureId, isDeleted: false }),
      ),
    );

    return {
      status: OK,
      success: true,
      message: featureMessages.FEATURE_UPDATED_SUCCESS,
      data: null,
    };
  } catch (error) {
    logger.error(`Error reordering features: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};
