import { logger } from '@config/logger';
import {
  FORBIDDEN,
  NOT_FOUND,
  OK,
  SERVER_ERROR,
  commonMessages,
  exampleEntitlementsMessages,
  exampleEntitlementsVariables,
  paymentVariables,
} from '@constants';
import type { IApiResponse, IFeatureEntitlement, IFormattedEntitlement, IUsageMeta } from '@customTypes';
import { entitlementService } from '@services';

/**
 * Format entitlements for display
 */
const formatEntitlements = (entitlements: IFeatureEntitlement[]): IFormattedEntitlement[] => {
  return entitlements.map((ent) => ({
    feature: ent.featureValue,
    label: ent.featureValue.replace(/-/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase()),
    type: ent.type,
    limit: ent.limit,
    currentUsage: ent.currentUsage,
    unit: ent.unit,
    resetPeriod: ent.resetPeriod,
    percentage:
      ent.limit === paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
        ? 0
        : Math.round((ent.currentUsage / (ent.limit as number)) * 100),
    remaining:
      ent.limit === paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
        ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
        : (ent.limit as number) - ent.currentUsage,
  }));
};

/**
 * Get API data with usage tracking
 */
export const getApiData = async (userId: string): Promise<IApiResponse & { meta?: IUsageMeta }> => {
  try {
    const usage = await entitlementService.getCurrentUsage(
      userId,
      exampleEntitlementsVariables.FEATURE_VALUE_API_REQUESTS_PER_MONTH,
    );

    return {
      status: OK,
      success: true,
      message: exampleEntitlementsMessages.API_DATA_FETCH_SUCCESS,
      data: { message: 'This is protected API data' },
      meta: {
        usage: usage?.current,
        limit: usage?.limit,
        remaining:
          usage?.limit === paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
            ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
            : (usage?.limit as number) - (usage?.current || 0),
      },
    };
  } catch (error) {
    logger.error(`Error fetching API data: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Export data
 */
export const exportData = async (): Promise<IApiResponse> => {
  try {
    return {
      status: OK,
      success: true,
      message: exampleEntitlementsMessages.DATA_EXPORT_SUCCESS,
      data: {
        downloadUrl: '/downloads/data.csv',
      },
    };
  } catch (error) {
    logger.error(`Error exporting data: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Add team member (increments usage)
 */
export const addTeamMember = async (userId: string): Promise<IApiResponse> => {
  try {
    // Check current usage before incrementing
    const currentUsage = await entitlementService.getCurrentUsage(
      userId,
      exampleEntitlementsVariables.FEATURE_VALUE_TEAM_MEMBERS,
    );
    const limit = currentUsage?.limit;

    // Check if limit is reached
    if (limit !== paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED && typeof limit === 'number') {
      const current = currentUsage?.current || 0;
      if (current >= limit) {
        return {
          status: FORBIDDEN,
          success: false,
          message: exampleEntitlementsMessages.TEAM_MEMBER_LIMIT_REACHED,
          data: null,
        };
      }
    }

    // Increment the currentUsage in subscription collection
    const updated = await entitlementService.incrementUsage(
      userId,
      exampleEntitlementsVariables.FEATURE_VALUE_TEAM_MEMBERS,
      1,
    );

    if (!updated) {
      return {
        status: SERVER_ERROR,
        success: false,
        message: exampleEntitlementsMessages.FAILED_TO_UPDATE_TEAM_MEMBER_COUNT,
        data: null,
      };
    }

    // Get updated entitlements to return
    const entitlements = await entitlementService.getUserEntitlements(userId);

    if (!entitlements) {
      return {
        status: NOT_FOUND,
        success: false,
        message: exampleEntitlementsMessages.NO_ACTIVE_SUBSCRIPTION,
        data: null,
      };
    }

    const formatted = formatEntitlements(entitlements);

    return {
      status: OK,
      success: true,
      message: exampleEntitlementsMessages.TEAM_MEMBER_ADDED_SUCCESS,
      data: formatted,
    };
  } catch (error) {
    logger.error(`Error adding team member: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Get user's entitlements and usage stats
 */
export const getMyEntitlements = async (userId: string): Promise<IApiResponse> => {
  try {
    const entitlements = await entitlementService.getUserEntitlements(userId);

    if (!entitlements) {
      return {
        status: NOT_FOUND,
        success: false,
        message: exampleEntitlementsMessages.NO_ACTIVE_SUBSCRIPTION,
        data: null,
      };
    }

    const formatted = formatEntitlements(entitlements);

    return {
      status: OK,
      success: true,
      message: exampleEntitlementsMessages.USER_ENTITLEMENTS_FETCH_SUCCESS,
      data: formatted,
    };
  } catch (error) {
    logger.error(`Error fetching user entitlements: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Upload file (just returns success)
 */
export const uploadFile = async (userId: string, fileSize: number): Promise<IApiResponse> => {
  try {
    // Check if user has file upload feature
    const hasFileUpload = await entitlementService.hasFeature(
      userId,
      exampleEntitlementsVariables.FEATURE_VALUE_FILE_UPLOADS,
    );
    if (!hasFileUpload) {
      return {
        status: FORBIDDEN,
        success: false,
        message: exampleEntitlementsMessages.FILE_UPLOAD_NOT_AVAILABLE,
        data: null,
      };
    }

    // Check storage limit
    const storageUsage = await entitlementService.getCurrentUsage(
      userId,
      exampleEntitlementsVariables.FEATURE_VALUE_STORAGE_LIMIT,
    );
    const fileSizeInGB = fileSize / 1024;

    if (storageUsage?.limit !== paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED) {
      const remaining = (storageUsage?.limit as number) - (storageUsage?.current || 0);
      if (fileSizeInGB > remaining) {
        return {
          status: FORBIDDEN,
          success: false,
          message: `${exampleEntitlementsMessages.INSUFFICIENT_STORAGE} Required: ${fileSizeInGB.toFixed(2)}GB, Available: ${remaining.toFixed(2)}GB`,
          data: null,
        };
      }
    }

    // Upload file logic here
    // ...

    // Just return success message (no storage tracking)
    return {
      status: OK,
      success: true,
      message: exampleEntitlementsMessages.FILE_UPLOAD_SUCCESS,
      data: null,
    };
  } catch (error) {
    logger.error(`Error uploading file: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};
