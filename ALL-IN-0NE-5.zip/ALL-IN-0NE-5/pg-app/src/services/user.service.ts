//Constants

import {
  BAD_REQUEST,
  CONFLICT,
  CREATED,
  NO_CONTENT,
  OK,
  SERVER_ERROR,
  authMessages,
  commonMessages,
  emailTemplatesVariables,
  notificationMessages,
  userMessages,
} from '@constants';
//Utils
// notificationHandler
import { authHandler, emailHandler, paginationHandler, userHandler, notificationHandler } from '@utils';
//Enums
// NotificationPriority, NotificationType,
import { NotificationPriority, NotificationType, Role, UserStatus } from '@enums';
import { logger } from '@config/index';
//Types
import type { IUser, UnifiedUserServiceResponse } from '@customTypes';
import { prismaService, userCommonService } from '@services';

/**
 * Handles user creation
 * @param {Request} req Express request object
 * @returns {Promise<CreateUserResponse>} Response containing the created user or error information
 */
export const createUser = async (payload: IUser): Promise<UnifiedUserServiceResponse> => {
  const { firstName, lastName, email, phoneNumber, countryCode } = payload;
  if (await userCommonService.checkIfUserExists(email)) {
    return {
      status: CONFLICT,
      success: false,
      message: commonMessages.USER_ALREADY_EXISTS,
      data: null,
    };
  }

  const { hashedToken, expireDate, token } = await userHandler.generateSetPasswordToken();
  const newUser = {
    firstName,
    lastName,
    email,
    phoneNumber,
    countryCode,
    status: UserStatus.Inactive,
    resetPasswordToken: hashedToken,
    resetPasswordExpire: expireDate,
  };

  const createdUser = await prismaService.createRecord('user', newUser);
  logger.log(`token: ${token}`);

  const emailInfo = await emailHandler.sendEmailBySlug({
    toEmail: email,
    toName: `${createdUser.firstName} ${createdUser.lastName}`,
    templateName: emailTemplatesVariables.emailTemplates[0].slug,
    data: { token },
  });
  return {
    status: CREATED,
    success: true,
    message: emailInfo ? userMessages.USER_CREATED_AND_EMAIL_SENT : userMessages.USER_CREATED_AND_EMAIL_NOT_SENT,
    data: createdUser,
  };
};

/**
 * Retrieves users from the database.
 * If a userId is provided, fetch that specific user; otherwise, fetch all users.
 * @param {Request} req Express request object
 * @returns {Promise<GetUsersResponse>} Response containing the user(s) or error information
 */

export const getUsers = async (
  userId: string,
  pageNumber: number,
  pageSize: number,
  search: string | any,
  sortBy: string | any, // -1 , 1,
  orderBy: string | any,
): Promise<UnifiedUserServiceResponse> => {
  // If userId is provided, fetch single user
  if (userId) {
    const user = await userCommonService.getUserById(Number(userId));
    return {
      status: user ? OK : BAD_REQUEST,
      success: Boolean(user),
      message: user ? userMessages.USER_FETCH_SUCCESS : commonMessages.USER_NOT_FOUND,
      data: user || null,
    };
  }
  // Pagination
  const { limit, offset } = paginationHandler.getPagination(pageNumber, pageSize);

  // Filter
  const filters: Record<string, any> = {
    role: Role.User,
  };

  const order = orderBy ?? 'id';
  const sort = sortBy ?? 'desc';
  const orderByClause: any[] = [];

  if (order === 'name') {
    orderByClause.push(
      {
        firstName: sort, // 'asc' or 'desc'
      },
      {
        last_name: sort,
      },
    );
  } else {
    orderByClause.push({
      [order]: sort,
    });
  }

  if (search) {
    filters.OR = [
      { firstName: { contains: search, mode: 'insensitive' } },
      { lastName: { contains: search, mode: 'insensitive' } },
      { email: { contains: search, mode: 'insensitive' } },
    ];
  }
  // Fetch users using Prisma-based getAllUsers
  const users = await userCommonService.getAllUsers(offset, limit, filters, orderByClause);
  // Fetch total count
  const total = await prismaService.getCounts('user', filters);

  return {
    status: OK,
    success: true,
    message: userMessages.USERS_FETCH_SUCCESS,
    data: { total, users },
  };
};

/**
 * Deletes a user from the database based on the provided user ID.
 * @param {Request} req Express request object
 * @returns {Promise<DeleteUserResponse>} Response containing the deletion result or error information
 */
export const deleteUser = async (userId: string): Promise<UnifiedUserServiceResponse> => {
  try {
    const user = await prismaService.deleteOneRecord('user', {
      id: Number(userId),
    });

    return {
      status: user ? NO_CONTENT : BAD_REQUEST,
      success: Boolean(user),
      message: user ? userMessages.USER_DELETE_SUCCESS : commonMessages.USER_NOT_FOUND,
      data: null,
    };
  } catch (_error) {
    // Prisma throws error if record doesn't exist
    return {
      status: BAD_REQUEST,
      success: false,
      message: commonMessages.USER_NOT_FOUND,
      data: null,
    };
  }
};

/**
 * Service to update a user's information (name, email, role, status only)
 * @param {Request} req Express request object
 * @returns {Promise<UpdateUserResponse>} Response containing the updated user or error information
 */
export const updateUser = async (userId: string, payload: IUser): Promise<UnifiedUserServiceResponse> => {
  try {
    const { firstName, lastName, email, phoneNumber, countryCode, role, status } = payload;
    // 🔍 Check if user exists
    const existingUser = await prismaService.getRecord('user', {
      where: { id: Number(userId) },
    });

    if (!existingUser) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.USER_NOT_FOUND,
        data: null,
      };
    }

    // 📧 Check email uniqueness
    if (email && email !== existingUser.email) {
      const emailUser = await prismaService.findFirstRecord('user', {
        email,
      });

      if (emailUser) {
        return {
          status: CONFLICT,
          success: false,
          message: commonMessages.USER_WITH_THIS_EMAIL_ALREADY_EXISTS,
          data: null,
        };
      }
    }
    // 🛠 Build update payload (only send provided fields)
    const updatePayload: Record<string, any> = {
      firstName: firstName || existingUser.firstName,
      lastName: lastName || existingUser.lastName,
      email: email ?? existingUser.email,
      phoneNumber: phoneNumber ?? existingUser.phoneNumber,
      countryCode: countryCode ?? existingUser.countryCode,
      role: role ?? existingUser.role,
      status: status ?? existingUser.status,
    };

    // ✏️ Update user
    const updatedUser = await prismaService.updateRecord('user', updatePayload, { id: Number(userId) });

    return {
      status: OK,
      success: true,
      message: userMessages.USER_UPDATED_SUCCESS,
      data: updatedUser,
    };
  } catch (_error) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: commonMessages.GENERIC_ERROR_MESSAGE,
      data: null,
    };
  }
};

/**
 * Handles user password change
 * @param {Request} req Express request object
 * @returns {Promise<SetPasswordResponse>} Response containing the updated user or error information
 */
export const setPassword = async (token: string, password: string): Promise<UnifiedUserServiceResponse> => {
  try {
    const hashedToken = await userHandler.generateHashedToken(token);

    // 🔍 Find user by reset token + expiry
    const user = await prismaService.findFirstRecord('user', {
      resetPasswordToken: hashedToken,
      resetPasswordExpire: {
        gt: new Date(),
      },
    });

    if (!user) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: userMessages.USER_SET_PASSWORD_LINK_INVALID,
        data: null,
      };
    }

    // ⛔ Extra safety — expired check (edge case)
    if (user.resetPasswordExpire && user.resetPasswordExpire < new Date()) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: userMessages.USER_SET_PASSWORD_LINK_EXPIRED,
        data: null,
      };
    }

    // 🔐 Hash new password
    const hashedPassword = await authHandler.hashPassword(password);

    // ✏️ Update user password + clear reset fields
    await prismaService.updateRecord(
      'user',
      {
        password: hashedPassword,
        status: UserStatus.Active,
        resetPasswordToken: null,
        resetPasswordExpire: null,
        isVerified: true,
      },
      { id: user.id }, // use user_id if your schema uses that
    );

    if (user) {
      try {
        const admin = await prismaService.findFirstRecord('user', {
          role: Role.Admin,
        });
        if (admin) {
          await emailHandler.sendEmailBySlug({
            toEmail: admin?.email,
            toName: admin?.firstName,
            templateName: emailTemplatesVariables.emailTemplates[5].slug,
            data: { name: user.firstName, email: user.email },
          });

          try {
            await notificationHandler.sendNotification({
              recipientId: admin.id as number,
              type: NotificationType.NOTIFICATION,
              title: notificationMessages.NOTIFICATION_NEW_USER_ACTIVATED,
              message: `${user.firstName} (${user.email}) has activated.`,
              priority: NotificationPriority.MEDIUM,
              metadata: { userId: user.id },
            });
          } catch (err) {
            logger.error(`Notification sent Error: ${err}`);
          }
        }
      } catch (err) {
        logger.error(`Error notify admins about new activation: ${err}`);
      }
    }

    return {
      status: OK,
      success: true,
      message: userMessages.USER_PASSWORD_SET_SUCCESS,
      data: null,
    };
  } catch (_error) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: userMessages.USER_SET_PASSWORD_LINK_INVALID,
      data: null,
    };
  }
};

/**
 * Handles user status change
 * @param {Request} req Express request object
 * @returns {Promise<UnifiedUserServiceResponse>} Response containing the updated user or error information
 */
export const changeStatus = async (userId: string, status: number): Promise<UnifiedUserServiceResponse> => {
  try {
    // 🔍 Check if user exists
    const user = await prismaService.getRecord('user', {
      where: { id: Number(userId) }, // change to user_id if needed
    });

    if (!user) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.USER_NOT_FOUND,
        data: null,
      };
    }

    // ✏️ Update status
    await prismaService.updateRecord(
      'user',
      { status },
      { id: Number(userId) }, // or { user_id: Number(userId) }
    );

    return {
      status: OK,
      success: true,
      message: userMessages.USER_STATUS_UPDATED,
      data: null,
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.GENERIC_ERROR_MESSAGE,
      data: null,
    };
  }
};

/**
 * Resend email invitation to a user based on their verification and password status
 * - If user is not verified AND password is set → send email verification email
 * - If user is not verified AND password is NOT set → send password setup email
 * @param {number} userId - The user ID to resend invitation to
 * @returns {Promise<UnifiedUserServiceResponse>} Response containing success/failure information
 */

export const resendEmailInvitation = async (userId: number): Promise<UnifiedUserServiceResponse> => {
  // Fetch user from Prisma
  const user = await prismaService.getRecordById('user', { id: Number(userId) });

  if (!user) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: commonMessages.USER_NOT_FOUND,
      data: null,
    };
  }

  // Check if user is already verified
  if (user.isVerified) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: userMessages.USER_ALREADY_VERIFIED,
      data: null,
    };
  }

  const hasPassword = Boolean(user.password);

  if (hasPassword && !user.isVerified) {
    // Generate verification token
    const payload = {
      id: user.id,
      email: user.email,
      role: user.role,
    };
    const verifyToken = await authHandler.generateVerifyEmailToken(payload);

    // Send verification email
    const emailInfo = await emailHandler.sendEmailBySlug({
      toEmail: user.email,
      toName: `${user.firstName}`,
      templateName: emailTemplatesVariables.emailTemplates[2].slug,
      data: { token: verifyToken },
    });

    if (!emailInfo) {
      return {
        status: SERVER_ERROR,
        success: false,
        message: commonMessages.EMAIL_NOT_SENT,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: authMessages.USER_VERIFY_EMAIL,
      data: null,
    };
  } else {
    // User has no password → send set-password email
    const { hashedToken, expireDate, token } = await userHandler.generateSetPasswordToken();

    // Update user reset token using Prisma
    await prismaService.updateRecord(
      'user',
      {
        resetPasswordToken: hashedToken,
        resetPasswordExpire: expireDate,
      },
      { id: user.id },
    );

    // Send password setup email
    const emailInfo = await emailHandler.sendEmailBySlug({
      toEmail: user.email,
      toName: `${user.firstName}`,
      templateName: emailTemplatesVariables.emailTemplates[0].slug,
      data: { token },
    });

    return {
      status: emailInfo ? OK : SERVER_ERROR,
      success: Boolean(emailInfo),
      message: emailInfo ? userMessages.USER_INVITATION_RESEND_SUCCESS : userMessages.USER_INVITATION_RESEND_FAILED,
      data: null,
    };
  }
};
