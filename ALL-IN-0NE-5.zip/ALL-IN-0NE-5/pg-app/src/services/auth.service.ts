// Built-in modules
import crypto from 'node:crypto';
import env from '@config/envVar';
import { logger } from '@config/logger';
import { defaultRole } from '@config/role';
import {
  BAD_REQUEST,
  CONFLICT,
  CREATED,
  FORBIDDEN,
  GONE,
  NOT_FOUND,
  OK,
  SERVER_ERROR,
  UNAUTHORIZE,
  authMessages,
  commonMessages,
  commonVariables,
  emailTemplatesVariables,
  notificationMessages,
  twoFAMessages,
  twoFAVariables,
} from '@constants';
// Types
import type {
  AuthTokenPayload,
  IApiResponse,
  IChangePasswordBody,
  ICustomError,
  IForgetPasswordBody,
  ILoginBody,
  IRegisterBody,
  IResetPasswordBody,
  IUpdateProfile,
  IUser,
} from '@customTypes';
import { NotificationPriority, NotificationType, Role, TwoFAFlow, TwoFAMethod, UserStatus } from '@enums';
// services
import { prismaService, twoFAService } from '@services';
// Utilities
import {
  authHandler,
  commonHandler,
  emailHandler,
  generateTokenHandler,
  notificationHandler,
  twoFAHandler,
} from '@utils';
// Third-party modules
import type { Response } from 'express';

/**
 * Handles user registration
 * @param {IRegisterBody} data User registration data
 * @returns {Promise<IApiResponse>} Response containing the created user or error information
 */

export const register = async (data: IRegisterBody): Promise<IApiResponse> => {
  const { firstName, lastName, email, password, phoneNumber, countryCode } = data;
  const formatEmail = email.toLowerCase();
  const checkUser = await prismaService.findFirstRecord('user', {
    email: formatEmail,
  });

  if (checkUser) {
    return {
      status: CONFLICT,
      success: false,
      message: commonMessages.USER_ALREADY_EXISTS,
      data: null,
    };
  }

  const hashedPassword = await authHandler.hashPassword(password);

  // 👤 Create user
  const user = await prismaService.createRecord('user', {
    firstName,
    lastName,
    email: formatEmail,
    password: hashedPassword,
    phoneNumber,
    countryCode,
    role: defaultRole,
    status: UserStatus.Inactive, // or 0 if using int
  });
  if (!user) {
    return {
      status: UNAUTHORIZE,
      success: false,
      message: commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
  };

  const verifyToken = await authHandler.generateVerifyEmailToken(payload);

  const emailInfo = await emailHandler.sendEmailBySlug({
    toEmail: email,
    toName: `${user.firstName}`,
    templateName: emailTemplatesVariables.emailTemplates[2].slug,
    data: { token: verifyToken },
  });
  if (!emailInfo) {
    await prismaService.deleteOneRecord('user', { id: user.id });
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.EMAIL_NOT_SENT,
      data: null,
    };
  }
  try {
    const admin = await prismaService.findFirstRecord('user', {
      role: Role.Admin,
    });
    if (admin) {
      await emailHandler.sendEmailBySlug({
        toEmail: admin?.email,
        toName: 'Admin',
        templateName: emailTemplatesVariables.emailTemplates[4].slug,
        data: { name: user.firstName, email: user.email },
      });

      try {
        await notificationHandler.sendNotification({
          recipientId: Number(admin.id),
          type: NotificationType.NOTIFICATION,
          title: notificationMessages.NOTIFICATION_NEW_REGISTRATION,
          message: `${user.firstName} (${user.email}) has registered.`,
          priority: NotificationPriority.MEDIUM,
          metadata: { userId: user.id },
        });
      } catch (err) {
        logger.error(`Notification sent Error: ${err}`);
      }
    }
  } catch (err) {
    logger.error(`Error notify admins about new registration: ${err}`);
  }
  return {
    status: CREATED,
    success: true,
    message: authMessages.USER_VERIFY_EMAIL,
    data: null,
  };
};
/**
 * Verifies the user's email address using the provided token.
 * - Decodes and verifies the JWT token.
 * - Finds the user associated with the email in the token.
 * - Checks if the user is already active.
 * - Activates the user if not already active.
 *
 * @param {string} token - JWT token for email verification.
 * @returns {Promise<IApiResponse>} Response indicating the result of the verification process.
 * - Success: Returns status OK and a success message if email is successfully verified.
 * - Failure: Returns appropriate error status and message if verification fails.
 */

export const verifyEmail = async (token: string): Promise<IApiResponse> => {
  try {
    let decoded: AuthTokenPayload;

    // 🔐 Verify JWT
    try {
      decoded = await commonHandler.verifyJwt(token, env.JWT_SECRET);
    } catch (error) {
      const err = error as ICustomError;
      const errorMessage =
        err.name === commonVariables.TOKEN_EXPIRED_ERROR
          ? commonMessages.SESSION_TIMEOUT
          : commonMessages.INVALID_TOKEN;

      return {
        status: UNAUTHORIZE,
        success: false,
        message: errorMessage,
        data: null,
      };
    }

    const email = decoded.email;

    // 👤 Find user
    const user = await prismaService.findFirstRecord('user', { email }, { select: { id: true, status: true } });

    if (!user) {
      return {
        status: NOT_FOUND,
        success: false,
        message: commonMessages.USER_NOT_FOUND,
        data: null,
      };
    }

    // 🚫 Already verified
    if (user.status === UserStatus.Active) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: authMessages.USER_VERIFIED,
        data: null,
      };
    }

    // ✅ Update status
    await prismaService.updateRecord('user', { status: UserStatus.Active, isVerified: true }, { id: user.id });

    return {
      status: OK,
      success: true,
      message: authMessages.VERIFY_EMAIL_SUCCESS,
      data: null,
    };
  } catch (error) {
    console.error(error);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.FORGET_PASSWORD_ERROR,
      data: error,
    };
  }
};

/**
 * Login a user with email and password. If the user has TwoFA enabled, a verification code will be sent to the selected method.
 * @param {ILoginBody} data - The login data
 * @param {Response} res - The response
 * @returns {Promise<IApiResponse>} - The response
 */
export const login = async (data: ILoginBody, res: Response): Promise<IApiResponse> => {
  const { email, password, shouldSendOtp } = data;
  const formatEmail = email.toLowerCase();
  // 👤 Find user
  const user = await prismaService.findFirstRecord(
    'user',
    { email: formatEmail },
    {
      select: {
        id: true,
        email: true,
        password: true,
        role: true,
        status: true,
        isTwoAuthEnabled: true,
        configuredTwoFAMethods: true,
        phoneNumber: true,
        isVerified: true,
      },
    },
  );

  if (!user) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: commonMessages.USER_EMAIL_NOT_FOUND,
      data: null,
    };
  }
  if (!user.isVerified && user.role === Role.User) {
    return {
      status: FORBIDDEN,
      success: false,
      message: authMessages.UNVERIFIED_EMAIL_ERROR,
      data: null,
    };
  }
  if (user && user.status === 0) {
    return {
      status: FORBIDDEN,
      success: false,
      message: authMessages.USER_INACTIVE_ERROR,
      data: {
        status: user.status,
      },
    };
  }
  const isMatch = await authHandler.comparePassword(password, user.password);

  if (!isMatch) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: commonMessages.INVALID_CREDENTIALS,
      data: null,
    };
  }

  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
    isTWOFAVerified: false,
  };
  // Handle 2FA
  if (user.isTwoAuthEnabled && Array.isArray(user.configuredTwoFAMethods)) {
    let preferredTwoFAMethod = null;
    const userPreferredTwoFAMethodConfig = user.configuredTwoFAMethods.find(
      (m: { isPreferredTwoFAMethod: any; isEnabled: boolean }) => m.isPreferredTwoFAMethod && m.isEnabled,
    );
    if (userPreferredTwoFAMethodConfig) {
      preferredTwoFAMethod = userPreferredTwoFAMethodConfig.methodType;
    }
    if (!preferredTwoFAMethod) {
      for (const methodType of twoFAVariables.TWO_FA_METHOD_PRIORITY_ORDER) {
        const matchedMethod = user.configuredTwoFAMethods.find(
          (m: { methodType: any; isEnabled: boolean }) => m.methodType === methodType && m.isEnabled,
        );
        if (matchedMethod) {
          preferredTwoFAMethod = matchedMethod.methodType;
        }
      }
    }

    if (preferredTwoFAMethod) {
      let message = authMessages.LOGIN_SUCCESS;
      if (shouldSendOtp) {
        switch (preferredTwoFAMethod) {
          case TwoFAMethod.EMAIL:
            await twoFAService.sendOtpToMail(email, password);
            message = twoFAMessages.VERIFICATION_CODE_TO_EMAIL;
            break;
          case TwoFAMethod.PHONE:
            await twoFAService.sendSmsCode({
              email: user.email,
              phoneNumber: user.phoneNumber,
              twoFAFlow: TwoFAFlow.VERIFY,
            });
            message = twoFAMessages.VERIFICATION_CODE_TO_PHONE;
            break;
          case TwoFAMethod.APP:
            message = twoFAMessages.VERIFICATION_CODE_TO_APP;
            break;
        }
      }
      return {
        status: OK,
        success: true,
        message,
        data: {
          isTwoAuthEnabled: user.isTwoAuthEnabled,
          token: await generateTokenHandler.generateAuthToken(res, payload),
          role: user.role,
          preferredTwoFAMethod: preferredTwoFAMethod,
          configuredTwoFAMethods: user.configuredTwoFAMethods,
          maskedPhoneNumber: user.phoneNumber ? twoFAHandler.maskNumber(user.phoneNumber) : null,
        },
      };
    }

    // If no method matched
    return {
      status: BAD_REQUEST,
      success: false,
      message: twoFAMessages.INVALID_TWOFA,
      data: {
        isTwoAuthEnabled: user.isTwoAuthEnabled,
        token: null,
        role: user.role,
      },
    };
  }
  if (env.TWOFA_REQUIRED.toLowerCase() === 'false') {
    payload.isTWOFAVerified = true;
  }

  // Update last login timestamp
  await prismaService.updateRecord('user', { lastLogin: new Date() }, { id: user.id });

  return {
    status: OK,
    success: true,
    message: authMessages.LOGIN_SUCCESS,
    data: {
      token: await generateTokenHandler.generateAuthToken(res, payload),
      role: user.role,
      isTwoAuthEnabled: user.isTwoAuthEnabled,
      configuredTwoFAMethods: user.configuredTwoFAMethods,
      preferredTwoFAMethod: null,
      maskedPhoneNumber: user.phoneNumber ? twoFAHandler.maskNumber(user.phoneNumber) : null,
    },
  };
};

/**
 * Refreshes the access token using the refresh token.
 * @param {FastifyReply} res - The response object.
 * @returns {Promise<IApiResponse>} - The response object with the new access token.
 */
export const refreshAccessToken = async (data: string): Promise<IApiResponse> => {
  return {
    status: OK,
    success: true,
    message: authMessages.TOKEN_ACCESS_SUCCESS,
    data: await authHandler.refreshAccessToken(data),
  };
};

/**
 * Returns the user profile.
 * @param {IUser} user - The user object.
 * @return {IApiResponse} - The response object.
 */
export const userProfile = async (user: IUser): Promise<IApiResponse> => {
  const userData = await prismaService.findFirstRecord(
    'user',
    { id: user.id },
    {
      include: {
        configuredTwoFAMethods: true,
        recoveryCodes: true,
        appToken: true,
        dataItemsCreated: true,
        dataItemsUpdated: true,
        dataBatches: true,
        notifications: true,
        files: {
          take: 1, // only need one avatar file
          include: {
            paths: {
              take: 1,
              select: { path: true },
            },
          },
        },
      },
    },
  );

  if (!userData) {
    return {
      status: NOT_FOUND,
      success: false,
      message: commonMessages.USER_NOT_FOUND,
      data: null,
    };
  }

  // extract avatar
  const avatarPath = userData?.files?.[0]?.paths?.[0]?.path ?? null;

  // remove files and format avatar
  const { ...restUser } = userData;

  const formattedUser = {
    ...restUser,
    avatar: avatarPath ? `${env.BASE_URL}/${avatarPath.replace(/^public[\\/]/, '').replace(/\\/g, '/')}` : null,
  };

  return {
    status: OK,
    success: true,
    message: authMessages.USER_PROFILE,
    data: formattedUser,
  };
};

/**
 * Updates user profile information.
 * @param {IUser} userData - The user object to be updated.
 * @param {IUpdateProfile} data - The user profile data to be updated.
 * @returns {Promise<IApiResponse>} - The response object with the updated user object.
 */

export const updateProfile = async (userData: IUser, data: IUpdateProfile): Promise<IApiResponse> => {
  const { firstName, lastName, email, phoneNumber, countryCode } = data;

  // 🔍 Check if email is changing & already taken
  if (email && email !== userData.email) {
    const existingUser = await prismaService.findFirstRecord('user', { email });

    if (existingUser) {
      return {
        status: CONFLICT,
        success: false,
        message: commonMessages.USER_ALREADY_EXISTS,
        data: null,
      };
    }
  }

  // 🧠 Build update payload (Prisma doesn't mutate objects)
  const updateData: any = {
    ...(firstName && { firstName }),
    ...(lastName && { lastName }),
    ...(email && { email: email.toLowerCase() }),
    ...(phoneNumber && { phoneNumber }),
    ...(countryCode && { countryCode }),
  };

  // ✏️ Update user
  await prismaService.updateRecord('user', updateData, { id: userData.id });

  // 🔄 Fetch fresh user data
  const updatedUser = await prismaService.findFirstRecord(
    'user',
    { id: userData.id },
    {
      select: {
        id: true,
        firstName: true,
        lastName: true,
        email: true,
        phoneNumber: true,
        countryCode: true,
        role: true,
        status: true,
        isTwoAuthEnabled: true,
      },
    },
  );

  return {
    status: CREATED,
    success: true,
    message: authMessages.UPDATE_PROFILE,
    data: updatedUser,
  };
};

/**
 * Handles user forget password by sending an email with a reset link.
 * @param {IForgetPasswordBody} data - The user email to be used for sending the reset link.
 * @returns {Promise<IApiResponse>} - The response object with the status, success, message and data.
 */

export const forgetPassword = async (data: IForgetPasswordBody): Promise<IApiResponse> => {
  try {
    const { email } = data;

    // 👤 Find active user
    const user = await prismaService.findFirstRecord(
      'user',
      { email, status: UserStatus.Active, isDeleted: false, isVerified: true },
      { select: { id: true, firstName: true, lastName: true } },
    );

    // 🔐 Don't reveal if email exists (security best practice)
    if (!user) {
      return {
        status: OK,
        success: true,
        message: commonMessages.SHARE_RESET_LINK,
        data: null,
      };
    }

    // 🎟 Generate reset token
    const { token, hashedToken, expireDate } = await authHandler.generateResetToken();

    // 💾 Store token in DB
    await prismaService.updateRecord(
      'user',
      {
        resetPasswordToken: hashedToken,
        resetPasswordExpire: expireDate,
      },
      { id: user.id },
    );

    // 📧 Send email
    const emailInfo = await emailHandler.sendEmailBySlug({
      toEmail: email,
      toName: `${user.firstName}+ ' ' + ${user.lastName}`,
      templateName: emailTemplatesVariables.emailTemplates[1].slug,
      data: { token },
    });

    return {
      status: emailInfo ? OK : SERVER_ERROR,
      success: !!emailInfo,
      message: emailInfo ? commonMessages.SHARE_RESET_LINK : commonMessages.EMAIL_NOT_SENT,
      data: null,
    };
  } catch (error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.FORGET_PASSWORD_ERROR,
      data: error,
    };
  }
};

/**
 * Resets user password with a valid reset token.
 * @param {IResetPasswordBody} data - The user data to be reset.
 * @returns {Promise<IApiResponse>} - The response object with the status, success, message and data.
 */
export const resetPassword = async (data: IResetPasswordBody): Promise<IApiResponse> => {
  const { token, password } = data;

  // 🔐 Hash incoming token
  const resetToken = crypto.createHash(commonVariables.HASH_METHOD).update(token).digest('hex');

  // 👤 Find user with valid token (Prisma uses `gt` instead of $gt)
  const user = await prismaService.findFirstRecord(
    'user',
    {
      resetPasswordToken: resetToken,
      resetPasswordExpire: { gt: new Date() },
    },
    { select: { id: true } },
  );

  if (!user) {
    return {
      status: UNAUTHORIZE,
      success: false,
      message: commonMessages.USER_NOT_FOUND,
      data: null,
    };
  }

  // 🔑 Hash new password
  const hashedPassword = await authHandler.hashPassword(password);

  // 💾 Update password + clear reset token
  await prismaService.updateRecord(
    'user',
    {
      password: hashedPassword,
      resetPasswordToken: null,
      resetPasswordExpire: null,
    },
    { id: user.id },
  );

  return {
    status: CREATED,
    success: true,
    message: authMessages.PASSWORD_CHANGED,
    data: null,
  };
};

/**
 * Changes the user's password.
 * @param {IUser} user - The user instance.
 * @param {IChangePasswordBody} data - The user data to be changed.
 * @returns {Promise<IApiResponse>} - The response object with the status, success, message and data.
 */
export const changePassword = async (user: IUser, data: IChangePasswordBody): Promise<IApiResponse> => {
  const { currentPassword, newPassword } = data;

  // 👤 Get user's current hashed password from DB
  const dbUser = await prismaService.findFirstRecord('user', { id: user.id }, { select: { id: true, password: true } });

  if (!dbUser) {
    return {
      status: UNAUTHORIZE,
      success: false,
      message: commonMessages.USER_NOT_FOUND,
      data: null,
    };
  }

  // 🔐 Compare old password
  const isMatch = await authHandler.comparePassword(currentPassword, dbUser.password);

  if (!isMatch) {
    return {
      status: UNAUTHORIZE,
      success: false,
      message: authMessages.INCORRECT_PASSWORD,
      data: null,
    };
  }

  // 🔑 Hash new password
  const hashedPassword = await authHandler.hashPassword(newPassword);

  // 💾 Update password
  await prismaService.updateRecord('user', { password: hashedPassword }, { id: dbUser.id });

  return {
    status: CREATED,
    success: true,
    message: authMessages.PASSWORD_CHANGED,
    data: null,
  };
};

/**
 * Resends email verification link to user
 * @param {string} email User's email address
 * @returns {Promise<IApiResponse>} Response containing success/error information
 */
export const resendEmailVerification = async (email: string): Promise<IApiResponse> => {
  const formatEmail = email.toLowerCase();

  // 🔍 Find user
  const user = await prismaService.findFirstRecord(
    'user',
    { email: formatEmail },
    { select: { id: true, email: true, firstName: true, lastName: true, role: true, status: true } },
  );

  if (!user) {
    return {
      status: NOT_FOUND,
      success: false,
      message: commonMessages.USER_NOT_FOUND,
      data: null,
    };
  }

  // ✅ Already verified?
  if (user.status === UserStatus.Active) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: authMessages.USER_VERIFIED,
      data: null,
    };
  }

  // 🎟 Create token
  const payload = {
    id: user.id,
    email: user.email,
    role: user.role,
  };

  const verifyToken = await authHandler.generateVerifyEmailToken(payload);

  // 📧 Send email
  const emailInfo = await emailHandler.sendEmailBySlug({
    toEmail: user.email,
    toName: `${user.firstName}+ ' ' + ${user.lastName}`,
    templateName: emailTemplatesVariables.emailTemplates[2].slug,
    data: { token: verifyToken },
  });

  if (!emailInfo) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.EMAIL_NOT_SENT,
      data: null,
    };
  }

  return {
    status: OK,
    success: true,
    message: authMessages.USER_VERIFY_EMAIL,
    data: null,
  };
};

/**
 * Logs out a user by clearing their auth token
 * @param {Response} res Express response object
 * @returns {Promise<IApiResponse>} Response indicating logout success
 */
export const logout = async (res: Response): Promise<IApiResponse> => {
  authHandler.clearToken(res);

  return {
    status: OK,
    success: true,
    message: authMessages.LOGOUT_SUCCESS,
    data: null,
  };
};

/**
 * This api is use for to check the token link is invalid or expired
 * @param token
 * @returns
 */
export const validateToken = async (token: string): Promise<IApiResponse> => {
  try {
    if (!token) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: commonMessages.RESET_TOKEN_REQUIRED,
        data: null,
      };
    }

    const hashedToken = crypto.createHash(`${commonVariables.HASH_METHOD}`).update(token).digest('hex');

    const user = await prismaService.findFirstRecord(
      'user',
      {
        resetPasswordToken: hashedToken,
        resetPasswordExpire: {
          gt: new Date(),
        },
      },
      {
        select: {
          id: true,
        },
      },
    );

    if (user) {
      return {
        status: OK,
        success: true,
        message: commonMessages.RESET_LINK_VALID,
        data: null,
      };
    }

    const expiredUser = await prismaService.findFirstRecord(
      'user',
      {
        resetPasswordToken: hashedToken,
        resetPasswordExpire: {
          lte: new Date(),
        },
      },
      {
        select: {
          id: true,
        },
      },
    );

    if (expiredUser) {
      return {
        status: GONE,
        success: false,
        message: commonMessages.PASSWORD_RESET_LINK_EXPIRED,
        data: null,
      };
    }

    return {
      status: BAD_REQUEST,
      success: false,
      message: commonMessages.PASSWORD_RESET_LINK_INVALID,
      data: null,
    };
  } catch (error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.RESET_LINK_VALIDATE_ERROR,
      data: error,
    };
  }
};
