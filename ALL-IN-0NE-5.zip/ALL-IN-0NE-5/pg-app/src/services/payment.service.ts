import { NOT_FOUND, OK, SERVER_ERROR, commonMessages, paymentMessages, paymentVariables } from '@constants';
import {
  entitlementService,
  planEntitlementService,
  prismaService,
  stripeService,
  userSubscriptionService,
} from '@services';
import type {
  IApiResponse,
  ISetupIntentResult,
  IBillingAddress,
  IFeatureEntitlement,
  IEntitlementInput,
  IParsedEntitlementCompressed,
  IPlan,
  IPlanUpdate,
  IProduct,
  SubscriptionSessionOptions,
} from '@customTypes';
import Stripe from 'stripe';
import { logger } from '@config/logger';
import { FeatureType } from '@enums';

/**
 * Handles creating a new product
 * @param {IProduct} data - The product data
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */
export const addProduct = async (data: IProduct) => {
  try {
    await stripeService.registerProduct(data);
    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_PRODUCT,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Handles get products
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any[]}>}
 */
export const getList = async () => {
  try {
    const productList = await stripeService.searchProduct();
    if (!productList) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.PRODUCT_NOT_FOUND,
        data: null,
      };
    }
    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_PRODUCT_LIST,
      data: productList,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Handles fetching a product by id
 * @param {string} productId - The product id
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */
export const getByProductId = async (productId: string) => {
  try {
    const productDoc = await stripeService.fetchProduct(productId);
    if (!productDoc) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.PRODUCT_NOT_FOUND,
        data: null,
      };
    }
    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_PRODUCT,
      data: productDoc,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Handles updating a product
 * @param {IProduct} data - The product data
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */
export const updateProductDetails = async (data: IProduct) => {
  try {
    await stripeService.modifyProduct(data);
    return {
      status: OK,
      success: true,
      message: paymentMessages.UPDATE_PRODUCT,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Handles deleting a product by id
 * @param {string} id - The product id
 * @returns {Promise<{status: number, success: boolean, message: string, data: null}>}
 */

export const deleteByProductId = async (id: string) => {
  try {
    await stripeService.removeProduct(id);
    return {
      status: OK,
      success: true,
      message: paymentMessages.DELETE_PRODUCT,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Handles creating a new plan
 * @param {IPlan} data - The plan data
 * @returns {Promise<IApiResponse>}
 */
export const addPrice = async (data: IPlan, userId: string): Promise<IApiResponse> => {
  try {
    const entitlementsData = data.metadata?.entitlements;
    let entitlements: IFeatureEntitlement[] = [];
    if (entitlementsData) {
      try {
        const parsed = JSON.parse(entitlementsData) as IEntitlementInput[];
        if (parsed.length > 0 && 'f' in parsed[0]) {
          entitlements = (parsed as IParsedEntitlementCompressed[]).map((comp) => ({
            featureId: comp.f,
            featureValue: comp.v,
            type: comp.t,
            limit: typeof comp.l === 'boolean' ? (comp.l ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED : 0) : comp.l,
            unit: comp.u || undefined,
            currentUsage: 0,
          })) as IFeatureEntitlement[];
        } else {
          entitlements = parsed.map((ent) => {
            if ('f' in ent) {
              // Compressed format
              const comp = ent as IParsedEntitlementCompressed;
              return {
                featureId: comp.f,
                featureValue: comp.v,
                type: comp.t,
                limit:
                  typeof comp.l === 'boolean' ? (comp.l ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED : 0) : comp.l,
                unit: comp.u || undefined,
                currentUsage: 0,
              } as IFeatureEntitlement;
            } else {
              // Full format
              const full = ent as {
                featureId: string;
                featureValue: string;
                type: FeatureType.BOOLEAN | FeatureType.NUMERIC | FeatureType.UNLIMITED;
                limit: number | typeof paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED | boolean;
                unit?: string;
              };
              return {
                featureId: full.featureId,
                featureValue: full.featureValue,
                type: full.type,
                limit:
                  typeof full.limit === 'boolean'
                    ? full.limit
                      ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
                      : 0
                    : full.limit,
                unit: full.unit || undefined,
                currentUsage: 0,
              } as IFeatureEntitlement;
            }
          });
        }
      } catch (e) {
        logger.warn(`Failed to parse entitlements from metadata: ${e instanceof Error ? e.message : e}`);
      }
    }
    const { entitlements: _entitlementsRemoved, ...metadataWithoutEntitlements } = (data.metadata || {}) as Record<
      string,
      string
    >;
    const planData = {
      ...data,
      metadata: metadataWithoutEntitlements,
    };
    let priceId: string;
    if (data && data.usageType === 'licensed') {
      priceId = await stripeService.createRecurringPlan(planData);
    } else if (data && data.usageType === 'metered') {
      priceId = await stripeService.createUsagePlan(planData);
    } else {
      throw new Error(paymentMessages.USAGE_TYPE_REQUIRED);
    }

    if (entitlements.length > 0) {
      const entitlementsResult = await planEntitlementService.createOrUpdatePlanEntitlements({
        priceId,
        entitlements,
      });
      await entitlementService.updateUserEntitlements(Number(userId), entitlements);
      if (entitlementsResult.success && entitlementsResult.data) {
        await stripeService.updatePlan({
          priceId,
          description: undefined,
          email: undefined,
          customerId: '',
          orderId: '',
          metadata: {
            entitlementsId: entitlementsResult.data.id,
          },
        });
        logger.info(`Saved entitlements for price ${priceId} with MongoDB ID: ${entitlementsResult.data.id}`);
      } else {
        logger.warn(`Failed to save entitlements for price ${priceId}: ${entitlementsResult.message}`);
      }
    }

    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_PLAN,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Retrieves a plan by its price ID from the Stripe service.
 * @param {string} priceId - The ID of the price to retrieve the plan for.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */

export const getPlanByPriceId = async (priceId: string) => {
  try {
    const planDetails = await stripeService.getPlanById(priceId);
    if (!planDetails) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.PLAN_NOT_FOUND,
        data: null,
      };
    }
    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_PLAN,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Updates the price details of a plan using the provided data.
 * @param {IPlanUpdate} data - The plan update data containing details such as description, email, customerId, priceId, and orderId.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null}>}
 */

export const updatePriceDetails = async (data: IPlanUpdate): Promise<IApiResponse> => {
  try {
    const entitlementsData = data.metadata?.entitlements;
    let entitlements: IFeatureEntitlement[] = [];

    if (entitlementsData) {
      try {
        const parsed = JSON.parse(entitlementsData) as IEntitlementInput[];
        if (parsed.length > 0 && 'f' in parsed[0]) {
          entitlements = (parsed as IParsedEntitlementCompressed[]).map((comp) => ({
            featureId: comp.f,
            featureValue: comp.v,
            type: comp.t,
            limit: typeof comp.l === 'boolean' ? (comp.l ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED : 0) : comp.l,
            unit: comp.u || undefined,
            currentUsage: 0,
          })) as IFeatureEntitlement[];
        } else {
          entitlements = parsed.map((ent) => {
            if ('f' in ent) {
              // Compressed format
              const comp = ent as IParsedEntitlementCompressed;
              return {
                featureId: comp.f,
                featureValue: comp.v,
                type: comp.t,
                limit:
                  typeof comp.l === 'boolean' ? (comp.l ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED : 0) : comp.l,
                unit: comp.u || undefined,
                currentUsage: 0,
              } as IFeatureEntitlement;
            } else {
              // Full format
              const full = ent as {
                featureId: string;
                featureValue: string;
                type: FeatureType.BOOLEAN | FeatureType.NUMERIC | FeatureType.UNLIMITED;
                limit: number | typeof paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED | boolean;
                unit?: string;
              };
              return {
                featureId: full.featureId,
                featureValue: full.featureValue,
                type: full.type,
                limit:
                  typeof full.limit === 'boolean'
                    ? full.limit
                      ? paymentVariables.ENTITLEMENT_LIMIT_UNLIMITED
                      : 0
                    : full.limit,
                unit: full.unit || undefined,
                currentUsage: 0,
              } as IFeatureEntitlement;
            }
          });
        }
      } catch (e) {
        logger.warn(`Failed to parse entitlements from metadata: ${e instanceof Error ? e.message : e}`);
      }
    }

    const { entitlements: _entitlementsRemovedUpdate, ...metadataWithoutEntitlements } = (data.metadata ||
      {}) as Record<string, string>;

    const updateData = {
      ...data,
      metadata: metadataWithoutEntitlements,
    };

    await stripeService.updatePlan(updateData);

    if (entitlements.length > 0) {
      const entitlementsResult = await planEntitlementService.createOrUpdatePlanEntitlements({
        priceId: data.priceId,
        entitlements,
      });

      if (entitlementsResult.success && entitlementsResult.data) {
        const existingPrice = await stripeService.getPlanById(data.priceId);
        const existingEntitlementsId = existingPrice?.metadata?.entitlementsId;

        if (existingEntitlementsId !== entitlementsResult.data.id) {
          await stripeService.updatePlan({
            priceId: data.priceId,
            description: undefined,
            email: undefined,
            customerId: '',
            orderId: '',
            metadata: {
              entitlementsId: entitlementsResult.data.id,
            },
          });
        }
        logger.info(`Updated entitlements for price ${data.priceId} with MongoDB ID: ${entitlementsResult.data.id}`);
      } else {
        logger.warn(`Failed to update entitlements for price ${data.priceId}: ${entitlementsResult.message}`);
      }
    } else {
      await planEntitlementService.deletePlanEntitlements(data.priceId);
      logger.info(`Deleted entitlements for price ${data.priceId}`);
    }

    return {
      status: OK,
      success: true,
      message: paymentMessages.UPDATE_PLAN,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Creates a new customer in Stripe.
 * @param {string} email - The email address of the new customer.
 * @param {string} name - The name of the new customer.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */
export const addCustomer = async (email: string, name: string) => {
  try {
    await stripeService.registerCustomer(email, name);
    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_CUSTOMER,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Fetches a customer by id from Stripe.
 * @param {string} id - The id of the customer to fetch.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | Stripe.Customer}>}
 */
export const getByCustomerId = async (id: string) => {
  try {
    const customer = await stripeService.fetchCustomer(id);
    if (!customer) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.CUSTOMER_NOT_FOUND,
        data: null,
      };
    }
    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_CUSTOMER,
      data: customer,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Updates a customer in Stripe.
 * @param {string} customerId - The id of the customer to update.
 * @param {string} email - The new email address of the customer.
 * @param {string} description - The new description of the customer.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */
export const updateCustomerDetails = async (customerId: string, email: string, description: string) => {
  try {
    const priceList = await stripeService.modifyCustomer(customerId, email, description);
    return {
      status: OK,
      success: true,
      message: paymentMessages.UPDATE_CUSTOMER,
      data: priceList,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Deletes a customer from Stripe.
 * @param {string} id - The id of the customer to delete.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any}>}
 */

export const deleteCustomer = async (id: string) => {
  try {
    const priceList = await stripeService.removeCustomer(id);
    return {
      status: OK,
      success: true,
      message: paymentMessages.DELETE_CUSTOMER,
      data: priceList,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Retrieves a list of all available plans from the Stripe service.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | any[]}>}
 *  - An object containing the HTTP status code, success flag, message, and a list of plans.
 */

export const getPlanList = async () => {
  try {
    const priceList = await stripeService.getPlans();
    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_PLAN_LIST,
      data: priceList,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Retrieves a subscription by id from Stripe.
 * @param {string} id - The id of the subscription to fetch.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | Stripe.Subscription}>}
 */
export const fetchSubscriptionById = async (id: string) => {
  try {
    const subscriptionDetails = await stripeService.fetchSubscription(id);
    if (!subscriptionDetails) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.CUSTOMER_NOT_FOUND,
        data: null,
      };
    }
    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_SUBSCRIPTION,
      data: subscriptionDetails,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Creates a new subscription with the given customer, price, currency, and trial days.
 * @param {string} customer - The id of the customer to create the subscription for.
 * @param {string} price - The id of the price to use for the subscription.
 * @param {string} currency - The currency of the price.
 * @param {number} trailDays - The number of trial days for the subscription.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null}>}
 */
export const createPostSubscription = async (customer: string, price: string, currency: string, trailDays: number) => {
  try {
    await stripeService.subscriptionService(customer, price, currency, trailDays);
    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SUBSCRIPTION,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Cancels a subscription by id from Stripe.
 * @param {string} id - The id of the subscription to cancel.
 * @returns {Promise<{status: number, success: boolean, message: string, data: null | Stripe.Subscription}>}
 */
export const deleteBysubscriptionId = async (id: string) => {
  try {
    await stripeService.cancelSubscription(id);
    return {
      status: OK,
      success: true,
      message: paymentMessages.DELETE_SUBSCRIPTION,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Creates a usage based subscription session for a given customer, price and currency.
 * @param {string} customer - The id of the customer to create the subscription for.
 * @param {string} price - The id of the price to use for the subscription.
 * @param {string} currency - The currency to use for the subscription.
 * @returns {Promise<{status: number, success: boolean, message: string, data: {url: string}|null}>}
 */
export const createUsagesSubscriptionSession = async (customer: string, price: string, currency: string) => {
  try {
    const sessionUrl = await stripeService.usageBasedSubscriptionSession(customer, price, currency);
    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SUBSCRIPTION,
      data: { url: sessionUrl },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Creates a prepaid subscription session for a given customer, price and currency.
 * @param {string} customer - The id of the customer to create the subscription for (optional).
 * @param {string} price - The id of the price to use for the subscription.
 * @param {string} currency - The currency to use for the subscription.
 * @param {number} quantity - The number of licenses to purchase.
 * @param {string} userId - The user ID to pass in metadata (optional).
 * @returns {Promise<IApiResponse>}
 */
export const prePaymentSubcriptionSession = async (
  customer: string | undefined,
  price: string,
  currency: string,
  quantity: number,
  userId?: string | undefined,
  customerEmail?: string | undefined,
  _customerName?: string | undefined,
  options?: SubscriptionSessionOptions,
): Promise<IApiResponse> => {
  try {
    // Validate required options
    if (!options || !options.successUrl || !options.cancelUrl) {
      throw new Error(paymentMessages.SUCCESS_URL_AND_CANCEL_URL_REQUIRED);
    }

    // If customerId not provided, try to get it from user subscription
    let customerId = customer;

    // Get existing customerId from user subscription if not provided
    if (!customerId && userId) {
      const existingSubscription = await userSubscriptionService.getUserSubscriptionByUserId(userId);

      if (existingSubscription.success && existingSubscription.data) {
        // Use existing customerId if available
        if (existingSubscription.data.customerId) {
          customerId = existingSubscription.data.customerId;
          logger.info(`Using existing customer ID from subscription: ${customerId}`);
        }
      } else {
        // Try to get customerId even if subscription doesn't exist
        const existingCustomerId = await userSubscriptionService.getCustomerIdByUserId(userId);
        if (existingCustomerId) {
          customerId = existingCustomerId;
          logger.info(`Using existing customer ID from subscription: ${customerId}`);
        }
      }
    }

    const sessionUrl = await stripeService.prePaidSubscriptionSession(
      customerId || '', // Pass empty string if no customerId (Stripe will create one)
      price,
      currency,
      quantity,
      userId, // Pass userId for metadata
      customerEmail, // Pass customer email
      options, // Pass options for customization
    );

    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SUBSCRIPTION,
      data: { url: sessionUrl },
    };
  } catch (error) {
    logger.error(`Error creating prepaid subscription session: ${error}`);
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Updates a prepaid subscription by given subscriptionId and description.
 * @param {string} subscriptionId - The id of the subscription to update.
 * @param {string} description - The description for the subscription.
 * @returns {Promise<{status: number, success: boolean, message: string, data: {url: string}|null}>}
 */
export const updatePrepaidSubscription = async (subscriptionId: string, description: string) => {
  try {
    const sessionUrl = await stripeService.updatePrepaidTypeSubscription(subscriptionId, description);
    return {
      status: OK,
      success: true,
      message: paymentMessages.UPDATE_SUBSCRIPTION,
      data: { url: sessionUrl },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Process one time payment.
 * @param {string} customer - The id of the customer to charge.
 * @param {string} price - The id of the price to use for the one time payment.
 * @param {string} currency - The currency to use for the one time payment.
 * @param {number} quantity - The number of licenses to purchase.
 * @returns {Promise<{status: number, success: boolean, message: string, data: {url: string}|null}>}
 */
export const onetimeProcess = async (customer: string, price: string, currency: string, quantity: number) => {
  try {
    const sessionUrl = await stripeService.oneTimePayment(customer, price, currency, quantity);
    return {
      status: OK,
      success: true,
      message: paymentMessages.ONE_TIME_PAYMENT,
      data: { url: sessionUrl },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Creates a Setup Intent for embedded checkout
 * @returns {Promise<IApiResponse>}
 */
export const createSetupIntentForSubscription = async (
  customerId: string | undefined,
  customerEmail: string,
  customerName?: string,
  userId?: string,
): Promise<IApiResponse> => {
  try {
    const result: ISetupIntentResult = await stripeService.createSetupIntent(
      customerId,
      customerEmail,
      customerName,
      userId,
    );
    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SUBSCRIPTION,
      data: result,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Creates a subscription after payment method is confirmed
 * @returns {Promise<IApiResponse>}
 */
export const createSubscriptionAfterPayment = async (
  customerId: string | undefined, // Now optional - will be created if not provided
  priceId: string,
  paymentMethodId: string,
  metadata?: Record<string, string>,
  address?: IBillingAddress,
): Promise<IApiResponse> => {
  try {
    const subscription: Stripe.Subscription = await stripeService.createSubscriptionWithPaymentMethod(
      customerId,
      priceId,
      paymentMethodId,
      metadata,
      address,
    );
    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SUBSCRIPTION,
      data: subscription,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Retrieves all active plans (prices) associated with a product by productId.
 * Archived prices (active: false) are excluded so they do not appear on the admin dashboard.
 * @param {string} productId - The product id
 * @returns {Promise<IApiResponse>}
 */
export const getPlansByProductId = async (productId: string): Promise<IApiResponse> => {
  try {
    const priceList = await stripeService.getPlansByProductId(productId);

    if (!priceList) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.PRODUCT_NOT_FOUND,
        data: null,
      };
    }

    const activeOnly = priceList.data
      ? { ...priceList, data: priceList.data.filter((price: { active?: boolean }) => price.active !== false) }
      : priceList;

    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_PLAN_LIST,
      data: activeOnly,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Archives a plan (price) on Stripe. Sets active to false so it cannot be used for new subscriptions.
 * @param {string} priceId - The Stripe price ID to archive.
 * @returns {Promise<IApiResponse>}
 */
export const archivePlanByPriceId = async (priceId: string): Promise<IApiResponse> => {
  try {
    const existing = await stripeService.getPlanById(priceId);
    if (!existing) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.PLAN_NOT_FOUND,
        data: null,
      };
    }
    const updated = await stripeService.archivePlan(priceId);
    if (!updated) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.PLAN_NOT_FOUND,
        data: null,
      };
    }
    return {
      status: OK,
      success: true,
      message: paymentMessages.DELETE_PLAN,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};
