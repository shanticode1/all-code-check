import {
  BAD_REQUEST,
  commonMessages,
  CONFLICT,
  NOT_FOUND,
  OK,
  SERVER_ERROR,
  supportMessages,
  supportVariables,
} from '@constants';
import type { IApiResponse, IContactFormSettings, ISupportConfig, IUser } from '@customTypes';
import { Role } from '@enums';
import { prismaService } from '@services';
import { paginationHandler } from '@utils';

/**
 * Get support configuration details.
 * @returns {Promise<IApiResponse>} Response containing support configuration details or error information
 */
export const getSupportConfig = async (): Promise<IApiResponse> => {
  try {
    const supportConfig = await prismaService.getRecords('supportConfig', {
      where: {},
      include: {
        formFields: {
          select: {
            id: true,
            key: true,
            enabled: true,
            required: true,
          },
        },
      },
    });

    if (!supportConfig) {
      return {
        status: NOT_FOUND,
        success: false,
        message: supportMessages.SUPPORT_CONFIG_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.FROM_CONFIG_GET,
      data: supportConfig,
    };
  } catch (_error) {
    return {
      status: NOT_FOUND,
      success: false,
      message: supportMessages.SUPPORT_CONFIG_FETCH_ERROR,
      data: null,
    };
  }
};

/**
 * Update support configuration details.
 * @param {object} updateData - Data to update the support configuration
 * @returns {Promise<IApiResponse>} Response containing the updated support configuration or error information
 */
export const updateSupportConfig = async (updateData: IContactFormSettings, userId: number): Promise<IApiResponse> => {
  try {
    if (!updateData || Object.keys(updateData).length === 0) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: supportMessages.SUPPORT_CONFIG_EMPTY_PAYLOAD,
        data: null,
      };
    }

    const existingConfig = await prismaService.findFirstRecord('supportConfig', { userId });

    let supportConfig: any;

    if (existingConfig) {
      // ✅ Update existing config
      supportConfig = await prismaService.updateRecord(
        'supportConfig',
        {
          primaryEmail: updateData.emailSettings?.primaryEmail?.trim(),
          ccEmails: updateData.emailSettings?.ccEmails ?? undefined,
          formEnabled: updateData.formConfig?.enabled,
          autoReplyEnabled: updateData.autoReply?.enabled,
          autoReplyMessage: updateData.autoReply?.message,
        },
        { id: existingConfig.id },
      );

      // 🔥 Replace form fields (FIXED)
      if (updateData.formConfig?.fields?.length) {
        await prismaService.deleteManyRecords('formField', {
          supportConfigId: existingConfig.id,
        });

        await prismaService.createManyRecord(
          'formField',
          updateData.formConfig.fields.map((field) => ({
            supportConfigId: existingConfig.id,
            key: field.key,
            enabled: field.enabled,
            required: field.required,
          })),
        );
      }
    } else {
      // ✅ Create new config
      supportConfig = await prismaService.createRecord('supportConfig', {
        userId,
        primaryEmail: updateData.emailSettings?.primaryEmail?.trim(),
        ccEmails: updateData.emailSettings?.ccEmails ?? undefined,
        formEnabled: updateData.formConfig?.enabled,
        autoReplyEnabled: updateData.autoReply?.enabled,
        autoReplyMessage: updateData.autoReply?.message,
      });

      if (updateData.formConfig?.fields?.length) {
        await prismaService.createManyRecord(
          'formField',
          updateData.formConfig.fields.map((field) => ({
            supportConfigId: supportConfig.id,
            key: field.key,
            enabled: field.enabled,
            required: field.required,
          })),
        );
      }
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.SUPPORT_CONFIG_UPDATE_SUCCESS,
      data: supportConfig,
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: supportMessages.SUPPORT_CONFIG_UPDATE_ERROR,
      data: null,
    };
  }
};

/**
 * Create a new support ticket.
 * @param {object} ticketData - Data for the new ticket
 * @returns {Promise<IApiResponse>} Response containing the created ticket or error information
 */
export const createTicket = async (ticketData: any): Promise<IApiResponse> => {
  try {
    const year = new Date().getFullYear();

    // Get last ticket for current year
    const lastTicket = await prismaService.findFirstRecord(
      'supportTicket',
      {
        ticketNumber: {
          startsWith: `TKT-${year}-`,
        },
      },
      {
        orderBy: {
          createdAt: 'desc',
        },
        select: {
          ticketNumber: true,
        },
      },
    );

    const nextSeq = lastTicket ? Number(lastTicket.ticketNumber.split('-')[2]) + 1 : 1;

    const ticketNumber = `TKT-${year}-${String(nextSeq).padStart(3, '0')}`;

    // Create ticket
    const newTicket = await prismaService.createRecord('supportTicket', {
      ...ticketData,
      ticketNumber,
    });
    // Get support config
    const [supportConfig] = await prismaService.getRecords('supportConfig', { where: {} });

    let autoReplyMessage = '';

    if (supportConfig?.autoReplyMessage) {
      autoReplyMessage = supportConfig.autoReplyMessage;

      await prismaService.createRecord('ticketChat', {
        ticketId: newTicket.id,
        senderId: supportConfig.userId,
        senderRole: Role.Admin,
        message: autoReplyMessage,
      });
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.TICKET_CREATE_SUCCESS,
      data: {
        newTicket,
        autoReply: autoReplyMessage,
      },
    };
  } catch (error: any) {
    if (error.code === 'P2002') {
      return {
        status: CONFLICT,
        success: false,
        message: 'Ticket number already exists. Please retry.',
        data: null,
      };
    }

    return {
      status: SERVER_ERROR,
      success: false,
      message: supportMessages.TICKET_CREATE_ERROR,
      data: null,
    };
  }
};

/**
 * Get all support tickets.
 * @returns {Promise<IApiResponse>} Response containing all tickets or error information
 */
export const getAllTickets = async (
  ticketId: string,
  pageNumber: number,
  pageSize: number,
  search: string,
  filterParams?: any,
  user?: IUser,
): Promise<IApiResponse> => {
  try {
    /* ================= SINGLE TICKET ================= */
    if (ticketId) {
      const ticket = await prismaService.getRecords('supportTicket', {
        where: { id: Number(ticketId) },
        include: {
          category: {
            select: {
              id: true,
              name: true,
              description: true,
            },
          },
        },
      });
      if (!ticket) {
        return {
          status: NOT_FOUND,
          success: false,
          message: supportMessages.TICKET_NOT_FOUND,
          data: null,
        };
      }

      const isUser = user?.role === Role.User;

      const unreadCount = await prismaService.getCounts('ticketChat', {
        ticketId: Number(ticketId), // ✅ likely correct column
        senderId: { not: user?.id },
        ...(isUser ? { readByUser: false } : { readByAdmin: false }),
      });

      const readCount = await prismaService.getCounts('ticketChat', {
        ticketId: Number(ticketId), // ✅ correct column
        senderId: { not: user?.id },
        ...(isUser ? { readByUser: true } : { readByAdmin: true }),
      });

      return {
        status: OK,
        success: true,
        message: supportMessages.TICKET_FETCH_SUCCESS,
        data: {
          ...ticket,
          unreadCount,
          readCount,
        },
      };
    }

    /* ================= MULTIPLE TICKETS ================= */
    const { limit, offset } = paginationHandler.getPagination(pageNumber, pageSize);

    const where: any = {
      ...filterParams,
    };

    if (user?.role === Role.User) {
      where.userId = user.id;
    }

    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { subject: { contains: search, mode: 'insensitive' } },
        { message: { contains: search, mode: 'insensitive' } },
      ];
    }

    // ✅ Get tickets
    const tickets = await prismaService.findManyRecords('supportTicket', where, {
      include: { category: true },
      orderBy: { createdAt: 'desc' },
      skip: offset,
      take: limit,
    });

    // ✅ FIXED (removed { where })
    const total = await prismaService.getCounts('supportTicket', where);

    if (!tickets.length) {
      return {
        status: OK,
        success: false,
        message: supportMessages.TICKETS_NOT_FOUND,
        data: null,
      };
    }

    const isUser = user?.role === Role.User;

    // ⚠️ Current approach runs 2 queries per ticket (not optimal but fixed)
    const ticketsWithCounts = await Promise.all(
      tickets.map(async (ticket: any) => {
        const unreadCount = await prismaService.getCounts('ticketChat', {
          ticketId: ticket.id,
          senderId: { not: user?.id },
          ...(isUser ? { readByUser: false } : { readByAdmin: false }),
        });

        const readCount = await prismaService.getCounts('ticketChat', {
          ticketId: ticket.id,
          senderId: { not: user?.id },
          ...(isUser ? { readByUser: true } : { readByAdmin: true }),
        });

        return {
          ...ticket,
          unreadCount,
          readCount,
        };
      }),
    );

    return {
      status: OK,
      success: true,
      message: supportMessages.TICKETS_FETCH_SUCCESS,
      data: {
        list: ticketsWithCounts,
        pagination: {
          page: pageNumber,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
          currentPage: pageNumber,
        },
      },
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: supportMessages.TICKETS_FETCH_ERROR,
      data: null,
    };
  }
};

/**
 * Update the status of a support ticket.
 * @param {string} ticketId - ID of the ticket to update
 * @param {string} status - New status for the ticket
 * @returns {Promise<IApiResponse>} Response containing the updated ticket or error information
 */
export const updateTicketStatus = async (ticketId: string, status: string): Promise<IApiResponse> => {
  try {
    const updatedTicket = await prismaService.updateRecord('supportTicket', { status }, { id: Number(ticketId) });

    if (!updatedTicket) {
      return {
        status: NOT_FOUND,
        success: false,
        message: supportMessages.TICKET_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.TICKET_UPDATE_SUCCESS,
      data: updatedTicket,
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: supportMessages.TICKET_UPDATE_ERROR,
      data: null,
    };
  }
};

/**
 * Delete a support ticket.
 * @param {string} ticketId - ID of the ticket to delete
 * @returns {Promise<IApiResponse>} Response containing deleted ticket info or error information
 */
export const deleteTicket = async (ticketId: string): Promise<IApiResponse> => {
  try {
    const deletedTicket = await prismaService.deleteOneRecord('supportTicket', {
      id: Number(ticketId),
    });

    if (!deletedTicket) {
      return {
        status: NOT_FOUND,
        success: false,
        message: supportMessages.TICKET_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.TICKET_DELETE_SUCCESS,
      data: deletedTicket,
    };
  } catch (_error) {
    return {
      status: NOT_FOUND,
      success: false,
      message: commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

/**
 * Get enabled and required support configuration details.
 * Optimized to filter at DB level
 * @returns {Promise<IApiResponse>} Response containing support configuration details or error information
 */
export const getEnabledRequiredSupportConfig = async (): Promise<IApiResponse> => {
  try {
    const [supportConfig] = await prismaService.getRecords('supportConfig', {
      where: {},
      include: {
        formFields: {
          select: {
            id: true,
            key: true,
            enabled: true,
            required: true,
          },
        },
      },
    });

    const fields = supportConfig?.formFields || [];
    // 🔥 Filter enabled OR required fields
    const filteredFields = fields.filter((field: any) => field.enabled === true || field.required === true);

    if (!filteredFields.length) {
      return {
        status: NOT_FOUND,
        success: false,
        message: supportMessages.SUPPORT_CONFIG_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.FROM_CONFIG_GET,
      data: filteredFields,
    };
  } catch (_error) {
    return {
      status: NOT_FOUND,
      success: false,
      message: supportMessages.SUPPORT_CONFIG_FETCH_ERROR,
      data: null,
    };
  }
};

/**
 * Create a new category.
 * @param {object} categoryData - Data for the new category
 * @returns {Promise<IApiResponse>} Response containing the created category or error information
 */
export const addCategory = async (categoryData: object): Promise<IApiResponse> => {
  try {
    const newCategory = await prismaService.createRecord('supportCategory', categoryData);

    return {
      status: OK,
      success: true,
      message: supportMessages.CATEGORY_CREATE_SUCCESS,
      data: newCategory,
    };
  } catch (_error) {
    return {
      status: NOT_FOUND,
      success: false,
      message: supportMessages.CATEGORY_CREATE_ERROR,
      data: null,
    };
  }
};

/**
 * Get category list with pagination and search.
 * @returns {Promise<IApiResponse>} Response containing category list or error information
 */
export const getCategories = async (pageNumber: number, pageSize: number, search?: string): Promise<IApiResponse> => {
  try {
    const { limit, offset } = paginationHandler.getPagination(pageNumber, pageSize);

    const filters: any = {};

    if (search) {
      filters.name = {
        contains: search,
        mode: 'insensitive',
      };
    }

    const categories = await prismaService.findManyRecords('supportCategory', filters, {
      orderBy: { createdAt: 'desc' },
      skip: offset,
      take: limit,
    });

    // ✅ FIXED
    const total = await prismaService.getCounts('supportCategory', filters);

    if (!categories.length) {
      return {
        status: NOT_FOUND,
        success: false,
        message: supportMessages.CATEGORY_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.CATEGORY_FETCH_SUCCESS,
      data: {
        list: categories,
        pagination: {
          offset,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR, // ✅ better status
      success: false,
      message: supportMessages.CATEGORY_FETCH_ERROR,
      data: null,
    };
  }
};

/**
 * Create categories in bulk (no duplicates).
 * @param {object[] | object} categoryData - Category data (single or array)
 * @returns {Promise<IApiResponse>} Response containing inserted categories info
 */
export const seedCategory = async (): Promise<IApiResponse> => {
  try {
    const categoryData = supportVariables.CATEGORIES;
    const categories = Array.isArray(categoryData) ? categoryData : [categoryData];

    await prismaService.createManyRecord('supportCategory', categories);

    return {
      status: OK,
      success: true,
      message: supportMessages.CATEGORY_CREATE_SUCCESS,
      data: {
        insertedCount: categories.length,
      },
    };
  } catch (_error) {
    return {
      status: NOT_FOUND,
      success: false,
      message: supportMessages.CATEGORY_CREATE_ERROR,
      data: null,
    };
  }
};

/**
 * Create ticket chats base on user
 */

export const createTicketChat = async (ticketId: string, payload: any): Promise<IApiResponse> => {
  try {
    const chat = await prismaService.createRecord('ticketChat', {
      ticketId: Number(ticketId),
      senderId: payload.senderId,
      senderRole: payload.senderRole,
      message: payload.message,
    });

    return {
      status: OK,
      success: true,
      message: supportMessages.MESSAGE_SENT_SUCCESS,
      data: {
        chat,
      },
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

/**
 * Get chat list
 * @param ticketId
 * @param currentUserId
 * @param page
 * @param limit
 * @returns
 */

export const getTicketChats = async (
  ticketId: string,
  pageNumber: number,
  pageSize: number,
  currentUserRole: number | undefined,
): Promise<IApiResponse> => {
  try {
    const { limit, offset } = paginationHandler.getPagination(pageNumber, pageSize);

    const numericTicketId = Number(ticketId);

    /* =========================
       🔥 MARK MESSAGES AS READ
    ========================== */

    if (currentUserRole === Role.User) {
      await prismaService.updateManyRecords(
        'ticketChat',
        {
          readByUser: true,
        },
        {
          ticketId: numericTicketId,
          senderRole: Role.Admin,
          readByUser: false,
        },
      );
    }

    if (currentUserRole === Role.Admin) {
      await prismaService.updateManyRecords(
        'ticketChat',
        {
          readByAdmin: true,
        },
        {
          ticketId: numericTicketId,
          senderRole: Role.User,
          readByAdmin: false,
        },
      );
    }

    /* =========================
       🔥 FETCH CHATS
    ========================== */

    const chatsRaw = await prismaService.findManyRecords(
      'ticketChat',
      { ticketId: numericTicketId },
      {
        include: {
          ticket: {
            select: {
              fullName: true,
              email: true,
            },
          },
        },
        orderBy: {
          createdAt: 'asc',
        },
        skip: offset,
        take: limit,
      },
    );

    const total = await prismaService.getCounts('ticketChat', {
      ticketId: numericTicketId,
    });
    const chats = chatsRaw.map(({ ticket, ...rest }: any) => ({
      ...rest,
      sender: ticket,
    }));

    if (!chats.length) {
      return {
        status: NOT_FOUND,
        success: false,
        message: supportMessages.CHAT_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: supportMessages.CHAT_LIST_FETCH_SUCCESS,
      data: {
        messages: chats,
        pagination: {
          pageNumber,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};
