import { BAD_REQUEST, NOT_FOUND, OK, SERVER_ERROR, commonMessages, fileHandlerMessages } from '@constants';
import type { IApiResponse, IFileUploadType, IUser } from '@customTypes';
import { Role } from '@enums';
import { prismaService } from '@services';

/**
 * Get particular file from the database with storage type.
 * @param {Request} req Express request object
 * @returns {IApiResponse} Response containing the files and user detail or error information
 */
export const fetchS3File = async (fileId: string): Promise<IApiResponse> => {
  try {
    if (!fileId) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: fileHandlerMessages.SELECT_FILE_ERROR,
        data: null,
      };
    }

    // 🔥 Prisma instead of File.findById()
    const file = await prismaService.findFirstRecord('file', {
      id: Number(fileId), // remove Number() if using string/uuid id
      isDeleted: false,
    });

    if (!file) {
      return {
        status: NOT_FOUND,
        success: false,
        message: fileHandlerMessages.FILES_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: fileHandlerMessages.FILE_DETAIL_GET_SUCCESS,
      data: file,
    };
  } catch (error: any) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: error.message || commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

/**
 * Get list of files with storage type of a user from the database.
 * @param {Request} req Express request object
 * @returns {IApiResponse} Response containing the files and user detail or error information
 */
export const fetchS3FileList = async (user: IUser): Promise<IApiResponse> => {
  try {
    // Normal users see only their files, admin/others see all
    const whereClause = user.role === Role.User ? { userId: user.id, isDeleted: false } : { isDeleted: false };

    const userFiles = await prismaService.findManyRecords('file', whereClause, {
      orderBy: { createdAt: 'desc' },
    });

    return {
      status: OK,
      success: true,
      message: fileHandlerMessages.FILES_GET_SUCCESS,
      data: userFiles,
    };
  } catch (error: any) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: error.message || commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

/**
 * Store local file path with storage_type to user in database.
 * @param {Request} req Express request object
 * @returns {IApiResponse} Response containing the files and user detail or error information
 */
export const s3FileUpload = async (user: IUser, files: IFileUploadType): Promise<IApiResponse> => {
  try {
    const uploadedFiles: string[] = [];

    if (files?.fileUpload?.length) {
      files.fileUpload.forEach((file: { path: string }) => uploadedFiles.push(file.path));
    }

    if (uploadedFiles.length === 0) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: fileHandlerMessages.SELECTED_FILE_ERROR,
        data: null,
      };
    }

    // Save uploaded file record using Prisma service
    const result = await prismaService.createRecord('file', {
      userId: user.id,
      path: uploadedFiles,
    });

    return {
      status: OK,
      success: true,
      message: fileHandlerMessages.FILES_UPLOAD_SUCCESS,
      data: result,
    };
  } catch (error: any) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: error.message || commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};
