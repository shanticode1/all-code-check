import { logger } from '@config/logger';
import { commonVariables } from '@constants';
import type { IUser } from '@customTypes';

import { prismaService } from '@services';
import { userHandler } from '@utils';

/**
 * Checks if a user exists in the database by their email.
 * @param {string} email - The email of the user to check for existence.
 * @returns {Promise<boolean>} - Resolves to true if the user exists, otherwise false.
 */
export const checkIfUserExists = async (email: string): Promise<boolean> => {
  const existingUser = await prismaService.getRecord('user', {
    where: {
      email: email,
    },
  });

  return !!existingUser;
};

/**
 * Retrieves a user by their ID from the database.
 * @param {string} userId - The ID of the user to be retrieved.
 * @returns {Promise<IUser | null>} - The user document if found, otherwise null.
 */

export const getUserById = async (userId: number): Promise<IUser | null> => {
  const user = await prismaService.findFirstRecord(
    'user',
    { id: userId },
    {
      select: {
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        phoneNumber: true,
        countryCode: true,
        avatar: true,
        status: true,
        isVerified: true,
        isDeleted: true,
        emailOtp: true,
        isTwoAuthEnabled: true,
        hasAcceptedTerms: true,
        lastLogin: true,
        configuredTwoFAMethods: true,
        recoveryCodes: true,
        createdAt: true,
        updatedAt: true,
        id: true,
      },
    },
  );

  return user;
};

/**
 * Retrieves a paginated list of users from the database with specified filtering and sorting.
 *
 * @param {number} limit - The maximum number of users to return.
 * @param {number} offset - The number of users to skip for pagination.
 * @param {Record<string, any>} filter - The filter criteria to apply to the user query.
 * @param {Record<string, any>} sort - The sorting criteria to apply to the user query.
 * @returns {Promise<IUser[]>} - A promise that resolves to an array of user objects, excluding sensitive fields.
 */
export const getAllUsers = async (
  offset: number,
  limit: number,
  filters: Record<string, any> = {},
  orderByClause?: Record<string, any>,
): Promise<any> => {
  try {
    // Fields selection, excluding sensitive fields
    const sensitiveFields = commonVariables.USER_SENSITIVE_INFO_DB_COLUMNS;
    const selectFields: Record<string, boolean> = {
      firstName: true,
      lastName: true,
      email: true,
      role: true,
      phoneNumber: true,
      countryCode: true,
      avatar: true,
      status: true,
      isVerified: true,
      isDeleted: true,
      emailOtp: true,
      isTwoAuthEnabled: true,
      hasAcceptedTerms: true,
      lastLogin: true,
      configuredTwoFAMethods: true,
      recoveryCodes: true,
      createdAt: true,
      updatedAt: true,
      id: true,
    };

    sensitiveFields.forEach((field) => {
      if (selectFields[field] !== undefined) delete selectFields[field];
    });
    // Fetch users from Prisma
    const userList = await prismaService.getRecords('user', {
      where: filters,
      select: selectFields,
      skip: offset,
      take: limit,
      orderBy: orderByClause,
    });
    return userList;
  } catch (error) {
    logger.error(`Could not fetch users: ${error}`);
    return [];
  }
};
/**
 * Retrieves a user by email.
 * @param {string} email The email of the user to be retrieved.
 * @returns {Promise<IUser | null>} The user document if found or null if not found.
 */
export const getUserByEmail = async (email: string) => {
  return await prismaService.getRecord('user', {
    where: {
      email: email.toLowerCase(),
      isDeleted: false,
    },
  });
};

/**
 * Retrieves a user by phone number.
 * @param {string} phoneNumber The phone number of the user to be retrieved.
 * @returns {Promise<IUser | null>} The user document if found or null if not found.
 */
export const getUserByPhone = async (phoneNumber: string) => {
  return await prismaService.getRecord('user', {
    where: {
      phoneNumber,
      isDeleted: false,
    },
  });
};

/**
 * Updates a user's information based on their email.
 * If provided, only fields that differ from the current values will be updated.
 * Special handling is included for updating the 'configuredTwoFAMethods' field.
 *
 * @param {string} email - The email of the user to be updated.
 * @param {Partial<IUser> | null} updates - The fields to update with their new values.
 * @returns {Promise<IUser | null>} - The updated user document, or null if the user was not found.
 */
export const updateUserByEmail = async (email: string, updates: Partial<IUser> | null) => {
  const userDoc = await getUserByEmail(email);
  if (!userDoc) return null;

  const updateData: Record<string, any> = {};

  if (updates) {
    for (const key of Object.keys(updates)) {
      const value = updates[key as keyof IUser];

      if (value === undefined || userDoc[key as keyof IUser] === value) continue;

      if (key === 'configuredTwoFAMethods' && Array.isArray(value)) {
        const currentMethods = userDoc.configuredTwoFAMethods ?? [];

        const newMethods = value.filter(
          (method: any) => !currentMethods.some((existing: any) => existing.methodType === method.methodType),
        );
        console.log(newMethods);

        if (newMethods?.length) {
          updateData.configuredTwoFAMethods = {
            create: newMethods.map((method: any) => ({
              methodType: method.methodType,
              isEnabled: method.isEnabled ?? true,
              isPreferredTwoFAMethod: method.isPreferredTwoFAMethod ?? false,
            })),
          };
        }
      } else {
        updateData[key] = value;
      }
    }
  }
  // If nothing changed return existing user
  if (!Object.keys(updateData)?.length) {
    return userHandler.modelToDomain(userDoc);
  }

  if (updates?.appToken) {
    updateData.appToken = {
      upsert: {
        create: {
          ascii: updates.appToken.ascii,
          hex: updates.appToken.hex,
          base32: updates.appToken.base32,
          otpauthUrl: updates.appToken.otpauth_url,
        },
        update: {
          ascii: updates.appToken.ascii,
          hex: updates.appToken.hex,
          base32: updates.appToken.base32,
          otpauthUrl: updates.appToken.otpauth_url,
        },
      },
    };
  }

  if (updates?.recoveryCodes?.length) {
    updateData.recoveryCodes = {
      create: updates.recoveryCodes.map((code: any) => ({
        code: code.code,
        iv: code.iv,
        tag: code.tag,
        used: code.used ?? false,
      })),
    };
  }
  await prismaService.updateRecord('user', updateData, { email: email.toLowerCase() });

  const user = await prismaService.findFirstRecord(
    'user',
    { email: email.toLowerCase() },
    {
      select: {
        firstName: true,
        lastName: true,
        email: true,
        role: true,
        phoneNumber: true,
        countryCode: true,
        avatar: true,
        status: true,
        isVerified: true,
        isDeleted: true,
        emailOtp: true,
        isTwoAuthEnabled: true,
        hasAcceptedTerms: true,
        lastLogin: true,
        configuredTwoFAMethods: true,
        recoveryCodes: true,
        createdAt: true,
        updatedAt: true,
        id: true,
      },
    },
  );
  return userHandler.modelToDomain(user);
};
