/* eslint-disable no-useless-catch */
import env from '@config/envVar';
import { PrismaClient } from '../../generated/prisma';
import { logger } from '@config/logger';
import { PrismaPg } from '@prisma/adapter-pg';

interface QueryOptions {
  where?: any;
  include?: any;
  select?: any;
  orderBy?: any;
  skip?: number;
  take?: number;
  distinct?: any;
}

/**
 * Prisma Client Initialization (Singleton)
 */

const adapter = new PrismaPg({
  connectionString: `${env.DATABASE_URL!}`,
});

export const prisma = new PrismaClient({
  adapter,
} as any);

const prismaModels = new Set(Object.keys(prisma).filter((key) => !key.startsWith('$') && !key.startsWith('_')));

prisma
  .$connect()
  .then(() => console.log('Prisma connected'))
  .catch((err) => console.error('Prisma connection error:', err));

/**
 * Helper Functions
 */

const getModel = (modelName: string) => {
  if (!prismaModels.has(modelName)) {
    throw new Error(`"${modelName}" is not a valid Prisma model`);
  }
  return (prisma as any)[modelName];
};

const sanitizeInclude = (record: any, keys: string[]) => {
  return Object.fromEntries(Object.entries(record).filter(([key]) => keys.includes(key)));
};

/**
 * ------------------- CRUD Methods -------------------
 */

export const createRecord = async (modelName: string, record: any) => {
  try {
    const model = getModel(modelName);
    return await model.create({ data: record });
  } catch (error) {
    logger.error(`Create record failed: ${error}`);
    throw error;
  }
};

export const createRecordV2 = async (modelName: string, options: Record<string, any> = {}) => {
  try {
    const model = getModel(modelName);
    return await model.create({ ...options });
  } catch (error) {
    logger.error(`Create record failed: ${error}`);
    throw error;
  }
};

export const createManyRecords = async (modelName: string, records: any[], skipDuplicates = true) => {
  try {
    const model = getModel(modelName);
    return await model.createMany({ data: records, skipDuplicates });
  } catch (error) {
    logger.error(`Create many records failed: ${error}`);
    throw error;
  }
};

export const updateRecord = async (modelName: string, record: any, where: any) => {
  try {
    const model = getModel(modelName);
    return await model.update({ data: record, where });
  } catch (error: any) {
    if (error.code === 'P2025') return null;
    throw error;
  }
};

export const upsertRecord = async (modelName: string, where: any, createData: any, updateData: any) => {
  const model = getModel(modelName);

  return await model.upsert({
    where,
    create: createData,
    update: updateData,
  });
};

export const deleteRecord = async (modelName: string, where: any) => {
  try {
    const model = getModel(modelName);
    return await model.delete({ where });
  } catch (error) {
    logger.error(`Delete record failed: ${error}`);
    throw error;
  }
};

export const deleteManyRecords = async (modelName: string, where: any = {}) => {
  try {
    const model = getModel(modelName);
    return await model.deleteMany({ where });
  } catch (error) {
    logger.error(`Delete many records failed: ${error}`);
    throw error;
  }
};

export const findFirstRecord = async (modelName: string, where: any = {}, options: QueryOptions = {}) => {
  try {
    const model = getModel(modelName);
    return await model.findFirst({ where, ...options });
  } catch (error) {
    logger.error(`Find first record failed: ${error}`);
    throw error;
  }
};

export const findManyRecords = async (modelName: string, filters: any = {}, options: QueryOptions = {}) => {
  try {
    const model = getModel(modelName);
    const whereClause = Object.keys(filters).length ? filters : undefined;
    return await model.findMany({ where: whereClause, ...options });
  } catch (error) {
    logger.error(`Find many records failed: ${error}`);
    throw error;
  }
};

export const getRecordById = async (modelName: string, where: any, options: QueryOptions = {}) => {
  try {
    const model = getModel(modelName);
    return await model.findUnique({ where, ...options });
  } catch (error) {
    logger.error(`Get record by ID failed: ${error}`);
    throw error;
  }
};

export const findRecordByEmail = async (modelName: string, email: string, includeKeys: string[] = []) => {
  try {
    const model = getModel(modelName);
    const record = await model.findUnique({ where: { email } });
    return record ? sanitizeInclude(record, includeKeys) : null;
  } catch (error) {
    logger.error(`Find record by email failed: ${error}`);
    throw error;
  }
};

export const getCounts = async (modelName: string, where: any = {}) => {
  try {
    const model = getModel(modelName);
    return await model.count({ where });
  } catch (error) {
    logger.error(`Get counts failed: ${error}`);
    throw error;
  }
};

export const getRecord = async (modelName: string, options: QueryOptions = {}) => {
  try {
    const model = getModel(modelName);
    return await model.findUnique({ ...options });
  } catch (error) {
    logger.error(`Get one record failed: ${error}`);
    throw error;
  }
};

export const getRecords = async (modelName: string, options: QueryOptions = {}) => {
  try {
    const model = getModel(modelName);
    return await model.findMany({ ...options });
  } catch (error) {
    logger.error(`Get records failed: ${error}`);
    throw error;
  }
};

export const deleteOneRecord = async (modelName: string, identifierId: any) => {
  try {
    const model = getModel(modelName);

    await model.delete({
      where: identifierId,
    });

    return true;
  } catch (error: any) {
    if (error.code === 'P2025') {
      // Record not found
      return false;
    }

    logger.error(`Delete record failed: ${error}`);
    throw error;
  }
};

/**
 * @description This method insert a record into the database
 * @param modelName ,
 * @param record
 * @returns
 */
export const createManyRecord = async (modelName: string, record: any): Promise<boolean> => {
  try {
    const model = getModel(modelName);
    await model.createMany({
      data: record, // ex: [{name: "John Doe", email: "john.doe@example.com"}]
      skipDuplicates: true, // Optionally skip duplicates based on unique fields (like `email`)
    });
    return true;
  } catch (error) {
    logger.error(`Create Many Records failed: ${error}`);
    throw error; // Re-throw the error to propagate it
  }
};

export const updateManyRecords = async (
  modelName: string,
  data: Record<string, any>,
  condition: Record<string, any>,
): Promise<number> => {
  try {
    const model = getModel(modelName);
    const result = await model.updateMany({
      where: condition,
      data,
    });

    return result.count;
  } catch (error) {
    logger.error(`Update Many Records failed: ${error}`);
    throw error;
  }
};

export const disconnect = async () => {
  await prisma.$disconnect();
  logger.log('Prisma disconnected');
};
