import { paymentMessages, commonMessages, NOT_FOUND, OK, SERVER_ERROR, paymentVariables } from '@constants';
import type { IApiResponse, ICreateUserSubscriptionRequest, IUpdateUserSubscriptionRequest } from '@customTypes';
import { SubscriptionStatus } from '@enums';
import { logger } from '@config/logger';
import { paginationHandler, paymentHandler } from '@utils';
import { prismaService, stripeService } from '@services';
import type Stripe from 'stripe';

const {
  DEFAULT_PLAN_NAME_FALLBACK,
  DEFAULT_CURRENCY,
  MAX_INVOICE_FETCH_LIMIT,
  INVOICE_STATUS_PAID,
  INVOICE_STATUS_OPEN,
  INVOICE_STATUS_VOID,
  INVOICE_STATUS_UNCOLLECTIBLE,
  PAYMENT_STATUS_SUCCESS,
  PAYMENT_STATUS_PROCESSING,
  PAYMENT_STATUS_CANCELLED,
  PAYMENT_STATUS_FAILED,
  PAYMENT_STATUS_UNKNOWN,
} = paymentVariables;

/**
 * Get User Subscription
 * @param filters
 * @returns
 */

export const getSubscriptions = async (filter: any) => {
  try {
    // userSubscription
    return await prismaService.findFirstRecord('subscription', filter);
  } catch (error) {
    logger.error(`Error fetching active subscription: ${error}`);
    return null;
  }
};

/**
 * Maps Stripe subscription status to our SubscriptionStatus enum
 */
const mapStripeStatusToSubscriptionStatus = (stripeStatus: string): SubscriptionStatus => {
  const statusMap: Record<string, SubscriptionStatus> = {
    active: SubscriptionStatus.ACTIVE,
    trialing: SubscriptionStatus.TRIAL,
    past_due: SubscriptionStatus.PAST_DUE,
    canceled: SubscriptionStatus.CANCELLED,
    cancelled: SubscriptionStatus.CANCELLED,
    unpaid: SubscriptionStatus.INACTIVE,
    incomplete: SubscriptionStatus.INACTIVE,
    incomplete_expired: SubscriptionStatus.EXPIRED,
  };
  return statusMap[stripeStatus.toLowerCase()] || SubscriptionStatus.INACTIVE;
};

/**
 * Gets user subscription by userId
 * @param {string} userId - The user ID
 * @returns {Promise<IApiResponse>}
 */
export const getUserSubscriptionByUserId = async (userId: string): Promise<IApiResponse> => {
  try {
    const subscription = await getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
    });
    if (!subscription) {
      return {
        status: OK,
        success: false,
        message: paymentMessages.SUBSCRIPTION_NOT_FOUND,
        data: null,
      };
    }

    const formattedSubscription = paymentHandler.userSubscriptionModelToDomain(subscription);

    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_SUBSCRIPTION,
      data: formattedSubscription,
    };
  } catch (error) {
    logger.error(`Error getting user subscription by userId: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Creates or updates user subscription by userId (upsert)
 * Used primarily by webhook handlers
 * @param {ICreateUserSubscriptionRequest} data - The subscription data
 * @returns {Promise<IApiResponse>}
 */
export const createOrUpdateByUserId = async (data: ICreateUserSubscriptionRequest): Promise<IApiResponse> => {
  try {
    const baseData: any = {
      customerId: data.customerId,
      planId: data.planId,
      planName: data.planName,
      expiry: data.expiry,
      status: data.status,
      stripeSubscriptionId: data.stripeSubscriptionId,
      updatedAt: new Date(),
    };

    if (data.entitlements) {
      baseData.entitlements = {
        deleteMany: {},
        create: data.entitlements.map((ent: any) => ({
          featureId: ent.featureId,
          featureValue: ent.featureValue,
          type: ent.type,
          limit: ent.limit,
          currentUsage: ent.currentUsage ?? 0,
          unit: ent.unit,
          resetPeriod: ent.resetPeriod ?? 'monthly',
          lastReset: new Date(),
        })),
      };
    }

    // 1️⃣ Try update first
    let subscription = await prismaService.updateRecord('subscription', baseData, {
      userId: Number(data.userId),
      isDeleted: false,
    });

    // 2️⃣ If not found → create
    if (!subscription) {
      subscription = await prismaService.createRecord('subscription', {
        userId: Number(data.userId),
        ...baseData,
        ...(data.entitlements && {
          entitlements: {
            create: data.entitlements.map((ent: any) => ({
              featureId: ent.featureId,
              featureValue: ent.featureValue,
              type: ent.type,
              limit: ent.limit,
              currentUsage: ent.currentUsage ?? 0,
              unit: ent.unit,
              resetPeriod: ent.resetPeriod ?? 'monthly',
              lastReset: new Date(),
            })),
          },
        }),
      });
    }

    const formattedSubscription = paymentHandler.userSubscriptionModelToDomain(subscription);

    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SUBSCRIPTION,
      data: formattedSubscription,
    };
  } catch (error) {
    logger.error(`Error creating/updating user subscription: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Gets user subscription by Stripe subscription ID (read-only)
 * @param {string} stripeSubscriptionId - The Stripe subscription ID
 * @returns {Promise<IApiResponse>}
 */
export const getByStripeSubscriptionId = async (stripeSubscriptionId: string): Promise<IApiResponse> => {
  try {
    const subscription = await getSubscriptions({
      stripeSubscriptionId: stripeSubscriptionId,
      isDeleted: false,
    });

    if (!subscription) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.SUBSCRIPTION_NOT_FOUND,
        data: null,
      };
    }

    const formattedSubscription = paymentHandler.userSubscriptionModelToDomain(subscription);

    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_SUBSCRIPTION,
      data: formattedSubscription,
    };
  } catch (error) {
    logger.error(`Error getting subscription by Stripe ID: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Updates user subscription by Stripe subscription ID
 * Used by webhook handlers when subscription status changes
 * @param {string} stripeSubscriptionId - The Stripe subscription ID
 * @param {IUpdateUserSubscriptionRequest} updates - The update data
 * @returns {Promise<IApiResponse>}
 */
export const updateByStripeSubscriptionId = async (
  stripeSubscriptionId: string,
  updates: IUpdateUserSubscriptionRequest,
): Promise<IApiResponse> => {
  try {
    // ✅ 1️⃣ MUST await this
    const subscription = await getSubscriptions({
      stripeSubscriptionId,
      isDeleted: false,
    });

    if (!subscription) {
      logger.info(`Subscription not found for Stripe ID: ${stripeSubscriptionId}`);
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.SUBSCRIPTION_NOT_FOUND,
        data: null,
      };
    }

    const updateData: any = {
      ...updates,
      updatedAt: new Date(),
    };

    // ✅ 2️⃣ Use UNIQUE field (id)
    const updatedRecord = await prismaService.updateRecord('subscription', updateData, {
      id: subscription.id, // 🔥 THIS FIXES EVERYTHING
    });

    const formattedSubscription = paymentHandler.userSubscriptionModelToDomain(updatedRecord);

    return {
      status: OK,
      success: true,
      message: paymentMessages.UPDATE_SUBSCRIPTION,
      data: formattedSubscription,
    };
  } catch (error) {
    logger.error(`Error updating subscription by Stripe ID: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Updates user subscription by customer ID
 * Since only one subscription can be active per user, using customer ID is more reliable
 * @param {string} customerId - The Stripe customer ID
 * @param {IUpdateUserSubscriptionRequest} updates - The update data
 * @returns {Promise<IApiResponse>}
 */
export const updateByCustomerId = async (
  customerId: string,
  updates: IUpdateUserSubscriptionRequest,
): Promise<IApiResponse> => {
  try {
    const subscription = getSubscriptions({ customerId, isDeleted: false });

    if (!subscription) {
      logger.info(`Subscription not found for customer ID: ${customerId}`);
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.SUBSCRIPTION_NOT_FOUND,
        data: null,
      };
    }

    // UserSubscription
    const updatedRecord = await prismaService.updateRecord(
      'subscription',
      {
        ...updates,
        updatedAt: new Date(),
      },
      { customerId, isDeleted: false },
    );
    const formattedSubscription = paymentHandler.userSubscriptionModelToDomain(updatedRecord);

    return {
      status: OK,
      success: true,
      message: paymentMessages.UPDATE_SUBSCRIPTION,
      data: formattedSubscription,
    };
  } catch (error) {
    logger.error(`Error updating subscription by customer ID: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Gets customer ID from user subscription
 * Used when creating checkout session to get existing customer
 * @param {string} userId - The user ID
 * @returns {Promise<string | null>} The customer ID or null if not found
 */
export const getCustomerIdByUserId = async (userId: string): Promise<string | null> => {
  try {
    const subscription = await getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
    });

    return subscription?.customerId || null;
  } catch (error) {
    logger.error(`Error getting customer ID by userId: ${error}`);
    return null;
  }
};

/**
 * Gets all user subscriptions with populated user details (Admin only)
 * @param {number} page - Page number (default: 1)
 * @param {number} limit - Items per page (default: 10)
 * @param {string} search - Search query for user name/email
 * @returns {Promise<IApiResponse>}
 */
export const getAllUserSubscriptions = async (page = 1, limit = 10, search?: string): Promise<IApiResponse> => {
  try {
    // ✅ Pagination
    const { limit: paginationLimit, offset } = paginationHandler.getPagination(page, limit);

    /* =============================
       🔎 Build Where Condition
    ============================== */

    const whereCondition: any = {
      isDeleted: false,
    };

    if (search) {
      whereCondition.user = {
        OR: [
          {
            email: {
              contains: search,
              mode: 'insensitive',
            },
          },
          {
            firstName: {
              contains: search,
              mode: 'insensitive',
            },
          },
          {
            lastName: {
              contains: search,
              mode: 'insensitive',
            },
          },
        ],
      };
    }

    /* =============================
       📦 Fetch Data + Count
    ============================== */

    const [total, subscriptions] = await Promise.all([
      prismaService.getCounts('subscription', whereCondition),

      prismaService.getRecords('subscription', {
        where: whereCondition,
        include: {
          user: {
            select: {
              id: true,
              email: true,
              firstName: true,
              lastName: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: paginationLimit,
      }),
    ]);

    /* =============================
       🎨 Format Response
    ============================== */

    const formattedSubscriptions = subscriptions.map((sub: any) => ({
      id: sub.id,
      userId: sub.userId,
      user: sub.user
        ? {
            id: sub.user.id,
            email: sub.user.email,
            firstName: sub.user.firstName,
            lastName: sub.user.lastName,
            name: `${sub.user.firstName || ''} ${sub.user.lastName || ''}`.trim(),
          }
        : null,
      customerId: sub.customerId,
      planId: sub.planId,
      planName: sub.planName,
      expiry: sub.expiry,
      status: sub.status,
      stripeSubscriptionId: sub.stripeSubscriptionId,
      createdAt: sub.createdAt,
      updatedAt: sub.updatedAt,
    }));

    /* =============================
       📤 Final Response
    ============================== */

    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_SUBSCRIPTION,
      data: {
        subscriptions: formattedSubscriptions,
        pagination: {
          page,
          limit: paginationLimit,
          total,
          totalPages: Math.ceil(total / paginationLimit),
        },
      },
    };
  } catch (error) {
    logger.error(`Error getting all user subscriptions: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Gets billing history for a user by fetching invoices from Stripe
 * @param {string} userId - The user ID
 * @param {number} page - Page number (default: 1)
 * @param {number} limit - Items per page (default: 10)
 * @param {string} search - Search query for filtering billing history
 * @returns {Promise<IApiResponse>}
 */
export const getUserBillingHistory = async (
  userId: string,
  page = 1,
  limit = 10,
  search?: string,
): Promise<IApiResponse> => {
  try {
    // Get user subscription to get customerId
    const subscription = await getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
    });

    if (!subscription || !subscription.customerId) {
      return {
        status: OK,
        success: false,
        message: paymentMessages.SUBSCRIPTION_NOT_FOUND,
        data: null,
      };
    }
    // Get pagination parameters using pagination handler
    const { limit: paginationLimit, offset } = paginationHandler.getPagination(page, limit);

    // Fetch invoices from Stripe (fetch a large batch, we'll paginate on our side)
    const invoices = await stripeService.fetchCustomerInvoices(subscription.customerId, MAX_INVOICE_FETCH_LIMIT);

    // Format billing history (using Promise.all for async operations)
    const billingHistory = await Promise.all(
      invoices.map(async (invoice: Stripe.Invoice) => {
        const lineItem = invoice.lines.data[0];

        // Get plan name with fallbacks
        let planName = lineItem?.price?.metadata?.planName;

        // Fallback to line item description
        if (!planName && lineItem?.description) {
          planName = lineItem.description;
        }

        // Fallback to product name if price is expanded
        if (!planName && lineItem?.price) {
          const price = lineItem.price as Stripe.Price;
          if (price.product && typeof price.product === 'object') {
            const product = price.product as Stripe.Product;
            planName = product.name;
          } else if (typeof price.product === 'string') {
            // Fetch product if it's just an ID
            try {
              const product = await stripeService.fetchProduct(price.product);
              if (product?.name) {
                planName = product.name;
              }
            } catch (error) {
              logger.warn(`Could not fetch product name for price ${price.id}: ${error}`);
            }
          }
        }

        // Final fallback to stored planName from user subscription
        if (!planName && subscription?.planName) {
          planName = subscription.planName;
        }

        // Default fallback
        if (!planName) {
          planName = DEFAULT_PLAN_NAME_FALLBACK;
        }

        // Get amount (convert from cents to dollars)
        const amount = invoice.amount_paid ? invoice.amount_paid / 100 : 0;

        // Get dates (convert to ISO strings for JSON serialization)
        const purchaseDate = invoice.created
          ? new Date(invoice.created * 1000).toISOString()
          : new Date().toISOString();
        const endDate = invoice.period_end ? new Date(invoice.period_end * 1000).toISOString() : null;

        // Map invoice status to payment status
        let status = PAYMENT_STATUS_UNKNOWN;
        if (invoice.status === INVOICE_STATUS_PAID) {
          status = PAYMENT_STATUS_SUCCESS;
        } else if (invoice.status === INVOICE_STATUS_OPEN) {
          status = PAYMENT_STATUS_PROCESSING;
        } else if (invoice.status === INVOICE_STATUS_VOID) {
          status = PAYMENT_STATUS_CANCELLED;
        } else if (invoice.status === INVOICE_STATUS_UNCOLLECTIBLE) {
          status = PAYMENT_STATUS_FAILED;
        } else {
          status = invoice.status || PAYMENT_STATUS_UNKNOWN;
        }

        return {
          id: invoice.id,
          invoiceNumber: invoice.number,
          planName,
          amount,
          currency: invoice.currency?.toUpperCase() || DEFAULT_CURRENCY,
          purchaseDate,
          endDate,
          status,
          invoicePdf: invoice.invoice_pdf,
          hostedInvoiceUrl: invoice.hosted_invoice_url,
          subscriptionId: typeof invoice.subscription === 'string' ? invoice.subscription : invoice.subscription?.id,
          createdAt: invoice.created ? new Date(invoice.created * 1000).toISOString() : new Date().toISOString(),
        };
      }),
    );

    // Sort by purchase date (newest first)
    billingHistory.sort((a, b) => new Date(b.purchaseDate).getTime() - new Date(a.purchaseDate).getTime());

    // Apply search filter if provided (only plan name, amount, and status)
    let filteredBillingHistory = billingHistory;
    if (search?.trim()) {
      const searchLower = search.toLowerCase();
      filteredBillingHistory = billingHistory.filter((item) => {
        return (
          item.planName?.toLowerCase().includes(searchLower) ||
          item.amount?.toString().includes(searchLower) ||
          item.status?.toLowerCase().includes(searchLower)
        );
      });
    }

    // Get total count before pagination
    const total = filteredBillingHistory.length;

    // Apply pagination
    const paginatedBillingHistory = filteredBillingHistory.slice(offset, offset + paginationLimit);

    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_SUBSCRIPTION,
      data: {
        billingHistory: paginatedBillingHistory,
        total,
        pagination: {
          page,
          limit: paginationLimit,
          total,
          totalPages: Math.ceil(total / paginationLimit),
        },
      },
    };
  } catch (error) {
    logger.error(`Error getting billing history for user ${userId}: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Gets Customer Portal session URL for user to manage subscription
 * @param {string} userId - The user ID
 * @param {string} returnUrl - The URL to return to after portal session
 * @returns {Promise<IApiResponse>}
 */
export const getCustomerPortalUrl = async (userId: string, returnUrl: string): Promise<IApiResponse> => {
  try {
    // Get user subscription to get customerId
    const subscription = await getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
    });

    if (!subscription || !subscription.customerId) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.SUBSCRIPTION_NOT_FOUND,
        data: null,
      };
    }

    // Create customer portal session
    const portalUrl = await stripeService.createCustomerPortalSession(subscription.customerId, returnUrl);

    return {
      status: OK,
      success: true,
      message: paymentMessages.GET_SUBSCRIPTION,
      data: { url: portalUrl },
    };
  } catch (error) {
    logger.error(`Error getting customer portal URL for user ${userId}: ${error}`);
    return {
      status: SERVER_ERROR,
      success: false,
      message: commonMessages.PROCESS_FAILED_ERROR,
      data: null,
    };
  }
};

/**
 * Helper function to map Stripe status to SubscriptionStatus
 * Exported for use in webhook handlers
 */
export { mapStripeStatusToSubscriptionStatus };
