import { logger } from '@config/logger';
import { entitlementVariables, paymentVariables } from '@constants';
import type { IFeatureEntitlement } from '@customTypes';
import { SubscriptionStatus } from '@enums';
import { prismaService, userSubscriptionService } from '@services';
import { entitlementHandler } from '@utils';

const { ENTITLEMENT_LIMIT_UNLIMITED, ENTITLEMENT_RESET_PERIOD_MONTHLY } = paymentVariables;

const { ENTITLEMENT_RESET_PERIOD_DAILY, ENTITLEMENT_RESET_PERIOD_YEARLY } = entitlementVariables;

/**
 * Check if user has access to a specific feature
 */
export const hasFeature = async (userId: string, featureValue: string): Promise<boolean> => {
  try {
    // UserSubscription
    const subscription = await userSubscriptionService.getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
      status: SubscriptionStatus.ACTIVE,
    });
    if (!subscription) return false;

    return entitlementHandler.hasFeatureAccess(subscription.entitlements, featureValue);
  } catch (error) {
    logger.error(`Error checking feature access: ${error}`);
    return false;
  }
};

/**
 * Get feature limit for a user
 */
export const getFeatureLimit = async (
  userId: string,
  featureValue: string,
): Promise<number | typeof ENTITLEMENT_LIMIT_UNLIMITED | null> => {
  try {
    // UserSubscription
    const subscription = await userSubscriptionService.getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
    });

    if (!subscription) return null;

    return entitlementHandler.getLimitFromEntitlements(subscription.entitlements, featureValue);
  } catch (error) {
    logger.error(`Error getting feature limit: ${error}`);
    return null;
  }
};

/**
 * Check if user can use a feature (limit not exceeded)
 */
export const canUseFeature = async (userId: string, featureValue: string): Promise<boolean> => {
  try {
    // UserSubscription
    const subscription = await userSubscriptionService.getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
      status: SubscriptionStatus.ACTIVE,
    });
    if (!subscription) return false;

    return entitlementHandler.canUseFeatureFromEntitlements(subscription.entitlements, featureValue);
  } catch (error) {
    logger.error(`Error checking feature usage: ${error}`);
    return false;
  }
};

/**
 * Increment usage counter for a feature
 */
export const incrementUsage = async (userId: string, featureValue: string, amount = 1): Promise<boolean> => {
  try {
    const result = await prismaService.updateManyRecords(
      'subscriptionEntitlement',
      {
        currentUsage: {
          increment: amount,
        },
      },
      {
        featureValue,
        subscription: {
          userId,
        },
      },
    );

    return result > 0;
  } catch (error) {
    logger.error(`Error incrementing feature usage: ${error}`);
    return false;
  }
};

/**
 * Get current usage and limit for a feature
 */
export const getCurrentUsage = async (
  userId: string,
  featureValue: string,
): Promise<{ current: number; limit: number | typeof ENTITLEMENT_LIMIT_UNLIMITED } | null> => {
  try {
    const subscription = await userSubscriptionService.getSubscriptions({
      userId: Number(userId),
      isDeleted: false,
    });

    if (!subscription) return null;

    return entitlementHandler.getCurrentUsageFromEntitlements(subscription.entitlements, featureValue);
  } catch (error) {
    logger.error(`Error getting current usage: ${error}`);
    return null;
  }
};

/**
 * Reset usage for features with a specific reset period (called by cron)
 */
export const resetUsageForPeriod = async (
  resetPeriod:
    | typeof ENTITLEMENT_RESET_PERIOD_DAILY
    | typeof ENTITLEMENT_RESET_PERIOD_MONTHLY
    | typeof ENTITLEMENT_RESET_PERIOD_YEARLY,
): Promise<{ modifiedCount: number }> => {
  try {
    const modifiedCount = await prismaService.updateManyRecords(
      'subscriptionEntitlement',
      {
        currentUsage: 0,
        lastReset: new Date(),
      },
      {
        resetPeriod,
      },
    );

    logger.info(`Reset ${resetPeriod} usage for ${modifiedCount} entitlements`);

    return { modifiedCount };
  } catch (error) {
    logger.error(`Error resetting usage for period ${resetPeriod}: ${error}`);
    return { modifiedCount: 0 };
  }
};

/**
 * Get all entitlements for a user
 */
export const getUserEntitlements = async (userId: string): Promise<IFeatureEntitlement[] | null> => {
  try {
    const subscription = await prismaService.findFirstRecord('subscription', {
      userId: Number(userId),
    });

    if (!subscription) return null;

    return subscription.entitlements || [];
  } catch (error) {
    logger.error(`Error getting user entitlements: ${error}`);
    return null;
  }
};

/**
 * Update entitlements for a user (used when upgrading/downgrading plans)
 */
export const updateUserEntitlements = async (userId: number, entitlements: IFeatureEntitlement[]): Promise<boolean> => {
  try {
    // 1️⃣ Get user subscription
    const subscription = await prismaService.findFirstRecord('subscription', { userId });

    if (!subscription) return false;

    const subscriptionId = subscription.id;

    // 2️⃣ Delete existing entitlements
    await prismaService.deleteManyRecords('subscriptionEntitlement', {
      userSubscriptionId: subscriptionId,
    });
    console.log('call internemt -------------');

    // 3️⃣ Create new entitlements
    if (entitlements?.length) {
      await prismaService.createManyRecords(
        'subscriptionEntitlement',
        entitlements.map((entitlement) => ({
          ...entitlement,
          userSubscriptionId: subscriptionId,
          currentUsage: entitlement.currentUsage ?? 0,
          lastReset: new Date(),
        })),
      );
    }

    return true;
  } catch (error) {
    logger.error(`Error updating user entitlements: ${error}`);
    return false;
  }
};

/**
 * Check and decrement count-based features (e.g., team members)
 */
export const decrementUsage = async (userId: number, featureValue: string, amount: number): Promise<boolean> => {
  try {
    const modifiedCount = await prismaService.updateManyRecords(
      'subscriptionEntitlement',
      {
        currentUsage: {
          decrement: amount,
        },
      },
      {
        featureValue,
        currentUsage: {
          gte: amount,
        },
        subscription: {
          userId,
        },
      },
    );

    return modifiedCount > 0;
  } catch (error) {
    logger.error(`Error decrementing feature usage: ${error}`);
    return false;
  }
};
