import { logger } from '@config/logger';
import { commonMessages, NOT_FOUND, OK, paymentMessages, SERVER_ERROR } from '@constants';
import { IApiResponse, ICreateSavedCardRequest, ISaveCardFilter, ISetupIntentResult } from '@customTypes';
import { prismaService, stripeService, userSubscriptionService } from '@services';
import { paymentHandler } from '@utils';

export const retrieveCardDetails = async (filter: ISaveCardFilter) => {
  try {
    return await prismaService.findFirstRecord('savedCard', filter);
  } catch (error) {
    logger.error(`Error retrieving card details: ${error}`);
    return null;
  }
};

/**
 * Creates a Setup Intent for saving cards (tokenization)
 * @returns {Promise<IApiResponse>}
 */
export const createSavedCardSetupIntent = async (
  userId: string,
  customerEmail: string,
  customerName?: string,
  customerId?: string,
): Promise<IApiResponse> => {
  try {
    let finalCustomerId = customerId;

    if (!finalCustomerId) {
      // Try saved cards first
      const filters = {
        userId: Number(userId),
        isDeleted: false,
      };

      const existingCard = await retrieveCardDetails(filters);

      if (existingCard?.customerId) {
        finalCustomerId = existingCard.customerId;
      }
    }

    if (!finalCustomerId) {
      const subscriptionResult = await userSubscriptionService.getUserSubscriptionByUserId(userId);
      if (subscriptionResult.success && subscriptionResult.data?.customerId) {
        finalCustomerId = subscriptionResult.data.customerId;
      }
    }

    const result: ISetupIntentResult = await stripeService.createSetupIntent(
      finalCustomerId,
      customerEmail,
      customerName,
      userId,
    );

    return {
      status: OK,
      success: true,
      message: paymentMessages.CREATE_SETUP_INTENT,
      data: result,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Saves a card token for a user
 * @returns {Promise<IApiResponse>}
 */
export const saveCard = async (userId: string, data: ICreateSavedCardRequest): Promise<IApiResponse> => {
  try {
    console.log(data, '-----80');

    const paymentMethod = await stripeService.retrievePaymentMethod(data.paymentMethodId);
    if (paymentMethod.type !== 'card' || !paymentMethod.card) {
      return {
        status: SERVER_ERROR,
        success: false,
        message: commonMessages.PROCESS_FAILED_ERROR,
        data: null,
      };
    }

    // Extract card fingerprint for duplicate detection
    const cardFingerprint = paymentMethod.card.fingerprint;
    if (!cardFingerprint) {
      return {
        status: SERVER_ERROR,
        success: false,
        message: commonMessages.PROCESS_FAILED_ERROR,
        data: null,
      };
    }

    const customerId = (paymentMethod.customer as string | null) || data.customerId || null;

    if (!customerId) {
      return {
        status: SERVER_ERROR,
        success: false,
        message: commonMessages.PROCESS_FAILED_ERROR,
        data: null,
      };
    }

    // Check if same payment method ID already exists (idempotency check)
    const filters = {
      userId: Number(userId),
      paymentMethodId: data.paymentMethodId,
      isDeleted: false,
    };

    const existingByPaymentMethod = await retrieveCardDetails(filters);

    if (existingByPaymentMethod) {
      return {
        status: OK,
        success: true,
        message: paymentMessages.SAVE_CARD,
        data: paymentHandler.savedCardModelToDomain(existingByPaymentMethod),
      };
    }

    // Check if same physical card (fingerprint) already exists
    // If duplicate found, return existing card (don't block payment flow)
    const cardFilters = {
      userId: Number(userId),
      cardFingerprint: cardFingerprint,
      isDeleted: false,
    };

    const existingByFingerprint = await retrieveCardDetails(cardFilters);

    if (existingByFingerprint) {
      // Card already saved - return existing card to allow payment to proceed
      return {
        status: OK,
        success: true,
        message: paymentMessages.SAVE_CARD,
        data: paymentHandler.savedCardModelToDomain(existingByFingerprint),
      };
    }

    const cardCount = await prismaService.getCounts('savedCard', {
      userId: Number(userId),
      isDeleted: false,
    });

    const cardData = {
      userId: Number(userId),
      customerId,
      paymentMethodId: data.paymentMethodId,
      cardFingerprint: cardFingerprint,
      brand: paymentMethod.card.brand,
      last4: paymentMethod.card.last4,
      expMonth: paymentMethod.card.exp_month,
      expYear: paymentMethod.card.exp_year,
      isDefault: cardCount === 0,
    };

    const savedCard = await prismaService.createRecord('savedCard', cardData);

    return {
      status: OK,
      success: true,
      message: paymentMessages.SAVE_CARD,
      data: paymentHandler.savedCardModelToDomain(savedCard),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Lists saved cards for a user
 * @returns {Promise<IApiResponse>}
 */
export const listSavedCards = async (userId: string): Promise<IApiResponse> => {
  try {
    const cards = await prismaService.getRecords('savedCard', {
      where: { userId: Number(userId), isDeleted: false },
      orderBy: { createdAt: 'desc' },
    });

    return {
      status: OK,
      success: true,
      message: paymentMessages.LIST_SAVED_CARDS,
      data: cards.map(paymentHandler.savedCardModelToDomain),
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Deletes a saved card
 * @returns {Promise<IApiResponse>}
 */
export const deleteSavedCard = async (userId: string, cardId: string): Promise<IApiResponse> => {
  try {
    const cardFilters = {
      id: Number(cardId),
      userId: Number(userId),
      isDeleted: false,
    };

    const card = await retrieveCardDetails(cardFilters);

    if (!card) {
      return {
        status: NOT_FOUND,
        success: false,
        message: paymentMessages.SAVED_CARD_NOT_FOUND,
        data: null,
      };
    }

    await stripeService.detachPaymentMethod(card.paymentMethodId);

    const updateCard = {
      isDeleted: true,
      deletedAt: new Date(),
      isDefault: false,
    };
    await prismaService.updateRecord('savedCard', updateCard, { id: card.id });

    // If the deleted card was default, set another card as default
    const nextDefault = await prismaService.findFirstRecord(
      'supportTicket',
      {
        userId: Number(userId),
        isDeleted: false,
      },
      {
        orderBy: {
          createdAt: 'desc',
        },
        select: {
          id: true,
        },
      },
    );
    if (nextDefault) {
      await prismaService.updateRecord(
        'savedCard',
        {
          isDefault: true,
        },
        { id: nextDefault.id },
      );
    }

    return {
      status: OK,
      success: true,
      message: paymentMessages.DELETE_SAVED_CARD,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;
    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};
