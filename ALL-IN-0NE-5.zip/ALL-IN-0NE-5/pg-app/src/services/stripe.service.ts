import env from '@config/envVar';
import { logger } from '@config/logger';
import { BAD_REQUEST, emailTemplatesVariables, NOT_FOUND, paymentMessages, paymentVariables } from '@constants';
import type { ICreateUserSubscriptionRequest, ICustomError, IUpdateUserSubscriptionRequest } from '@customTypes';
import Stripe from 'stripe';
import type { IPlan, IPlanUpdate, IProduct, SubscriptionSessionOptions } from '../types/payment.type';
import { SubscriptionStatus } from '@enums';
import { emailHandler, stripeHandler } from '@utils';
import { mapStripeStatusToSubscriptionStatus, userService, userSubscriptionService } from '@services';
const stripe = new Stripe(env.STRIPE_SECRET_KEY);

/**
 * Registers a product on Stripe
 * @param data - The product data
 * @returns The Stripe product ID
 * @throws Error
 */
export const registerProduct = async (data: IProduct) => {
  /** Create a product on Stripe */
  try {
    const product = await stripe.products.create({
      name: data.name,
      description: data.description,
      // Add other optional fields as needed
    });
    return product.id;
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Updates a product on Stripe
 * @param data - The product data containing the product ID and details to update
 * @returns The updated Stripe product object
 * @throws Error if the update operation fails
 */
export const modifyProduct = async (data: IProduct) => {
  try {
    // update product details on stripe...
    return await stripe.products.update(data.productId, {
      name: data.name,
      description: data.description,
    });
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Retrieves a product from Stripe
 * @param productId - The product ID
 * @returns The Stripe product object
 * @throws Error if the retrieval operation fails
 */
export const fetchProduct = async (productId: string) => {
  try {
    // get particular product on stripe... productId=price_1MoBy5LkdIwHu7ixZhnattss
    return await stripe.products.retrieve(productId);
  } catch (error) {
    const err = error as ICustomError;
    if (err && err.statusCode === NOT_FOUND) {
      return null;
    }
    throw err;
  }
};

/**
 * Deletes a product on Stripe
 * @param productId - The product ID
 * @returns A Stripe response object
 * @throws Error if the deletion operation fails
 */
export const removeProduct = async (productId: string) => {
  try {
    /** search price based on filter */
    return await stripe.products.del(productId);
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Searches for active products on Stripe
 * @returns A Stripe search response object containing a list of products
 * @throws Error if the search operation fails
 */
export const searchProduct = async () => {
  try {
    /** search price based on filter */
    return await stripe.products.search({
      query: `active:'true'`,
    });
  } catch (error) {
    const err = error as ICustomError;
    if ((err && err.statusCode === NOT_FOUND) || err.statusCode === BAD_REQUEST) {
      return null;
    }
    throw err;
  }
};
/**
 * Creates a new recurring plan on Stripe.
 * @param {IPlan} data - The plan data with productId, currency, amount and interval.
 * @returns {Promise<string>} - The plan ID.
 * @throws Error if the creation operation fails.
 */
export const createRecurringPlan = async (data: IPlan) => {
  /** Create a plan on Stripe */
  try {
    // Build recurring object with interval and optional interval_count (for quarterly)
    const recurring: Stripe.PriceCreateParams.Recurring = {
      interval: data.interval, // For subscription pricing exm. : year/month
    };

    // Add interval_count if provided (for quarterly plans: 3 months)
    if (data.interval_count || data.recurring?.interval_count) {
      recurring.interval_count = data.interval_count || data.recurring.interval_count;
    }

    // Build metadata object, including image URL if provided
    const metadata: Record<string, string> = {
      ...(data?.metadata || {}),
      ...(data.imageUrl && { image: data.imageUrl }),
    };

    const prices = await stripe.prices.create({
      currency: data.currency, // change on requirement
      unit_amount: data.amount, // Amount in cents (1000 cents = $10.00)
      product: data.productId, // product Id of stripe //prod_Pws9PxtPpNXQwe
      recurring,
      ...(Object.keys(metadata).length > 0 && { metadata }),
    });
    return prices.id;
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Creates a new usage-based plan on Stripe.
 * @param {IPlan} data - The plan data with productId, currency, amount, interval and usageType.
 * @returns {Promise<string>} - The plan ID.
 * @throws Error if the creation operation fails.
 */
export const createUsagePlan = async (data: IPlan) => {
  /** Create a plan on Stripe */
  try {
    // Build recurring object with interval, usage_type, and optional interval_count
    const recurring: Stripe.PriceCreateParams.Recurring = {
      interval: data.interval,
      usage_type: data.usageType,
    };

    // Add interval_count if provided (for quarterly plans: 3 months)
    if (data.interval_count || data.recurring?.interval_count) {
      recurring.interval_count = data.interval_count || data.recurring.interval_count;
    }

    // Build metadata object, including image URL if provided
    const metadata: Record<string, string> = {
      ...(data?.metadata || {}),
      ...(data.imageUrl && { image: data.imageUrl }),
    };

    const prices = await stripe.prices.create({
      currency: data.currency, // change on requirement
      unit_amount: data.amount, // Amount in cents (1000 cents = $10.00)
      product: data.productId, // product Id of stripe //prod_Pws9PxtPpNXQwe
      recurring,
      ...(Object.keys(metadata).length > 0 && { metadata }),
    });
    return prices.id;
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Creates a new one-time plan on Stripe.
 * @param {IPlan} data - The plan data with productId, currency, and amount.
 * @returns {Promise<string>} - The plan ID.
 * @throws Error if the creation operation fails.
 */
export const createOneTimePlan = async (data: IPlan) => {
  /** Create a plan on Stripe */
  try {
    const prices = await stripe.prices.create({
      currency: data.currency, // change on requirement
      unit_amount: data.amount, // Amount in cents (1000 cents = $10.00)
      product: data.productId, // product Id of stripe //prod_Pws9PxtPpNXQwe
    });
    return prices.id;
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Updates a plan on Stripe with the provided data.
 * @param {IPlanUpdate} data - The plan update data containing priceId, description, and other optional details.
 * @returns {Promise<object>} - The updated Stripe price object.
 * @throws Error if the update operation fails.
 */

export const updatePlan = async (data: IPlanUpdate) => {
  try {
    // Fetch existing price to preserve current metadata
    const existingPrice = await stripe.prices.retrieve(data.priceId);
    const existingMetadata = existingPrice.metadata || {};

    // Build metadata object: merge existing metadata with provided metadata, then add/update image
    const metadata: Record<string, string> = {
      ...existingMetadata,
      ...(data?.metadata || {}),
      ...(data.imageUrl !== undefined && { [paymentVariables.METADATA_KEY_IMAGE]: data.imageUrl || '' }), // Allow empty string to remove image
    };

    // Remove image key if imageUrl is explicitly set to empty/null
    if (data.imageUrl === '' || data.imageUrl === null) {
      delete metadata[paymentVariables.METADATA_KEY_IMAGE];
    }

    // update plan details on stripe...
    return await stripe.prices.update(data.priceId, {
      nickname: data.description,
      metadata,
      active: true, // set false for archive the price
    });
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Retrieves a plan by its priceId from the Stripe service.
 * @param {string} priceId - The ID of the price to retrieve the plan for.
 * @returns {Promise<{id: string, object: string, active: boolean, billing_scheme: string, currency: string, lookup_key: string | null, livemode: boolean, metadata: object, nickname: string | null, product: string, recurring: {interval: string, usage_type: string}, tiers: {currency: string, up_to: number, unit_amount: number}[], tiers_mode: string, transform_quantity: {divide_by: number, round: string}, type: string, unit_amount: number, unit_amount_decimal: string}>}
 *  - The Stripe price object.
 * @throws Error if the retrieval operation fails.
 */
export const getPlanById = async (priceId: string) => {
  try {
    // get particular plan on stripe... priceId=price_1MoBy5LkdIwHu7ixZhnattss
    return await stripe.prices.retrieve(priceId);
  } catch (error) {
    const err = error as ICustomError;
    if (err && err.statusCode === NOT_FOUND) {
      return null;
    }
    throw err;
  }
};

/**
 * Retrieves a list of all available plans from the Stripe service.
 * @returns {Promise<{data: {id: string, object: string, active: boolean, billing_scheme: string, currency: string, lookup_key: string | null, livemode: boolean, metadata: object, nickname: string | null, product: string, recurring: {interval: string, usage_type: string}, tiers: {currency: string, up_to: number, unit_amount: number}[], tiers_mode: string, transform_quantity: {divide_by: number, round: string}, type: string, unit_amount: number, unit_amount_decimal: string}[], has_more: boolean, url: string}>}
 *  - An object containing the HTTP status code, success flag, message, and a list of plans.
 * @throws Error if the retrieval operation fails.
 */
export const getPlans = async () => {
  try {
    /** search price based on filter */
    return await stripe.prices.list({
      limit: 3,
    });
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Creates a new customer in Stripe for managing plans and payments.
 * @param {string} email - The email address of the new customer.
 * @param {string} name - The name of the new customer.
 * @returns {Promise<{id: string, object: string, address: object | null, balance: number, created: number, currency: string | null, delinquent: boolean, description: string | null, discount: object | null, email: string, invoice_prefix: string, livemode: boolean, metadata: object, name: string | null, phone: string | null, shipping: object | null, tax_exempt: string | null}>}
 *  - The Stripe customer object.
 * @throws Error if the creation operation fails.
 */
export const registerCustomer = async (email: string, name: string) => {
  /** Create a customer on Stripe for managing plans and payments */
  try {
    return await stripe.customers.create({
      name,
      email, // set other details like address,description metadata etc
    });
  } catch (err) {
    const error = err instanceof Error;
    logger.error(`konoo ${error}`);
    throw error;
  }
};

/**
 * Updates a customer in Stripe.
 * @param {string} customerId - The id of the customer to update.
 * @param {string} email - The new email address of the customer.
 * @param {string} description - The new description of the customer.
 * @returns {Promise<{id: string, object: string, address: object | null, balance: number, created: number, currency: string | null, delinquent: boolean, description: string | null, discount: object | null, email: string, invoice_prefix: string, livemode: boolean, metadata: object, name: string | null, phone: string | null, shipping: object | null, tax_exempt: string | null}>}
 *  - The Stripe customer object.
 * @throws Error if the update operation fails.
 */
export const modifyCustomer = async (customerId: string, email: string, description: string) => {
  try {
    // update customer details on stripe...
    return await stripe.customers.update(
      customerId, //here the customer id is unique key for update data on stripe
      {
        email: email,
        description: description,
        //... update other info based on your requirement like:-  name , phone,address etc..,
      },
    );
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Deletes a customer from Stripe.
 * @param {string} customerId - The id of the customer to delete.
 * @returns {Promise<{id: string, object: string, deleted: boolean}>}
 *  - An object indicating whether the customer was successfully deleted.
 * @throws Error if the deletion operation fails.
 */
export const removeCustomer = async (customerId: string) => {
  try {
    // delete particular customer on stripe... i.e.: customerId=cus_NffrFeUfNV2Hib
    return await stripe.customers.del(customerId);
  } catch (err) {
    const error = err instanceof Error;
    throw error;
  }
};

/**
 * Retrieves a customer by id from Stripe.
 * @param {string} customerId - The id of the customer to fetch.
 * @returns {Promise<{id: string, object: string, address: object | null, balance: number, created: number, currency: string | null, delinquent: boolean, description: string | null, discount: object | null, email: string, invoice_prefix: string, livemode: boolean, metadata: object, name: string | null, phone: string | null, shipping: object | null, tax_exempt: string | null}>}
 *  - The Stripe customer object.
 * @throws Error if the retrieval operation fails.
 */
export const fetchCustomer = async (customerId: string) => {
  try {
    // delete particular customer on stripe... customerId=cus_NffrFeUfNV2Hib
    return await stripe.customers.retrieve(customerId);
  } catch (error) {
    const err = error as ICustomError;
    if (err && err.statusCode === NOT_FOUND) {
      return null;
    }
    throw err;
  }
};

/**
 * Creates a one time payment session for a given customer, price, currency, and quantity.
 * @param {string} customer - The id of the customer to create the session for.
 * @param {string} price - The id of the price to use for the session.
 * @param {string} currency - The currency to use for the session.
 * @param {number} quantity - The number of licenses to purchase.
 * @returns {Promise<string>} The URL of the checkout session.
 * @throws {Error} If the session creation fails.
 */
export const oneTimePayment = async (customer: string, price: string, currency: string, quantity: number) => {
  let session = null;
  try {
    //create one time payment checkout session
    session = await stripe.checkout.sessions.create({
      mode: 'payment',
      payment_method_types: ['card'], // set multiple method if need like ["card"]
      customer,
      line_items: [
        {
          price,
          quantity: quantity,
        },
      ],
      currency: `${currency}`, // Set the currency for which the checkout session is to be created
      metadata: {
        //set metadata for access inside hook
        price: price,
        type: 'one-time',
      },
      success_url: env.CORS_ORIGIN, // set redirect user after subscritopn process is successfully done
      cancel_url: env.CORS_ORIGIN, // set redirect user after subscritopn  cancel
    });
  } catch (error) {
    logger.error(`Failed to create One time payment of StripeCustomerId: ${customer} ${error}`);
    throw new Error(`Failed to create One time payment of customer : ${customer}`);
  }
  return session.url;
};

/**
 * Creates a pre paid subscription session for a given customer, price, currency, and quantity.
 * @param {string} customer - The id of the customer to create the session for (optional).
 * @param {string} price - The id of the price to use for the session.
 * @param {string} currency - The currency to use for the session.
 * @param {number} quantity - The number of licenses to purchase.
 * @param {string} userId - The user ID to pass in metadata (optional).
 * @returns {Promise<string>} The URL of the checkout session.
 * @throws {Error} If the session creation fails.
 */
export const prePaidSubscriptionSession = async (
  customer: string | undefined,
  price: string,
  currency: string,
  quantity: number,
  userId: string | undefined,
  customerEmail: string | undefined,
  options: SubscriptionSessionOptions,
) => {
  try {
    // Validate required options
    if (!options?.successUrl || !options.cancelUrl) {
      throw new Error(paymentMessages.SUCCESS_URL_AND_CANCEL_URL_REQUIRED);
    }

    quantity = quantity || paymentVariables.DEFAULT_SUBSCRIPTION_QUANTITY;

    // Ensure userId is in customer metadata (for webhook fallback)
    if (userId && customer) {
      try {
        const customerData = await stripe.customers.retrieve(customer);
        if (customerData && typeof customerData === 'object' && customerData !== null && !customerData.deleted) {
          const currentMetadata = customerData[paymentVariables.STRIPE_FIELD_METADATA] || {};
          if (!currentMetadata[paymentVariables.METADATA_KEY_USER_ID]) {
            await stripe.customers.update(customer, {
              [paymentVariables.STRIPE_FIELD_METADATA]: {
                ...currentMetadata,
                [paymentVariables.METADATA_KEY_USER_ID]: userId,
              },
            });
            logger.info(`Updated customer ${customer} metadata with userId=${userId}`);
          }
        }
      } catch (error) {
        logger.warn(`Could not update customer metadata with userId: ${error}`);
      }
    }

    // Build metadata - this goes on both session and subscription
    const metadata: Record<string, string> = {
      [paymentVariables.METADATA_KEY_USAGE_TYPE]: options.usageType || paymentVariables.USAGE_TYPE_LICENSED,
      [paymentVariables.METADATA_KEY_PRICE]: price,
      ...(userId && { [paymentVariables.METADATA_KEY_USER_ID]: userId }),
      ...(options.additionalMetadata || {}),
    };

    // Fetch price details and extract product info
    const priceInfo = await stripeHandler.fetchPriceDetails(stripe, price);
    const productName = priceInfo?.productName || options.defaultProductName || paymentVariables.DEFAULT_PRODUCT_NAME;
    const featuresList = stripeHandler.parseFeatures(priceInfo?.features || '');
    const productDescription = stripeHandler.buildProductDescription(
      productName,
      priceInfo?.intervalText || paymentVariables.INTERVAL_TEXT_MONTHLY,
      featuresList,
    );

    // Extract trialDays from price metadata
    let trialDays: number | undefined;
    if (priceInfo?.priceDetails) {
      const priceMetadata = priceInfo.priceDetails[paymentVariables.STRIPE_FIELD_METADATA] || {};
      const trialDaysStr = priceMetadata[paymentVariables.METADATA_KEY_TRIAL_DAYS];
      if (trialDaysStr) {
        const parsed = Number.parseInt(trialDaysStr, 10);
        if (!Number.isNaN(parsed) && parsed > 0) {
          trialDays = parsed;
          logger.info(`Found trialDays=${trialDays} in price metadata for price ${price}`);
        }
      }
    }

    // Build line items
    const lineItems = stripeHandler.buildLineItems(
      price,
      priceInfo?.priceDetails || null,
      productName,
      productDescription,
      priceInfo?.imageUrl || '',
      currency,
      quantity,
    );

    // Build session configuration
    const sessionConfig: Stripe.Checkout.SessionCreateParams = {
      mode: paymentVariables.STRIPE_MODE_SUBSCRIPTION,
      payment_method_types: [
        paymentVariables.PAYMENT_METHOD_TYPE_CARD,
        paymentVariables.PAYMENT_METHOD_TYPE_AMAZON_PAY,
      ],

      line_items: lineItems,
      metadata,
      payment_method_collection: paymentVariables.SUBSCRIPTION_PAYMENT_METHOD_COLLECTION_IF_REQUIRED,
      currency,
      success_url: options.successUrl,
      cancel_url: options.cancelUrl,
      billing_address_collection: paymentVariables.SUBSCRIPTION_BILLING_ADDRESS_COLLECTION_REQUIRED,
      allow_promotion_codes: true,
      ...(customer && { customer }),
      ...(!customer && customerEmail && { customer_email: customerEmail }),
      ...(options.submitButtonText && {
        custom_text: {
          submit: {
            message: options.submitButtonText,
          },
        },
      }),
      // Add subscription_data with metadata and trial period if needed
      subscription_data: {
        metadata, // Ensure metadata is copied to subscription
        ...(trialDays &&
          trialDays > 0 && {
            trial_period_days: trialDays,
            trial_settings: {
              end_behavior: {
                missing_payment_method: paymentVariables.SUBSCRIPTION_END_BEHAVIOR_CANCEL,
              },
            },
          }),
      },
    };

    // Create checkout session
    const session = await stripe.checkout.sessions.create(sessionConfig);
    return session.url;
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    logger.error(`Failed to create subscription checkout session: ${errorMessage}`);
    throw err;
  }
};

/**
 * Creates a subscription by using stripe without create checkout page.
 * @param {string} customerId - The id of the customer to create the subscription for.
 * @param {string} price - The id of the price to use for the subscription.
 * @param {string} currency - The currency to use for the subscription.
 * @param {number} trailDays - The number of trial days for the subscription.
 * @returns {Promise<Stripe.Subscription>} The created subscription.
 * @throws {Error} If the subscription creation fails.
 */
export const subscriptionService = async (customerId: string, price: string, currency: string, trailDays: number) => {
  try {
    // create subscription by  using stripe without create checkout page
    return await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: price }],
      trial_period_days: trailDays, // set trial based on needs
      currency: `${currency}`,
      metadata: {
        /**set metadata for webhook optrations */
        usage_type: 'licensed', //fixed price plan
        price: price,
      },
      collection_method: 'charge_automatically', // Charge automatically for the subscription
      trial_settings: {
        //trial plan settinge cancel if card/payment method not attched
        end_behavior: {
          missing_payment_method: 'cancel',
        },
      },
    });
  } catch (err) {
    const error = err instanceof Error;
    logger.error(`failed when create subscription of customer : ${error}`);
    throw error;
  }
};

/**
 * Creates a pay as you go subscription session for a given customer, price and currency.
 * @param {string} customer - The id of the customer to create the subscription for.
 * @param {string} price - The id of the price to use for the subscription.
 * @param {string} currency - The currency to use for the subscription.
 * @returns {Promise<string>} The URL of the checkout session.
 * @throws {Error} If the session creation fails.
 */
export const usageBasedSubscriptionSession = async (customer: string, price: string, currency: string) => {
  let session = null;
  try {
    // this based on pay as you go plan means pay only usages
    session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      customer,
      line_items: [
        {
          price, //for usages type not need to padd quantity
        },
      ],
      metadata: {
        usage_type: 'licensed',
        price: price,
      },
      payment_method_collection: 'if_required',
      currency: `${currency}`, // Set the currency for which the checkout session is to be created
      success_url: `${env.CORS_ORIGIN}/home`, // set redirect user after subscritopn process is successfully done
      cancel_url: `${env.CORS_ORIGIN}/home`, // set redirect user after subscritopn  cancel
    });
  } catch (err) {
    const error = err instanceof Error;
    logger.error(`failed when create pay as you go plan  of customer : ${error}`);

    throw error;
  }
  return session.url; //if need also return session id
};

/**
 * Retrieves a subscription by id from Stripe.
 * @param {string} subscriptionId - The id of the subscription to fetch.
 * @returns {Promise<Stripe.Subscription>} The fetched subscription.
 * @throws {Error} If the fetch operation fails.
 */
export const fetchSubscription = async (subscriptionId: string) => {
  try {
    // delete particular customer on stripe... customerId=cus_NffrFeUfNV2Hib
    return await stripe.subscriptions.retrieve(subscriptionId);
  } catch (error) {
    const err = error as ICustomError;
    if (err && err.statusCode === NOT_FOUND) {
      return null;
    }
    throw err;
  }
};

/**
 * Updates a prepaid subscription by given subscriptionId and description.
 * @param {string} subscriptionId - The id of the subscription to update.
 * @param {string} description - The description for the subscription.
 * @returns {Promise<void>}
 * @throws {Error} If the update operation fails.
 */
export const updatePrepaidTypeSubscription = async (subscriptionId: string, description: string) => {
  try {
    await stripe.subscriptions.update(subscriptionId, {
      description: description,
      metadata: {
        order_id: '6735', //this is a exmaple
      },
    });
  } catch (err) {
    const error = err instanceof Error;
    logger.error(`failed when update pay as you go plan : ${error}`);
    throw error;
  }
  return;
};

/**
 * Cancels an active subscription by its ID.
 * @param {string} subscriptionId - The id of the subscription to cancel.
 * @returns {Promise<Stripe.Subscription>} The canceled subscription.
 * @throws {Error} If the cancel operation fails.
 */
export const cancelSubscription = async (subscriptionId: string) => {
  try {
    // cancel any active subscription
    return await stripe.subscriptions.cancel(subscriptionId);
  } catch (err) {
    const error = err instanceof Error;
    logger.error(`Error canceling subscription: : ${error}`);
    throw error;
  }
};

/**
 * Handles Stripe webhook events.
 *
 * @param {Request} req - The request data.
 *
 * @throws {Error} If the event handling fails.
 */
export const webhookService = async (req: any) => {
  const sig = req.headers[paymentVariables.STRIPE_WEBHOOK_SIGNATURE_HEADER];
  const endpointSecret = env.STRIPE_WEBHOOK_SECRET; // set token for access stripe webhook
  let event: any;
  try {
    // get data and
    event = stripe.webhooks.constructEvent(req.rawBody, sig, endpointSecret);
  } catch (err) {
    logger.error(`stripe webhook error:${err}`);
    throw err;
  }
  const data = event.data.object; // stripe event data for perform other task like update details in db etc.
  logger.info(`stripe webhook matadata: ${data}`);
  logger.info(`event name:${event.type}`);
  // Handle the event
  switch (event.type) {
    /* 
    we can ignore this event as checkout session completed event is handled in subscription.created event as well 
    this will make code redundant and not needed to handle both events .its a choice , i am keeping it here for reference and to avoid future confusion.
    */
    case paymentVariables.WEBHOOK_EVENT_CHECKOUT_SESSION_COMPLETED: {
      /**
       * Primary event: Create user_subscription when checkout completes
       *
       * IMPORTANT: userId is ALWAYS present in session metadata (added by frontend via req.user.id)
   
       */
      try {
        const customerId = data.customer;
        const subscriptionId = data.subscription;
        const userId = data.metadata?.userId;

        logger.info(
          `Webhook checkout.session.completed: customerId=${customerId}, subscriptionId=${subscriptionId}, userId=${userId}`,
        );

        // Validate required fields - fail fast if missing
        if (!userId) {
          logger.error(`Missing userId in session metadata for session ${data.id}`);
          return;
        }

        if (!subscriptionId) {
          logger.error(`Missing subscriptionId for session ${data.id}`);
          return;
        }

        if (!customerId) {
          logger.error(`Missing customerId for session ${data.id}`);
          return;
        }

        // Get planId from checkout session line_items
        let planId: string | undefined;
        try {
          const lineItems = await stripe.checkout.sessions.listLineItems(data.id, {
            expand: ['data.price'],
          });
          planId = lineItems.data[0]?.price?.id;
          logger.info(`Retrieved planId ${planId} from checkout session`);
        } catch (error) {
          logger.error(`Error retrieving line items for session ${data.id}: ${error}`);
        }

        if (!planId) {
          logger.error(`Could not determine planId for subscription ${subscriptionId}`);
          return;
        }

        // Fetch plan name from price metadata
        let planName: string | undefined;
        try {
          const price = await stripe.prices.retrieve(planId);
          planName = price[paymentVariables.STRIPE_FIELD_METADATA]?.[paymentVariables.METADATA_KEY_PLAN_NAME];
        } catch (error) {
          logger.warn(`Could not fetch plan name for price ${planId}: ${error}`);
        }

        // Fetch and convert plan entitlements
        const entitlements = await stripeHandler.fetchAndConvertPlanEntitlements(planId);
        logger.info(`Fetched ${entitlements.length} entitlements for plan ${planId}`);

        // Retrieve subscription for latest status and expiry
        let finalStatus: SubscriptionStatus;
        let finalExpiry: Date | undefined;

        try {
          const subscription = await stripe.subscriptions.retrieve(subscriptionId);
          finalStatus = mapStripeStatusToSubscriptionStatus(subscription.status);

          // Extract expiry date
          if (subscription.current_period_end && typeof subscription.current_period_end === 'number') {
            const expiryDate = new Date(subscription.current_period_end * 1000);
            if (!Number.isNaN(expiryDate.getTime())) {
              finalExpiry = expiryDate;
            }
          }

          logger.info(
            `Retrieved subscription ${subscriptionId}: status=${finalStatus}, expiry=${finalExpiry ? finalExpiry.toISOString() : 'not set'}`,
          );
        } catch (error) {
          logger.error(`Failed to retrieve subscription ${subscriptionId}: ${error}`);
          return;
        }

        // Build update data
        const updateData: ICreateUserSubscriptionRequest = {
          userId,
          customerId,
          planId,
          planName,
          stripeSubscriptionId: subscriptionId,
          status: finalStatus,
          entitlements,
          expiry: finalExpiry as Date,
        };
        // Save to database
        const result = await userSubscriptionService.createOrUpdateByUserId(updateData);

        if (!result.success) {
          logger.error(`Failed to save subscription ${subscriptionId} to database: ${result.message}`);
          return;
        }

        logger.info(`Successfully saved subscription ${subscriptionId} with status ${finalStatus}`);
      } catch (error: any) {
        logger.error(`Error handling checkout.session.completed: ${error.message || error}`);
        logger.error(`Error stack: ${error.stack || 'No stack trace'}`);
      }
      break;
    }

    case paymentVariables.WEBHOOK_EVENT_CUSTOMER_SUBSCRIPTION_CREATED: {
      /**
       * Handles subscription creation from Setup Intent flow (embedded checkout)
       * Also serves as backup for Checkout Session flow
       *
       * IMPORTANT: userId is ALWAYS present in subscription metadata (added by frontend via req.user.id)
       * No need for customer metadata fallback or complex retrieval logic.
       */
      try {
        const subscriptionId = data[paymentVariables.STRIPE_FIELD_ID];
        const customerId = data[paymentVariables.STRIPE_FIELD_CUSTOMER];
        const userId = data[paymentVariables.STRIPE_FIELD_METADATA]?.[paymentVariables.METADATA_KEY_USER_ID];

        logger.info(
          `Webhook customer.subscription.created: subscriptionId=${subscriptionId}, customerId=${customerId}, userId=${userId}`,
        );

        // Validate required fields - fail fast if missing
        if (!userId) {
          logger.error(`Missing userId in subscription metadata for subscription ${subscriptionId}`);
          return;
        }

        // Extract planId from webhook data
        const webhookItem = data.items?.data?.[0];
        if (!webhookItem?.price) {
          logger.error(`Missing price data for subscription ${subscriptionId}`);
          return;
        }

        const priceValue = webhookItem.price;
        const planId = typeof priceValue === 'string' ? priceValue : priceValue[paymentVariables.STRIPE_FIELD_ID];

        if (!planId) {
          logger.error(`Could not determine planId for subscription ${subscriptionId}`);
          return;
        }

        logger.info(`Processing subscription: planId=${planId}, userId=${userId}`);

        // Fetch plan name from price metadata
        let planName: string | undefined;
        try {
          const price = await stripe.prices.retrieve(planId);
          planName = price[paymentVariables.STRIPE_FIELD_METADATA]?.[paymentVariables.METADATA_KEY_PLAN_NAME];
        } catch (error) {
          logger.warn(`Could not fetch plan name for price ${planId}: ${error}`);
        }

        // Fetch and convert plan entitlements
        const entitlements = await stripeHandler.fetchAndConvertPlanEntitlements(planId);
        logger.info(`Fetched ${entitlements.length} entitlements for plan ${planId}`);

        // Re-sync status from Stripe right before saving to handle race condition
        // The subscription status might have changed (incomplete → active) during operations above
        let finalStatus: SubscriptionStatus;
        let finalExpiry: Date | undefined;

        try {
          const latestSubscription = await stripe.subscriptions.retrieve(subscriptionId);
          finalStatus = mapStripeStatusToSubscriptionStatus(latestSubscription.status);

          // Extract expiry date
          if (latestSubscription.current_period_end && typeof latestSubscription.current_period_end === 'number') {
            const expiryDate = new Date(latestSubscription.current_period_end * 1000);
            if (!Number.isNaN(expiryDate.getTime())) {
              finalExpiry = expiryDate;
            }
          }

          logger.info(
            `Re-synced subscription ${subscriptionId}: status=${finalStatus}, expiry=${finalExpiry ? finalExpiry.toISOString() : 'not set'}`,
          );
        } catch (syncError) {
          logger.error(`Failed to re-sync subscription ${subscriptionId}: ${syncError}`);
          // Use webhook data as fallback
          finalStatus = mapStripeStatusToSubscriptionStatus(data[paymentVariables.STRIPE_FIELD_STATUS]);
        }

        // Build update data
        const updateData: ICreateUserSubscriptionRequest = {
          userId,
          customerId,
          planId,
          planName,
          stripeSubscriptionId: subscriptionId,
          status: finalStatus,
          entitlements,
          expiry: finalExpiry as Date,
        };

        // Save to database
        const dbUpdateResult = await userSubscriptionService.createOrUpdateByUserId(updateData);

        if (!dbUpdateResult.success) {
          logger.error(`Failed to save subscription ${subscriptionId} to database: ${dbUpdateResult.message}`);
          return;
        }

        logger.info(`Successfully saved subscription ${subscriptionId} with status ${finalStatus}`);

        // Send subscription created email asynchronously
        const isTrial = finalStatus === SubscriptionStatus.TRIAL;
        const expiryDate = finalExpiry ? finalExpiry.toLocaleDateString() : 'N/A';

        emailHandler.sendSubscriptionEmailAsync(
          stripe,
          userId,
          customerId,
          undefined,
          emailTemplatesVariables.emailTemplates[8].slug,
          {
            title: isTrial
              ? paymentMessages.SUBSCRIPTION_EMAIL_TRIAL_STARTED_TITLE
              : paymentMessages.SUBSCRIPTION_EMAIL_ACTIVE_TITLE,
            greeting: isTrial
              ? paymentMessages.SUBSCRIPTION_EMAIL_TRIAL_STARTED_GREETING
              : paymentMessages.SUBSCRIPTION_EMAIL_ACTIVE_GREETING,
            planName: planName || 'N/A',
            status: isTrial ? 'Free Trial' : 'Active',
            expiryLabel: isTrial ? 'Trial Ends' : 'Next Billing',
            expiryDate,
            message: paymentMessages.SUBSCRIPTION_EMAIL_ACTIVE_MESSAGE,
          },
          subscriptionId,
        );
      } catch (error: any) {
        logger.error(`Error handling customer.subscription.created: ${error.message || error}`);
        logger.error(`Error stack: ${error.stack || 'No stack trace'}`);
      }
      break;
    }

    case paymentVariables.WEBHOOK_EVENT_CUSTOMER_SUBSCRIPTION_UPDATED: {
      /**
       * Correctly sync Stripe subscription updates with DB
       * - ACTIVE remains ACTIVE even if cancel_at_period_end = true
       * - Entitlements cleared ONLY on actual cancellation
       * - Stripe is the source of truth
       */
      try {
        const subscriptionId = data.id;
        const webhookStatus = data.status;
        const cancelAtPeriodEnd = !!data.cancel_at_period_end;
        const webhookEventCreated = event.created; // unix timestamp

        logger.info(
          `customer.subscription.updated received: subscriptionId=${subscriptionId}, webhookStatus=${webhookStatus}, cancelAtPeriodEnd=${cancelAtPeriodEnd}`,
        );

        /**
         * STEP 1: Fetch existing DB subscription (NO side effects)
         */
        const existingDbResult = await userSubscriptionService.getByStripeSubscriptionId(subscriptionId);

        if (!existingDbResult.success || !existingDbResult.data) {
          logger.info(`Subscription ${subscriptionId} not found in DB. Ignoring update (likely old subscription).`);
          return;
        }

        const existingDbSub = existingDbResult.data;

        /**
         * STEP 2: Guard against out-of-order webhook delivery
         */
        if (existingDbSub.stripeEventCreated && existingDbSub.stripeEventCreated > webhookEventCreated) {
          logger.info(`Ignoring older webhook event for ${subscriptionId}. DB event is newer.`);
          return;
        }

        /**
         * STEP 3: Retrieve live subscription from Stripe (SOURCE OF TRUTH)
         */
        let stripeSubscription: Stripe.Subscription;
        try {
          stripeSubscription = await stripe.subscriptions.retrieve(subscriptionId, {
            expand: ['items.data.price'],
          });
        } catch (err) {
          logger.error(`Failed to retrieve Stripe subscription ${subscriptionId}: ${err}`);
          return;
        }

        const stripeStatus = stripeSubscription.status;
        const stripeCancelAtPeriodEnd = !!stripeSubscription.cancel_at_period_end;
        const periodEnd = stripeSubscription.current_period_end;

        /**
         * STEP 4: Determine expiry
         */
        let expiry: Date | undefined;
        if (typeof periodEnd === 'number') {
          const date = new Date(periodEnd * 1000);
          if (!Number.isNaN(date.getTime())) {
            expiry = date;
          }
        }

        /**
         * STEP 5: Determine planId
         */
        let planId: string | undefined;
        const firstItem = stripeSubscription.items.data[0];
        if (firstItem?.price) {
          planId = typeof firstItem.price === 'string' ? firstItem.price : firstItem.price.id;
        }

        /**
         * STEP 6: Determine subscription state
         */
        const isActuallyCancelled = stripeStatus === 'canceled';

        const isScheduledToCancel = stripeCancelAtPeriodEnd && stripeStatus === 'active';

        let finalStatus: SubscriptionStatus;

        if (isActuallyCancelled) {
          finalStatus = SubscriptionStatus.CANCELLED;
        } else {
          // ACTIVE, TRIAL, PAST_DUE etc
          finalStatus = mapStripeStatusToSubscriptionStatus(stripeStatus);
        }

        /**
         * STEP 7: Build DB update payload
         */
        const updateData: IUpdateUserSubscriptionRequest = {
          status: finalStatus,
          stripeEventCreated: webhookEventCreated,
        };

        if (expiry) {
          updateData.expiry = expiry;
        }

        /**
         * Scheduled cancellation handling
         */
        if (isScheduledToCancel) {
          updateData.cancelScheduled = true;
          updateData.cancelAt = expiry || null;
        } else {
          updateData.cancelScheduled = false;
          updateData.cancelAt = null;
        }

        /**
         * STEP 8: Handle entitlements
         */
        if (isActuallyCancelled) {
          // Clear entitlements ONLY on actual cancellation
          updateData.entitlements = [];
        } else if (planId) {
          // Active / Trial / Past Due
          try {
            const entitlements = await stripeHandler.fetchAndConvertPlanEntitlements(planId);
            updateData.entitlements = entitlements;
            updateData.planId = planId;

            try {
              const price = await stripe.prices.retrieve(planId);
              updateData.planName = price.metadata?.[paymentVariables.METADATA_KEY_PLAN_NAME] || undefined;
            } catch (e) {
              logger.warn(`Could not fetch planName for price ${planId} ${e}`);
            }
          } catch (err) {
            logger.error(`Failed to fetch entitlements for plan ${planId}: ${err}`);
          }
        }

        /**
         * STEP 9: Persist DB update
         */
        const updateResult = await userSubscriptionService.updateByStripeSubscriptionId(subscriptionId, updateData);

        if (!updateResult.success) {
          logger.error(`Failed to update subscription ${subscriptionId}: ${updateResult.message}`);
          return;
        }

        logger.info(
          `Subscription ${subscriptionId} synced successfully. status=${finalStatus}, scheduledCancel=${isScheduledToCancel}`,
        );

        /**
         * STEP 10: Email notifications
         */
        const userId = updateResult.data?.userId?.toString();
        const customerId = stripeSubscription.customer || updateResult.data?.customerId;

        if (isActuallyCancelled) {
          emailHandler.sendSubscriptionEmailAsync(
            stripe,
            userId,
            customerId as string,
            undefined,
            emailTemplatesVariables.emailTemplates[9].slug,
            {
              title: paymentMessages.SUBSCRIPTION_EMAIL_CANCELLED_TITLE,
              message: paymentMessages.SUBSCRIPTION_EMAIL_CANCELLED_MESSAGE,
            },
          );
        } else if (isScheduledToCancel) {
          const expiryText = expiry
            ? expiry.toLocaleDateString()
            : paymentMessages.SUBSCRIPTION_EMAIL_END_OF_BILLING_PERIOD;
          emailHandler.sendSubscriptionEmailAsync(
            stripe,
            userId,
            customerId as string,
            undefined,
            emailTemplatesVariables.emailTemplates[9].slug,
            {
              title: paymentMessages.SUBSCRIPTION_EMAIL_CANCELLATION_SCHEDULED_TITLE,
              message: `${paymentMessages.SUBSCRIPTION_EMAIL_CANCELLATION_SCHEDULED_MESSAGE} ${expiryText}.`,
            },
          );
        } else {
          emailHandler.sendSubscriptionEmailAsync(
            stripe,
            userId,
            customerId as string,
            undefined,
            emailTemplatesVariables.emailTemplates[10].slug,
            {
              status: finalStatus,
              expiryDate: expiry ? expiry.toLocaleDateString() : 'N/A',
            },
          );
        }
      } catch (error) {
        logger.error(`Error handling customer.subscription.updated: ${error}`);
      }
      break;
    }

    case paymentVariables.WEBHOOK_EVENT_CUSTOMER_SUBSCRIPTION_DELETED: {
      try {
        const subscriptionId = data[paymentVariables.STRIPE_FIELD_ID];
        const customerId = data[paymentVariables.STRIPE_FIELD_CUSTOMER];

        logger.info(
          `customer.subscription.deleted received: subscriptionId=${subscriptionId}, customerId=${customerId}`,
        );

        // First, check if this subscription exists in our DB
        // This prevents updating a different subscription (e.g., during plan changes)
        const existingSubscription = await userSubscriptionService.getByStripeSubscriptionId(subscriptionId);

        if (!existingSubscription.success || !existingSubscription.data) {
          // Subscription not found - this is likely an old subscription that was already
          // replaced by a new one during a plan change. Safe to ignore.
          logger.info(
            `Subscription ${subscriptionId} not found in DB for deletion. This is expected during plan changes when the old subscription was already replaced.`,
          );
          return;
        }

        // Update only this specific subscription by stripeSubscriptionId
        // Keep stripeSubscriptionId in the record for audit trail (don't nullify)
        console.log(existingSubscription);

        const result = await userSubscriptionService.updateByStripeSubscriptionId(subscriptionId, {
          status: SubscriptionStatus.CANCELLED,
          entitlements: {
            deleteMany: {}, // Clear all entitlements
          },
        });

        if (result.success) {
          logger.info(`User subscription cancelled for subscriptionId: ${subscriptionId}, customerId: ${customerId}`);

          // Send subscription deleted email asynchronously
          const subscriptionData = result.data;
          const userId = subscriptionData?.userId?.toString();

          emailHandler.sendSubscriptionEmailAsync(
            stripe,
            userId,
            customerId,
            undefined,
            emailTemplatesVariables.emailTemplates[9].slug,
            {
              title: paymentMessages.SUBSCRIPTION_EMAIL_CANCELLED_TITLE,
              message: paymentMessages.SUBSCRIPTION_EMAIL_DELETED_MESSAGE,
              expiryInfo: '',
              additionalMessage: paymentMessages.SUBSCRIPTION_EMAIL_DELETED_ADDITIONAL_MESSAGE,
            },
          );
        } else {
          logger.error(`Failed to cancel subscription ${subscriptionId}: ${result.message}`);
        }
      } catch (error) {
        logger.error(`Error handling customer.subscription.deleted: ${error}`);
      }
      break;
    }

    // invoice.payment_succeeded update price after payment succeed
    case paymentVariables.WEBHOOK_EVENT_INVOICE_PAYMENT_SUCCEEDED: {
      /**
       * Perform the operation after payment succed.
       */
      break;
    }

    case paymentVariables.WEBHOOK_EVENT_INVOICE_PAID: {
      /**
       * Perform the operation after invoice status=paid.
       */
      break;
    }

    case paymentVariables.WEBHOOK_EVENT_INVOICE_UPCOMING: {
      /**
       * Perform the operation for check next invoice of the subscription.
       */
      break;
    }

    default:
      break;
  }
};

/**
 * Creates a Setup Intent for embedded checkout
 * @param customerId - Existing customer ID (optional)
 * @param customerEmail - Customer email address
 * @param customerName - Customer name (optional)
 * @param userId - User ID for metadata (optional)
 */

export const createSetupIntent = async (
  customerId: string | undefined,
  customerEmail: string,
  customerName?: string,
  userId?: string,
): Promise<{ clientSecret: string; customerId: string }> => {
  let customer: Stripe.Customer | null = null;

  // STEP 1: Try to use existing customerId if provided
  if (customerId) {
    try {
      const customerData = await stripe.customers.retrieve(customerId);
      if (customerData && !customerData.deleted) {
        customer = customerData as Stripe.Customer;
        logger.info(`Using existing customer ${customerId} for Setup Intent`);
      }
    } catch (_error) {
      logger.warn(`Customer ${customerId} not found or deleted`);
    }
  }

  // STEP 2: If no customer yet, search by email (to avoid duplicates)
  if (!customer && customerEmail) {
    try {
      const existingCustomers = await stripe.customers.list({
        email: customerEmail,
        limit: 1,
      });

      if (existingCustomers.data.length > 0) {
        customer = existingCustomers.data[0];
        logger.info(`Found existing customer ${customer.id} by email ${customerEmail}`);
      }
    } catch (error) {
      logger.warn(`Error searching customer by email: ${error}`);
    }
  }

  // STEP 3: Create new customer only if none found
  if (!customer && customerEmail) {
    customer = await stripe.customers.create({
      email: customerEmail,
      name: customerName || customerEmail.split('@')[0] || paymentVariables.DEFAULT_CUSTOMER_NAME,
      metadata: { [paymentVariables.METADATA_KEY_USER_ID]: userId || '' },
    });
    logger.info(`Created new customer ${customer.id} for email ${customerEmail}`);
  }

  if (!customer) {
    throw new Error(paymentMessages.COULD_NOT_CREATE_OR_FIND_CUSTOMER);
  }

  // Create Setup Intent with customer
  const setupIntentParams: Stripe.SetupIntentCreateParams = {
    customer: customer.id,
    usage: paymentVariables.SETUP_INTENT_USAGE_OFF_SESSION,
    automatic_payment_methods: {
      enabled: true,
      allow_redirects: paymentVariables.SETUP_INTENT_ALLOW_REDIRECTS_NEVER,
    },
  };

  logger.info(`Creating Setup Intent for customer ${customer.id}`);

  const setupIntent = await stripe.setupIntents.create(setupIntentParams);

  if (!setupIntent.client_secret) {
    throw new Error(paymentMessages.FAILED_TO_CREATE_SETUP_INTENT);
  }

  return {
    clientSecret: setupIntent.client_secret,
    customerId: customer.id,
  };
};

export const createSubscriptionWithPaymentMethod = async (
  customerId: string | undefined, // Now optional - will create customer if not provided
  priceId: string,
  paymentMethodId: string,
  metadata?: Record<string, string>,
  address?: {
    line1: string;
    line2?: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
  },
): Promise<Stripe.Subscription> => {
  try {
    // Retrieve payment method first
    const paymentMethod = await stripe.paymentMethods.retrieve(paymentMethodId);

    // STEP 1: Get or create customer
    // If customerId is provided, use it. Otherwise, create/find customer.
    let finalCustomerId = customerId;

    if (!finalCustomerId) {
      // Get customer info from payment method billing details or metadata
      const email = paymentMethod.billing_details?.email || metadata?.customerEmail || '';
      const name = paymentMethod.billing_details?.name || metadata?.customerName || '';
      const userId = metadata?.[paymentVariables.METADATA_KEY_USER_ID] || metadata?.userId || '';

      if (!email) {
        throw new Error(paymentMessages.CUSTOMER_EMAIL_REQUIRED);
      }

      // Check if customer already exists by email
      const existingCustomers = await stripe.customers.list({
        email: email,
        limit: 1,
      });

      if (existingCustomers.data.length > 0) {
        finalCustomerId = existingCustomers.data[0].id;
        logger.info(`Found existing customer ${finalCustomerId} by email ${email}`);
      } else {
        // Create new customer
        const newCustomer = await stripe.customers.create({
          email: email,
          name: name || email.split('@')[0] || paymentVariables.DEFAULT_CUSTOMER_NAME,
          metadata: { [paymentVariables.METADATA_KEY_USER_ID]: userId },
        });
        finalCustomerId = newCustomer.id;
        logger.info(`Created new customer ${finalCustomerId} for email ${email}`);
      }
    }

    // STEP 2: Attach payment method to customer if not already attached
    if (!paymentMethod.customer) {
      await stripe.paymentMethods.attach(paymentMethodId, {
        customer: finalCustomerId,
      });
      logger.info(`Attached payment method ${paymentMethodId} to customer ${finalCustomerId}`);
    } else if (paymentMethod.customer !== finalCustomerId) {
      // Payment method is attached to a different customer - use that customer instead
      logger.warn(
        `Payment method ${paymentMethodId} is attached to customer ${paymentMethod.customer}, using that instead of ${finalCustomerId}`,
      );
      finalCustomerId = paymentMethod.customer as string;
    }

    // Update customer address if provided
    let customerAddress: Stripe.AddressParam | undefined;

    if (address) {
      customerAddress = {
        line1: address.line1,
        line2: address.line2 || undefined,
        city: address.city,
        state: address.state,
        postal_code: address.postal_code,
        country: address.country || paymentVariables.DEFAULT_COUNTRY_CODE,
      };

      // Update customer address before subscription creation
      await stripe.customers.update(finalCustomerId, {
        address: customerAddress,
      });

      logger.info(
        `Updated customer ${finalCustomerId} with address: ${customerAddress.line1}, ${customerAddress.city}, ${customerAddress.state}, ${customerAddress.postal_code}, ${customerAddress.country}`,
      );
    }

    // Use finalCustomerId for all subsequent operations
    customerId = finalCustomerId;

    // Step 8: Update payment method with billing address (MUST be done before subscription creation)
    // This ensures the payment method has the address when payment intent is created
    if (customerAddress) {
      try {
        await stripe.paymentMethods.update(paymentMethodId, {
          billing_details: {
            address: customerAddress,
            email: paymentMethod.billing_details?.email || undefined,
            name: paymentMethod.billing_details?.name || undefined,
          },
        });

        logger.info(`Updated payment method ${paymentMethodId} with complete billing address`);
      } catch (updateError) {
        logger.error(`Failed to update payment method billing address: ${updateError}`);
        // Don't throw - continue, but log the error
      }
    }

    // Set default payment method
    await stripe.customers.update(customerId, {
      invoice_settings: {
        default_payment_method: paymentMethodId,
      },
    });

    // Build metadata object - userId is always passed from frontend via req.user.id
    // No need to check customer metadata as fallback
    const userIdForMetadata = metadata?.[paymentVariables.METADATA_KEY_USER_ID] || metadata?.userId;

    const subscriptionMetadata: Record<string, string> = {
      [paymentVariables.METADATA_KEY_USAGE_TYPE]:
        metadata?.[paymentVariables.METADATA_KEY_USAGE_TYPE] || paymentVariables.USAGE_TYPE_LICENSED,
      [paymentVariables.METADATA_KEY_PRICE]: priceId,
      ...(metadata || {}),
    };

    // Explicitly add userId to subscription metadata
    if (userIdForMetadata) {
      subscriptionMetadata[paymentVariables.METADATA_KEY_USER_ID] = userIdForMetadata;
      logger.info(`Adding userId=${userIdForMetadata} to subscription metadata`);
    } else {
      logger.warn(`No userId in metadata for subscription creation with priceId=${priceId}`);
    }

    // Extract trialDays from price metadata - matching checkout session flow
    let trialDays: number | undefined;
    try {
      const price = await stripe.prices.retrieve(priceId);
      const priceMetadata = price[paymentVariables.STRIPE_FIELD_METADATA] || {};
      const trialDaysStr = priceMetadata[paymentVariables.METADATA_KEY_TRIAL_DAYS];
      if (trialDaysStr) {
        const parsed = Number.parseInt(trialDaysStr, 10);
        // Check if parsed is a valid positive number
        if (!Number.isNaN(parsed) && parsed > 0) {
          trialDays = parsed;
          logger.info(`Found trialDays=${trialDays} in price metadata for price ${priceId}`);
        }
      }
    } catch (error) {
      logger.warn(`Error fetching price metadata for trialDays: ${error}`);
      // Continue without trial period if metadata fetch fails
    }

    // Create subscription - matching checkout session flow exactly
    // Use payment_behavior: 'default_incomplete' to handle payment confirmation
    const subscriptionParams: Stripe.SubscriptionCreateParams = {
      customer: customerId,
      items: [{ price: priceId }],
      default_payment_method: paymentMethodId,
      expand: [paymentVariables.STRIPE_EXPAND_LATEST_INVOICE_PAYMENT_INTENT],
      metadata: subscriptionMetadata,
      collection_method: paymentVariables.SUBSCRIPTION_COLLECTION_METHOD_CHARGE_AUTOMATICALLY,
      payment_behavior: paymentVariables.SUBSCRIPTION_PAYMENT_BEHAVIOR_DEFAULT_INCOMPLETE,
      payment_settings: {
        payment_method_types: [
          paymentVariables.PAYMENT_METHOD_TYPE_CARD,
          paymentVariables.PAYMENT_METHOD_TYPE_AMAZON_PAY,
        ],
        save_default_payment_method: paymentVariables.SUBSCRIPTION_SAVE_DEFAULT_PAYMENT_METHOD_ON_SUBSCRIPTION,
      },
    };

    // Add trial period if trialDays is found in metadata - matching checkout session flow
    if (trialDays && trialDays > 0) {
      subscriptionParams.trial_period_days = trialDays;
      subscriptionParams.trial_settings = {
        end_behavior: {
          missing_payment_method: paymentVariables.SUBSCRIPTION_END_BEHAVIOR_CANCEL,
        },
      };
      logger.info(`Adding ${trialDays} day trial period to subscription for price ${priceId}`);
    }

    const subscription = await stripe.subscriptions.create(subscriptionParams);

    logger.info(`Subscription created: ${subscription.id} for customer ${customerId}, status: ${subscription.status}`);

    // If subscription is incomplete, return with payment confirmation details
    if (
      subscription.status === paymentVariables.SUBSCRIPTION_STATUS_INCOMPLETE ||
      subscription.status === paymentVariables.SUBSCRIPTION_STATUS_INCOMPLETE_EXPIRED
    ) {
      const invoice = subscription.latest_invoice;
      if (
        invoice &&
        typeof invoice === 'object' &&
        invoice !== null &&
        paymentVariables.STRIPE_FIELD_PAYMENT_INTENT in invoice
      ) {
        const paymentIntent = invoice[paymentVariables.STRIPE_FIELD_PAYMENT_INTENT];
        if (
          paymentIntent &&
          typeof paymentIntent === 'object' &&
          paymentIntent !== null &&
          paymentVariables.STRIPE_FIELD_ID in paymentIntent
        ) {
          if (paymentVariables.STRIPE_FIELD_CLIENT_SECRET in paymentIntent) {
            const clientSecret = paymentIntent[paymentVariables.STRIPE_FIELD_CLIENT_SECRET] as string;

            logger.info(
              `Subscription ${subscription[paymentVariables.STRIPE_FIELD_ID]} requires payment confirmation. Payment Intent: ${paymentIntent[paymentVariables.STRIPE_FIELD_ID]}, Payment Method: ${paymentMethodId}`,
            );
            return {
              ...subscription,
              requires_payment_confirmation: true,
              payment_intent_client_secret: clientSecret,
            } as any;
          }
        }
      }
    }

    return subscription;
  } catch (error: any) {
    logger.error(`Error creating subscription: ${error.message || error}`);
    throw error;
  }
};

/**
 * Creates a Stripe Customer Portal session for managing subscriptions and billing
 * @param {string} customerId - The Stripe customer ID
 * @param {string} returnUrl - The URL to return to after the customer finishes in the portal
 * @returns {Promise<string>} The URL of the customer portal session
 * @throws {Error} If the portal session creation fails
 */
export const createCustomerPortalSession = async (customerId: string, returnUrl: string): Promise<string> => {
  try {
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: returnUrl,
    });

    if (!session.url) {
      throw new Error(paymentMessages.FAILED_TO_CREATE_CUSTOMER_PORTAL_SESSION);
    }

    logger.info(`Created customer portal session for customer ${customerId}`);
    return session.url;
  } catch (error: any) {
    logger.error(`Error creating customer portal session: ${error.message || error}`);
    throw error;
  }
};

/**
 * Fetches all invoices for a customer from Stripe
 * @param {string} customerId - The Stripe customer ID
 * @param {number} limit - Maximum number of invoices to retrieve (default: 100)
 * @returns {Promise<Stripe.Invoice[]>} Array of Stripe invoice objects
 * @throws Error if the fetch operation fails
 */
export const fetchCustomerInvoices = async (customerId: string, limit = 100): Promise<Stripe.Invoice[]> => {
  try {
    const invoices = await stripe.invoices.list({
      customer: customerId,
      limit,
      expand: [paymentVariables.STRIPE_EXPAND_DATA_SUBSCRIPTION, paymentVariables.STRIPE_EXPAND_DATA_LINES_DATA_PRICE],
    });

    return invoices.data;
  } catch (error) {
    logger.error(`Error fetching invoices for customer ${customerId}: ${error}`);
    throw error;
  }
};

export const retrievePaymentMethod = async (paymentMethodId: string): Promise<Stripe.PaymentMethod> => {
  try {
    return await stripe.paymentMethods.retrieve(paymentMethodId);
  } catch (error) {
    logger.error(`Error retrieving payment method ${paymentMethodId}: ${error}`);
    throw error;
  }
};

export const detachPaymentMethod = async (paymentMethodId: string): Promise<Stripe.PaymentMethod> => {
  try {
    return await stripe.paymentMethods.detach(paymentMethodId);
  } catch (error) {
    logger.error(`Error detaching payment method ${paymentMethodId}: ${error}`);
    throw error;
  }
};

/**
 * Retrieves all prices (plans) associated with a product from Stripe
 * @param productId - The product ID
 * @returns The Stripe prices list object
 * @throws Error if the retrieval operation fails
 */
export const getPlansByProductId = async (productId: string) => {
  try {
    return await stripe.prices.list({
      product: productId,
      limit: 100, // Adjust limit as needed
    });
  } catch (error) {
    const err = error as ICustomError;
    if (err && err.statusCode === NOT_FOUND) {
      return null;
    }
    throw err;
  }
};

/**
 * Archives a plan (price) on Stripe by setting active to false.
 * Archived prices are not usable for new subscriptions/checkout; existing subscriptions are unaffected.
 * @param {string} priceId - The Stripe price ID to archive.
 * @returns {Promise<Stripe.Price>} The updated Stripe price object.
 */
export const archivePlan = async (priceId: string) => {
  try {
    return await stripe.prices.update(priceId, { active: false });
  } catch (err) {
    const error = err as ICustomError;
    if (error && error.statusCode === NOT_FOUND) {
      return null;
    }
    throw err;
  }
};
