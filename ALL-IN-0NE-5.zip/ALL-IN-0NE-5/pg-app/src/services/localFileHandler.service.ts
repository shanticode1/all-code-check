import env from '@config/envVar';
import { BAD_REQUEST, CREATED, NOT_FOUND, OK, SERVER_ERROR, commonMessages, fileHandlerMessages } from '@constants';
import type { IApiResponse, IFileUploadType, IUser } from '@customTypes';
import { Role } from '@enums';
import { deleteLocalUploadedFileV2 } from '@middlewares';
import { prismaService } from '@services';

/**
 * Get particular file from the database with storage type.
 * @param {string} fileId - Id of the file to fetch
 * @returns {IApiResponse} Response containing the file and error information
 */
export const fetchLocalFile = async (fileId: number): Promise<IApiResponse> => {
  try {
    if (!fileId) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: fileHandlerMessages.SELECT_FILE_ERROR,
        data: null,
      };
    }

    // 🔥 Using your Prisma wrapper
    const fileData = await prismaService.getRecordById('file', { id: Number(fileId) });

    if (!fileData) {
      return {
        status: NOT_FOUND,
        success: false,
        message: fileHandlerMessages.FILES_NOT_FOUND,
        data: null,
      };
    }

    return {
      status: OK,
      success: true,
      message: fileHandlerMessages.FILE_DETAIL_GET_SUCCESS,
      data: fileData,
    };
  } catch (error: any) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: error.message || commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

/**
 * Get list of files with storage type of a user from the database.
 * @param {Request} req Express request object
 * @returns {IApiResponse} Response containing the files and user detail or error information
 */
export const fetchLocalFileList = async (user: IUser): Promise<IApiResponse> => {
  try {
    // Role based filter (same logic as before)
    const whereFilter = user.role === Role.User ? { userId: Number(user.id) } : {};

    // 🔥 Using Prisma wrapper instead of File.find()
    const userFiles = await prismaService.findManyRecords('file', whereFilter);

    return {
      status: OK,
      success: true,
      message: fileHandlerMessages.FILES_GET_SUCCESS,
      data: userFiles,
    };
  } catch (error: any) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: error.message || commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

/**
 * Store local file path of user in database.
 * @param {Request} req Express request object
 * @returns {IApiResponse} Response containing the files and user detail or error information
 */
export const localFileUpload = async (user: IUser, files: IFileUploadType): Promise<IApiResponse> => {
  try {
    const uploadedFiles: string[] = [];

    if (files?.fileUpload) {
      files.fileUpload.forEach((file: { path: string }) => {
        if (file?.path) uploadedFiles.push(file.path);
      });
    }

    if (uploadedFiles.length === 0) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: fileHandlerMessages.SELECTED_FILE_ERROR,
        data: null,
      };
    }

    // 🔥 Only allow one file
    const newFilePath = uploadedFiles[0];

    // ✅ Find existing user file
    const existingFile = await prismaService.findFirstRecord(
      'file',
      { userId: Number(user.id) },
      {
        include: { paths: true },
      },
    );

    // ✅ Delete old file if exists
    if (existingFile?.paths?.length) {
      for (const p of existingFile.paths) {
        try {
          await deleteLocalUploadedFileV2(p.path);
        } catch {}
      }

      await prismaService.deleteManyRecords('filePath', {
        fileId: existingFile.id,
      });

      await prismaService.deleteManyRecords('file', {
        id: existingFile.id,
      });
    }

    // ✅ Create new file record
    const result = await prismaService.createRecordV2('file', {
      data: {
        user: {
          connect: { id: Number(user.id) },
        },
        isDeleted: false,
        paths: {
          create: {
            path: newFilePath,
          },
        },
      },
      include: {
        paths: true,
      },
    });

    const BASE_URL = env.BASE_URL;

    const formattedPaths =
      result.paths?.map((p: any) => {
        const normalizedPath = p.path.replace(/^public[\\/]/, '').replace(/\\/g, '/');

        return `${BASE_URL}/${normalizedPath}`;
      }) || [];

    return {
      status: CREATED,
      success: true,
      message: fileHandlerMessages.FILES_UPLOAD_SUCCESS,
      data: {
        id: result.id,
        userId: result.userId,
        path: formattedPaths,
      },
    };
  } catch (error: any) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: error.message || commonMessages.INTERNAL_SERVER_ERROR,
      data: null,
    };
  }
};

export const getFileById = async (fileFilter: any): Promise<any> => {
  const fileData = await prismaService.findFirstRecord(
    'file',
    {
      paths: {
        some: {
          path: fileFilter,
        },
      },
    },
    {
      include: {
        paths: true,
      },
    },
  );

  return fileData;
};

/**
 * Delete multiple files associated with a file record.
 * @param {any} input - Input containing file paths to delete
 * @param {string} fileId - ID of the file record
 * @returns {IApiResponse} Response indicating success or failure of deletion
 */
export const deleteFilesService = async (input: any, fileId: number, user: IUser): Promise<IApiResponse> => {
  const deletedFiles: string[] = [];
  const notFoundFiles: string[] = [];
  try {
    if (fileId && user) {
      return await deleteLocalFile(user, fileId);
    }
    const filePaths: string[] = [];
    if (input.filePath) filePaths.push(input.filePath);

    if (Array.isArray(input.files)) {
      for (const f of input.files) {
        if (f.filePath) filePaths.push(f.filePath);
      }
    }

    if (Array.isArray(input.path)) {
      for (const p of input.path) {
        filePaths.push(p);
      }
    }

    if (!input.fileId && filePaths.length === 0) {
      return {
        success: false,
        status: BAD_REQUEST,
        message: 'fileId and at least one file path are required',
        data: null,
      };
    }
    // 🔹 Load File with paths
    const fileRecord = await prismaService.getRecord('file', {
      where: { id: Number(input.fileId) },
      include: { paths: true },
    });

    if (!fileRecord) {
      return {
        success: false,
        status: NOT_FOUND,
        message: 'File record not found',
        data: null,
      };
    }
    for (const rawPath of filePaths) {
      const relative = rawPath.split('/uploads/')[1];
      const pathParam = `uploads/${relative}`;
      const dbPath = fileRecord.paths.find((p: any) => p.path === pathParam);
      if (!dbPath) {
        notFoundFiles.push(pathParam);
        continue;
      }
      try {
        // delete from disk
        await deleteLocalUploadedFileV2(pathParam);
        // delete FilePath row
        await prismaService.deleteRecord('filePath', {
          id: dbPath.id,
        });
        deletedFiles.push(pathParam);
      } catch {
        notFoundFiles.push(pathParam);
      }
    }
    // 🔹 check remaining paths
    const remainingPaths = await prismaService.getRecords('filePath', {
      where: { fileId: Number(input.fileId) },
    });

    if (remainingPaths.length === 0) {
      await prismaService.deleteRecord('file', {
        id: Number(input.fileId),
      });
    }
    return {
      success: deletedFiles.length > 0,
      status: deletedFiles.length > 0 ? OK : NOT_FOUND,
      message: deletedFiles.length > 0 ? `${deletedFiles.length} file(s) deleted successfully` : 'No files deleted',
      data: null,
    };
  } catch (_error) {
    return {
      success: false,
      status: SERVER_ERROR,
      message: 'Failed to delete files',
      data: null,
    };
  }
};

/**
 * Delete a local file belonging to a user or admin.
 *
 * This method:
 * - Validates file access based on user role
 * - Ensures the file is stored locally
 * - Removes the file from the local filesystem
 * - Deletes the corresponding database record
 *
 * @param {IUser} user - Logged-in user details
 * @param {string} fileId - Unique identifier of the file to be deleted
 *
 * @returns {Promise<IApiResponse>} Response indicating success or failure
 */
export const deleteLocalFile = async (user: IUser, fileId: number): Promise<IApiResponse> => {
  try {
    // 🔹 Role based filter
    const whereFilter =
      user.role === Role.User ? { id: Number(fileId), userId: Number(user.id) } : { id: Number(fileId) };
    // 🔹 Get file with paths
    const fileRecord = await prismaService.findFirstRecord('file', whereFilter, {
      include: {
        paths: true,
      },
    });

    if (!fileRecord) {
      return {
        status: NOT_FOUND,
        success: false,
        message: fileHandlerMessages.FILE_NOT_FOUND,
        data: null,
      };
    }

    // 🔹 Delete files from disk
    for (const file of fileRecord.paths) {
      try {
        await deleteLocalUploadedFileV2(file.path);
      } catch {
        // ignore filesystem error but continue DB delete
      }
    }
    // 🔹 Delete DB record (cascade deletes FilePath)
    await prismaService.deleteRecord('file', {
      id: fileRecord.id,
    });

    return {
      status: OK,
      success: true,
      message: fileHandlerMessages.FILE_DELETE_SUCCESS,
      data: null,
    };
  } catch (_error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: fileHandlerMessages.UPLOAD_FILE_ERROR,
      data: null,
    };
  }
};
