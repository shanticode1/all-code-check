import { unlink } from 'node:fs/promises';
import csv from 'csvtojson';
import { Parser } from 'json2csv';
import PDFDocument from 'pdfkit';
// Config
import { logger } from '@config/logger';
// Utils
import { dataManagementHandler } from '@utils';
// Constants
import { BAD_REQUEST, NO_CONTENT, OK, SERVER_ERROR, dataManagementMessages, dataManagementVariables } from '@constants';
// Enums
import { DataBatchStatus } from '@enums';
// Types
import type { ExportFilters, IApiResponse, IFileType, IUser } from '@customTypes';
import { prismaService } from '@services';

/**
 * Handles uploading a CSV file
 * @param {IFileType} file - The uploaded CSV file
 * @param {IUser} user - The user who uploaded the file
 * @returns {Promise<IApiResponse>} Response indicating success or failure with message and data
 */
export const uploadFile = async (file: IFileType, user: IUser): Promise<IApiResponse> => {
  if (!file?.csv_file || file?.csv_file.length === 0) {
    return {
      status: BAD_REQUEST,
      success: false,
      message: dataManagementMessages.FILE_REQUIRED_ERROR,
      data: null,
    };
  }

  const filePath = file.csv_file[0].path;

  try {
    const startTime = Date.now();

    // Convert CSV to JSON
    const jsonData = await csv().fromFile(filePath);
    await unlink(filePath);

    const { valid, errors, headersError, missingHeaders } = dataManagementHandler.validateCSV(jsonData);

    if (errors.length > 0 || headersError) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: headersError
          ? `${dataManagementMessages.FILE_VALIDATION_ERROR}: Missing headers - ${missingHeaders?.join(', ')}`
          : dataManagementMessages.FILE_VALIDATION_ERROR,
        data: headersError ? null : errors,
      };
    }

    logger.log(`Valid records: ${valid.length}`);
    logger.log(`Errors: ${errors.length}`);

    // Use Prisma transaction for batch + data items
    const result = await prismaService.prisma.$transaction(async (tx: any) => {
      // Create batch record
      const batch = await tx.batch.create({
        data: {
          uploadedBy: user.id,
          fileName: file.csv_file[0].originalname,
          totalRecords: jsonData.length,
          status: DataBatchStatus.Processing,
        },
      });

      // Prepare data items
      const dataItems = valid.map((item) => ({
        ...item,
        createdBy: user.id,
        lastUpdatedBy: user.id,
        batchId: batch.id,
      }));

      // Insert data items
      if (dataItems.length > 0) {
        await tx.dataItem.createMany({
          data: dataItems,
        });
      }

      // Update batch after processing
      await dataManagementHandler.updateBatch(batch, jsonData, valid, errors, startTime);

      return batch;
    });

    return {
      status: OK,
      success: true,
      message: dataManagementMessages.FILE_DATA_UPLOAD_SUCCESS,
      data: {
        batchId: result.id,
        totalProcessed: jsonData.length,
        successful: valid.length,
        failed: errors.length,
        errors: errors.length > 0 ? errors : null,
      },
    };
  } catch (error) {
    console.error(error);
    return {
      status: SERVER_ERROR,
      success: false,
      message: dataManagementMessages.FILE_PROCESSING_ERROR,
      data: error,
    };
  }
};

/**
 * Generates a CSV report based on the data items created by the user
 * @param {ExportFilters} filters - Filters to apply to the data
 * @param {IUser} user - The user who created the data items
 * @returns {Promise<IApiResponse>} Response containing the CSV document or error information
 */
export const downloadFile = async (filters: ExportFilters, user: IUser): Promise<IApiResponse> => {
  try {
    const data = await dataManagementHandler.getDataItemsCreatedByUser(user?.id, filters);
    if (!data || !data.length) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: dataManagementMessages.FILE_DATA_NOT_FOUND,
        data: null,
      };
    }

    const { transformedData, fields } = dataManagementHandler.createTransformedDataAndFields(data);

    const json2csvParser = new Parser({
      fields,
      delimiter: ',',
      quote: '"',
    });
    const csv = json2csvParser.parse(transformedData);

    return {
      status: OK,
      success: true,
      message: dataManagementMessages.FILE_DOWNLOAD_SUCCESS,
      data: csv,
    };
  } catch (error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: dataManagementMessages.FILE_DOWNLOAD_ERROR,
      data: error,
    };
  }
};

/**
 * Generates a PDF report based on the data items created by the user
 * @param {ExportFilters} filters - Filters to apply to the data
 * @param {IUser} user - The user who created the data items
 * @returns {Promise<IApiResponse>} Response containing the PDF document or error information
 */
export const downloadPdf = async (filters: ExportFilters, user: IUser): Promise<IApiResponse> => {
  try {
    const data = await dataManagementHandler.getDataItemsCreatedByUser(user?.id, filters);

    if (!data || !data.length) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: dataManagementMessages.FILE_DATA_NOT_FOUND,
        data: null,
      };
    }

    const doc = new PDFDocument({
      size: 'A4',
      margin: 50,
      bufferPages: true,
    });

    const chunks: Buffer[] = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    dataManagementHandler.addPDFHeaderInfo(doc, dataManagementVariables.PDF_GENERATION_OPTIONS);
    dataManagementHandler.addDataToPDF(doc, data, dataManagementVariables.PDF_GENERATION_OPTIONS);

    doc.end();

    return new Promise((resolve) => {
      doc.on('end', () => {
        resolve({
          status: OK,
          success: true,
          message: dataManagementMessages.FILE_DOWNLOAD_SUCCESS,
          data: Buffer.concat(chunks),
        });
      });
    });
  } catch (error) {
    return {
      status: SERVER_ERROR,
      success: false,
      message: dataManagementMessages.FILE_DOWNLOAD_ERROR,
      data: error,
    };
  }
};

/**
 * Retrieves a list of data batches uploaded by the specified user.
 *
 * @param {IUser} user - The user whose batches are to be retrieved.
 * @returns {Promise<IApiResponse>} Response containing the list of batches or error information.
 */
export const getBatches = async (user: IUser): Promise<IApiResponse> => {
  try {
    // Fetch batches using prismaService
    const data = await prismaService.findManyRecords('batch', { uploadedBy: user?.id });

    return {
      status: OK,
      success: true,
      message: dataManagementMessages.GET_BATCHES_SUCCESS,
      data,
    };
  } catch (error) {
    console.error(error);
    return {
      status: SERVER_ERROR,
      success: false,
      message: dataManagementMessages.GET_BATCHES_ERROR,
      data: error,
    };
  }
};

/**
 * Deletes all data items associated with a given batch ID.
 * @param {string} params.batchId - The ID of the batch whose data items are to be deleted.
 * @returns {Promise<IApiResponse>} Response containing the result of the deletion, including the status, success flag, message, and data (if any).
 */
export const deleteDataItemsByBatch = async (params: { batchId: string }): Promise<IApiResponse> => {
  try {
    // Check if the batch exists
    const batch = await prismaService.findFirstRecord('batch', { id: params.batchId });

    if (!batch) {
      return {
        status: BAD_REQUEST,
        success: false,
        message: dataManagementMessages.BATCH_NOT_FOUND,
        data: null,
      };
    }

    // Delete all data items associated with this batch
    await prismaService.deleteManyRecords('dataItem', { batchId: params.batchId });

    // Optionally, delete the batch itself
    await prismaService.deleteOneRecord('batch', { id: params.batchId });

    return {
      status: NO_CONTENT,
      success: true,
      message: dataManagementMessages.FILE_DATA_DELETED_SUCCESS,
      data: null,
    };
  } catch (error) {
    console.error(error);
    return {
      status: SERVER_ERROR,
      success: false,
      message: dataManagementMessages.FILE_DATA_DELETED_ERROR,
      data: error,
    };
  }
};
