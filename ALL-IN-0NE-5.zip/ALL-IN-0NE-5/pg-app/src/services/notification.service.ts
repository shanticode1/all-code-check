import { OK, SERVER_ERROR, commonMessages, notificationMessages } from '@constants';
import type { UnifiedNotificationServiceResponse } from '@customTypes';
import { NotificationType } from '@enums';
import { prismaService } from '@services';

/**
 * Retrieves a list of notifications for the authenticated user.
 * @param {number} page The page number to fetch notifications from.
 * @param {number} limit The number of notifications to fetch per page.
 * @param {id} id The id for fetch notifications of user.
 * @param {string[]} [type] An optional array of notification types to filter by.
 * @param {Date} [startDate] An optional start date to filter notifications by.
 * @param {Date} [endDate] An optional end date to filter notifications by.
 * @returns {Promise<UnifiedNotificationServiceResponse>} A promise resolving to an object containing the list of notifications and pagination information.
 */

export const getNotificationList = async (
  page: number,
  limit: number,
  id: number,
  type?: string[],
  startDate?: Date,
  endDate?: Date,
): Promise<UnifiedNotificationServiceResponse> => {
  try {
    const pageNumber = Number(page);
    const pageSize = Number(limit);
    const skip = (pageNumber - 1) * pageSize;

    /**
     * 🔥 Equivalent of createNotificationListFilter() but Prisma style
     */
    const where: any = {
      OR: [{ userId: id }, { type: { in: [NotificationType.ALL, NotificationType.SYSTEM_ALERT] } }],
    };

    // If specific types are provided → apply them
    if (type?.length) {
      where.type = { in: type };
    }

    // Date filtering
    if (startDate || endDate) {
      where.createdAt = {
        ...(startDate && { gte: new Date(startDate) }),
        ...(endDate && { lte: new Date(endDate) }),
      };
    }

    /**
     * 📦 Fetch data via prismaService
     */
    const [total, notifications] = await Promise.all([
      prismaService.getCounts('notification', where),
      prismaService.getRecords('notification', {
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: pageSize,
      }),
    ]);

    const totalPages = Math.ceil(total / pageSize);

    return {
      status: OK,
      success: true,
      message: notificationMessages.NOTIFICATION_FETCH_SUCCESS,
      data: {
        notifications,
        pagination: {
          page: pageNumber,
          limit: pageSize,
          total,
          totalPages,
          hasNextPage: pageNumber < totalPages,
          hasPrevPage: pageNumber > 1,
        },
      },
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};

/**
 * Marks one or multiple notifications as read for the given user.
 * @param {string[] | string} ids Notification id or array of ids to mark as read
 * @param {string} userId The id of the authenticated user
 * @returns {Promise<UnifiedNotificationServiceResponse>} Result status
 */
export const markNotificationsRead = async (ids: string[] | string): Promise<UnifiedNotificationServiceResponse> => {
  try {
    const idArray = Array.isArray(ids) ? ids : [ids];

    await prismaService.updateManyRecords(
      'notification',
      {
        read: true,
      },
      {
        id: {
          in: idArray,
        },
      },
    );

    return {
      status: OK,
      success: true,
      message: notificationMessages.NOTIFICATION_UPDATE_SUCCESS,
      data: null,
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : commonMessages.INTERNAL_SERVER_ERROR;

    return {
      status: SERVER_ERROR,
      success: false,
      message: errorMessage,
      data: null,
    };
  }
};
