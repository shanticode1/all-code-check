# 🚀 Node.js + Express + Prisma + TypeScript Boilerplate

A scalable backend starter template built with **Express**, **Prisma
ORM**, **PostgreSQL**, and **TypeScript**.\
Designed using clean architecture principles and best practices for
production-ready applications.

------------------------------------------------------------------------

## 📌 Features

-   ⚡ Fast and low-overhead **Express** framework\
-   🛢 **PostgreSQL** with **Prisma ORM**\
-   🧠 Clean modular folder structure\
-   🔐 Authentication-ready architecture\
-   📦 Centralized validation layer (Joi)\
-   🧹 **Biome** for linting and code formatting\
-   📘 Swagger (OpenAPI) documentation\
-   🧩 Service-based business logic\
-   🌱 Environment-based configuration\
-   🛡 Fully typed with TypeScript

------------------------------------------------------------------------

## 🏗 Tech Stack

  Technology         Purpose
  ------------------ ----------------------
  Node.js            Runtime
  Express            Web framework
  Prisma             ORM
  PostgreSQL         Database
  TypeScript         Static typing
  Joi / Validation   Request validation
  Biome              Linting & formatting
  Swagger            API documentation

------------------------------------------------------------------------

## 📁 Project Structure

``` plaintext
src/
├── app.ts                  # Main application setup
├── server.ts               # Server initialization
├── config/                 # Configuration files
├── constants/              # Application-wide constants
├── enums/                  # Enums (e.g., roles)
├── docs/                   # Swagger/OpenAPI documentation
├── controllers/            # Request handlers
├── middlewares/            # Route middlewares (auth, etc.)
├── services/               # Business logic layer
├── validations/            # Validation schemas
├── routes/                 # Route definitions
├── types/                  # Type definitions
└── utils/                  # Utility/helper functions
```

------------------------------------------------------------------------

## ⚙️ Getting Started

### 1️⃣ Clone Repository

``` bash
git clone <repository-url>
cd project-name
```


### 2️⃣ Install Dependencies

``` bash
yarn install
# or
npm install
```

## Setup Instructions

1. **Base Setup**
```bash
git checkout main
npm install
```

2. **App Support Setup**
```bash
git checkout feat/appSupportManagement
npm install
```

3. **App Subscription Setup**
```bash
git checkout feat/subscriptionManagement
npm install
```

2. **App Activity Setup**
```bash
git checkout feat/activityManagement
npm install
```

------------------------------------------------------------------------

## 🔐 Environment Setup

An example environment file is included.

``` bash
# Copy example file
cp .env.example .env
```

``` bash
# Setup .env
npm run env:setup
```
------------------------------------------------------------------------

## 🛢 Prisma Setup

``` bash
# Generate Prisma Client
npx prisma generate

# Run migrations
npx prisma migrate dev --name init

# Open Prisma Studio
npx prisma studio
```

------------------------------------------------------------------------

## 🧹 Biome (Lint & Format)

``` bash
# Run Biome check
npx biome check .

# Auto-fix issues
npx biome check . --apply
```

------------------------------------------------------------------------

## ▶️ Running the Server

### Development

``` bash
yarn dev
```

### Production

``` bash
yarn build
yarn start
```

Server runs at:

    http://localhost:5000

------------------------------------------------------------------------

## 📘 API Documentation

Available at:

    http://localhost:5000/docs

------------------------------------------------------------------------

## 🧠 Application Architecture

  Layer         Responsibility
  ------------- -------------------------
  Routes        API endpoints
  Middlewares   Auth, logging
  Validations   Request schemas
  Controllers   Handle request/response
  Services      Business logic
  Prisma        Database operations

------------------------------------------------------------------------

## 🔄 Request Flow

    Client → Route → Middleware → Validation → Controller → Service → Prisma → Response

------------------------------------------------------------------------

## 🧪 Scripts

``` json
"scripts": {
  "dev": "ts-node-dev --respawn --transpile-only src/server.ts",
  "build": "tsc",
  "start": "node dist/server.js",
  "prisma:generate": "prisma generate",
  "prisma:migrate": "prisma migrate dev",
  "prisma:studio": "prisma studio",
  "lint": "biome check .",
  "lint:fix": "biome check . --apply"
}
```

------------------------------------------------------------------------

## 🛡 Best Practices Used

-   Clean separation of concerns\
-   Service-layer abstraction\
-   Centralized error handling\
-   Type-safe database access\
-   Schema-based validation\
-   Environment-based config\
-   Linting & formatting with Biome\
-   Scalable folder structure

------------------------------------------------------------------------

## 🔒 Future Enhancements

-   Role-based access control (RBAC)
-   Rate limiting
-   Logging (Pino/Winston)
-   Redis caching

------------------------------------------------------------------------

## 👨‍💻 Author

Backend boilerplate built using Express + Prisma + TypeScript.