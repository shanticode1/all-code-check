import 'module-alias/register'; // Must be at the top
import { logger } from '../src/config/logger';
import { prismaService } from '../src/services';
import bcrypt from 'bcryptjs';
import { Role, UserStatus } from '../src/enums';
import { CATEGORIES } from '../src/constants/variables/support.variables';

/**
 * Seeds the database with an admin user if it doesn't already exist. Passwords are securely hashed using bcrypt.
 */
async function seedAdmin() {
  try {
    // ADMIN SEEDER
    // Hash passwords before inserting
    const hashedPassword = await bcrypt.hash('Admin@123', 10);
    const existingAdmin = await prismaService.findFirstRecord('user', {
      email: 'admin.c247@mailinator.com',
    });

    if (!existingAdmin) {
      // 👤 Create Admin
      await prismaService.createRecord('user', {
        firstName: 'Admin',
        lastName: 'admin',
        email: 'admin.c247@mailinator.com',
        password: hashedPassword,
        role: Role.Admin,
        isVerified: true,
        status: UserStatus.Active,
      });
    } else {
      logger.info('Admin user already exists, skipping creation.');
    }
    logger.info('Database seeding completed with hashed passwords!');
  } catch (error) {
    logger.error(`Error during database seeding: ${error}`);
  }
}
// SEED ADMIN
seedAdmin();

/**
 * Seeds the database with an admin user if it doesn't already exist. Passwords are securely hashed using bcrypt.
 */
async function seedUser() {
  try {
    // ADMIN SEEDER
    // Hash passwords before inserting
    const hashedPassword = await bcrypt.hash('User@123', 10);
    const existingAdmin = await prismaService.findFirstRecord('user', {
      email: 'user@yopmail.com',
    });

    if (!existingAdmin) {
      // 👤 Create Admin
      await prismaService.createRecord('user', {
        firstName: 'Admin',
        lastName: 'admin',
        email: 'admin.c247@mailinator.com',
        password: hashedPassword,
        role: Role.Admin,
        isVerified: true,
        status: UserStatus.Active,
      });
    } else {
      logger.info('Admin user already exists, skipping creation.');
    }
    logger.info('Database seeding completed with hashed passwords!');
  } catch (error) {
    logger.error(`Error during database seeding: ${error}`);
  }
}
// SEED ADMIN
seedUser();

async function seedCategories() {
  try {
    logger.log('🌱 Seeding categories...');
    const categoryData = CATEGORIES;
    const categories = Array.isArray(categoryData) ? categoryData : [categoryData];

    await prismaService.createManyRecord('supportCategory', categories);
    logger.log('✅ Categories seeded successfully');
  } catch (error) {
    logger.error(`❌ Category seeding failed: ${error}`);
  }
}

seedCategories();
