import { BusinessDbModel } from "../db-models/business.db-model";
import { DatabaseError } from "../errors/database.error";
import { Logger } from "../logger";
import { BusinessServicesService } from "../services/business-services.service";
import { ServiceType } from "../types/enums/service.type";

// migrate-business-capacity-script
export abstract class BusinessServiceCapacitySettings {

    public static async migrateBusinessCapacitySetting() {
        try {
            const businesses = await BusinessDbModel.BusinessModel.find({
                activationToken: undefined,
                isActive: true,
                isDeleted: false,
            }).exec();

            Logger.logger.info(`Found ${businesses.length} active businesses.`);

            for (const businessDetails of businesses) {
                const serviceDocs =
                    await BusinessServicesService.getBusinessServiceDocsForbusinessCapacity(
                        businessDetails.id
                    );

                if (!serviceDocs?.length) continue;

                // Ensure nested objects exist
                if (!businessDetails.settings.serviceCapacityVisibility)
                    businessDetails.settings.serviceCapacityVisibility = { types: [] };

                const existingTypes =
                    businessDetails.settings.serviceCapacityVisibility.types || [];

                // 🔹 Map string -> enum safely
                const hiddenTypes = serviceDocs
                    .filter((service) => service.isCapacityVisible === false)
                    .map((service) => {
                        const typeKey = Object.keys(ServiceType).find(
                            (key) => key.toLowerCase() === service.type?.toLowerCase()
                        );
                        return typeKey ? ServiceType[typeKey as keyof typeof ServiceType] : null;
                    })
                    .filter((type): type is ServiceType => type !== null); // remove null values

                // 🔹 Merge & deduplicate
                const mergedUniqueTypes = Array.from(
                    new Set([...existingTypes, ...hiddenTypes])
                );

                // 🔹 Save only if changed
                if (
                    JSON.stringify(existingTypes.sort()) !==
                    JSON.stringify(mergedUniqueTypes.sort())
                ) {
                    businessDetails.settings.serviceCapacityVisibility.types =
                        mergedUniqueTypes.map((type) =>
                            typeof type === 'object' && 'type' in type
                                ? type
                                : { type: [type] }
                        );

                    await businessDetails.save();
                    Logger.logger.info(
                        `✅ Updated business ${businessDetails._id} with hidden types: ${mergedUniqueTypes.join(', ')}`
                    );
                }
            }

            Logger.logger.info('🎉 Business capacity migration completed successfully.');
        } catch (err) {
            Logger.logger.error('❌ Error migrating business capacity settings', err);
            throw new DatabaseError('Error migrating business capacity settings');
        }
    }

}
