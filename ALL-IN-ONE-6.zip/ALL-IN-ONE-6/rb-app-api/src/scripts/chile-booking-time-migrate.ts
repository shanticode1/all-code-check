import { BookingDbModel } from "../db-models/booking.db-model";
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model";
import { TimeZoneDbModel } from "../db-models/time-zone.db-model";
import { Logger } from "../logger";
// import { bookingObjectIds } from '../../_ids';
const fs = require('fs');

const moment = require('moment-timezone');
const { ObjectId } = require('mongodb');
export abstract class BookingTimeZoneScriptService {
    public static async updateBackWardBookingTime() {
        try {
            // for back 1 hr
            let tampArr = [];
            const comparisonDate = new Date(Date.UTC(2024, 8, 8, 3, 0, 0)); // 8th Sept 2024 4:00 AM UTC
            // update business on boarding stpes count ofr existing users
            const businesses = await BusinessDbModel.BusinessModel.find({ isActive: true, isDeleted: false }).exec();
            console.log('db businesses:', businesses.length);
            businesses.forEach(async businessDetails => {
                const timeZone = await TimeZoneDbModel.TimeZoneModel.findOne({
                    id: businessDetails.timeZoneId,
                    isBusinessDefault: true,
                }).exec();
                // only update America/Santiago
                if (timeZone.name === 'America/Santiago') {
                    // get bookings data based on business
                    const bookings = await BookingDbModel.BookingModel.find(
                        {
                            businessId: businessDetails.id,
                            // startDate: { $gt: new Date(comparisonDate) }
                        }).exec();

                    bookings.forEach(async (booking) => {
                        console.log('id:', booking.id);
                        // if (!bookingObjectIds.includes(booking.id)) {
                        //     const createdAtDate = ObjectId(booking.id).getTimestamp();
                        //     const createdAt = new Date(createdAtDate); // get booking created date
                        //     //    check if booking created Date before 7th Sept 2024 4:00 AM UTC
                        //     if (createdAt < comparisonDate) {
                        //         console.log('inside if createdDate:', createdAt);
                        //         // check start date of booking is after 7th Sept 2024 4:00 AM UTC
                        //         if (new Date(booking.startDate) > comparisonDate) {
                        //             console.log('after 7th sept date');
                        //             // Given UTC timestamp
                        //             const startDateTimesSamp = booking.startDate;
                        //             // Parse the timestamp
                        //             const sdt = moment.utc(startDateTimesSamp);
                        //             // Subtract 1 hour
                        //             booking.startDate = sdt.subtract(1, 'hour');
                        //             const endDateTimesSamp = booking.endDate;
                        //             // Parse the timestamp
                        //             const edt = moment.utc(endDateTimesSamp);
                        //             // Subtract 1 hour
                        //             booking.endDate = edt.subtract(1, 'hour');
                        //             // save data into db
                        //             // update when data update when booking before daylight start
                        //             booking['isDayLightUpdated'] = true;
                        //             await booking.save();
                        //             tampArr.push({
                        //                 id: booking.id,
                        //                 businessId: booking.businessId,
                        //             });
                        //             const jsonData = JSON.stringify(tampArr);
                        //             fs.writeFileSync('daylightbooking.json', jsonData, 'utf8');
                        //         }
                        //     }
                        // }
                    });
                }
            })
            Logger.logger.info('migrate Business booking successfully...')
        } catch (error) {
            Logger.logger.error('step error:', error)
        }
    }


    public static async revertBackWardBookingTime() {
        try {
            console.log('REVERT TIME LOG');
            let tampArr = [];
            const bookings = await BookingDbModel.BookingModel.find(
                {
                    isDayLightUpdated: true
                    // startDate: { $gt: new Date(comparisonDate) }
                }).exec();
            console.log('bookings:0', bookings.length);
            bookings.forEach(async (booking) => {
                console.log('id:', booking.id);
                // if (!bookingObjectIds.includes(booking.id)) {
                //     const createdAtDate = ObjectId(booking.id).getTimestamp();
                //     const createdAt = new Date(createdAtDate); // get booking created date
                //     //    check if booking created Date before 7th Sept 2024 4:00 AM UTC
                //     // if (createdAt < comparisonDate) {
                //     console.log('inside if createdDate:', createdAt);
                //     // check start date of booking is after 7th Sept 2024 4:00 AM UTC
                //     // if (new Date(booking.startDate) > comparisonDate) {
                //     console.log('after 7th sept date');
                //     // Given UTC timestamp
                //     const startDateTimesSamp = booking.startDate;
                //     // Parse the timestamp
                //     const sdt = moment.utc(startDateTimesSamp);
                //     // Subtract 1 hour
                //     booking.startDate = sdt.add(1, 'hour');
                //     const endDateTimesSamp = booking.endDate;
                //     // Parse the timestamp
                //     const edt = moment.utc(endDateTimesSamp);
                //     // Subtract 1 hour
                //     booking.endDate = edt.add(1, 'hour');
                //     // save data into db
                //     // update when data update when booking before daylight start
                //     booking['isDayLightUpdated'] = false;
                //     await booking.save();
                //     tampArr.push({
                //         id: booking.id,
                //         businessId: booking.businessId,
                //     });
                //     const jsonData = JSON.stringify(tampArr);
                //     fs.writeFileSync('daylightbooking-revert.json', jsonData, 'utf8');
                //     // }
                //     // }
                // }
            });

        } catch (error) {


        }
    }

    public static async backWardBookingTimeByBusinessId(id) {
        try {
            console.log('back by id:', id);
            const comparisonDate = new Date(Date.UTC(2024, 8, 8, 3, 0, 0)); // 8th Sept 2024 3:00 AM UTC
            let tampArr = [];
            const bookings = await BookingDbModel.BookingModel.find(
                {
                    businessId: id,
                    // eventType: '',
                }).exec();
            console.log('bookings:', bookings.length);
            bookings.forEach(async (booking) => {
                console.log('id:', booking.id);
                // if (!bookingObjectIds.includes(booking.id) || (booking && booking.eventType != 'google')) {
                //     const createdAtDate = ObjectId(booking.id).getTimestamp();
                //     const createdAt = new Date(createdAtDate); // get booking created date
                //     //    check if booking created Date before 7th Sept 2024 4:00 AM UTC
                //     if (createdAt < comparisonDate) {
                //         console.log('inside if createdDate:', createdAt);
                //         // check start date of booking is after 7th Sept 2024 4:00 AM UTC
                //         if (new Date(booking.startDate) > comparisonDate) {
                //             console.log('after 8th sept date');
                //             // Given UTC timestamp
                //             const startDateTimesSamp = booking.startDate;
                //             // Parse the timestamp
                //             const sdt = moment.utc(startDateTimesSamp);
                //             // Subtract 1 hour
                //             booking.startDate = sdt.subtract(1, 'hour');
                //             const endDateTimesSamp = booking.endDate;
                //             // Parse the timestamp
                //             const edt = moment.utc(endDateTimesSamp);
                //             // Subtract 1 hour
                //             booking.endDate = edt.subtract(1, 'hour');
                //             booking['isDayLightUpdated'] = true;
                //             // save data into db
                //             await booking.save();
                //             // update when data update when booking before daylight start
                //             tampArr.push({
                //                 id: booking.id,
                //                 businessId: booking.businessId,
                //             });
                //             const jsonData = JSON.stringify(tampArr);
                //             fs.writeFileSync(`daylightbooking-${id}.json`, jsonData, 'utf8');
                //         }
                //     }
                // }
            });

        } catch (error) {
            console.log(error)
        }
    }

    public static async revertBookingTimeByBusinessId(id) {
        try {
            console.log('back by id:', id);
            const comparisonDate = new Date(Date.UTC(2024, 8, 8, 3, 0, 0)); // 8th Sept 2024 3:00 AM UTC
            let tampArr = [];
            const bookings = await BookingDbModel.BookingModel.find(
                {
                    businessId: id,
                    // eventType: '',
                }).exec();
            console.log('bookings:', bookings.length);
            bookings.forEach(async (booking) => {
                console.log('id:', booking.id);
                // if (!bookingObjectIds.includes(booking.id) || (booking && booking.eventType != 'google')) {
                //     const createdAtDate = ObjectId(booking.id).getTimestamp();
                //     const createdAt = new Date(createdAtDate); // get booking created date
                //     //    check if booking created Date before 7th Sept 2024 4:00 AM UTC
                //     if (createdAt < comparisonDate) {
                //         console.log('inside if createdDate:', createdAt);
                //         // check start date of booking is after 7th Sept 2024 4:00 AM UTC
                //         if (new Date(booking.startDate) > comparisonDate) {
                //             console.log('after 8th sept date');
                //             // Given UTC timestamp
                //             const startDateTimesSamp = booking.startDate;
                //             // Parse the timestamp
                //             const sdt = moment.utc(startDateTimesSamp);
                //             // add 1 hour
                //             booking.startDate = sdt.add(1, 'hour');
                //             const endDateTimesSamp = booking.endDate;
                //             // Parse the timestamp
                //             const edt = moment.utc(endDateTimesSamp);
                //             // add 1 hour
                //             booking.endDate = edt.add(1, 'hour');
                //             booking['isDayLightUpdated'] = true;
                //             // save data into db
                //             await booking.save();
                //             // update when data update when booking before daylight start
                //             tampArr.push({
                //                 id: booking.id,
                //                 businessId: booking.businessId,
                //             });
                //             const jsonData = JSON.stringify(tampArr);
                //             fs.writeFileSync(`daylightbooking-revert-${id}.json`, jsonData, 'utf8');
                //         }
                //     }
                // }
            });

        } catch (error) {
            console.log(error)
        }
    }
}
