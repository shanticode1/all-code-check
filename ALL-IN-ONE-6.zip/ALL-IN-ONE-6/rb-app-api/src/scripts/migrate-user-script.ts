import { roles } from "../data/user.roles";
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model";
import { CurrencyRateDbModel } from "../db-models/currency-rate.db.modal";
import { StaffDbModel } from "../db-models/staff.db-model";
import { UserDbModel } from "../db-models/users.db-model";
import { Logger } from "../logger";
import { UserService } from "../services/users.service";
import { CurrencyRate } from "../types/currencyRates";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { User } from "../types/user";

export abstract class ScriptService {
    public static async migrateBusinessToUser() {
        let userId: string = '';
        const businesses = await BusinessDbModel.BusinessModel.find({ isActive: true, isDeleted: false }).exec();
        console.log('db businesses:', businesses.length);
        
        businesses.forEach(async businessDetails => {
            const user = new User(
                undefined,
                businessDetails.email,
                businessDetails.password,
                businessDetails.contactName,
                roles.Business,
                true,
                false,
                undefined
            )
            console.log('email:-', businessDetails.email);
            const userData = await UserService.getUserByEmail(businessDetails.email);
            if (userData == null) {
                console.log('inside user', userData);
                const userDoc = UserDbModel.convertToDbModel(user)
                const userResult = await UserDbModel.UserModel.create(userDoc);
                userId = userResult._id.toHexString();
            }
            else {
                userId = userData.id;
            }
            businessDetails.userId = userId;
            if (businessDetails.membershipTier === MembershipTier.Pro) {
                businessDetails.isAnnualActive = true;  //allow staffs access to existing all user until their renewal date in December  
            }
            await businessDetails.save()
        })
        Logger.logger.info('migrate Business To User successfully...')
    }


    public static async migrateStaffToUser() {
        const staffs = await StaffDbModel.StaffModel.find({ isActive: true, isDeleted: false }).exec();
        console.log('db businesses:', staffs.length);
        staffs.forEach(async staff => {
            const getBunessess: IBusiness = await BusinessDbModel.BusinessModel.findOne({ isActive: true, isDeleted: false, _id: staff.businessId }).exec()
            staff.userId = getBunessess.userId;
            await staff.save();
        })
        Logger.logger.info('migrate Business To User successfully...')
    }

    public static async insertCurrencyRates() {
        const currencyValues = [
            { id: "", country: "United States", currencyCode: "USD", appMinCurrency: 2 },
            { id: "", country: "Chile", currencyCode: "CLP", appMinCurrency: 2000 },
            { id: "", country: "Argentina", currencyCode: "ARS", appMinCurrency: 2500 },
            { id: "", country: "Mexico", currencyCode: "MXN", appMinCurrency: 50 },
            { id: "", country: "Uruguay", currencyCode: "UYU", appMinCurrency: 100 },
            { id: "", country: "Peru", currencyCode: "PEN", appMinCurrency: 10 },
            { id: "", country: "Colombia", currencyCode: "COP", appMinCurrency: 10000 },
            { id: "", country: "Paraguay", currencyCode: "PYG", appMinCurrency: 20000 },
            { id: "", country: "Dominican Republic", currencyCode: "DOP", appMinCurrency: 150 },
            { id: "", country: "Brazil", currencyCode: "BRL", appMinCurrency: 15 },
            { id: "", country: "Panama", currencyCode: "PAB", appMinCurrency: 2 },
            { id: "", country: "Costa Rica", currencyCode: "CRC", appMinCurrency: 1000 },
            { id: "", country: "Australia", currencyCode: "AUD", appMinCurrency: 2 },
            { id: "", country: "Bolivia", currencyCode: "BOB", appMinCurrency: 7 },
            { id: "", country: "Bahamas", currencyCode: "BSD", appMinCurrency: 1 },
            { id: "", country: "Belize", currencyCode: "BZD", appMinCurrency: 2 },
            { id: "", country: "Canada", currencyCode: "CAD", appMinCurrency: 1 },
            { id: "", country: "Switzerland", currencyCode: "CHF", appMinCurrency: 1 },
            { id: "", country: "China", currencyCode: "CNY", appMinCurrency: 7 },
            { id: "", country: "Cape Verde", currencyCode: "CVE", appMinCurrency: 103 },
            { id: "", country: "Eurozone", currencyCode: "EUR", appMinCurrency: 1 },
            { id: "", country: "Guatemala", currencyCode: "GTQ", appMinCurrency: 8 },
            { id: "", country: "Guyana", currencyCode: "GYD", appMinCurrency: 209 },
            { id: "", country: "Honduras", currencyCode: "HNL", appMinCurrency: 26 },
            { id: "", country: "India", currencyCode: "INR", appMinCurrency: 87 },
            { id: "", country: "Japan", currencyCode: "JPY", appMinCurrency: 149 },
            { id: "", country: "Nicaragua", currencyCode: "NIO", appMinCurrency: 37 },
            { id: "", country: "Norway", currencyCode: "NOK", appMinCurrency: 11 },
            { id: "", country: "New Zealand", currencyCode: "NZD", appMinCurrency: 2 },
            { id: "", country: "Sweden", currencyCode: "SEK", appMinCurrency: 10 },
            { id: "", country: "Venezuela", currencyCode: "VEF", appMinCurrency: 248832 },
            { id: "", country: "South Africa", currencyCode: "ZAR", appMinCurrency: 18 }
        ];

        for (const currency of currencyValues) {

            const currencyRate = new CurrencyRate(
                currency.id,
                currency.country,
                currency.currencyCode,
                currency.appMinCurrency,
                true,
                false,
            );

            const newRates = CurrencyRateDbModel.convertToDbModel(currencyRate);
            await CurrencyRateDbModel.CurrencyRateModel.create(newRates);
        }

        Logger.logger.info('Inserted currency rates successfully...');
    }
}
