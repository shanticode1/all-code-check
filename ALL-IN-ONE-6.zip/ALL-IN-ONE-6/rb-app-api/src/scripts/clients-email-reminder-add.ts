import { ClientDbModel } from "../db-models/client.db-model";
import { Logger } from "../logger";

export abstract class ClientEmailReminderOnService {
    public static async clientEmailReminderAdd() {
        try {
            /** Get all existing list of clients for modify collection */
            const clients = await ClientDbModel.ClientModel.find({});
            console.log('clients client count:', clients.length);
            clients.forEach(async (clientDoc) => {
                clientDoc.isEmailAllow = true;  //Set reminder of existing users
                // await clientDoc.save(); // update client with new values
            })
            Logger.logger.info('All Client updated successfully...')
        } catch (error) {
            console.log('error while calling client email reminder update service:', error);
            Logger.logger.error(error)
        }
    }
}