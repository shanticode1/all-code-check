import { BusinessDbModel, IBusiness } from "../db-models/business.db-model";
import { Logger } from "../logger";

export abstract class StepperCountScriptService {
    public static async updateBusinessStepCount() {
        try {
            // update business on boarding stpes count ofr existing users
            const businesses = await BusinessDbModel.BusinessModel.find({ isActive: true, isDeleted: false }).exec();
            console.log('db businesses:', businesses.length);
            businesses.forEach(async businessDetails => {
                console.log(businessDetails.id, 'stripeOnTrial:', businessDetails.stripeOnTrial, 'before', businessDetails.lastCompletedOnboardingStep);
                if (businessDetails.stripeOnTrial != undefined || businessDetails.stripeOnTrial != null) {
                    //isTrialActivatedOnce
                    businessDetails.lastCompletedOnboardingStep = 5;
                }
                if (businessDetails.googleToken) {
                    businessDetails.lastCompletedOnboardingStep = 6;
                }
                await businessDetails.save();
            })
            Logger.logger.info('migrate Business stpes successfully...')
        } catch (error) {
            Logger.logger.error('step error:', error)
        }
    }
}
