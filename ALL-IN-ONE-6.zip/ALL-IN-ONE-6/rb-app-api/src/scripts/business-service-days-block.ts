import { Logger } from "../logger";
import { BusinessServicesService } from "../services/business-services.service";
import { BusinessesService } from "../services/businesses.service";

export abstract class BusinessServiceDaysBlock {
    public static async updateServicesDays() {
        try {
            /** update business service day block time in service table */
            const businesses = await BusinessesService.getAllBusinesses();
            console.log('db businesses:', businesses.length);
            businesses.forEach(async businessDetails => {
                /** get services based on business and update services days */
                const serviceDocs = await BusinessServicesService.getBusinessServiceDocsForbusiness(businessDetails.id)
                serviceDocs.forEach(async (sd) => {
                    /** update service with block days */
                    const businessBlockTime = businessDetails.businessHoursBlocks;
                    // sd.serviceDaysBlocks = businessBlockTime.map(bd => ({
                    //     dayOfTheWeek: bd.startDayOfTheWeek
                    // }));
                    const uniqueDays = new Set();
                    sd.serviceDaysBlocks = businessBlockTime
                        .map(bd => ({
                            dayOfTheWeek: bd.startDayOfTheWeek
                        }))
                        .filter(bd => {
                            // Only add to the new array if it's not already in the Set
                            if (!uniqueDays.has(bd.dayOfTheWeek)) {
                                uniqueDays.add(bd.dayOfTheWeek);
                                return true;
                            }
                            return false;
                        });
                    console.log('businessId:', businessDetails.id, 'uniqueDays:', sd.serviceDaysBlocks);
                    // await sd.save();  //save service time
                });
            })
            Logger.logger.info('migrate service days successfully...')
        } catch (error) {
            Logger.logger.error('step error:', error)
        }
    }
}
