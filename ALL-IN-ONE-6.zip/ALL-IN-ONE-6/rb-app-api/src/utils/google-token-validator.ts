// this for if in case any reason google token or value to set
// config.ts
export abstract class GoogleTokenValidator {
    private static globalVariable: boolean = true;

    static getGlobalVariable(): boolean {
        return this.globalVariable;
    }

    static setGlobalVariable(value: boolean): void {
        this.globalVariable = value;
    }
}


