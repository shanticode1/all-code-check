export class BodyParserUtil {
  
  /**
   * Dynamically parses all JSON-like string values in the body object.
   * Automatically detects and parses JSON objects and arrays.
   */
  public static parseBodyJson(body: Record<string, any>): Record<string, any> {
    // Create a shallow copy to avoid mutating the original
    const parsedBody = { ...body };

    for (const [key, value] of Object.entries(parsedBody)) {
      if (typeof value === "string") {
        const trimmed = value.trim();
        // Check if value looks like JSON (object or array)
        if (
          (trimmed.startsWith("{") && trimmed.endsWith("}")) ||
          (trimmed.startsWith("[") && trimmed.endsWith("]"))
        ) {
          try {
            parsedBody[key] = JSON.parse(trimmed);
          } catch (error: any) {
            console.error(`Error while parsing key "${key}": ${error.message}`);
          }
        }
      }
    }

    return parsedBody;
  }
}
