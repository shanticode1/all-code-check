// const countriesData = require('../data/country-state-city-names.json');
// import * as countriesData from '../data/country-state-city-names.json';

import { cityCountry } from "../data/country-state-city-names";

// Utility: normalize country names (case-insensitive + trim extra spaces)
function normalizeName(name: string): string {
    return name.toLowerCase().replace(/\s+/g, ' ').trim();
}

export const CitiesByCountry = async (countryName: string): Promise<string[]> => {
    try {
        const countryList = cityCountry;
        const normalizedInput = normalizeName(countryName);
        // Find matching country key in JSON
        const matchedKey = Object.keys(countryList).find(
            (key) => normalizeName(key) === normalizedInput
        );

        if (!matchedKey) {
            console.warn(`Country "${countryName}" not found in data.`);
            return [];
        }

        const country = (countryList as Record<string, any>)[matchedKey];

        if (!country || typeof country !== 'object') {
            console.warn(`No valid data for country "${matchedKey}".`);
            return [];
        }

        // Flatten all cities from all states/provinces
        const cities = Object.values(country)
            .filter((arr) => Array.isArray(arr) && arr.length > 0)
            .flat() as string[];

        if (cities.length === 0) {
            console.warn(`No cities found for country "${matchedKey}".`);
        }

        return cities;
    } catch (err) {
        console.error('Error fetching cities:', err);
        return [];
    }
};

