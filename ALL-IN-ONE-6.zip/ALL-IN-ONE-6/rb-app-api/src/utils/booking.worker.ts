// src/booking/booking.worker.ts
import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import { BookingsService } from '../services/bookings.service';
import { Logger } from '../logger';

export abstract class BookingWorker {
    private static connection = new IORedis({
        host: process.env.REDIS_HOST || '127.0.0.1',
        port: Number(process.env.REDIS_PORT) || 6379,
        password: process.env.REDIS_PASSWORD, // use the same value from .env
        maxRetriesPerRequest: null,
        enableReadyCheck: false,
    });

    private static worker: Worker;

    public static start(): void {
        Logger.logger.info('🚀 Starting Booking Worker......');
        if (this.worker) return;

        this.worker = new Worker(
            'bookingQueue',
            async (job) => {
                try {
                    Logger.logger.info(`⚙️ Processing booking job : ${job.id}`);
                    const result = await BookingsService.create(
                        job.data.fromBusiness,
                        job.data.chargeImmediately,
                        job.data.booking
                    );
                    Logger.logger.info(`✅ Booking created for client: ${job.data.booking?.customer?.email}`);
                    return result; // returned to queue
                } catch (error) {
                    Logger.logger.error(`❌ Booking failed for ${job.id}: ${error} ${error.stack}`);
                    // Re-throw the error so BullMQ knows it failed
                    // send structured error back to the queue
                    throw {
                        message: error.message || 'Unknown error',
                        statusCode: error.statusCode || 500,
                        name: error.name || 'Error'
                    };

                }
            },
            {
                connection: this.connection,
                concurrency: 1,
            }
        );

        this.worker.on('completed', (job) => {
            Logger.logger.info(`🎉 Job ${job.id} completed successfully`);
        });

        this.worker.on('failed', (job, err) => {
            Logger.logger.error(`❌ Job ${job?.id} failed: ${err.message}`);
        });

        this.connection.on('connect', () => Logger.logger.info('✅ Redis connected in worker'));
        this.connection.on('error', (err) => Logger.logger.error('❌ Redis error in worker', err));
    }

    public static async close(): Promise<void> {
        if (this.worker) await this.worker.close();
        await this.connection.quit();
    }
}
