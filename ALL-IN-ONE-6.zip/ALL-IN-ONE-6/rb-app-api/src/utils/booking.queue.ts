import { Queue, QueueEvents, Job } from 'bullmq';
import IORedis from 'ioredis';
export abstract class BookingQueue {
    private static connection = new IORedis({
        host: process.env.REDIS_HOST || '127.0.0.1',
        port: Number(process.env.REDIS_PORT) || 6379,
        password: process.env.REDIS_PASSWORD, // use the same value from .env
        maxRetriesPerRequest: null,
        enableReadyCheck: false,
    });

    private static queue = new Queue('bookingQueue', {
        connection: BookingQueue.connection,
    });

    private static queueEvents = new QueueEvents('bookingQueue', {
        connection: BookingQueue.connection,
    });

    /**
     * Add booking job and wait for result (for API to return full response)
     */
    public static async addBookingJobAndWait(payload: any): Promise<any> {

        const jobId = `${payload?.booking?.customer.email}_${payload.booking.service?.id}_${payload?.booking?.startDate}`;
        try {
            const job: Job = await BookingQueue.queue.add('createBooking', payload, {
                jobId,
                removeOnComplete: true,
                removeOnFail: false,
                attempts: 3,
                backoff: { type: 'exponential', delay: 3000 },
            });

            // return new Promise((resolve, reject) => {
            //     BookingQueue.queueEvents.on('completed', ({ jobId: completedId, returnvalue }) => {
            //         if (completedId === job.id) resolve(returnvalue);
            //     });

            //     BookingQueue.queueEvents.on('failed', ({ jobId: failedId, failedReason }) => {
            //         if (failedId === job.id) reject(new Error(failedReason));
            //     });
            // });

            // ✅ Wait for job to finish using Redis connection
            return await job.waitUntilFinished(BookingQueue.queueEvents);
        } catch (err) {
            // ✅ Deserialize proper error structure
            if (err && typeof err === 'object') {
                const reconstructedError: any = new Error(err.message || 'Job failed');
                reconstructedError.name = err.name || 'Error';
                reconstructedError.statusCode = err.statusCode || 500;
                reconstructedError.stack = err.stack;
                throw reconstructedError;
            }
            // fallback (string or undefined)
            throw new Error(err?.toString() || 'Unknown job error');
        }
    }

    public static async close(): Promise<void> {
        await BookingQueue.connection.quit();
    }
}
