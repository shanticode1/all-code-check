import { DayOfTheWeek } from "../types/enums/day-of-the-week.enum"

export abstract class DateUtils {

	public static toLocalDateString(date: Date, timeZone: string): string {
		return date.toLocaleString("es-419", { timeZone: timeZone, dateStyle: 'full' })
	}

	// public static toLocalTimeString(date: Date, timeZone: string): string {
	// 	return date.toLocaleString("es-419", { timeZone: timeZone, timeStyle: 'short', hour12: true })
	// }

	public static toLocalTimeString(date: Date, timeZone: string): string {
		const timeString = date.toLocaleTimeString("es-419",
			{ timeZone: timeZone, hour: 'numeric', minute: 'numeric', hour12: false }); // Use toLocaleTimeString for only time
		// Get the hour in 12-hour format to determine AM/PM
		const hours12 = date.toLocaleTimeString("en-US", { timeZone: timeZone, hour: 'numeric', hour12: true });
		const period = hours12.includes("AM") ? "AM" : "PM"; // Determine AM or PM
		// console.log(`${timeString} ${period}`)
		return `${timeString} ${period}`; // Concatenate time and AM/PM
	}

	public static getLocalDayString(date: Date, timeZone: string): String {
		const localDateString = this.getLocalDateString(date, timeZone)
		return localDateString.split(', ')[1].split('-')[2]
	}

	public static getLocalDayOfTheWeek(date: Date, timeZone: string): DayOfTheWeek {
		const localDateString = this.getLocalDateString(date, timeZone)
		return DayOfTheWeek[localDateString.split(', ')[0]]
	}

	public static getLocalHourString(date: Date, timeZone: string): string {
		const localDateString = this.getLocalDateString(date, timeZone)
		return localDateString.split(', ')[2].split(':')[0]
	}

	public static getLocalMinuteString(date: Date, timeZone: string): string {
		const localDateString = this.getLocalDateString(date, timeZone)
		return localDateString.split(', ')[2].split(':')[1]
	}

	public static getLocalDateString(date: Date, timeZone: string): string {
		return date.toLocaleString('en-CA', {
			timeZone,
			weekday: 'long',
			year: 'numeric',
			month: 'numeric',
			day: 'numeric',
			hour: 'numeric',
			minute: 'numeric',
			second: 'numeric',
			hour12: false
		})
	}

	public static dateToShortString(date: Date): string {
		return Intl.DateTimeFormat(undefined, { dateStyle: 'short', timeStyle: 'medium' }).format(date)
	}

	// return (Math.floor((dateB.getTime() - dateA.getTime()) / (1000 * 60)))
	public static differenceInMinutes(dateA: Date, dateB: Date): number {
		return (Math.floor((dateB.getTime() - dateA.getTime()) / (1000 * 60)))
	}

	public static formatDatesToWeekTimeBlock(startDateStr: Date, endDateStr: Date, timeZone: string) {
		const start = new Date(startDateStr);
		const end = new Date(endDateStr);
		const getDayHourMinute = (date: Date) => {
			const weekday = new Intl.DateTimeFormat('en-US', { weekday: 'short', timeZone }).format(date);
			const hour = new Intl.DateTimeFormat('en-US', { hour: 'numeric', hour12: false, timeZone }).format(date);
			const minute = new Intl.DateTimeFormat('en-US', { minute: 'numeric', timeZone }).format(date);

			const dayMap: Record<string, number> = {
				Sun: 0,
				Mon: 1,
				Tue: 2,
				Wed: 3,
				Thu: 4,
				Fri: 5,
				Sat: 6,
			};

			return {
				dayOfWeek: dayMap[weekday as keyof typeof dayMap],
				hour: parseInt(hour, 10),
				minute: parseInt(minute, 10),
			};
		};

		const startParts = getDayHourMinute(start);
		const endParts = getDayHourMinute(end);

		return [{
			startDayOfTheWeek: startParts.dayOfWeek,
			startHour: startParts.hour,
			startMinute: startParts.minute,
			endDayOfTheWeek: endParts.dayOfWeek,
			endHour: endParts.hour,
			endMinute: endParts.minute,
		}];
	}

	public static getTimeDifferenceInMinutes(startDate: string, endDate: string): number {
		const start = new Date(startDate).getTime();
		const end = new Date(endDate).getTime();
		return Math.floor((end - start) / (1000 * 60));
	}
	public static toLocalDateStringFormat(date: Date, timeZone: string): string {
		const localDate = new Date(date.toLocaleString("en-US", { timeZone }));
	  
		const day = localDate.getDate().toString().padStart(2, "0");
		const month = (localDate.getMonth() + 1).toString().padStart(2, "0");
		const year = localDate.getFullYear();
	  
		return `${day}/${month}/${year}`;
	  }
	  
	/**
 * Returns a date range from today to the next 3 months.
 * Handles year rollover (e.g., November → February next year).
 */
	public static getNextThreeMonthRange(): { timeMin: Date; timeMax: Date } {
		const today = new Date();
		// Clone current date to avoid mutating it
		const threeMonthsLater = new Date(today);

		// Add 3 months
		threeMonthsLater.setMonth(today.getMonth() + 3);

		// Handle year rollover if month exceeds December
		if (threeMonthsLater.getMonth() < (today.getMonth() + 3) % 12) {
			threeMonthsLater.setFullYear(today.getFullYear() + 1);
		}

		return {
			timeMin: today,
			timeMax: threeMonthsLater,
		};
	}
}


