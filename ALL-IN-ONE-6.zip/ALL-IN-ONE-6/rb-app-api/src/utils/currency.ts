
import { stripeCurrencies } from "../data/whatsAppProductAndCurrency";
import { Currency } from "../types/enums/currency";
// const currencies = require('currency-codes');
const currencies = require('iso-country-currency');

export abstract class CurrencyService {
    static getCurrency(currency): string {
        let currencyValue = Object.keys(Currency).find(key => Currency[key] === currency);
        const isCurrenyExist = stripeCurrencies.includes(currencyValue);
        if (isCurrenyExist === false) {
            currencyValue = 'USD';
        }
        return currencyValue;
    }
    static getPlansCurrency(prices, currentCurrency): string {
        let currencyCode = Object.keys(prices).find(key => key.toLowerCase() === currentCurrency.toLowerCase());
        let currencyValue: any = currencyCode ? currencyCode.toUpperCase() : currencyCode
        const isCurrenyExist = stripeCurrencies.includes(currencyValue);
        if (isCurrenyExist === false) {
            currencyValue = 'USD';
        }
        return currencyValue;
    }

    static async getCurrencyByCountryShortName(countryCode: string) {
        try {
            const currencyInfo = currencies.getAllInfoByISO(countryCode);
            let currencyCode = Object.keys(Currency).find(key => Currency[key] === currencyInfo.currency);
            let currencyIndex = Number(currencyCode);
            let currencyValue = Currency[currencyIndex];
            const isCurrenyExist = stripeCurrencies.includes(Currency[currencyIndex]);
            if (isCurrenyExist === false) {
                currencyValue = 'USD';
            }            
            return currencyValue;
        } catch (error) {
            console.error('Error:', error.message);
            return 'Error occurred';
        }
    }
}


