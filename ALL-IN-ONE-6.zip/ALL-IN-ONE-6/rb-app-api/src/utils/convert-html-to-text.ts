const { convert } = require('html-to-text');

// this for convert thml to sting for view 
export abstract class TextFormatService {
    static async convertHtmlToString(text: string): Promise<string> {
        const options = {
            wordwrap: false,
            ignoreHref: false,
            ignoreImage: true,
        }
        const textWithLinks = convert(text, options);
        const formattedData = await this.removeDuplicateLines(textWithLinks)
        return formattedData
    }

    static removeSpecialCharacters(text: string): string {
        const regex = /[^a-zA-Z0-9 ]/g;
        return text.replace(regex, ' ');
    }

    public static async removeDuplicateLines(text) {
        // 1. Remove mailto references completely
        text = text.replace(/\s*\[mailto:[^\]]+\]/gi, '');

        // 2. Remove duplicate URLs like:
        //    https://abc.com [https://abc.com]
        text = text.replace(
            /(https?:\/\/[^\s\]]+)\s*\[\1\]/gi,
            '$1'
        );

        // 3. Remove [email@example.com] if any
        text = text.replace(
            /\s*\[[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\]/g,
            ''
        );

        // 4. Normalize spaces
        return text.replace(/\s+/g, ' ').trim();
    }

    public static escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // escape regex chars
    }
}


