import * as mongoose from "mongoose";
import { schedule } from "node-cron";

import { DbSeeder } from "./db-seeder";
import { App } from "./app";
import { Logger } from "./logger";
import { EmailService } from "./services/email.service";
import { BookingRemindersService } from "./services/boking-reminders.service";
import { WhatsAppRemindersService } from "./services/whatsapp-booking-reminders.service";
import { RenewWebHookService } from "./services/scheduler.service";
import { CreditsScriptService } from "./credits.script";
import { StripeService } from "./services/stripe.service";
import { BookingsService } from "./services/bookings.service";
import { ScriptService } from "./scripts/migrate-user-script";
import { BookingWorker } from "./utils/booking.worker";
const isProd = process.env.NODE_ENV.toLowerCase() == "production";

abstract class Server {
  private static port: number = 5320;

  public static async run(): Promise<void> {
    Logger.initializeLogger();

    try {
      await Server.dbConnect();
      // Start queue worker
    } catch (err) {
      Logger.logger.error(
        `Could not connect to: ${process.env.MONGO_URL}`,
        err.message
      );
      process.exit(1);
    }

    try {
      await DbSeeder.seedDatabase();
    } catch (err) {
      Logger.logger.error("Failed to seed the database", err);
    }

    await Server.startApplication();
    // one time script
    // CreditsScriptService.runOnTimeScript();
    await BookingWorker.start();
    if (isProd) {
      schedule('0 23 * * *', () => {
        console.log('This task runs every day at 11 PM UTC');
        RenewWebHookService.renewCalendarWebhook();

      }, {
        timezone: 'Etc/UTC' // Set the timezone to UTC
      });

      /**  update annual user credits every month*/
      schedule('0 0 * * *', () => {
        console.log('This task runs every day at 12 AM UTC');
        CreditsScriptService.annualUsersCreditsScript();  //scheduler for pro user every month credites
      }, {
        timezone: 'Etc/UTC' // Set the timezone to UTC
      });

      /**  update pending to cancel after booking time passed */
      schedule('0 1 * * *', () => {
        console.log('This task runs every day at 01 AM UTC');
        BookingsService.cancelPendingbookingAfterTime();
      }, {
        timezone: 'Etc/UTC' // Set the timezone to UTC
      });

      schedule('0 5 * * *', () => {
        console.log('This task runs every day at 02 AM Chile local time (05 AM UTC)');
        RenewWebHookService.getNextCalendarEvents();
      }, {
        timezone: 'Etc/UTC' // ✅ Keep timezone in UTC
      });

      schedule("*/20 * * * *", async () => {
        BookingRemindersService.sendReminders();
      });

      schedule("*/8 * * * *", async () => {
        WhatsAppRemindersService.sendWhatsAppReminders();
      });

      schedule("*/5 * * * *", async () => {
        BookingsService.cancelPendingBookingPaymentAfter15Mins();
      });
    } else {
      // if need test test server
      // schedule("*/5 * * * *", async () => {
      //   BookingsService.cancelPendingBookingPaymentAfter15Mins();
      // });
      // schedule("*/20 * * * *", async () => {
      //   BookingRemindersService.sendReminders();
      // });
    }
  }

  private static async dbConnect(): Promise<mongoose.Mongoose> {
    const runningInDevelopment = process.env.NODE_ENV === "development";
    const connectionScheme = runningInDevelopment ? "mongodb" : "mongodb+srv";

    return await mongoose.connect(
      `${connectionScheme}://rezrvapp-api:${process.env.MONGO_PASSWORD}@${process.env.MONGO_URL}/rezrvapp`,
      {
        connectTimeoutMS: 5000,
        authSource: runningInDevelopment ? null : "admin",
        replicaSet: runningInDevelopment ? null : process.env.MONGO_REPL_SET,
        tls: runningInDevelopment ? false : true,
      }
    );
  }

  private static async startApplication(): Promise<void> {
    App.createApp().listen(Server.port, () => Server.onServerListen());
  }

  private static onServerListen(): void {
    Logger.logger.info(`Express server listening on port ${Server.port}`);
  }
}

(async () => {
  await Server.run();
})();
