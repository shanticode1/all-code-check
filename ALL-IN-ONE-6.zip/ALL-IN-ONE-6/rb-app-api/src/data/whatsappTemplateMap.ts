
export const whatsappTemplateMap = {
    // prod: "reminder", //old name
    prod: "reminder_v2",
    test: "reminder_test_no_button", //reminder_test_pay_button
    test_meet: "reminder_location_meet"
}

export const whatsAppCreditsMap = {
    BASIC: 0,
    PLUS: 50,
    PRO: 100,
    TRIAL_PLUS: 5,
    TRIAL_PRO: 5, //update 1 july
    WHATSAPP_BAGS_CREDITS: 50
}
export const staffCount = {
    pro_count: 4,
    basic_count: 1,
}