
export const StripeConnectedType = {
    EXPRESS: 'express',
    STANDARD: 'standard',
    CUSTOM: 'custom',
}
export const zeroDecimalCurrencies = ["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"];
