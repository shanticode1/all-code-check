export const whatsAppProductToPriceMap = {
    prod: {
        WHATSAPP_BAGS_BASIC: 'price_1P6hBvB070pPqlXTaaDmrAhF',  //paymenttype=One-time
        WHATSAPP_BAGS_PLUS: 'price_1P8RxVB070pPqlXTdv60Cydt',  //paymenttype=One-time
        WHATSAPP_BAGS_PRO: 'price_1P8S6bB070pPqlXTzydj9ed2',    //paymenttype=One-time

        WHATSAPP_PAY_AS_YOU_GO_PLUS: 'price_1P8SIhB070pPqlXTiVlMSTB6',   //payment type=Usage-based
        WHATSAPP_PAY_AS_YOU_GO_PRO: 'price_1P70qjB070pPqlXT3b9QvZi1',    //payment type=Usage-based

        WHATS_APP_PLUS_MONTHLY: "price_1P6xLfB070pPqlXTLF8lvseU",   //paymenttype=Subscriptions
        WHATS_APP_PLUS_ANNUAL: "price_1P6xLfB070pPqlXTneqUOsBq",    //paymenttype=Subscriptions
        WHATS_APP_PRO_MONTHLY: "price_1P6yOtB070pPqlXTnEhoO9AR",    //paymenttype=Subscriptions
        WHATS_APP_PRO_ANNUAL: "price_1P70nnB070pPqlXToWGApjNl",     //paymenttype=Subscriptions
        PRODUCTS: [
            "prod_Pwr3tWioF4eIqO",   //plus
            "prod_Pws9PxtPpNXKbg",   //pro
            "prod_PwaMldyaUOjEOF",   //bag basic
            "prod_PyOl1wv21DxVok",   //bag plus
            "prod_PyOuFl473eBgTX",   //bag pro
            "prod_PyP6oSp6iWc6Jt",   //PAYO plus
            "prod_PwugQ3VZPsBAnE",   //PAYO pro

        ],
        PLUS: [
            "price_1P6xLfB070pPqlXTLF8lvseU",
            "price_1P6xLfB070pPqlXTneqUOsBq",
        ],
        PRO: [
            "price_1P6yOtB070pPqlXTnEhoO9AR",
            "price_1P70nnB070pPqlXToWGApjNl",
        ]

    },
    test: {
        WHATSAPP_BAGS_BASIC: 'price_1P6hBvB070pPqlXTaaDmrAhF',  //paymenttype=One-time
        WHATSAPP_BAGS_PLUS: 'price_1P8RxVB070pPqlXTdv60Cydt',  //paymenttype=One-time
        WHATSAPP_BAGS_PRO: 'price_1P8S6bB070pPqlXTzydj9ed2',    //paymenttype=One-time

        WHATSAPP_PAY_AS_YOU_GO_PLUS: 'price_1P8SIhB070pPqlXTiVlMSTB6',   //payment type=Usage-based
        WHATSAPP_PAY_AS_YOU_GO_PRO: 'price_1P70qjB070pPqlXT3b9QvZi1',    //payment type=Usage-based

        WHATS_APP_PLUS_MONTHLY: "price_1P6xLfB070pPqlXTLF8lvseU",   //paymenttype=Subscriptions
        WHATS_APP_PLUS_ANNUAL: "price_1P6xLfB070pPqlXTneqUOsBq",    //paymenttype=Subscriptions
        WHATS_APP_PRO_MONTHLY: "price_1P6yOtB070pPqlXTnEhoO9AR",    //paymenttype=Subscriptions
        WHATS_APP_PRO_ANNUAL: "price_1P70nnB070pPqlXToWGApjNl",     //paymenttype=Subscriptions
        PRODUCTS: [
            "prod_Pwr3tWioF4eIqO",   //plus
            "prod_Pws9PxtPpNXKbg",   //pro
            "prod_PwaMldyaUOjEOF",   //bag basic
            "prod_PyOl1wv21DxVok",   //bag plus
            "prod_PyOuFl473eBgTX",   //bag pro
            "prod_PyP6oSp6iWc6Jt",   //PAYO plus
            "prod_PwugQ3VZPsBAnE",   //PAYO pro

        ],
        PLUS: [
            "price_1P6xLfB070pPqlXTLF8lvseU",
            "price_1P6xLfB070pPqlXTneqUOsBq",
        ],
        PRO: [
            "price_1P6yOtB070pPqlXTnEhoO9AR",
            "price_1P70nnB070pPqlXToWGApjNl",
        ],
        ONE_TIME: [
            'price_1P6hBvB070pPqlXTaaDmrAhF',
            'price_1P8RxVB070pPqlXTdv60Cydt',
            'price_1P8S6bB070pPqlXTzydj9ed2',
        ]

    }
};

// DOP
export const stripeCurrencies = ["ARS", "CLP", "COP", "CRC", "DOP", "MXN", "PEN", "PYG", "UYU","BRL","EUR",'USD'];

export const defaultCurrency='US';

export const planType = {
    USAGE: 'recurring',
    ONE_TIME: 'one_time',
    METERED: 'metered',
    LICENSED: 'licensed'
}