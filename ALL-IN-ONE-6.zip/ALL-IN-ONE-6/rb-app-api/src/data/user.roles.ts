export const roles = {
    admin: 1,
    Business: 2,
    staff: 3,
    Client:4
};

export const roleNames = {
    1: 'admin',
    2: 'Business',
    3: 'staff',
    4:'Client'
};