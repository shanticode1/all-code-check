export class TimeZone {

	constructor(
			public id: string,
			public name: string,
			public displayName: string,
			public isBusinessDefault: boolean) {}
}