export class BusinessServicePayment {

    constructor(
        public isPaymentAllow: boolean,
        public paymentType: number[],
        public isPaymentLinkSend: boolean,
        public isCurrency?: boolean,
        public isPercentage?: boolean) { }
}