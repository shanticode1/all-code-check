import { StaffHoursBlock } from "./staff-hours-block"

export class BusinessStaffSnapshot {

	constructor(
		public id: string,
		public businessId: string,
		public servicesId: [],
		public name: string,
		public isOperatingNonStop: boolean,
		public staffHoursBlocks: StaffHoursBlock[],
		public isActive: boolean,
		public isDeleted: boolean,
	    public email?:string
	) {}
}