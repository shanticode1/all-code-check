import { StaffHoursBlock } from "./staff-hours-block";
import { DayOfTheWeek } from "./enums/day-of-the-week.enum";
import { GoogleToken } from "./googleToken";
import { GoogleCalendar } from "./google-calendar";
import { BusinessService } from "./business-service";
import { Business } from "./business";
import { User } from "./user";
import { TimeZone } from "./time-zone";

export class Staff {
  constructor(
    public id: string,
    public businessId: string,
    public servicesId: [],
    public name: string,
    public email: string,
    public password: string,
    public userId: string,
    public isOperatingNonStop: boolean,
    public staffHoursBlocks: StaffHoursBlock[],
    public isActive: boolean,
    public isDeleted: boolean,
    public logo: any,
    public googleToken: GoogleToken,
    public googleCalendar: GoogleCalendar[],
    public gmail: string,
    public isConflict: boolean,
    public gPicture: string,
    public gName: string,
    public gEventWatchId: string,
    public gResourceId: string,
    public syncEventToken: string,
    public watchEventExpiry: string,
    public isActiveByBusiness: boolean,
    public services: BusinessService[],
    public business?: Business,
    public isAllow?: boolean,
    public user?: User,
    public timeZone?: TimeZone,
    public notificationEnabled?: boolean,

  ) { }

  public orderStaffHoursBlocks(): void {
    if (this.staffHoursBlocks?.length > 1) {
      this.staffHoursBlocks.sort((a: StaffHoursBlock, b: StaffHoursBlock) => {
        if (a.startDayOfTheWeek == DayOfTheWeek.Sunday) {
          return 1;
        }
        if (b.startDayOfTheWeek == DayOfTheWeek.Sunday) {
          return -1;
        }
        return a.startDayOfTheWeek - b.startDayOfTheWeek;
      });
    }
  }
}

