export class BusinessSocialMedias {

	constructor(
			public ig: string,
			public fb: string,
			public wa: string,
			public countryCode: string
		) {}
}