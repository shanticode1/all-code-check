import { Business } from "./business"
import { BusinessService } from "./business-service"
import { BusinessServiceSnapshot } from "./business-service-snapshot"
import { Customer } from "./customer"
import { BookingPaymentStatus, BookingStatus } from "./enums/booking.status"
import { Staff } from "./staff"

export class Booking {
	constructor(
		public id: string,
		public business: Business,
		public service: BusinessService,
		public friendlyId: string,
		public startDate: Date,
		public endDate: Date,
		public clientId: string,
		public customer: Customer,
		public notes: string,
		public staffId: string,
		public status: BookingStatus,
		public serviceSnapshot: BusinessServiceSnapshot,
		public staffSnapshot: Staff,
		public eventType: string,
		public googleEventId: string,
		public calendarId: string,
		public title: string,
		public creator: string,
		public googleMeetLink: string,
		public businessIdForGoogle?: string,
		public staffIdForGoogle?: string,
		public paymentUrl?: string,
		public chargeImmediately?: boolean,
		public paymentStatus?: string,
		public isDepositPaid?: boolean,
		public isRemainingPaid?: boolean,
		public isFullPaid?: boolean,
		public link?: string,
		public isNoRequired?: boolean,
		public billingStatus?: BookingPaymentStatus,
		public promoCode?: string,
		public isPaidByMembership?: boolean,
		public membershipId?: string,
		public membershipSnapshotId?:string
	) { }
}

export class GoogleEventType {

	constructor(
		public title: string,
		public googleMeetLink: string,
		public creator: string,
		public organizer: string,
		public attendees: string
	) { }
}