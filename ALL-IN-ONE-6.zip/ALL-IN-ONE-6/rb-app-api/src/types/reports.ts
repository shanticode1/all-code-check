export class ReportsRequest {
  constructor(
    public toDate: Date | string,
    public fromDate: Date | string,
    public serviceId: string,
    public staffId: string
  ) {}
}

export class ReportsResponse {
  constructor(
    public total_booking: number,
    public total_revanue: string,
    public top_service: object,
    public no_of_reservation_staff: object,
    public chartData: Array<any>,
    public currency: number
  ) {}
}
