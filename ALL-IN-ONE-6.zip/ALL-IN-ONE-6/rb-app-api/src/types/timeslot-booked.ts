import { BookingStatus } from "./enums/booking.status";
import { Timeslot } from "./timeslots";

export class TimeslotBooked {
  constructor(
    public startDate: Date,
    public endDate: Date,
    public staffId: string,
    public startHour: number,
    public endHour: number,
    public serviceId: string,
    public eventType: string,
    public calendarId: string,
    public status: BookingStatus,
    // public timeZone?: string,

  ) { }
}
