import { MembershipServiceSnapshot } from "./service-membership-snapshot";

export class ClientMembership {
    constructor(
        public id: string,
        public businessId: string,
        public clientId: string,
        public membershipId: string,
        public membershipUnits: number,
        public paymentStatus: string,
        public checkoutInitiatedAt: Date,
        public isActive: boolean,
        public isDeleted: boolean,
        public membershipSnapshot: MembershipServiceSnapshot,
        public createdAt?: Date,
        public updatedAt?: Date,
        public purchaseDate?: Date,
        public bookingCapacity?: number,
        public userId?: string,

    ) { }
}
