export class BusinessDateOverrides {

	constructor(
        public businessId: string,
        public blockoutDates: string[]
    ) {}

}