export class GoogleToken {
    constructor(
        public access_token: string,
        public refresh_token: string,
        public scope: string,
        public token_type: string,
        public id_token: string,
        public expiry_date: number,
        // public syncEventToken:string
    ) { }
}




