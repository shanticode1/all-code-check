export class Address {
	constructor(
		public address: string,
		public suite: string,
		public district: string,
		public city: string,
		public region: string,
		public postcode: string,
		public country: string,
		public countryShortName: string,
		public coordinates?: {
			latitude: number;
			longitude: number;
		}
	) { }
}
