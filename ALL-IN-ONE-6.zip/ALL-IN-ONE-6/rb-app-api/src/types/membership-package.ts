import * as crypto from "crypto";

export class MembershipPackage {

	constructor(
		public serviceId: string,
		public bookingQuantity: number,) { }
}

export class MembershipService {

	constructor(
		public id: string,
		public businessId: string,
		public name: string,
		public description: string,
		public membershipHash: string,
		public packageSetting: MembershipPackage[],
		public price: number,
		public isDeleted?: boolean,
		public isActive?: boolean,
		public logo?: string,
		public currency?: number,
		public type?: string
	) { }

	   public calculateMembershipHash(): void {
		  this.membershipHash = crypto
			.createHash("shake256", { outputLength: 11 })
			.update(
			  this.name +
			  this.description +
			  this.price +
			  this.currency +
			  this.type 
			)
			.digest("hex");
		}
}

