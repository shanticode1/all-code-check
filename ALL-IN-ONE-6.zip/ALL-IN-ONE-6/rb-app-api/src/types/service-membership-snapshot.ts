import { IMembershipPackage } from "../db-models/membership-setting.db-model";

export class MembershipServiceSnapshot {
    constructor(
        public id: string,
        public membershipName: string,
        public membershipDescription: string,
        public membershipHash: string,
        public membershipPackageSetting: IMembershipPackage[],
        public membershipPrice: number,
        public membershipCurrency: number,
        public isDeleted?: boolean,
        public isActive?: boolean,
        public membershipLogo?: string,
        public membershipType?: string
    ) { }
}