export class GoogleCalendar {
    constructor(
        public calendarId: string,
        public status: string,
        public name: string,
        public isProcessing: boolean,
        public lastLoggedInTime: Date
    ) { }
}