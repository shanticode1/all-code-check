import { EventType, RecurrenceType } from "./enums/event-type.enum";

export class BusinessServiceEventSetting {
    constructor(
        public eventType: string,
        public startDate: Date,
        public startTime: string,
        public endDate: Date,
        public endTime: string,
        public staffs: string[],
        public isStaffConflict?: boolean,
        public isBusinessConflict?: boolean,
        public recurrenceType?: string,
        public isNoConflict?:boolean,
        public customSetting?: any
    ) { }
}
