import { Address } from "./address"
import { BusinessServiceEventSetting } from "./business-service-event-setting"
import { BusinessServicePayment } from "./business-service-payment"
import { Currency } from "./enums/currency"
import { DurationUnit } from "./enums/duration-unit.enum"

export class BusinessServiceSnapshot {

	constructor(
		public id: string,
		public serviceHash: string,
		public serviceName: string,
		public serviceDescription: string,
		public serviceDuration: number,
		public serviceDurationUnit: DurationUnit,
		public servicePrice: number,
		public serviceCurrency: Currency,
		// public groupMeetLink:string
		public paymentSetting: BusinessServicePayment,
		public depositAmount: number,
		public eventSetting?: BusinessServiceEventSetting,
		// public isCapacityVisible?: boolean,
		public serviceAddress?: Address,
		public type?: string,
		public cutOff?: number,
		public cutOffUnit?: DurationUnit
	) { }
}