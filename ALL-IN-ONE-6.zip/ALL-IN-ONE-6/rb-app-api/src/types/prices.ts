export class Prices {
	constructor(
		public oneTimePriceId: string,
		public recurringPriceId: string,
		public usagePriceId: string,
		public staffUsagePriceId: string
	) { }
}
