export class Customer {
	constructor(
		public name: string,
		public surname: string,
		public email: string,
		public phoneNumber: string,
		public countryCode: string,
		public isWhatsAppAllow: boolean,
		public isEmailAllow:boolean
	) { }
}