export class Payment {
    constructor(
        public customerId: string,
        public priceId: string,
    ) { }
}

export class MembershipType {
    constructor(
        public membershipId: string,
        public quantity: number,
    ) { }
}