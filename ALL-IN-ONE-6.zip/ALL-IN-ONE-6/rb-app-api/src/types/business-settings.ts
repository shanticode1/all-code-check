import { ICapactiySetting, IReminderSetting } from "../db-models/business-setting.db-model";
import { PaymentType } from "./enums/payment-type.enum";

export class BusinessSettings {
  constructor(
    public bookingAutoapprove: boolean,
    public hideAddress: boolean,
    public paymentTypes: PaymentType[],
    public manualPaymentInfo: string,
    public isWhatsAppReminder: boolean,
    public isEmailReminder: boolean,
    public whatsAppReminderInfo: string,
    public emailInfo: string,
    public emailReminderDuration: IReminderSetting,
    public whatsappReminderDuration: IReminderSetting,
    public cancelationPolicyInfo: string,
    public serviceCapacityVisibility: ICapactiySetting
  ) { }
}

export class ReminderSetting {
  constructor(
    public duration: number,
    public durationUnit: number,
  ) { }
}
