export class BusinessNotes {
  constructor(
    public email:String,
    public notes:String
    ) {}
}
