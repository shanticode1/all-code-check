import { Timeslot } from "./timeslots";

export interface BusinessAvailability {
    unavailableDates: string[];
    availableDates: AvailableDate[];
}

export interface AvailableDate {
    date: string,
    timeSlots: Timeslot[];
}