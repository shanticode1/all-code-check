import { Address } from "./address"
import { BusinessHoursBlock } from "./business-hours-block"
import { BusinessService } from "./business-service"
import { BusinessType } from "./business-type"
import { Coordinates } from "./coordinates"
import { Currency } from "./enums/currency"
import { DayOfTheWeek } from "./enums/day-of-the-week.enum"
import { ServiceCategory } from "./service-category"
import { BusinessSettings } from "./business-settings"
import { TimeZone } from "./time-zone"
import { BusinessNotes } from "./business-notes"
import { BusinessSocialMedias } from "./business-social-medias"
import { MembershipTier } from "./enums/membership-tier.enum"
import { ModalTypeEnum } from "./enums/ModalType.enum"
import { GoogleToken } from "./googleToken"
import { GoogleCalendar } from "./google-calendar"
import { Prices } from "./prices"
import { User } from "./user"
import { PaymentStatus } from "./enums/payment.status"
import { IMarketPlaceImanges } from "../db-models/business.db-model"
import { MembershipPackage, MembershipService } from "./membership-package"
export class Business {
	constructor(
		public id: string,
		public userId: string,
		public contactName: string,
		public name: string,
		public slug: string,
		public phoneNumber: string,
		public countryCode: string,
		public address: Address,
		public coordinates: Coordinates,
		public email: string,
		public password: string,
		public type: BusinessType,
		public timeZone: TimeZone,
		public currency: Currency,
		public isOperatingNonStop: boolean,
		public businessHoursBlocks: BusinessHoursBlock[],
		public blockoutDates: string[],
		public about: string,
		public services: BusinessService[],
		public serviceCategories: ServiceCategory[],
		public settings: BusinessSettings,
		public socialMedia: BusinessSocialMedias,
		public isActive: boolean,
		public isDeleted: boolean,
		public membershipTier: MembershipTier,
		public createdAt: Date,
		public membershipExpirationDate: Date,
		public staffMembershipExpirationDate: Date,
		public modalType: ModalTypeEnum,
		public lastLoginDate: Date,
		public isAccountActivated: boolean,
		public stripeCustomerId: string,
		public stripeOnTrial: boolean,
		public frillToken: string,
		public referral: string,
		public heroImage: string,
		public bannerImage: string,
		public lastCompletedOnboardingStep: number,
		public googleToken: GoogleToken,
		public googleCalendar: GoogleCalendar[],
		public gmail: string,
		public isConflict: boolean,
		public gPicture: string,
		public gName: string,
		public isTrialActivatedOnce: boolean,
		public isTrialOnce: number,
		public gEventWatchId: string,
		public gResourceId: string,
		public syncEventToken: string,
		public whatsAppCredits: number,
		public watchEventExpiry: number,
		public whatsAppMembershipTier: number,
		public stripePayAsYouGoOnTrial: boolean,
		public stripePriceIds: Prices,
		// public isFileDeleted:boolean
		public whatsAppBagsCredits?: number,
		public whatsAppPayAsYouGoCredits?: number,
		public usageCount?: number,
		public whatsappBagsQuantity?: number,
		public isPaymentDue?: boolean,
		public whatsAppPayAsYouGoMembershipTier?: number,
		public user?: User,
		public membershipStaffCount?: number,
		public buyExtraStaffCount?: number,
		public isStaffPaymentPaid?: boolean,
		public isAnnualActive?: boolean,
		public stripeConnectAccountId?: string,
		public isConnectedAccDetailSubmitted?: boolean,
		public isPaymentMethodConnected?: boolean,
		public planBillingStatus?: PaymentStatus,
		public paymentRetryCount?: number,
		public isAccessPaused?: boolean,
		public marketPlaceImages?: IMarketPlaceImanges[],
		public isPublishedOnMarketplace?: boolean,
		public fileIds?: string[],
		public packages?: MembershipService[]
	) { }

	public removePassword(): void {
		delete this.password
	}

	public orderBusinessHoursBlocks(): void {
		if (this.businessHoursBlocks?.length > 1) {
			this.businessHoursBlocks.sort((a: BusinessHoursBlock, b: BusinessHoursBlock) => {
				if (a.startDayOfTheWeek == DayOfTheWeek.Sunday) {
					return 1
				}
				if (b.startDayOfTheWeek == DayOfTheWeek.Sunday) {
					return -1
				}
				return a.startDayOfTheWeek - b.startDayOfTheWeek
			})
		}
	}
}

export class BusinessPagination {

	constructor(
		public totalCount: number,
		public businesses: any[]) { }
}