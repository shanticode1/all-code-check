export enum MembershipTier {
	Free,
    Plus,
    Pro
}


export enum WhatsAppMembershipTier {
	Free,
    Plus,
    Pro
}