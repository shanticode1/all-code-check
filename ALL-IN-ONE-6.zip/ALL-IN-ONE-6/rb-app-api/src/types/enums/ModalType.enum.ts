export enum ModalTypeEnum {
    TrialEnded,
    TrialEnding
}


export enum trialEnum {
    oldUser,
    isTrial,
    notTrial,
    signUp
}