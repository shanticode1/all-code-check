export enum BookingStatus {
	Pending,
	Approved,
	Rejected,
	Cancelled,
	GoogleEvent,
	All
}

export enum BookingPaymentStatus {
	Pagado,
	ParcialmentePagado,
	Deposito,
	NoPagado,
	PagoPendiente,
	Reembolsado,
	ReembolsoParcial,
	Devolucion,
	ExentoDePago,
	PagoFallido,
	SinCosto
}