export enum BookingReminderType {
	Email,
	WhatsApp
}

export const whatsAppPhoneListForTest = {
	NUMBERS: [
		"7693868590",  //+91
		"9421554013",  //+91
		"941876777",  //+56
		"7023460747"  //+91
	],
	EMAILS:[
		"hello@rezrva.com",
		"reservations@rezrva.com",
	]
}
