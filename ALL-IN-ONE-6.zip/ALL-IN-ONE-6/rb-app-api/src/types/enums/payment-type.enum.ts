export enum PaymentType {
    Manual,
    Paypal,
    Stripe
}

export enum ServicePaymentType {
    FullPayment,
    Deposit,
    NoPayment
}