export enum EventType {
    DoesNotRepeat = "doesNotRepeat",
    Daily = "daily",
    Weekly = "weekly",
    Monthly = "monthly",
    Custom = "custom"
}

export enum RecurrenceType {
    OneTime = "oneTime",
    Repeated = "repeated",
}