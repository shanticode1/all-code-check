export enum ServiceType {
	One,
	Group,
	Event,
}
