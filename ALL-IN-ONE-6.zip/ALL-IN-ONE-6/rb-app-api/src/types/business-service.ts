import * as crypto from "crypto";

import { BookingReminder } from "./booking-reminder";
import { Currency } from "./enums/currency";
import { DurationUnit } from "./enums/duration-unit.enum";
import { ServiceCategory } from "./service-category";
import { ServiceDaysBlock } from "./business-hours-block";
import { ServicePaymentType } from "./enums/payment-type.enum";
import { BusinessServicePayment } from "./business-service-payment";
import { BusinessServiceEventSetting } from "./business-service-event-setting";
import { Address } from "./address";

export class BusinessService {
  constructor(
    public id: string,
    public name: string,
    public description: string,
    public category: ServiceCategory,
    public duration: number,
    public durationUnit: DurationUnit,
    public price: number,
    public currency: Currency,
    public type: string,
    public capacity: number,
    public hash: string,
    public bookingReminders: BookingReminder[],
    public isActive: boolean,
    public isDeleted: boolean,
    public location: string,
    // public groupMeetLink: string,
    // public meetEventId:string
    public serviceDaysBlocks?: ServiceDaysBlock[],
    public paymentSetting?: BusinessServicePayment,
    public depositAmount?: number,
    public eventSetting?: BusinessServiceEventSetting,
    // public isCapacityVisible?: boolean,
    public serviceAddress?: Address,
    public cutOff?: number,
    public cutOffUnit?: DurationUnit,
    public logo?: string,
    public isInActiveByPlan?: boolean
  ) { }

  public calculateHash(): void {
    this.hash = crypto
      .createHash("shake256", { outputLength: 11 })
      .update(
        this.name +
        this.description +
        this.duration +
        this.durationUnit +
        this.price +
        this.currency +
        this.type +
        this.capacity
      )
      .digest("hex");
  }

  public static async calculateHashV2(s) {
    return crypto
      .createHash("shake256", { outputLength: 11 })
      .update(
        s.name +
        s.description +
        s.duration +
        s.durationUnit +
        s.price +
        s.currency +
        s.type +
        s.capacity
      )
      .digest("hex");
  }
}
