export class CurrencyRate {
    constructor(
        public id: string,
        public country: string,
        public currencyCode: string,
        public appMinCurrency: number,
        public isActive?: boolean,
        public isDeleted?: boolean,
    ) { }
}

