export class User {
    constructor(
        public id: string,
        public email: string,
        public password: string,
        public userName: string,
        public role: number,
        public isActive: boolean,
        public isDeleted: boolean,
        public activationToken: any,
        public createdAt?: Date,
        public updatedAt?: Date,
        public contactName?:string,
    ) {  }
}