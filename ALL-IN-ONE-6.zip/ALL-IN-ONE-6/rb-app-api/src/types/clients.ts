import { Address } from "./address";
import { TimeZone } from "./time-zone";

export class Client {
	constructor(
		public id: string,
		public businessId: string,
		public email: string,
		public name: string,
		public surname: string,
		public phone: string,
		public countryCode: string,
		public lastBookingDate: Date,
		public notes: string,
		public isWhatsAppAllow: boolean,
		public isEmailAllow: boolean,
		public bookings?: any[],
		public password?: string,
		public userId?: string,
		public timeZone?: TimeZone,
		public address?:Address
	) { }
}

