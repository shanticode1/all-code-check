export class Timeslot {
    constructor(
        public startDateTime: Date,
        public endDateTime: Date,
        public display: string
    ) {}
}
  