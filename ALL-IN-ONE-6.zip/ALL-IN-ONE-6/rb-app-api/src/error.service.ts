import { LogDbModel } from "./db-models/error.log.db.model";

export abstract class ErrorService {

    public static async saveErrors(payload, level) {
        const runningInProduction = process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'development' || process.env.NODE_ENV === 'test';
        if (runningInProduction) {
            const logEntry = {
                type: level,
                message: payload,
            }
            await LogDbModel.ErrorModel.create(logEntry);
        }
    }
}