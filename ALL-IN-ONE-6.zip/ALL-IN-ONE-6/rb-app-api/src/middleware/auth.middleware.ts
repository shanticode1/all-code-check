import { AuthenticationService } from "../services/authentication.service"

export abstract class AuthMiddleware {

	public static getAuthFunction(errorWhenAuthenticationFails: boolean = true) {

		return async (req, res, next) => {
			const authHeader = req.headers.authorization
			const token = authHeader?.split(' ')[1]
			if (token == null || token == "") {
				if (errorWhenAuthenticationFails) {
					res.status(401).send()
					return
				}
				next()
				return
			}
			try {
				res.locals = await AuthenticationService.getUserIdFromToken(token);
				res.locals.userId = res.locals.sub;
			} catch (err) {
				if (errorWhenAuthenticationFails) {
					res.status(401).send()
					return
				}
			}
			next()
		}
	}

	public static userRole(roles) {
		return (req, res, next) => {
			if (!roles.includes(res.locals.role)) {
				return res.status(403).json({ message: 'Access denied' });
			}
			next();
		};
	}
	public static userRoleV2(roles) {
		return (req, res, next) => {
			if (!roles.includes(res.locals.role)) {
				return res.status(410).json({ isRole: false });
			}
			next();
		};
	}
}