import * as bcrypt from "bcrypt";

import { BusinessTypeDbModel } from "./db-models/business-type.db-model";
import { BusinessDbModel } from "./db-models/business.db-model";
import { Logger } from "./logger";
import { BusinessType } from "./types/business-type";
import { Business } from "./types/business";
import { Address } from "./types/address";
import { BusinessSettings } from "./types/business-settings";
import { TimeZone } from "./types/time-zone";
import { BusinessHoursBlock } from "./types/business-hours-block";
import { Currency } from "./types/enums/currency";
import { ITimeZone, TimeZoneDbModel } from "./db-models/time-zone.db-model";

export abstract class DbSeeder {
  public static businessDefaultTimeZoneDoc: ITimeZone;

  public static async seedDatabase() {
    await DbSeeder.seedBusinessTypes();
    await DbSeeder.seedTimeZones();
    await DbSeeder.seedTestBusinesses();
  }

  private static async seedBusinessTypes(): Promise<void> {
    if (
      (await BusinessTypeDbModel.BusinessTypeModel.countDocuments().exec()) > 0
    ) {
      return;
    }

    const businessTypeDocs = this.getBusinessTypes().map((bt) =>
      BusinessTypeDbModel.convertToDbModel(bt)
    );

    await BusinessTypeDbModel.BusinessTypeModel.insertMany(businessTypeDocs);
  }

  private static async seedTimeZones(): Promise<void> {
    if ((await TimeZoneDbModel.TimeZoneModel.countDocuments().exec()) > 0) {
      DbSeeder.businessDefaultTimeZoneDoc =
        await TimeZoneDbModel.TimeZoneModel.findOne({
          isBusinessDefault: true,
        }).exec();
      return;
    }

    const timeZoneDocs = this.getTimeZones().map((tz) =>
      TimeZoneDbModel.convertToDbModel(tz)
    );

    if (timeZoneDocs.filter((tz) => tz.isBusinessDefault == true).length > 1) {
      Logger.logger.warn(
        "There are more than 1 time zones with isBusinessDefault flag"
      );
    }

    await TimeZoneDbModel.TimeZoneModel.insertMany(timeZoneDocs);
    DbSeeder.businessDefaultTimeZoneDoc = timeZoneDocs.find(
      (tz) => tz.isBusinessDefault == true
    );
  }

  private static async seedTestBusinesses(): Promise<void> {
    if (
      DbSeeder.businessDefaultTimeZoneDoc == null ||
      (await BusinessDbModel.BusinessModel.countDocuments().exec()) > 0
    ) {
      return;
    }

    const businessDocs = (await this.getTestBusinesses()).map((b) =>
      BusinessDbModel.convertToDbModel(b)
    );

    await BusinessDbModel.BusinessModel.insertMany(businessDocs);
  }

  private static getBusinessTypes(): BusinessType[] {
    return [
      new BusinessType(null, "Estética & Belleza"),
      new BusinessType(null, "Fitness & Wellness"),
      new BusinessType(null, "Actividades & Tours"),
      new BusinessType(null, "Educación & Asesoría"),
      new BusinessType(null, "Transporte & Couriers"),
      new BusinessType(null, "Otro"),
    ];
  }

  private static getTimeZones(): TimeZone[] {
    return [
      new TimeZone(null, "Africa/Abidjan", "Africa/Abidjan", false),
      new TimeZone(null, "Africa/Algiers", "Africa/Algiers", false),
      new TimeZone(null, "Africa/Bissau", "Africa/Bissau", false),
      new TimeZone(null, "Africa/Cairo", "Africa/Cairo", false),
      new TimeZone(null, "Africa/Ceuta", "Africa/Ceuta", false),
      new TimeZone(null, "Africa/El_Aaiun", "Africa/El Aaiun", false),
      new TimeZone(null, "Africa/Johannesburg", "Africa/Johannesburg", false),
      new TimeZone(null, "Africa/Juba", "Africa/Juba", false),
      new TimeZone(null, "Africa/Khartoum", "Africa/Khartoum", false),
      new TimeZone(null, "Africa/Lagos", "Africa/Lagos", false),
      new TimeZone(null, "Africa/Maputo", "Africa/Maputo", false),
      new TimeZone(null, "Africa/Monrovia", "Africa/Monrovia", false),
      new TimeZone(null, "Africa/Nairobi", "Africa/Nairobi", false),
      new TimeZone(null, "Africa/Ndjamena", "Africa/Ndjamena", false),
      new TimeZone(null, "Africa/Sao_Tome", "Africa/Sao Tome", false),
      new TimeZone(null, "Africa/Tripoli", "Africa/Tripoli", false),
      new TimeZone(null, "Africa/Tunis", "Africa/Tunis", false),
      new TimeZone(null, "Africa/Windhoek", "Africa/Windhoek", false),
      new TimeZone(null, "America/Adak", "America/Adak", false),
      new TimeZone(null, "America/Anchorage", "America/Anchorage", false),
      new TimeZone(null, "America/Araguaina", "America/Araguaina", false),
      new TimeZone(null, "America/Asuncion", "America/Asuncion", false),
      new TimeZone(null, "America/Bahia", "America/Bahia", false),
      new TimeZone(
        null,
        "America/Bahia_Banderas",
        "America/Bahia Banderas",
        false
      ),
      new TimeZone(null, "America/Barbados", "America/Barbados", false),
      new TimeZone(null, "America/Belem", "America/Belem", false),
      new TimeZone(null, "America/Belize", "America/Belize", false),
      new TimeZone(
        null,
        "America/North_Dakota/Beulah",
        "America/Beulah",
        false
      ),
      new TimeZone(null, "America/Boa_Vista", "America/Boa Vista", false),
      new TimeZone(null, "America/Bogota", "America/Bogotá", false),
      new TimeZone(null, "America/Boise", "America/Boise", false),
      new TimeZone(
        null,
        "America/Argentina/Buenos_Aires",
        "America/Buenos Aires",
        false
      ),
      new TimeZone(
        null,
        "America/Cambridge_Bay",
        "America/Cambridge Bay",
        false
      ),
      new TimeZone(null, "America/Campo_Grande", "America/Campo Grande", false),
      new TimeZone(null, "America/Cancun", "America/Cancun", false),
      new TimeZone(null, "America/Caracas", "America/Caracas", false),
      new TimeZone(
        null,
        "America/Argentina/Catamarca",
        "America/Catamarca",
        false
      ),
      new TimeZone(null, "America/Cayenne", "America/Cayenne", false),
      new TimeZone(null, "America/Chicago", "America/Chicago", false),
      new TimeZone(null, "America/Chihuahua", "America/Chihuahua", false),
      new TimeZone(null, "America/Costa_Rica", "America/San José", false),
      new TimeZone(null, "America/Cuiaba", "America/Cuiaba", false),
      new TimeZone(
        null,
        "America/Mexico_City",
        "America/Cuidad de Mexico",
        false
      ),
      new TimeZone(null, "America/Danmarkshavn", "America/Danmarkshavn", false),
      new TimeZone(null, "America/Dawson", "America/Dawson", false),
      new TimeZone(null, "America/Dawson_Creek", "America/Dawson Creek", false),
      new TimeZone(null, "America/Denver", "America/Denver", false),
      new TimeZone(null, "America/Detroit", "America/Detroit", false),
      new TimeZone(null, "America/Edmonton", "America/Edmonton", false),
      new TimeZone(null, "America/Eirunepe", "America/Eirunepe", false),
      new TimeZone(null, "America/El_Salvador", "America/San Salvador", false),
      new TimeZone(null, "America/Fort_Nelson", "America/Fort Nelson", false),
      new TimeZone(null, "America/Fortaleza", "America/Fortaleza", false),
      new TimeZone(null, "America/Glace_Bay", "America/Glace Bay", false),
      new TimeZone(null, "America/Goose_Bay", "America/Goose Bay", false),
      new TimeZone(null, "America/Grand_Turk", "America/Grand Turk", false),
      new TimeZone(null, "America/Guatemala", "America/Guatemala", false),
      new TimeZone(null, "America/Guayaquil", "America/Guayaquil", false),
      new TimeZone(null, "America/Guyana", "America/Guyana", false),
      new TimeZone(null, "America/Halifax", "America/Halifax", false),
      new TimeZone(null, "America/Havana", "America/Havana", false),
      new TimeZone(null, "America/Hermosillo", "America/Hermosillo", false),
      new TimeZone(
        null,
        "America/Indiana/Indianapolis",
        "America/Indianapolis",
        false
      ),
      new TimeZone(null, "America/Inuvik", "America/Inuvik", false),
      new TimeZone(null, "America/Iqaluit", "America/Iqaluit", false),
      new TimeZone(null, "America/Jamaica", "America/Kingston", false),
      new TimeZone(null, "America/Argentina/Jujuy", "America/Jujuy", false),
      new TimeZone(null, "America/Juneau", "America/Juneau", false),
      new TimeZone(null, "America/Indiana/Knox", "America/Knox", false),
      new TimeZone(null, "America/La_Paz", "America/La Paz", false),
      new TimeZone(
        null,
        "America/Argentina/La_Rioja",
        "America/La Rioja",
        false
      ),
      new TimeZone(null, "America/Lima", "America/Lima", false),
      new TimeZone(null, "America/Los_Angeles", "America/Los Angeles", false),
      new TimeZone(
        null,
        "America/Kentucky/Louisville",
        "America/Louisville",
        false
      ),
      new TimeZone(null, "America/Maceio", "America/Maceio", false),
      new TimeZone(null, "America/Managua", "America/Managua", false),
      new TimeZone(null, "America/Manaus", "America/Manaus", false),
      new TimeZone(null, "America/Indiana/Marengo", "America/Marengo", false),
      new TimeZone(null, "America/Martinique", "America/Martinique", false),
      new TimeZone(null, "America/Matamoros", "America/Matamoros", false),
      new TimeZone(null, "America/Mazatlan", "America/Mazatlan", false),
      new TimeZone(null, "America/Argentina/Mendoza", "America/Mendoza", false),
      new TimeZone(null, "America/Menominee", "America/Menominee", false),
      new TimeZone(null, "America/Merida", "America/Merida", false),
      new TimeZone(null, "America/Metlakatla", "America/Metlakatla", false),
      new TimeZone(null, "America/Miquelon", "America/Miquelon", false),
      new TimeZone(null, "America/Moncton", "America/Moncton", false),
      new TimeZone(null, "America/Monterrey", "America/Monterrey", false),
      new TimeZone(null, "America/Montevideo", "America/Montevideo", false),
      new TimeZone(
        null,
        "America/Kentucky/Monticello",
        "America/Monticello",
        false
      ),
      new TimeZone(
        null,
        "America/North_Dakota/New_Salem",
        "America/New Salem",
        false
      ),
      new TimeZone(null, "America/New_York", "America/New York", false),
      new TimeZone(null, "America/Nipigon", "America/Nipigon", false),
      new TimeZone(null, "America/Nome", "America/Nome", false),
      new TimeZone(null, "America/Noronha", "America/Noronha", false),
      new TimeZone(null, "America/Nuuk", "America/Nuuk", false),
      new TimeZone(null, "America/Ojinaga", "America/Ojinaga", false),
      new TimeZone(null, "America/Panama", "America/Panama", false),
      new TimeZone(null, "America/Pangnirtung", "America/Pangnirtung", false),
      new TimeZone(null, "America/Paramaribo", "America/Paramaribo", false),
      new TimeZone(
        null,
        "America/Indiana/Petersburg",
        "America/Petersburg",
        false
      ),
      new TimeZone(null, "America/Phoenix", "America/Phoenix", false),
      new TimeZone(
        null,
        "America/Port-au-Prince",
        "America/Port au Prince",
        false
      ),
      new TimeZone(null, "America/Porto_Velho", "America/Porto Velho", false),
      new TimeZone(null, "America/Puerto_Rico", "America/Puerto Rico", false),
      new TimeZone(null, "America/Punta_Arenas", "America/Punta Arenas", false),
      new TimeZone(null, "America/Rainy_River", "America/Rainy River", false),
      new TimeZone(null, "America/Rankin_Inlet", "America/Rankin Inlet", false),
      new TimeZone(null, "America/Recife", "America/Recife", false),
      new TimeZone(null, "America/Regina", "America/Regina", false),
      new TimeZone(null, "America/Resolute", "America/Resolute", false),
      new TimeZone(null, "America/Rio_Branco", "America/Rio Branco", false),
      new TimeZone(
        null,
        "America/Argentina/Rio_Gallegos",
        "America/Rio Gallegos",
        false
      ),
      new TimeZone(null, "America/Argentina/Salta", "America/Salta", false),
      new TimeZone(
        null,
        "America/Argentina/San_Luis",
        "America/San Luis",
        false
      ),
      new TimeZone(
        null,
        "America/Argentina/San_Juan",
        "America/San_Juan",
        false
      ),
      new TimeZone(null, "America/Santarem", "America/Santarem", false),
      new TimeZone(null, "America/Santiago", "America/Santiago", true),
      new TimeZone(
        null,
        "America/Santo_Domingo",
        "America/Santo Domingo",
        false
      ),
      new TimeZone(null, "America/Sao_Paulo", "America/Sao Paulo", false),
      new TimeZone(null, "America/Scoresbysund", "America/Scoresbysund", false),
      new TimeZone(null, "America/Sitka", "America/Sitka", false),
      new TimeZone(null, "America/St_Johns", "America/St Johns", false),
      new TimeZone(
        null,
        "America/Swift_Current",
        "America/Swift Current",
        false
      ),
      new TimeZone(null, "America/Tegucigalpa", "America/Tegucigalpa", false),
      new TimeZone(
        null,
        "America/Indiana/Tell_City",
        "America/Tell City",
        false
      ),
      new TimeZone(null, "America/Thule", "America/Thule", false),
      new TimeZone(null, "America/Thunder_Bay", "America/Thunder Bay", false),
      new TimeZone(null, "America/Tijuana", "America/Tijuana", false),
      new TimeZone(null, "America/Toronto", "America/Toronto", false),
      new TimeZone(null, "America/Argentina/Tucuman", "America/Tucuman", false),
      new TimeZone(null, "America/Argentina/Ushuaia", "America/Ushuaia", false),
      new TimeZone(null, "America/Vancouver", "America/Vancouver", false),
      new TimeZone(null, "America/Indiana/Vevay", "America/Vevay", false),
      new TimeZone(
        null,
        "America/Indiana/Vincennes",
        "America/Vincennes",
        false
      ),
      new TimeZone(null, "America/Whitehorse", "America/Whitehorse", false),
      new TimeZone(null, "America/Indiana/Winamac", "America/Winamac", false),
      new TimeZone(null, "America/Winnipeg", "America/Winnipeg", false),
      new TimeZone(null, "America/Yakutat", "America/Yakutat", false),
      new TimeZone(null, "America/Yellowknife", "America/Yellowknife", false),
      new TimeZone(null, "Antarctica/Casey", "Antarctica/Casey", false),
      new TimeZone(null, "Antarctica/Davis", "Antarctica/Davis", false),
      new TimeZone(null, "Antarctica/Macquarie", "Antarctica/Macquarie", false),
      new TimeZone(null, "Antarctica/Mawson", "Antarctica/Mawson", false),
      new TimeZone(null, "Antarctica/Palmer", "Antarctica/Palmer", false),
      new TimeZone(null, "Antarctica/Rothera", "Antarctica/Rothera", false),
      new TimeZone(null, "Antarctica/Troll", "Antarctica/Troll", false),
      new TimeZone(null, "Antarctica/Vostok", "Antarctica/Vostok", false),
      new TimeZone(
        null,
        "America/Argentina/Cordoba",
        "Argentina/Cordoba",
        false
      ),
      new TimeZone(null, "Asia/Almaty", "Asia/Almaty", false),
      new TimeZone(null, "Asia/Amman", "Asia/Amman", false),
      new TimeZone(null, "Asia/Anadyr", "Asia/Anadyr", false),
      new TimeZone(null, "Asia/Aqtau", "Asia/Aqtau", false),
      new TimeZone(null, "Asia/Aqtobe", "Asia/Aqtobe", false),
      new TimeZone(null, "Asia/Ashgabat", "Asia/Ashgabat", false),
      new TimeZone(null, "Asia/Atyrau", "Asia/Atyrau", false),
      new TimeZone(null, "Asia/Baghdad", "Asia/Baghdad", false),
      new TimeZone(null, "Asia/Baku", "Asia/Baku", false),
      new TimeZone(null, "Asia/Bangkok", "Asia/Bangkok", false),
      new TimeZone(null, "Asia/Barnaul", "Asia/Barnaul", false),
      new TimeZone(null, "Asia/Beirut", "Asia/Beirut", false),
      new TimeZone(null, "Asia/Bishkek", "Asia/Bishkek", false),
      new TimeZone(null, "Asia/Brunei", "Asia/Brunei", false),
      new TimeZone(null, "Asia/Chita", "Asia/Chita", false),
      new TimeZone(null, "Asia/Choibalsan", "Asia/Choibalsan", false),
      new TimeZone(null, "Asia/Colombo", "Asia/Colombo", false),
      new TimeZone(null, "Asia/Damascus", "Asia/Damascus", false),
      new TimeZone(null, "Asia/Dhaka", "Asia/Dhaka", false),
      new TimeZone(null, "Asia/Dili", "Asia/Dili", false),
      new TimeZone(null, "Asia/Dubai", "Asia/Dubai", false),
      new TimeZone(null, "Asia/Dushanbe", "Asia/Dushanbe", false),
      new TimeZone(null, "Asia/Famagusta", "Asia/Famagusta", false),
      new TimeZone(null, "Asia/Gaza", "Asia/Gaza", false),
      new TimeZone(null, "Asia/Hebron", "Asia/Hebron", false),
      new TimeZone(null, "Asia/Ho_Chi_Minh", "Asia/Ho Chi Minh", false),
      new TimeZone(null, "Asia/Hong_Kong", "Asia/Hong Kong", false),
      new TimeZone(null, "Asia/Hovd", "Asia/Hovd", false),
      new TimeZone(null, "Asia/Irkutsk", "Asia/Irkutsk", false),
      new TimeZone(null, "Asia/Jakarta", "Asia/Jakarta", false),
      new TimeZone(null, "Asia/Jayapura", "Asia/Jayapura", false),
      new TimeZone(null, "Asia/Jerusalem", "Asia/Jerusalem", false),
      new TimeZone(null, "Asia/Kabul", "Asia/Kabul", false),
      new TimeZone(null, "Asia/Kamchatka", "Asia/Kamchatka", false),
      new TimeZone(null, "Asia/Karachi", "Asia/Karachi", false),
      new TimeZone(null, "Asia/Kathmandu", "Asia/Kathmandu", false),
      new TimeZone(null, "Asia/Khandyga", "Asia/Khandyga", false),
      new TimeZone(null, "Asia/Kolkata", "Asia/Kolkata", false),
      new TimeZone(null, "Asia/Krasnoyarsk", "Asia/Krasnoyarsk", false),
      new TimeZone(null, "Asia/Kuala_Lumpur", "Asia/Kuala Lumpur", false),
      new TimeZone(null, "Asia/Kuching", "Asia/Kuching", false),
      new TimeZone(null, "Asia/Macau", "Asia/Macau", false),
      new TimeZone(null, "Asia/Magadan", "Asia/Magadan", false),
      new TimeZone(null, "Asia/Makassar", "Asia/Makassar", false),
      new TimeZone(null, "Asia/Manila", "Asia/Manila", false),
      new TimeZone(null, "Asia/Nicosia", "Asia/Nicosia", false),
      new TimeZone(null, "Asia/Novokuznetsk", "Asia/Novokuznetsk", false),
      new TimeZone(null, "Asia/Novosibirsk", "Asia/Novosibirsk", false),
      new TimeZone(null, "Asia/Omsk", "Asia/Omsk", false),
      new TimeZone(null, "Asia/Oral", "Asia/Oral", false),
      new TimeZone(null, "Asia/Pontianak", "Asia/Pontianak", false),
      new TimeZone(null, "Asia/Pyongyang", "Asia/Pyongyang", false),
      new TimeZone(null, "Asia/Qatar", "Asia/Qatar", false),
      new TimeZone(null, "Asia/Qostanay", "Asia/Qostanay", false),
      new TimeZone(null, "Asia/Qyzylorda", "Asia/Qyzylorda", false),
      new TimeZone(null, "Asia/Riyadh", "Asia/Riyadh", false),
      new TimeZone(null, "Asia/Sakhalin", "Asia/Sakhalin", false),
      new TimeZone(null, "Asia/Samarkand", "Asia/Samarkand", false),
      new TimeZone(null, "Asia/Seoul", "Asia/Seoul", false),
      new TimeZone(null, "Asia/Shanghai", "Asia/Shanghai", false),
      new TimeZone(null, "Asia/Singapore", "Asia/Singapore", false),
      new TimeZone(null, "Asia/Srednekolymsk", "Asia/Srednekolymsk", false),
      new TimeZone(null, "Asia/Taipei", "Asia/Taipei", false),
      new TimeZone(null, "Asia/Tashkent", "Asia/Tashkent", false),
      new TimeZone(null, "Asia/Tbilisi", "Asia/Tbilisi", false),
      new TimeZone(null, "Asia/Tehran", "Asia/Tehran", false),
      new TimeZone(null, "Asia/Thimphu", "Asia/Thimphu", false),
      new TimeZone(null, "Asia/Tokyo", "Asia/Tokyo", false),
      new TimeZone(null, "Asia/Tomsk", "Asia/Tomsk", false),
      new TimeZone(null, "Asia/Ulaanbaatar", "Asia/Ulaanbaatar", false),
      new TimeZone(null, "Asia/Urumqi", "Asia/Urumqi", false),
      new TimeZone(null, "Asia/Ust-Nera", "Asia/Ust-Nera", false),
      new TimeZone(null, "Asia/Vladivostok", "Asia/Vladivostok", false),
      new TimeZone(null, "Asia/Yakutsk", "Asia/Yakutsk", false),
      new TimeZone(null, "Asia/Yangon", "Asia/Yangon", false),
      new TimeZone(null, "Asia/Yekaterinburg", "Asia/Yekaterinburg", false),
      new TimeZone(null, "Asia/Yerevan", "Asia/Yerevan", false),
      new TimeZone(null, "Atlantic/Azores", "Atlantic/Azores", false),
      new TimeZone(null, "Atlantic/Bermuda", "Atlantic/Bermuda", false),
      new TimeZone(null, "Atlantic/Canary", "Atlantic/Canary", false),
      new TimeZone(null, "Atlantic/Cape_Verde", "Atlantic/Cape Verde", false),
      new TimeZone(null, "Atlantic/Faroe", "Atlantic/Faroe", false),
      new TimeZone(null, "Atlantic/Madeira", "Atlantic/Madeira", false),
      new TimeZone(null, "Atlantic/Reykjavik", "Atlantic/Reykjavik", false),
      new TimeZone(
        null,
        "Atlantic/South_Georgia",
        "Atlantic/South Georgia",
        false
      ),
      new TimeZone(null, "Atlantic/Stanley", "Atlantic/Stanley", false),
      new TimeZone(null, "Australia/Adelaide", "Australia/Adelaide", false),
      new TimeZone(null, "Australia/Brisbane", "Australia/Brisbane", false),
      new TimeZone(
        null,
        "Australia/Broken_Hill",
        "Australia/Broken Hill",
        false
      ),
      new TimeZone(null, "Australia/Darwin", "Australia/Darwin", false),
      new TimeZone(null, "Australia/Eucla", "Australia/Eucla", false),
      new TimeZone(null, "Australia/Hobart", "Australia/Hobart", false),
      new TimeZone(null, "Australia/Lindeman", "Australia/Lindeman", false),
      new TimeZone(null, "Australia/Lord_Howe", "Australia/Lord Howe", false),
      new TimeZone(null, "Australia/Melbourne", "Australia/Melbourne", false),
      new TimeZone(null, "Australia/Perth", "Australia/Perth", false),
      new TimeZone(null, "Australia/Sydney", "Australia/Sydney", false),
      new TimeZone(null, "Europe/Amsterdam", "Europe/Amsterdam", false),
      new TimeZone(null, "Europe/Andorra", "Europe/Andorra", false),
      new TimeZone(null, "Europe/Astrakhan", "Europe/Astrakhan", false),
      new TimeZone(null, "Europe/Athens", "Europe/Athens", false),
      new TimeZone(null, "Europe/Belgrade", "Europe/Belgrade", false),
      new TimeZone(null, "Europe/Berlin", "Europe/Berlin", false),
      new TimeZone(null, "Europe/Brussels", "Europe/Brussels", false),
      new TimeZone(null, "Europe/Bucharest", "Europe/Bucharest", false),
      new TimeZone(null, "Europe/Budapest", "Europe/Budapest", false),
      new TimeZone(null, "Europe/Chisinau", "Europe/Chisinau", false),
      new TimeZone(null, "Europe/Copenhagen", "Europe/Copenhagen", false),
      new TimeZone(null, "Europe/Dublin", "Europe/Dublin", false),
      new TimeZone(null, "Europe/Gibraltar", "Europe/Gibraltar", false),
      new TimeZone(null, "Europe/Helsinki", "Europe/Helsinki", false),
      new TimeZone(null, "Europe/Istanbul", "Europe/Istanbul", false),
      new TimeZone(null, "Europe/Kaliningrad", "Europe/Kaliningrad", false),
      new TimeZone(null, "Europe/Kiev", "Europe/Kiev", false),
      new TimeZone(null, "Europe/Kirov", "Europe/Kirov", false),
      new TimeZone(null, "Europe/Lisbon", "Europe/Lisbon", false),
      new TimeZone(null, "Europe/London", "Europe/London", false),
      new TimeZone(null, "Europe/Luxembourg", "Europe/Luxembourg", false),
      new TimeZone(null, "Europe/Madrid", "Europe/Madrid", false),
      new TimeZone(null, "Europe/Malta", "Europe/Malta", false),
      new TimeZone(null, "Europe/Minsk", "Europe/Minsk", false),
      new TimeZone(null, "Europe/Monaco", "Europe/Monaco", false),
      new TimeZone(null, "Europe/Moscow", "Europe/Moscow", false),
      new TimeZone(null, "Europe/Oslo", "Europe/Oslo", false),
      new TimeZone(null, "Europe/Paris", "Europe/Paris", false),
      new TimeZone(null, "Europe/Prague", "Europe/Prague", false),
      new TimeZone(null, "Europe/Riga", "Europe/Riga", false),
      new TimeZone(null, "Europe/Rome", "Europe/Rome", false),
      new TimeZone(null, "Europe/Samara", "Europe/Samara", false),
      new TimeZone(null, "Europe/Saratov", "Europe/Saratov", false),
      new TimeZone(null, "Europe/Simferopol", "Europe/Simferopol", false),
      new TimeZone(null, "Europe/Sofia", "Europe/Sofia", false),
      new TimeZone(null, "Europe/Stockholm", "Europe/Stockholm", false),
      new TimeZone(null, "Europe/Tallinn", "Europe/Tallinn", false),
      new TimeZone(null, "Europe/Tirane", "Europe/Tirane", false),
      new TimeZone(null, "Europe/Ulyanovsk", "Europe/Ulyanovsk", false),
      new TimeZone(null, "Europe/Uzhgorod", "Europe/Uzhgorod", false),
      new TimeZone(null, "Europe/Vienna", "Europe/Vienna", false),
      new TimeZone(null, "Europe/Vilnius", "Europe/Vilnius", false),
      new TimeZone(null, "Europe/Volgograd", "Europe/Volgograd", false),
      new TimeZone(null, "Europe/Warsaw", "Europe/Warsaw", false),
      new TimeZone(null, "Europe/Zaporozhye", "Europe/Zaporozhye", false),
      new TimeZone(null, "Europe/Zurich", "Europe/Zurich", false),
      new TimeZone(null, "Indian/Chagos", "Indian/Chagos", false),
      new TimeZone(null, "Indian/Christmas", "Indian/Christmas", false),
      new TimeZone(null, "Indian/Cocos", "Indian/Cocos", false),
      new TimeZone(null, "Indian/Kerguelen", "Indian/Kerguelen", false),
      new TimeZone(null, "Indian/Mahe", "Indian/Mahe", false),
      new TimeZone(null, "Indian/Maldives", "Indian/Maldives", false),
      new TimeZone(null, "Indian/Mauritius", "Indian/Mauritius", false),
      new TimeZone(null, "Indian/Reunion", "Indian/Reunion", false),
      new TimeZone(null, "Pacific/Apia", "Pacific/Apia", false),
      new TimeZone(null, "Pacific/Auckland", "Australia/Auckland", false),
      new TimeZone(null, "Pacific/Bougainville", "Pacific/Bougainville", false),
      new TimeZone(null, "Pacific/Chatham", "Pacific/Chatham", false),
      new TimeZone(null, "Pacific/Chuuk", "Pacific/Chuuk", false),
      new TimeZone(null, "Pacific/Easter", "America/Isla de Pascua", false),
      new TimeZone(null, "Pacific/Efate", "Pacific/Efate", false),
      new TimeZone(null, "Pacific/Fakaofo", "Pacific/Fakaofo", false),
      new TimeZone(null, "Pacific/Fiji", "Australia/Fiji", false),
      new TimeZone(null, "Pacific/Funafuti", "Pacific/Funafuti", false),
      new TimeZone(null, "Pacific/Galapagos", "America/Galapagos", false),
      new TimeZone(null, "Pacific/Gambier", "Pacific/Gambier", false),
      new TimeZone(null, "Pacific/Guadalcanal", "Pacific/Guadalcanal", false),
      new TimeZone(null, "Pacific/Guam", "America/Guam", false),
      new TimeZone(null, "Pacific/Honolulu", "America/Honolulu", false),
      new TimeZone(null, "Pacific/Kanton", "Pacific/Kanton", false),
      new TimeZone(null, "Pacific/Kiritimati", "Pacific/Kiritimati", false),
      new TimeZone(null, "Pacific/Kosrae", "Pacific/Kosrae", false),
      new TimeZone(null, "Pacific/Kwajalein", "Pacific/Kwajalein", false),
      new TimeZone(null, "Pacific/Majuro", "Pacific/Majuro", false),
      new TimeZone(null, "Pacific/Marquesas", "Pacific/Marquesas", false),
      new TimeZone(null, "Pacific/Nauru", "Pacific/Nauru", false),
      new TimeZone(null, "Pacific/Niue", "Pacific/Niue", false),
      new TimeZone(null, "Pacific/Norfolk", "Pacific/Norfolk", false),
      new TimeZone(null, "Pacific/Noumea", "Pacific/Noumea", false),
      new TimeZone(null, "Pacific/Pago_Pago", "Pacific/Pago Pago", false),
      new TimeZone(null, "Pacific/Palau", "Pacific/Palau", false),
      new TimeZone(null, "Pacific/Pitcairn", "Pacific/Pitcairn", false),
      new TimeZone(null, "Pacific/Pohnpei", "Pacific/Pohnpei", false),
      new TimeZone(null, "Pacific/Port_Moresby", "Pacific/Port Moresby", false),
      new TimeZone(null, "Pacific/Rarotonga", "Pacific/Rarotonga", false),
      new TimeZone(null, "Pacific/Tahiti", "Pacific/Tahiti", false),
      new TimeZone(null, "Pacific/Tarawa", "Pacific/Tarawa", false),
      new TimeZone(null, "Pacific/Tongatapu", "Pacific/Tongatapu", false),
      new TimeZone(null, "Pacific/Wake", "Pacific/Wake", false),
      new TimeZone(null, "Pacific/Wallis", "Pacific/Wallis", false),
    ];
  }

  private static async getTestBusinesses(): Promise<Business[]> {
    let hashedPassword: string = null;

    try {
      hashedPassword = await bcrypt.hash("password1", 11);
    } catch (err) {
      Logger.logger.error("Failed to hash password", err);
      throw new Error("Failed to hash password");
    }

    return [
      new Business(
        null,
        null,
        "Jose Test",
        "Test Hairdresser",
        "test-hairdresser",
        "912345678",
        "+212",
        new Address("700 Arturo Prat", "Buin", "chile", "", "", "", "", ""),
        undefined,
        "test@mail.com",
        hashedPassword,
        // BusinessTypeDbModel.convertToDomainModel(DbSeeder.businessTypeDocs.find(bt => bt.name == 'Hairdresser')),
        undefined,
        TimeZoneDbModel.convertToDomainModel(
          DbSeeder.businessDefaultTimeZoneDoc
        ),
        Currency.CLP,
        false,
        [
          new BusinessHoursBlock(2, 8, 0, 2, 19, 0),
          new BusinessHoursBlock(1, 8, 0, 1, 19, 0),
          new BusinessHoursBlock(3, 8, 0, 3, 19, 0),
          new BusinessHoursBlock(4, 8, 0, 4, 19, 0),
          new BusinessHoursBlock(5, 8, 0, 5, 19, 0),
        ],
        undefined,
        "This is a test business",
        undefined,
        undefined,
        new BusinessSettings(false, false, [], "", false, false, "", "", null, null, null, null),
        undefined,
        true,
        false,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined
      ),
    ];
  }
}
