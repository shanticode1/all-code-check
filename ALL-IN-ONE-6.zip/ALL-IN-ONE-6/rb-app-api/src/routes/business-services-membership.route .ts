import { Router } from "express";

import { IdValidator } from "../validators/id.validator";
import { BusinessesRoutes } from "./businesses.routes";
import { roles } from "../data/user.roles";
import { AuthMiddleware } from "../middleware/auth.middleware";
import { MembershipPackage, MembershipService } from "../types/membership-package";
import { BusinessMembershipService } from "../services/business-services-membership.service ";
import { ServiceMembershipValidator } from "../validators/service-membership.validator";
import { BusinessValidator } from "../validators/business.validator";
import * as multer from "multer";

const upload = multer({});
export abstract class BusinessMembershipServicesRoutes {
  public static businessMembershipServicesServicesPath = `${BusinessesRoutes.businessesPath}/:businessId/service-membership`;

  public static addBusinessMembershipServicesRoutes(): Router {
    const router = Router({ mergeParams: true });
    BusinessMembershipServicesRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {

    router.get("/",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business]), async (req: any, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        if (
          IdValidator.isInvalidForRead(businessIdParam)
        ) {
          res.status(400).send();
          return;
        }


        if (businessIdParam != res.locals.sub) {
          res.status(403).send();
          return;
        }
        try {
          res.json(
            await BusinessMembershipService.getAll(businessIdParam)
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      });

    router.get("/:membershipId",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business]), async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const membershipParam = (req.params as any).membershipId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(membershipParam)
        ) {
          res.status(400).send();
          return;
        }


        if (businessIdParam != res.locals.sub) {
          res.status(403).send();
          return;
        }
        try {
          res.json(
            await BusinessMembershipService.getById(businessIdParam, membershipParam)
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      });

    router.get("/membership/:membershipId",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business]), async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const membershipParam = (req.params as any).membershipId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(membershipParam)
        ) {
          res.status(400).send();
          return;
        }


        if (businessIdParam != res.locals.sub) {
          res.status(403).send();
          return;
        }
        try {
          res.json(
            await BusinessMembershipService.getMembershipHistoryById(businessIdParam, membershipParam)
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      });

    router.post("/",
      upload.any(),
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business]),
      async (req: any, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const parsedBody = BusinessesRoutes.parseBodyJson(req.body);
        req.body = parsedBody;

        if (req.files && req.files.length > 0) {
          for (const file of req.files) {
            // File size validation
            if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
              res.status(400).send();
              return;
            }
            if (file.fieldname === "logo") {
              req.body['logo'] = file;
            }
          }
        }
        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          ServiceMembershipValidator.isInvalidForCreate(req.body)
        ) {
          res.status(400).send();
          return;
        }
        if (businessIdParam != res.locals.userId) {
          res.status(403).send();
          return;
        }
        try {
          const packages = req.body.packageSetting.map(setting => {
            return new MembershipPackage(setting.serviceId, setting.bookingQuantity);
          });
          res
            .status(201)
            .json(
              await BusinessMembershipService.create(
                businessIdParam,
                new MembershipService(
                  null,
                  businessIdParam,
                  req.body.name,
                  req.body.description,
                  null,
                  packages,
                  req.body.price,
                  false,
                  true,
                  req.body.logo,
                  req.body.currency
                )
              )
            );
          return;
        } catch (err) {
          next(err);
          return;
        }
      });

    router.put("/:membershipId",
      upload.any(),
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business]),
      async (req: any, res, next) => {
        const parsedBody = BusinessesRoutes.parseBodyJson(req.body);
        req.body = parsedBody;
        const businessIdParam = (req.params as any).businessId as string;
        const membershipParam = (req.params as any).membershipId as string;
        if (req.files && req.files.length > 0) {
          for (const file of req.files) {
            // File size validation
            if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
              res.status(400).send();
              return;
            }
            if (file.fieldname === "logo") {
              req.body['logo'] = file;
            }
          }
        }
        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(membershipParam) ||
          ServiceMembershipValidator.isInvalidForPartialUpdate(req.body)
        ) {
          res.status(400).send();
          return;
        }

        if (businessIdParam != res.locals.userId) {
          res.status(403).send();
          return;
        }
        let result: MembershipService;
        try {

          // FILE validation


          const packages = req.body.packageSetting.map(setting => {
            return new MembershipPackage(setting.serviceId, setting.bookingQuantity);
          });


          result = await BusinessMembershipService.partialUpdate(
            new MembershipService(
              membershipParam,
              businessIdParam,
              req.body.name,
              req.body.description,
              null,
              packages,
              req.body.price,
              req.body.isDeleted,
              req.body.isActive,
              req.body.logo
            )
          );
        } catch (err) {
          next(err);
          return;
        }

        if (result == null) {
          res.status(204).send();
          return;
        }
        res.json(result);
        return;
      });

    router.delete("/:membershipId",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business]),
      async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const membershipParam = (req.params as any).membershipId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(membershipParam)
        ) {
          res.status(400).send();
          return;
        }

        if (businessIdParam != res.locals.userId) {
          res.status(403).send();
          return;
        }

        try {
          res.json(
            await BusinessMembershipService.delete(membershipParam, businessIdParam)
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      });

  }
}
