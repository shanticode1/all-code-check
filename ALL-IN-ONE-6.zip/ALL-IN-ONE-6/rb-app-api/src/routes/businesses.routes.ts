import { Router } from "express";
import * as Joi from "joi";

import { AuthMiddleware } from "../middleware/auth.middleware";
import { BusinessesService } from "../services/businesses.service";
import { Address } from "../types/address";
import { Business } from "../types/business";
import { BusinessHoursBlock } from "../types/business-hours-block";
import { BusinessService } from "../types/business-service";
import { BusinessType } from "../types/business-type";
import { Coordinates } from "../types/coordinates";
import { Currency } from "../types/enums/currency";
import { ServiceCategory } from "../types/service-category";
import { TimeZone } from "../types/time-zone";
import { BaseValidator } from "../validators/base.validator";
import { BusinessValidator } from "../validators/business.validator";
import { IdValidator } from "../validators/id.validator";
import { BusinessSettings } from "../types/business-settings";
import { BusinessNotes } from "../types/business-notes";
import { BusinessSocialMedias } from "../types/business-social-medias";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { GoogleToken } from "../types/googleToken";
import { GoogleCalendar } from "../types/google-calendar";
import * as multer from "multer";
import { roles } from "../data/user.roles";
import { StaffService } from "../services/staff.service";
import { BookingsService } from "../services/bookings.service";
import { Staff } from "../types/staff";
import { StaffHoursBlock } from "../types/staff-hours-block";
import { ClientService } from "../services/client.service";
import { Client } from "../types/clients";

const upload = multer({});
const verifytoken = process.env.WHATAPP_WEBHOOK_TOKEN || 'whatsappremindertokentest';
export abstract class BusinessesRoutes {
  public static businessesPath = "/businesses";

  public static addBusinessesRoutes(): Router {
    const router = Router();
    BusinessesRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {
    router.get(
      "/:businessId",
      AuthMiddleware.getAuthFunction(),
      // AuthMiddleware.userRoleV2([2, 3]),
      async (req, res, next) => {
        if (IdValidator.isInvalidForRead(req.params.businessId)) {
          res.status(400).send();
          return;
        }
        if (req.params.businessId != res.locals.sub) {
          res.status(403).send();
          return;
        }
        try {
          // res.json(await BusinessesService.getByUserId(req.params.businessId));
          if (res.locals.role === roles.Business) {
            res.json(await BusinessesService.getById(req.params.businessId));
          }
          else if (res.locals.role === roles.staff) {
            res.json(await StaffService.getByIdV2(res.locals.iss, res.locals.role));
          }
          else if (res.locals.role === roles.Client) {
            res.json(await ClientService.getByIdV2(res.locals.iss, res.locals.role));
          }
          return;
        } catch (err) {
          next(err);
          return;
        }
      }
    );

    router.get("/", async (req, res, next) => {
      const slugParam = req.query.slug as string;
      const clientParam = req.query.clientId as string;

      if (slugParam == null) {
        res.status(403).send();
        return;
      }

      if (BusinessesRoutes.slugParamIsInvalid(slugParam)) {
        res.status(400).send();
        return;
      }

      let business: Business;

      try {
        business = await BusinessesService.getBySlug(slugParam, clientParam);
      } catch (err) {
        next(err);
        return;
      }

      if (business == null) {
        res.status(404).send();
        return;
      }

      delete business.contactName;
      // delete business.coordinates;
      delete business.membershipExpirationDate;
      business.services?.forEach((s) => {
        delete s.bookingReminders;
        delete s.hash;
      });
      delete business.stripeCustomerId;
      delete business.stripeOnTrial;
      delete business.isAccountActivated;
      delete business.frillToken;
      delete business.referral;
      delete business.lastCompletedOnboardingStep;

      res.json(business);
    });

    router.get("/slug/v2", async (req, res, next) => {
      const slugParam = req.query.slug as string;

      if (slugParam == null) {
        res.status(403).send();
        return;
      }

      if (BusinessesRoutes.slugParamIsInvalid(slugParam)) {
        res.status(400).send();
        return;
      }

      let business: Business;

      try {
        business = await BusinessesService.getBySlugV2(slugParam);

      } catch (err) {
        next(err);
        return;
      }

      if (business == null) {
        res.status(404).send();
        return;
      }

      delete business.contactName;
      delete business.coordinates;
      delete business.membershipExpirationDate;
      business.services?.forEach((s) => {
        delete s.bookingReminders;
        delete s.hash;
      });
      delete business.stripeCustomerId;
      delete business.stripeOnTrial;
      delete business.isAccountActivated;
      delete business.frillToken;
      delete business.referral;
      delete business.lastCompletedOnboardingStep;

      res.json(business);
    });
    router.post("/", async (req, res, next) => {
      if (BusinessValidator.isInvalidForCreateUser(req.body)) {
        res.status(400).send();
        return;
      }
      const clientName = req.body.contactName.split(' ');
      req.body.name = clientName[0];
      req.body.surname = clientName[1];

      try {
        if (roles[req.body.role] === roles.Client) {
          res
            .status(201)
            .json(
              await ClientService.createClientAccount(
                new Client(
                  "",
                  req.body.businessId,
                  req.body.email,
                  req.body.name,
                  req.body.surname,
                  req.body.phone,
                  req.body.countryCode == null ? undefined : req.body.countryCode,
                  req.body.lastBookingDate,
                  req.body.notes,
                  req.body.isWhatsAppAllow == null ? undefined : req.body.isWhatsAppAllow,
                  req.body.isEmailAllow == null ? undefined : req.body.isEmailAllow,
                  req.body.bookings == null ? undefined : req.body.bookings,
                  req.body.password == null ? undefined : req.body.password,
                  undefined,
                  undefined,
                  req.body.address == null
                    ? undefined
                    : new Address(
                      req.body.address.address,
                      req.body.address.suite == null
                        ? undefined
                        : req.body.address.suite,
                      req.body.address.district == null
                        ? undefined
                        : req.body.address.district,
                      req.body.address.city == null
                        ? undefined
                        : req.body.address.city,
                      req.body.address.region == null
                        ? undefined
                        : req.body.address.region,
                      req.body.address.postcode == null
                        ? undefined
                        : req.body.address.postcode,
                      req.body.address.country == null
                        ? undefined
                        : req.body.address.country,
                      req.body.address.countryShortName == null
                        ? undefined
                        : req.body.address.countryShortName,
                    ),
                ),
                true
              )
            );
        } else {
          res
            .status(201)
            .json(
              await BusinessesService.create(
                new Business(
                  undefined,
                  undefined,
                  req.body.contactName,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  req.body.email,
                  req.body.password,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  MembershipTier.Free,
                  new Date(),
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined,
                  undefined
                )
              )
            );
        }

        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    router.patch(
      "/:businessId",
      upload.any(),
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([roles.Business, roles.staff, roles.Client]),
      async (req: any, res, next) => {
        const parsedBody = this.parseBodyJson(req.body);
        req.body = parsedBody;
        let marketPlaceImages: any = [];
        if (res.locals.role === roles.Business && BusinessValidator.isInvalidForPartialUpdate(req.body)) {
          res.status(400).send();
          return;
        }
        // FILE validation
        if (req.files && req.files.length > 0) {
          for (const file of req.files) {
            // File size validation
            if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
              res.status(400).send();
              return;
            }
            if (file.fieldname === "heroImage") {
              req.body['heroImage'] = file;
            }
            if (file.fieldname === "bannerImage") {
              req.body['bannerImage'] = file;
            }

            // staff profile image validation
            if (file.fieldname === "logo") {
              req.body['logo'] = file;
            }

            // market place image validation
            if (file.fieldname.startsWith("marketPlaceImages")) {
              marketPlaceImages.push(file);
            }
          }
        }
        req.body['marketPlaceImages'] = marketPlaceImages;

        if (req.params.businessId != res.locals.sub) {
          res.status(403).send();
          return;
        }
        let result: Business | Staff | Client;
        try {
          if (res.locals.role === roles.Business) {
            result = await BusinessesService.partialUpdate(
              new Business(
                req.params.businessId,
                req.body.userId == null ? undefined : req.body.userId,
                req.body.contactName,
                req.body.name,
                req.body.slug,
                req.body.phoneNumber,
                req.body.countryCode == null ? undefined : req.body.countryCode,
                req.body.address == null
                  ? undefined
                  : new Address(
                    req.body.address.address,
                    req.body.address.suite == null
                      ? undefined
                      : req.body.address.suite,
                    req.body.address.district == null
                      ? undefined
                      : req.body.address.district,
                    req.body.address.city == null
                      ? undefined
                      : req.body.address.city,
                    req.body.address.region == null
                      ? undefined
                      : req.body.address.region,
                    req.body.address.postcode == null
                      ? undefined
                      : req.body.address.postcode,
                    req.body.address.country == null
                      ? undefined
                      : req.body.address.country,
                    req.body.address.countryShortName == null
                      ? undefined
                      : req.body.address.countryShortName,
                  ),
                req.body.coordinates == null
                  ? undefined
                  : new Coordinates(
                    req.body.coordinates.latitude,
                    req.body.coordinates.longitude
                  ),
                req.body.email == null ? undefined : req.body.email,
                req.body.password == null ? undefined : req.body.password,
                req.body.type == null
                  ? undefined
                  : new BusinessType(req.body.type.id, req.body.type.name),
                req.body.timeZone == null
                  ? undefined
                  : new TimeZone(
                    req.body.timeZone.id,
                    req.body.timeZone.name,
                    req.body.timeZone.displayName,
                    req.body.timeZone.isBusinessDefault
                  ),
                req.body.currency as Currency,
                req.body.isOperatingNonStop,
                req.body.businessHoursBlocks == null
                  ? undefined
                  : req.body.businessHoursBlocks.map(
                    (bh) =>
                      new BusinessHoursBlock(
                        bh.startDayOfTheWeek,
                        bh.startHour,
                        bh.startMinute,
                        bh.endDayOfTheWeek,
                        bh.endHour,
                        bh.endMinute
                      )
                  ),
                undefined,
                req.body.about == null ? undefined : req.body.about,
                req.body.services == null
                  ? undefined
                  : req.body.services.map(
                    (s) =>
                      new BusinessService(
                        s.id,
                        s.name,
                        s.description,
                        s.category == null
                          ? undefined
                          : new ServiceCategory(
                            s.category.id,
                            s.category.name == null
                              ? undefined
                              : s.category.name,
                            s.category.description == null
                              ? undefined
                              : s.category.description
                          ),
                        s.duration,
                        s.durationUnit,
                        s.price,
                        s.currency,
                        s.type,
                        s.capacity,
                        s.hash,
                        undefined,
                        s.isActive,
                        s.isDeleted,
                        s.location == null ? undefined : s.location
                        // s.groupMeetLink == null ? undefined : s.groupMeetLink,
                        // s.meetEventId == null ? undefined : s.meetEventId
                      )
                  ),
                req.body.serviceCategories == null
                  ? undefined
                  : req.body.serviceCategories.map(
                    (sc) => new ServiceCategory(sc.id, sc.name, sc.description)
                  ),
                req.body.settings == null
                  ? undefined
                  : new BusinessSettings(
                    req.body.settings.bookingAutoapprove,
                    req.body.settings.hideAddress,
                    req.body.settings.paymentTypes,
                    req.body.settings.manualPaymentInfo == null ? undefined : req.body.settings.manualPaymentInfo,
                    req.body.settings.isWhatsAppReminder == null ? undefined : req.body.settings.isWhatsAppReminder,
                    req.body.settings.isEmailReminder == null ? undefined : req.body.settings.isEmailReminder,
                    req.body.settings.whatsAppReminderInfo
                      == null ? undefined : req.body.settings.whatsAppReminderInfo,
                    req.body.settings.emailInfo
                      == null ? undefined : req.body.settings.emailInfo,
                    req.body.settings.emailInfo
                      == null ? undefined : req.body.settings.emailReminderDuration,
                    req.body.settings.emailInfo
                      == null ? undefined : req.body.settings.whatsappReminderDuration,
                    req.body.settings.cancelationPolicyInfo == null ? undefined : req.body.settings.cancelationPolicyInfo,
                    req.body.settings.serviceCapacityVisibility == null ? undefined : req.body.settings.serviceCapacityVisibility,
                  ),
                req.body.socialMedia == null
                  ? undefined
                  : new BusinessSocialMedias(
                    req.body.socialMedia.ig,
                    req.body.socialMedia.fb,
                    req.body.socialMedia.wa,
                    req.body.socialMedia.countryCode
                  ),
                req.body.isActive,
                req.body.isDeleted,
                req.body.membershipTier,
                req.body.createdAt,
                req.body.membershipExpirationDate == null
                  ? undefined
                  : req.body.membershipExpirationDate,
                req.body.staffMembershipExpirationDate == null
                  ? undefined
                  : req.body.staffMembershipExpirationDate,
                undefined,
                req.body.lastLoginDate == null
                  ? undefined
                  : req.body.lastLoginDate,
                undefined,
                undefined,
                undefined,
                undefined,
                req.body.referral == null ? undefined : req.body.referral,
                req.body.heroImage,
                req.body.bannerImage,
                req.body.lastCompletedOnboardingStep == null
                  ? undefined
                  : req.body.lastCompletedOnboardingStep,
                req.body.googleToken == null
                  ? undefined
                  : new GoogleToken(
                    req.body.googleToken.access_token == null
                      ? undefined
                      : req.body.googleToken.access_token,
                    req.body.googleToken.refresh_token == null
                      ? undefined
                      : req.body.googleToken.refresh_token,
                    req.body.googleToken.scope == null
                      ? undefined
                      : req.body.googleToken.scope,
                    req.body.googleToken.token_type == null
                      ? undefined
                      : req.body.googleToken.token_type,
                    req.body.googleToken.id_token == null
                      ? undefined
                      : req.body.googleToken.id_token,
                    req.body.googleToken.expiry_date == null
                      ? undefined
                      : req.body.googleToken.expiry_date
                    // req.body.syncEventToken == null ? undefined : req.body.syncEventToken
                  ),
                req.body.googleCalendar == null
                  ? undefined
                  : req.body.googleCalendar.map(
                    (sc) =>
                      new GoogleCalendar(
                        sc.calendarId,
                        sc.status,
                        sc.name,
                        sc.isProcessing,
                        sc.lastLoggedInTime
                      )
                  ),
                req.body.gmail == null ? undefined : req.body.gmail,
                req.body.isConflict == null ? undefined : req.body.isConflict,
                req.body.gPicture == null ? undefined : req.body.gPicture,
                req.body.gName == null ? undefined : req.body.gName,
                undefined,
                req.body.gEventWatchId == null
                  ? undefined
                  : req.body.gEventWatchId,
                req.body.gResourceId == null ? undefined : req.body.gResourceId,
                req.body.syncEventToken == null
                  ? undefined
                  : req.body.syncEventToken,
                req.body.whatsAppCredits == null
                  ? undefined
                  : req.body.whatsAppCredits,
                req.body.watchEventExpiry == null
                  ? undefined
                  : req.body.watchEventExpiry,
                req.body.whatsAppMembershipTier == null ? undefined : req.body.whatsAppMembershipTier,
                req.body.stripePayAsYouGoOnTrial == null ? undefined : req.body.stripePayAsYouGoOnTrial,
                req.body.stripePriceIds == null ? undefined : req.body.stripePriceIds,
                req.body.whatsAppBagsCredits == null ? undefined : req.body.whatsAppBagsCredits,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                req.body.marketPlaceImages == null ? undefined : req.body.marketPlaceImages,
                req.body.isPublishedOnMarketplace == null ? undefined : req.body.isPublishedOnMarketplace,
                req.body.fileIds
              )
            );
          }
          else if (res.locals.role === roles.staff) {
            req.body.name = req.body.contactName;
            result = await StaffService.partialUpdate(
              new Staff(
                req.body.id,
                req.body.businessId,
                req.body.servicesId,
                req.body.name,
                req.body.email == null ? undefined : req.body.email,
                req.body.password == null ? undefined : req.body.password,
                req.body.userId == null ? undefined : req.body.userId,
                req.body.isOperatingNonStop,
                req.body.staffHoursBlocks == null ?
                  undefined :
                  req.body.staffHoursBlocks.map(bh => new StaffHoursBlock(
                    bh.startDayOfTheWeek,
                    bh.startHour,
                    bh.startMinute,
                    bh.endDayOfTheWeek,
                    bh.endHour,
                    bh.endMinute
                  )),
                req.body.isActive,
                req.body.isDeleted,
                req.body.logo,
                undefined,
                req.body.gmail == null ? undefined : req.body.gmail,
                req.body.isConflict == null ? undefined : req.body.isConflict,
                req.body.gPicture == null ? undefined : req.body.gPicture,
                req.body.gName == null ? undefined : req.body.gName,
                undefined,
                req.body.gEventWatchId == null
                  ? undefined
                  : req.body.gEventWatchId,
                req.body.gResourceId == null ? undefined : req.body.gResourceId,
                req.body.syncEventToken == null
                  ? undefined
                  : req.body.syncEventToken,
                undefined,
                undefined,
                undefined
              )
            );
          } else if (res.locals.role === roles.Client) {
            const parts = req.body.contactName.trim().split(/\s+/);
            req.body.name = parts[0];                    // first word
            req.body.surname = parts.slice(1).join(" "); // all remaining words
            result = await ClientService.partialUpdateV2(
              new Client(
                res.locals.sub,
                req.params.businessId,
                req.body.email == null ? undefined : req.body.email,
                req.body.name,
                req.body.surname,
                req.body.phoneNumber,
                req.body.countryCode == null ? undefined : req.body.countryCode,
                req.body.lastBookingDate == null ? undefined : req.body.lastBookingDate,
                req.body.notes == null ? undefined : req.body.notes,
                req.body.isWhatsAppAllow == null ? undefined : req.body.isWhatsAppAllow,
                req.body.isEmailAllow == null ? undefined : req.body.isEmailAllow,
                req.body.bookings == null ? undefined : req.body.bookings,
                req.body.password == null ? undefined : req.body.password,
                req.body.userId == null ? undefined : req.body.userId,
                req.body.timeZone == null
                  ? undefined
                  : new TimeZone(
                    req.body.timeZone.id,
                    req.body.timeZone.name,
                    req.body.timeZone.displayName,
                    req.body.timeZone.isBusinessDefault
                  ),
                req.body.address == null
                  ? undefined
                  : new Address(
                    req.body.address.address,
                    req.body.address.suite == null
                      ? undefined
                      : req.body.address.suite,
                    req.body.address.district == null
                      ? undefined
                      : req.body.address.district,
                    req.body.address.city == null
                      ? undefined
                      : req.body.address.city,
                    req.body.address.region == null
                      ? undefined
                      : req.body.address.region,
                    req.body.address.postcode == null
                      ? undefined
                      : req.body.address.postcode,
                    req.body.address.country == null
                      ? undefined
                      : req.body.address.country,
                    req.body.address.countryShortName == null
                      ? undefined
                      : req.body.address.countryShortName,
                  ),
              )
            );
          }
        } catch (err) {
          next(err);
          return;
        }
        if (result == null) {
          res.status(204).send();
          return;
        }
        res.json(result);
        return;
      }
    );

    router.get("/webhook/verify-token", async (req, res, next) => {
      try {
        let mode = req.query["hub.mode"];
        let token = req.query["hub.verify_token"];
        let challenge = req.query["hub.challenge"];
        // Check if a token and mode is in the query string of the request
        if (mode && token) {
          // Check the mode and token sent is correct
          if (mode === "subscribe" && token === verifytoken) {
            // Respond with the challenge token from the request
            res.status(200).send(challenge);
          } else {
            // Respond with '403 Forbidden' if verify tokens do not match
            res.sendStatus(403);
          }
        }
      } catch (err) {
        next(err);
        return;
      }
    });

    router.post("/webhook/verify-token", async (req: any, res, next) => {
      try {
        let webhookEvent = req.rawBody || {};
        webhookEvent = JSON.parse(webhookEvent);
        var signature = req.headers["x-hub-signature-256"];
        if (!signature) {
          console.warn(`Couldn't find "x-hub-signature-256" in headers.`);
          res.sendStatus(401);
          return;
        };
        // check message status
        if (webhookEvent) {
          const statusPayload = webhookEvent.entry.flatMap(entry =>
            entry.changes
              .filter(change => change.field === 'messages' && change.value.statuses)
              .flatMap(change => change.value.statuses)
              .filter(status => status.status === 'delivered')
          );
          // find booking based on message id and update status
          if (statusPayload && statusPayload.length > 0) {
            statusPayload.forEach(async (statusEl) => {
              const bookingDoc = await BookingsService.findBookingByMessageId(statusEl.id);
              if (bookingDoc && !bookingDoc.isMessageDelivered) {
                bookingDoc['isMessageDelivered'] = true;
                await BusinessesService.updateBusinessWhatsappCredits(bookingDoc.businessId);
                await bookingDoc.save()
              }
            });
          }
        }
        res.sendStatus(200);
        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    router.get("/services/paginated", async (req, res, next) => {
      let business: any;
      try {
        const pageParam = Number(req.query.page) || 1;
        const limitParam = Number(req.query.limit) || 10;
        const findByParam = req.query.findBy as string || 'business';
        const sortByParam = req.query.sortBy as string || 'desc';
        const searchParam = req.query.search as string || '';
        const findByCategory = req.query.category as string || '';
        const findByCountry = req.query.country as string || '';

        const clientId = res.locals.sub;
        business = await BusinessesService.getAllServices(pageParam, limitParam, findByParam, sortByParam, searchParam, clientId, findByCategory, findByCountry);
      } catch (err) {
        next(err);
        return;
      }
      if (business == null) {
        res.status(404).send();
        return;
      }
      res.json(business);
    });

    router.get("/v1/public", async (req, res, next) => {
      const countryParam = req.query.country as string;
      const pageParam = Number(req.query.page) || 1;
      const limitParam = Number(req.query.limit) || 10;
      const searchParam = req.query.search as string || '';
      const findByCategory = req.query.category as string || '';
      if (countryParam == null) {
        res.status(403).send();
        return;
      }
      let business: Business[];

      try {
        business = await BusinessesService.getByCountry(countryParam, pageParam, limitParam, searchParam, findByCategory);

      } catch (err) {
        next(err);
        return;
      }

      if (business == null) {
        res.status(404).send();
        return;
      }

      res.json(business);
    });

    router.get("/v1/public/newBusinesses", async (req, res, next) => {
      const countryParam = req.query.country as string;
      const pageParam = Number(req.query.page) || 1;
      const limitParam = Number(req.query.limit) || 10;
      if (countryParam == null) {
        res.status(403).send();
        return;
      }
      let business: Business[];

      try {
        business = await BusinessesService.getNewBusiness(countryParam, pageParam, limitParam);

      } catch (err) {
        next(err);
        return;
      }

      if (business == null) {
        res.status(404).send();
        return;
      }

      res.json(business);
    });
  }

  private static slugParamIsInvalid(slug: string): boolean {
    const validationSchema = Joi.object({
      slug: Joi.string()
        .pattern(BaseValidator.slugRegex)
        .min(2)
        .max(50)
        .required(),
    });

    return BaseValidator.isInvalidForSchema({ slug }, validationSchema);
  }

  public static parseBodyJson(body) {
    // Create a shallow copy to avoid mutating the original
    const parsedBody = { ...body };
    for (const [key, value] of Object.entries(parsedBody)) {
      if (typeof value === "string" && (key === "address" || key === "coordinates" || key === "type" || key === "timeZone" || key === "socialMedia" || key === "packageSetting" || key === 'fileIds')) {
        try {
          parsedBody[key] = JSON.parse(value);
        } catch (error) {
          console.error(`Error while parsing ${key}: ${error.message}`);
        }
      }
    }

    return parsedBody;
  }
}
