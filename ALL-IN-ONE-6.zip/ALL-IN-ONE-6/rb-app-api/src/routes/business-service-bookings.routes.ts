import { Router } from "express";
import Joi = require("joi");

import { AuthMiddleware } from "../middleware/auth.middleware";
import { BookingsService } from "../services/bookings.service";
import { Booking } from "../types/booking";
import { Business } from "../types/business";
import { BusinessService } from "../types/business-service";
import { BusinessServiceSnapshot } from "../types/business-service-snapshot";
import { BookingStatus } from "../types/enums/booking.status";
import { Staff } from "../types/staff";
import { BaseValidator } from "../validators/base.validator";
import { BookingValidator } from "../validators/booking.validator";
import { IdValidator } from "../validators/id.validator";
import { BusinessBusinessServicesRoutes } from "./business-busines-services.route";
import { GoogleCalendar } from "../types/google-calendar";
import { GoogleToken } from "../types/googleToken";
import { Address } from "../types/address";
import { Coordinates } from "../types/coordinates";
import { BookingQueue } from "../utils/booking.queue";

export abstract class BusinessServiceBookingsRoutes {
  public static businessServiceBookingsPath = `${BusinessBusinessServicesRoutes.businessBusinessServicesPath}/:serviceId/bookings`;

  public static addBusinessServiceBookingsRoutes(): Router {
    const router = Router({ mergeParams: true });
    BusinessServiceBookingsRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {
    router.get(
      "/:bookingId",
      AuthMiddleware.getAuthFunction(),
      async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const serviceIdParam = (req.params as any).serviceId as string;
        const bookingId = (req.params as any).bookingId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(serviceIdParam) ||
          IdValidator.isInvalidForRead(bookingId)
        ) {
          res.status(400).send();
          return;
        }

        if (businessIdParam != res.locals.userId) {
          res.status(403).send();
          return;
        }

        try {
          res.json(
            await BookingsService.getByIdForBusinessAndService(
              businessIdParam,
              serviceIdParam,
              bookingId
            )
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      }
    );

    router.get(
      "/",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([2, 3]),
      async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const serviceIdParam = (req.params as any).serviceId as string;
        const statusParam = req.query.status as string;
        const pastParam = req.query.past as string;
        const fromParam = req.query.from as string;
        const toParam = req.query.to as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(serviceIdParam) ||
          BusinessServiceBookingsRoutes.areGetParamsInvalid(
            statusParam,
            pastParam,
            fromParam,
            toParam
          )
        ) {
          res.status(400).send();
          return;
        }

        if (businessIdParam != res.locals.sub) {
          res.status(403).send();
          return;
        }

        const status: BookingStatus =
          statusParam === undefined ? undefined : BookingStatus[statusParam];

        const past =
          pastParam != null ? pastParam.toLowerCase() == "true" : null;

        const from = fromParam != null ? new Date(fromParam) : null;

        const to = toParam != null ? new Date(toParam) : null;

        try {
          res.json(
            await BookingsService.getForBusinessAndService(
              businessIdParam,
              serviceIdParam,
              status,
              past,
              from,
              to
            )
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      }
    );

    router.post("/", async (req, res, next) => {
      const fromBusiness = (req.query.fromBusiness as string) === "true";
      // const isCustomer = (req.query.isCustomer as any).isCustomer;
      const businessIdParam = (req.params as any).businessId as string;
      const serviceIdParam = (req.params as any).serviceId as string;
      if (
        IdValidator.isInvalidForRead(businessIdParam) ||
        IdValidator.isInvalidForRead(serviceIdParam) ||
        BookingValidator.isInvalidForCreate(req.body)
      ) {
        res.status(400).send();
        return;
      }

      try {
        if (fromBusiness) {
          req.body.customer.isWhatsAppAllow = true;
        }
        res
          .status(201)
          .json(         
            await BookingsService.createQueued(fromBusiness, req.body.chargeImmediately,
              new Booking(
                null,
                new Business(
                  businessIdParam,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null
                ),
                new BusinessService(
                  serviceIdParam,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  null,
                  // null,
                  // null
                ),
                undefined,
                new Date(req.body.startDate),
                new Date(req.body.endDate),
                undefined,
                req.body.customer,
                req.body.notes == null ? undefined : req.body.notes,
                req.body.staffId == null ? undefined : req.body.staffId,
                fromBusiness
                  ? BookingStatus.Approved
                  : req.body.status == null
                    ? undefined
                    : req.body.status,
                req.body.serviceSnapshot == null
                  ? undefined
                  : new BusinessServiceSnapshot(
                    req.body.serviceSnapshot.id,
                    req.body.serviceSnapshot.serviceHash,
                    req.body.serviceSnapshot.serviceName,
                    req.body.serviceSnapshot.serviceDescription,
                    req.body.serviceSnapshot.serviceDuration,
                    req.body.serviceSnapshot.serviceDurationUnit,
                    req.body.serviceSnapshot.servicePrice,
                    req.body.serviceSnapshot.serviceCurrency,
                    // req.body.googleMeetLink == null ? undefined : req.body.googleMeetLink
                    req.body.serviceSnapshot.paymentSetting,
                    req.body.serviceSnapshot.depositAmount,
                    req.body.serviceSnapshot.eventSetting,
                    // req.body.serviceSnapshot.isCapacityVisible,
                    req.body.serviceAddress == null
                      ? undefined
                      : new Address(
                        req.body.serviceAddress.address,
                        req.body.serviceAddress.suite == null
                          ? undefined
                          : req.body.serviceAddress.suite,
                        req.body.serviceAddress.district == null
                          ? undefined
                          : req.body.serviceAddress.district,
                        req.body.serviceAddress.city == null
                          ? undefined
                          : req.body.serviceAddress.city,
                        req.body.serviceAddress.region == null
                          ? undefined
                          : req.body.serviceAddress.region,
                        req.body.serviceAddress.postcode == null
                          ? undefined
                          : req.body.serviceAddress.postcode,
                        req.body.serviceAddress.country == null
                          ? undefined
                          : req.body.serviceAddress.country,
                        req.body.serviceAddress.countryShortName == null
                          ? undefined
                          : req.body.serviceAddress.countryShortName,
                        req.body.serviceAddress.coordinates == null
                          ? undefined : new Coordinates(
                            req.body.serviceAddress.coordinates.latitude,
                            req.body.serviceAddress.coordinates.longitude
                          )
                      ),
                    req.body.serviceSnapshot.type == null ? undefined : req.body.serviceSnapshot.type,
                    req.body.serviceSnapshot.cutOff == null ? undefined : req.body.serviceSnapshot.cutOff,
                    req.body.serviceSnapshot.cutOffUnit == null ? undefined : req.body.serviceSnapshot.cutOffUnit,
                  ),
                req.body.staffSnapshot == null
                  ? undefined
                  : new Staff(
                    req.body.staffSnapshot.id,
                    req.body.staffSnapshot.business,
                    req.body.staffSnapshot.services,
                    req.body.staffSnapshot.name,
                    req.body.staffSnapshot.email,
                    req.body.staffSnapshot.password == null ? undefined : req.body.staffSnapshot.password,
                    req.body.staffSnapshot.userId,
                    req.body.staffSnapshot.isOperatingNonStop,
                    req.body.staffSnapshot.staffHoursBlocks,
                    req.body.staffSnapshot.isActive,
                    req.body.staffSnapshot.isDeleted,
                    req.body.staffSnapshot.logo,
                    req.body.googleToken == null
                      ? undefined
                      : new GoogleToken(
                        req.body.googleToken.access_token == null
                          ? undefined
                          : req.body.googleToken.access_token,
                        req.body.googleToken.refresh_token == null
                          ? undefined
                          : req.body.googleToken.refresh_token,
                        req.body.googleToken.scope == null
                          ? undefined
                          : req.body.googleToken.scope,
                        req.body.googleToken.token_type == null
                          ? undefined
                          : req.body.googleToken.token_type,
                        req.body.googleToken.id_token == null
                          ? undefined
                          : req.body.googleToken.id_token,
                        req.body.googleToken.expiry_date == null
                          ? undefined
                          : req.body.googleToken.expiry_date
                        // req.body.syncEventToken == null ? undefined : req.body.syncEventToken
                      ),
                    req.body.googleCalendar == null
                      ? undefined
                      : req.body.googleCalendar.map(
                        (sc) =>
                          new GoogleCalendar(
                            sc.calendarId,
                            sc.status,
                            sc.name,
                            sc.isProcessing,
                            sc.lastLoggedInTime
                          )
                      ),
                    req.body.gmail == null ? undefined : req.body.gmail,
                    req.body.isConflict == null ? undefined : req.body.isConflict,
                    req.body.gPicture == null ? undefined : req.body.gPicture,
                    req.body.gName == null ? undefined : req.body.gName,
                    undefined,
                    req.body.gEventWatchId == null
                      ? undefined
                      : req.body.gEventWatchId,
                    req.body.gResourceId == null ? undefined : req.body.gResourceId,
                    req.body.syncEventToken == null
                      ? undefined
                      : req.body.syncEventToken,
                    undefined,
                    undefined
                  ),
                req.body.eventType == null ? undefined : req.body.eventType,
                req.body.googleEventId == null ? undefined : req.body.googleEventId,
                req.body.calendarId == null ? undefined : req.body.calendarId,
                req.body.title == null ? undefined : req.body.title,
                req.body.creator == null ? undefined : req.body.creator,
                req.body.googleMeetLink == null ? undefined : req.body.googleMeetLink,
                undefined,
                undefined,
                req.body.chargeImmediately == null ? undefined : req.body.chargeImmediately
              )
            )
          );
        return;
      } catch (err) {
        if (err.httpCode === 409 || err.message.includes('El servicio está completamente reservado')) {
          res.status(409).json({ message: err.message, code: 409 });
          return;
        }
        next(err);
        return;
      }
    });

    router.patch(
      "/:bookingId",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([2, 3]),
      async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const serviceIdParam = (req.params as any).serviceId as string;
        const bookingIdParam = (req.params as any).bookingId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(serviceIdParam) ||
          IdValidator.isInvalidForRead(req.params.bookingId) ||
          BookingValidator.isInvalidForPartialUpdate(req.body)
        ) {
          res.status(400).send();
          return;
        }

        if (businessIdParam != res.locals.sub) {
          res.status(403).send();
          return;
        }

        let result: Booking;

        try {
          result = await BookingsService.partialUpdate(
            new Booking(
              bookingIdParam,
              new Business(
                businessIdParam,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
              ),
              new BusinessService(
                serviceIdParam,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                // null,
                // null
              ),
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              req.body.status == null ? undefined : req.body.status,
              req.body.serviceSnapshot == null
                ? undefined
                : new BusinessServiceSnapshot(
                  req.body.serviceSnapshot.id,
                  req.body.serviceSnapshot.serviceHash,
                  req.body.serviceSnapshot.serviceName,
                  req.body.serviceSnapshot.serviceDescription,
                  req.body.serviceSnapshot.serviceDuration,
                  req.body.serviceSnapshot.serviceDurationUnit,
                  req.body.serviceSnapshot.servicePrice,
                  req.body.serviceSnapshot.serviceCurrency,
                  // req.body.groupMeetLink == null ? undefined : req.body.groupMeetLink
                  req.body.serviceSnapshot.paymentSetting,
                  req.body.serviceSnapshot.depositAmount,
                  req.body.serviceSnapshot.eventSetting,
                  // req.body.serviceSnapshot.isCapacityVisible,
                  req.body.serviceAddress == null
                    ? undefined
                    : new Address(
                      req.body.serviceAddress.address,
                      req.body.serviceAddress.suite == null
                        ? undefined
                        : req.body.serviceAddress.suite,
                      req.body.serviceAddress.district == null
                        ? undefined
                        : req.body.serviceAddress.district,
                      req.body.serviceAddress.city == null
                        ? undefined
                        : req.body.serviceAddress.city,
                      req.body.serviceAddress.region == null
                        ? undefined
                        : req.body.serviceAddress.region,
                      req.body.serviceAddress.postcode == null
                        ? undefined
                        : req.body.serviceAddress.postcode,
                      req.body.serviceAddress.country == null
                        ? undefined
                        : req.body.serviceAddress.country,
                      req.body.serviceAddress.countryShortName == null
                        ? undefined
                        : req.body.serviceAddress.countryShortName,
                      req.body.serviceAddress.coordinates == null
                        ? undefined : new Coordinates(
                          req.body.serviceAddress.coordinates.latitude,
                          req.body.serviceAddress.coordinates.longitude
                        )
                    ),
                  req.body.serviceSnapshot.type == null ? undefined : req.body.serviceSnapshot.type,
                  req.body.serviceSnapshot.cutOff == null ? undefined : req.body.serviceSnapshot.cutOff,
                  req.body.serviceSnapshot.cutOffUnit == null ? undefined : req.body.serviceSnapshot.cutOffUnit,
                ),
              req.body.staffSnapshot == null
                ? undefined
                : new Staff(
                  req.body.staffSnapshot.id,
                  req.body.staffSnapshot.business,
                  req.body.staffSnapshot.services,
                  req.body.staffSnapshot.name,
                  req.body.staffSnapshot.email,
                  req.body.staffSnapshot.password == null ? undefined : req.body.staffSnapshot.password,
                  req.body.staffSnapshot.userId,
                  req.body.staffSnapshot.isOperatingNonStop,
                  req.body.staffSnapshot.staffHoursBlocks,
                  req.body.staffSnapshot.isActive,
                  req.body.staffSnapshot.isDeleted,
                  req.body.staffSnapshot.logo,
                  req.body.googleToken == null
                    ? undefined
                    : new GoogleToken(
                      req.body.googleToken.access_token == null
                        ? undefined
                        : req.body.googleToken.access_token,
                      req.body.googleToken.refresh_token == null
                        ? undefined
                        : req.body.googleToken.refresh_token,
                      req.body.googleToken.scope == null
                        ? undefined
                        : req.body.googleToken.scope,
                      req.body.googleToken.token_type == null
                        ? undefined
                        : req.body.googleToken.token_type,
                      req.body.googleToken.id_token == null
                        ? undefined
                        : req.body.googleToken.id_token,
                      req.body.googleToken.expiry_date == null
                        ? undefined
                        : req.body.googleToken.expiry_date
                      // req.body.syncEventToken == null ? undefined : req.body.syncEventToken
                    ),
                  req.body.googleCalendar == null
                    ? undefined
                    : req.body.googleCalendar.map(
                      (sc) =>
                        new GoogleCalendar(
                          sc.calendarId,
                          sc.status,
                          sc.name,
                          sc.isProcessing,
                          sc.lastLoggedInTime
                        )
                    ),
                  req.body.gmail == null ? undefined : req.body.gmail,
                  req.body.isConflict == null ? undefined : req.body.isConflict,
                  req.body.gPicture == null ? undefined : req.body.gPicture,
                  req.body.gName == null ? undefined : req.body.gName,
                  undefined,
                  req.body.gEventWatchId == null
                    ? undefined
                    : req.body.gEventWatchId,
                  req.body.gResourceId == null ? undefined : req.body.gResourceId,
                  req.body.syncEventToken == null
                    ? undefined
                    : req.body.syncEventToken,
                  undefined,
                  undefined
                ),
              req.body.eventType == null ? undefined : req.body.eventType,
              req.body.googleEventId == null ? undefined : req.body.googleEventId,
              req.body.calendarId == null ? undefined : req.body.calendarId,
              req.body.title == null ? undefined : req.body.title,
              req.body.creator == null ? undefined : req.body.creator,
              req.body.googleMeetLink == null ? undefined : req.body.googleMeetLink,
              undefined
            )
          );
        } catch (err) {
          next(err);
          return;
        }

        if (result == null) {
          res.status(204).send();
          return;
        }

        res.json(result);
        return;
      }
    );

    router.patch(
      "/:bookingId",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([2, 3]),
      async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const serviceIdParam = (req.params as any).serviceId as string;
        const bookingIdParam = (req.params as any).bookingId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam) ||
          IdValidator.isInvalidForRead(serviceIdParam) ||
          IdValidator.isInvalidForRead(req.params.bookingId) ||
          BookingValidator.isInvalidForPartialUpdate(req.body)
        ) {
          res.status(400).send();
          return;
        }
        if (businessIdParam != res.locals.sub) {
          res.status(403).send();
          return;
        }

        let result: Booking;

        try {
          result = await BookingsService.partialUpdate(
            new Booking(
              bookingIdParam,
              new Business(
                businessIdParam,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
              ),
              new BusinessService(
                serviceIdParam,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                // null,
                // null
              ),
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              req.body.status == null ? undefined : req.body.status,
              req.body.serviceSnapshot == null
                ? undefined
                : new BusinessServiceSnapshot(
                  req.body.serviceSnapshot.id,
                  req.body.serviceSnapshot.serviceHash,
                  req.body.serviceSnapshot.serviceName,
                  req.body.serviceSnapshot.serviceDescription,
                  req.body.serviceSnapshot.serviceDuration,
                  req.body.serviceSnapshot.serviceDurationUnit,
                  req.body.serviceSnapshot.servicePrice,
                  req.body.serviceSnapshot.serviceCurrency,
                  // req.body.serviceSnapshot.groupMeetLink == null ? undefined : req.body.serviceSnapshot.groupMeetLink
                  req.body.serviceSnapshot.paymentSetting,
                  req.body.serviceSnapshot.depositAmount,
                  req.body.serviceSnapshot.eventSetting,
                  // req.body.serviceSnapshot.isCapacityVisible,
                  req.body.serviceAddress == null
                    ? undefined
                    : new Address(
                      req.body.serviceAddress.address,
                      req.body.serviceAddress.suite == null
                        ? undefined
                        : req.body.serviceAddress.suite,
                      req.body.serviceAddress.district == null
                        ? undefined
                        : req.body.serviceAddress.district,
                      req.body.serviceAddress.city == null
                        ? undefined
                        : req.body.serviceAddress.city,
                      req.body.serviceAddress.region == null
                        ? undefined
                        : req.body.serviceAddress.region,
                      req.body.serviceAddress.postcode == null
                        ? undefined
                        : req.body.serviceAddress.postcode,
                      req.body.serviceAddress.country == null
                        ? undefined
                        : req.body.serviceAddress.country,
                      req.body.serviceAddress.countryShortName == null
                        ? undefined
                        : req.body.serviceAddress.countryShortName,
                      req.body.serviceAddress.coordinates == null
                        ? undefined : new Coordinates(
                          req.body.serviceAddress.coordinates.latitude,
                          req.body.serviceAddress.coordinates.longitude
                        )
                    ),
                  req.body.serviceSnapshot.type == null ? undefined : req.body.serviceSnapshot.type,
                  req.body.serviceSnapshot.cutOff == null ? undefined : req.body.serviceSnapshot.cutOff,
                  req.body.serviceSnapshot.cutOffUnit == null ? undefined : req.body.serviceSnapshot.cutOffUnit,
                ),
              req.body.staffSnapshot == null
                ? undefined
                : new Staff(
                  req.body.staffSnapshot.id,
                  req.body.staffSnapshot.business,
                  req.body.staffSnapshot.services,
                  req.body.staffSnapshot.name,
                  req.body.staffSnapshot.email,
                  req.body.staffSnapshot.password == null ? undefined : req.body.staffSnapshot.password,
                  req.body.staffSnapshot.userId,
                  req.body.staffSnapshot.isOperatingNonStop,
                  req.body.staffSnapshot.staffHoursBlocks,
                  req.body.staffSnapshot.isActive,
                  req.body.staffSnapshot.logo,
                  req.body.staffSnapshot.isDeleted,
                  req.body.googleToken == null
                    ? undefined
                    : new GoogleToken(
                      req.body.googleToken.access_token == null
                        ? undefined
                        : req.body.googleToken.access_token,
                      req.body.googleToken.refresh_token == null
                        ? undefined
                        : req.body.googleToken.refresh_token,
                      req.body.googleToken.scope == null
                        ? undefined
                        : req.body.googleToken.scope,
                      req.body.googleToken.token_type == null
                        ? undefined
                        : req.body.googleToken.token_type,
                      req.body.googleToken.id_token == null
                        ? undefined
                        : req.body.googleToken.id_token,
                      req.body.googleToken.expiry_date == null
                        ? undefined
                        : req.body.googleToken.expiry_date
                      // req.body.syncEventToken == null ? undefined : req.body.syncEventToken
                    ),
                  req.body.googleCalendar == null
                    ? undefined
                    : req.body.googleCalendar.map(
                      (sc) =>
                        new GoogleCalendar(
                          sc.calendarId,
                          sc.status,
                          sc.name,
                          sc.isProcessing,
                          sc.lastLoggedInTime
                        )
                    ),
                  req.body.gmail == null ? undefined : req.body.gmail,
                  req.body.isConflict == null ? undefined : req.body.isConflict,
                  req.body.gPicture == null ? undefined : req.body.gPicture,
                  req.body.gName == null ? undefined : req.body.gName,
                  undefined,
                  req.body.gEventWatchId == null
                    ? undefined
                    : req.body.gEventWatchId,
                  req.body.gResourceId == null ? undefined : req.body.gResourceId,
                  req.body.syncEventToken == null
                    ? undefined
                    : req.body.syncEventToken,
                  undefined,
                  undefined
                ),
              req.body.eventType == null ? undefined : req.body.eventType,
              req.body.googleEventId == null ? undefined : req.body.googleEventId,
              req.body.calendarId == null ? undefined : req.body.calendarId,
              req.body.title == null ? undefined : req.body.title,
              req.body.creator == null ? undefined : req.body.creator,
              req.body.googleMeetLink == null ? undefined : req.body.googleMeetLink,
              undefined
            )
          );
        } catch (err) {
          next(err);
          return;
        }

        if (result == null) {
          res.status(204).send();
          return;
        }

        res.json(result);
        return;
      }
    );


  }

  private static areGetParamsInvalid(
    statusParam: string,
    pastParam: string,
    fromParam: string,
    toParam: string
  ): boolean {
    const validationSchema = Joi.object({
      status: Joi.string()
        .valid(
          ...Object.values(BookingStatus).filter((bs) => typeof bs === "string")
        )
        .optional(),
      past: Joi.boolean().optional(),
      from: Joi.date().optional(),
      to: Joi.when("from", {
        is: Joi.date().required(),
        then: Joi.date().greater(Joi.ref("from")).optional(),
        otherwise: Joi.date().optional(),
      }),
    })
      .oxor("past", "from")
      .oxor("past", "to");

    const validationPayload = {
      status: statusParam,
      past: pastParam,
      from: fromParam,
      to: toParam,
    };

    return BaseValidator.isInvalidForSchema(
      validationPayload,
      validationSchema
    );
  }

}
