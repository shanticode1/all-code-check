import { Router } from "express"
import * as Joi from "joi"

import { AuthMiddleware } from "../middleware/auth.middleware"
import { BusinessesService } from "../services/businesses.service"
import { Address } from "../types/address"
import { Business } from "../types/business"
import { BusinessHoursBlock } from "../types/business-hours-block"
import { BusinessService } from "../types/business-service"
import { BusinessType } from "../types/business-type"
import { Coordinates } from "../types/coordinates"
import { Currency } from "../types/enums/currency"
import { ServiceCategory } from "../types/service-category"
import { TimeZone } from "../types/time-zone"
import { BaseValidator } from "../validators/base.validator"
import { BusinessValidator } from "../validators/business.validator"
import { IdValidator } from "../validators/id.validator"
import { BusinessSettings } from "../types/business-settings"
import { BusinessNotes } from "../types/business-notes"
import { BusinessSocialMedias } from "../types/business-social-medias"
import { MembershipTier } from "../types/enums/membership-tier.enum"
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model"
import { BookingDbModel, IBooking } from "../db-models/booking.db-model"
import { Logger } from "../logger"
import { ClientDbModel } from "../db-models/client.db-model"
import { Client } from "../types/clients"

export abstract class AdminRoutes {
	public static adminPath = '/__admin'

	public static addAdminRoutes(): Router {
		const router = Router()
		AdminRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router): void {
		router.get('/',
			AuthMiddleware.getAuthFunction(),
			async (req, res, next) => {
				const pageParam = (req.query as any).pageNumber as number;
				const sizeParam = (req.query as any).pageSize as number;
				const searchParam = (req.query as any).mail as string;

				if (res.locals.userId != '62c4f7b5c05cd410fb4eaf36') {
					res.status(400).send()
					return
				}
				const page = pageParam ? pageParam : 1;
				const size = sizeParam ? sizeParam : 100;
				try {
					res.json(await BusinessesService.getAllForAdmin(page, size, searchParam))
					return
				} catch (err) {
					next(err)
					return
				}
			})

		router.get("/businesswithbooking", AuthMiddleware.getAuthFunction(), async (req, res, next) => {
			try {
				let businessDocs: IBusiness[]

				try {
					businessDocs = await BusinessDbModel.BusinessModel.find({ isActive: true, isDeleted: false }).exec()
				} catch (err) {
					Logger.logger.error("Failed to get businesses", err)
				}

				console.log('Total Active Businesses: ', businessDocs.length);

				let count = 0;
				for await (const b of businessDocs) {
					//get number of bookings
					let bookings = await BookingDbModel.BookingModel.find({ businessId: b.id }).exec();
					if (bookings && bookings.length > 5) {
						count = count + 1;
					}
				}

				console.log('Total Active Businesses with 5 Bookings: ', count);

				return res.json('OK');
			} catch (err) {
				next(err);
				return;
			}
		});

		router.get("/updateclient", AuthMiddleware.getAuthFunction(), async (req, res, next) => {
			try {
				let bookingDocs: IBooking[]

				try {
					bookingDocs = await BookingDbModel.BookingModel.find().exec()

					for await (const currentBooking of bookingDocs) {
						try {
							//Check if email exists in client collection
							let client = await ClientDbModel.ClientModel.findOne({ email: currentBooking.customer.email, businessId: currentBooking.businessId }).exec();

							if (client) {
								//Client Exist: Update booking doc
								currentBooking.clientId = client.id;
								await currentBooking.save();

								//check if lastbookingDate exist and is less than current doc
								let bookingDate = currentBooking._id.getTimestamp();
								if (client.lastBookingDate && client.lastBookingDate < bookingDate) {
									client.lastBookingDate = bookingDate
									await client.save();
								}

							} else {
								//Add new client.
								let client = new Client("", currentBooking.businessId, currentBooking.customer.email, currentBooking.customer.name, currentBooking.customer.surname, currentBooking.customer.phoneNumber, currentBooking.customer.countryCode, currentBooking._id.getTimestamp(), "", currentBooking.customer.isWhatsAppAllow, currentBooking.customer.isEmailAllow, [])

								ClientDbModel.convertToDbModel(client);
								let newClient = await ClientDbModel.ClientModel.create(client);

								// Attach new Client ID to booking
								currentBooking.clientId = newClient.id;
								await currentBooking.save();
							}
						} catch (err) {

						}
					}
				} catch (err) {
					console.log(err)
					Logger.logger.error("Failed to update clients", err)
				}

				return res.json('OK');
			} catch (err) {
				next(err);
				return;
			}
		});
	}
}

