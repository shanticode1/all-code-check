import { Router } from "express"

import { TimeZonesService } from "../services/time-zones.service"
import { IdValidator } from "../validators/id.validator"


export abstract class TimeZonesRoutes {
	public static timeZonesPath = '/time-zones'

	public static addTimeZonesRoutes(): Router {
		const router = Router()
		TimeZonesRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router): void {

		router.get('/:timeZoneId', async (req, res, next) => {

			if (IdValidator.isInvalidForRead(req.params.timeZoneId)) {
				res.status(400).send()
				return
			}

			try {
				res.json(await TimeZonesService.getById(req.params.timeZoneId))
				return
			} catch (err) {
				next(err)
				return
			}
		})

		router.get('/', async (req, res, next) => {

			try {
				res.json(await TimeZonesService.get())
				return
			} catch (err) {
				next(err)
				return
			}

		})

		router.get('/google/time-zone', async (req, res, next) => {			
			const latParam = req.query.lat as string
			const lngParam = req.query.lng as string
			try {
				res.json(await TimeZonesService.getGoogleTimeZone(latParam, lngParam))
				return
			} catch (err) {
				console.log(err,'---err');
				next(err)
				return
			}

		})
	}

}