import { Router } from "express"
import { Logger } from "../logger";
import { AuthMiddleware } from "../middleware/auth.middleware"
import { BusinessServicesService } from "../services/business-services.service";
import { BusinessesService } from "../services/businesses.service";
import { StaffService } from "../services/staff.service";
import { StripeService } from "../services/stripe.service"
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { staffCount, whatsAppCreditsMap } from "../data/whatsappTemplateMap";
import { ProductToPriceMap } from "../data/productToPriceMap";
import { PricesDbModel } from "../db-models/prices.db.model";
import { IBusiness } from "../db-models/business.db-model";
import { PaymentValidator } from "../validators/payment.validator";
import { DatabaseError } from "../errors/database.error";
import { planType } from "../data/whatsAppProductAndCurrency";
import { GoogleService } from "../services/google.service";
import { trialEnum } from "../types/enums/ModalType.enum";
import { UserService } from "../services/users.service";
import { defaultCurrency } from "../data/whatsAppProductAndCurrency";
import { roleNames, roles } from "../data/user.roles";
import { BookingsService } from "../services/bookings.service";
import { BookingStatus } from "../types/enums/booking.status";
import { BookingDbModel } from "../db-models/booking.db-model";
import { EmailService } from "../services/email.service";
import { BusinessServiceSnapshotsService } from "../services/business-service-snapshots.service";
import { TimeZonesService } from "../services/time-zones.service";
import { BusinessMembershipService } from "../services/business-services-membership.service ";
import { ClientMembershipService } from "../services/client-services-membership.service ";
import { TimeSlotService } from "../services/time-slot-service";
import { PaymentStatus } from "../types/enums/payment.status";
import { ClientService } from "../services/client.service";

const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
export abstract class PaymentRoutes {
	public static paymentPath = '/payments'

	public static addPaymentRoutes(): Router {
		const router = Router()
		PaymentRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router) {
		router.post('/create-customer',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([2]),
			async (req, res, next) => {
				let result: any

				if (req.body.businessId != res.locals.userId) {
					res.status(403).send()
					return
				}

				try {
					result = await StripeService.createCustomerV2(req.body.businessId, req.body.name, req.body.email, null)
					res.json(result)
				} catch (err) {
					next(err)
					return
				}

				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})

		router.post('/create-checkout-session',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([2]),
			async (req, res, next) => {
				let result: any
				try {
					// const isValid = PaymentValidator.isInvalidForCreateOrUpdate(req.body);
					// if (isValid) {
					// 	res.status(400).json({ message: `${isValid}` })
					// 	return
					// }
					const categoryParam = (req.query as any).category as string;
					const countryShortName = req.cookies.countryShortName || defaultCurrency;
					result = await StripeService.createCheckoutSessionV2(req.body.customerId, req.body.priceId, req.body.quantity, categoryParam, countryShortName, req.body.operationType)
					res.json(result)
				} catch (err) {
					next(err)
					// res.status(500).json({ message: err.message })
					// res.status(500).send(err.message)
					return;
				}

				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})

		router.post('/membership/create-checkout-session',
			AuthMiddleware.getAuthFunction(),
			// AuthMiddleware.userRole([roles.Client]),
			async (req, res, next) => {
				let result: any
				try {
					const isValid = PaymentValidator.isInvalidForCreateMembership(req.body);
					if (isValid) {
						res.status(400).json({ message: `${isValid}` })
						return
					}
					result = await StripeService.createMembershipCheckoutSession(res.locals.userId, req.body.membershipId, req.body.quantity)
					res.json(result)
				} catch (err) {
					next(err)
					// res.status(500).json({ message: err.message })
					// res.status(500).send(err.message)
					return;
				}

				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})

		router.post('/create-billing-session',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([2]),
			async (req, res, next) => {
				let result: any
				try {
					// if (PaymentValidator.isInvalidForRead(req.body)) {
					// 	res.status(400).send()
					// 	return
					// }
					result = await StripeService.createBillingSession(req.body.customerId)
					res.json({ url: result.url });
				} catch (err) {
					next(err)
					return
				}
				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})

		router.patch('/upgrade-checkout-session',
			AuthMiddleware.getAuthFunction(),
			async (req, res, next) => {
				let result: any
				try {
					const categoryParam = (req.query as any).category as string;
					const countryShortName = req.cookies.countryShortName || defaultCurrency;
					result = await StripeService.createUpgradeCheckoutSession(req.body.customerId, req.body.priceId, categoryParam, countryShortName)
					res.json(result)
				} catch (err) {
					next(err)
					return;
				}

				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})

		router.get('/plan/list',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([2]),
			async (req, res, next) => {
				let result: any;
				try {

					const categoryParam = (req.query as any).category as string;
					const countryShortName = req.cookies.countryShortName || defaultCurrency;
					result = await StripeService.getPricesByProductId(categoryParam, res.locals.userId, countryShortName);
					res.json(result)
				} catch (err) {
					next(err)
					return
				}

				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})


		router.post('/account-onboarding',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([2]),
			async (req, res, next) => {
				let result: any
				try {
					result = await StripeService.createAccountOnboardingLink(req.body.businessId)
					res.json(result)
				} catch (err) {
					if (err.httpCode === 409) {
						res.status(409).json({ message: err.message, code: err.httpCode });
						return;
					}
					next(err)
					return
				}

				if (result == null) {
					res.status(204).send()
					return
				}
				return
			})

		// delete google token
		router.delete(
			"/disconnect",
			AuthMiddleware.getAuthFunction(),
			async (req, res, next) => {
				let result;
				try {
					const userId = res.locals.sub;
					const roleId = parseInt(res.locals.role);
					if (roleId === roles.Business) {
						result = await StripeService.disconnectStripeAccount(userId)
					}
				} catch (err) {
					next(err);
					return;
				}
				if (result == null) {
					res.status(204).send();
					return;
				}
				res.json(result);
				return;
			}
		);

		router.post('/webhook', async (request: any, response) => {
			const sig = request.headers['stripe-signature'];
			const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;
			// local token
			// const endpointSecret = 'whsec_5kWqlPoPcmukAHW4QzlAsdtFVmM8suXw';
			let event;
			try {
				event = stripe.webhooks.constructEvent(request.rawBody, sig, endpointSecret);
			} catch (err) {
				Logger.logger.error('stripe webhook error:', err.message);
				response.status(400).send(`Webhook Error: ${err.message}`);
				return;
			}
			let currentBusinessDoc: any;
			let currentBookingDoc: any;
			let data = event.data.object;
			Logger.logger.info(`Stripe webhook event received: ${event.type}`);
			// Handle the event
			switch (event.type) {
				case 'customer.subscription.created': {
					currentBusinessDoc = await BusinessesService.getBusinessDocByStripeCustomerId(data.customer)
					if (currentBusinessDoc) {
						try {
							const isProd = process.env.NODE_ENV.toLowerCase() == "production";
							// this is for run old plans
							if (isProd) {
								if (ProductToPriceMap.prod.PLUS.includes(data.plan.id)) {
									currentBusinessDoc.membershipTier = MembershipTier.Plus;
								}
								if (ProductToPriceMap.prod.PRO.includes(data.plan.id)) {
									currentBusinessDoc.membershipTier = MembershipTier.Pro;
									// currentBusinessDoc.membershipStaffCount = staffCount.count;
								}
							} else {
								if (ProductToPriceMap.test.PLUS.includes(data.plan.id)) {
									currentBusinessDoc.membershipTier = MembershipTier.Plus;
								}

								if (ProductToPriceMap.test.PRO.includes(data.plan.id)) {
									currentBusinessDoc.membershipTier = MembershipTier.Pro;
									// currentBusinessDoc.membershipStaffCount = staffCount.count;
								}
							}
							// this for new dynamic price data
							if (data.plan.usage_type == planType.LICENSED) {
								if (currentBusinessDoc.stripePriceIds == undefined) {
									currentBusinessDoc.stripePriceIds = {
										oneTimePriceId: '',
										recurringPriceId: '',
										usagePriceId: ''
									}
								}
								currentBusinessDoc.stripePriceIds['recurringPriceId'] = data.metadata && data.plan.metadata.category === 'regular-plan' ? data.plan.id : '';

								if (data.plan && data.plan.metadata && data.plan.metadata['type']) {
									currentBusinessDoc.membershipTier = Number(data.plan.metadata['type']);
									// currentBusinessDoc.membershipStaffCount = data.plan.metadata['staff_count'] ? data.plan.metadata['staff_count'] : 0;
								}
								if (data.plan && data.plan.metadata && data.plan.metadata['type'] == 2) {
									// currentBusinessDoc.membershipStaffCount = 4;
									// create staff plan 
									// await StripeService.createStaffPlanForPro(data.customer, currentBusinessDoc, data.plan.currency, data)
								}
							}
							// add staff with plan
							if (data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan')) {
								currentBusinessDoc.subscriptionId = data.id;
							}

							// old check
							// currentBusinessDoc.stripeOnTrial = true;
							currentBusinessDoc.stripePlanStatus = data.status
							if (data.status === "trialing") {
								currentBusinessDoc.stripeOnTrial = true;
								// save trial month date for add next month credits
								currentBusinessDoc.trialMonthDate = new Date(data.current_period_end * 1000)
								// hide for prod
								if (data.plan.usage_type == planType.LICENSED && data.plan && data.plan.metadata['trial_whatsapp_credits']) {
									// for new user set email and whatsapp by default true
									currentBusinessDoc.whatsAppCredits = Number(data.plan.metadata['trial_whatsapp_credits']);
									currentBusinessDoc.settings.isWhatsAppReminder = true;
									currentBusinessDoc.settings.isEmailReminder = true;
								}
							} else if (data.status === 'active') {
								// currentBusinessDoc.stripePlanStatus = data.status
								// hide for prod
								if (data.plan && data.plan.metadata && data.plan.usage_type == planType.LICENSED['whatsapp_credits']) currentBusinessDoc.whatsAppCredits = Number(data.plan.metadata['whatsapp_credits'])
							}
							if (data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan')) {
								currentBusinessDoc.membershipExpirationDate = new Date(data.current_period_end * 1000);
							}
							// currentBusinessDoc.staffMembershipExpirationDate = new Date(data.current_period_end * 1000)
							if (data.items.data.find(item => item.plan.id && item.plan.metadata['category'] === 'staff')) currentBusinessDoc.staffMembershipExpirationDate = new Date(data.current_period_end * 1000);
							currentBusinessDoc.isTrialActivatedOnce = true;
							currentBusinessDoc.isTrialOnce = trialEnum.isTrial
							// whatsApp subscriptions updates... and add credits to customer
							const updates = await this.updateWhatsappSubscription(currentBusinessDoc, data, "create");
							currentBusinessDoc = updates;
							await currentBusinessDoc.save()
						} catch (err) {
							Logger.logger.error(`Failed on customer.subscription.created: ${currentBusinessDoc.stripeCustomerId}`, err)
							// throw new DatabaseError(`Failed on customer.subscription.created: ${currentBusinessDoc.stripeCustomerId}`)
						}
					}
					break;
				}

				case "customer.subscription.updated": {
					//started trial
					currentBusinessDoc = await BusinessesService.getBusinessDocByStripeCustomerId(data.customer)
					if (currentBusinessDoc) {
						try {
							const isProd = process.env.NODE_ENV.toLowerCase() == "production";
							let planId = '';
							if (data.plan && data.plan.id) {
								planId = data.plan.id
							} else {
								const planInfo = data.items.data.find(item => item.plan.id && item.metadata['category'] !== 'staff');
								planId = planInfo.plan.id
							}
							// with old price
							if (data.plan && data.plan.id) {
								if (isProd) {
									if (ProductToPriceMap.prod.PLUS.includes(planId)) {
										currentBusinessDoc.membershipTier = MembershipTier.Plus;
										await StaffService.updateBusinessStaffToFreeTier(currentBusinessDoc.id);
									}
									if (ProductToPriceMap.prod.PRO.includes(planId)) {
										currentBusinessDoc.membershipTier = MembershipTier.Pro;
										// currentBusinessDoc.membershipStaffCount = staffCount.count;
									}
								} else {
									if (ProductToPriceMap.test.PLUS.includes(planId)) {
										currentBusinessDoc.membershipTier = MembershipTier.Plus;
										await StaffService.updateBusinessStaffToFreeTier(currentBusinessDoc.id);
									}
									if (ProductToPriceMap.test.PRO.includes(planId)) {
										currentBusinessDoc.membershipTier = MembershipTier.Pro;
										// currentBusinessDoc.membershipStaffCount = staffCount.count;
									}
								}
							}
							if (currentBusinessDoc.stripePriceIds && currentBusinessDoc.stripePriceIds.recurringPriceId !== planId && data.items && data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan')) {
								currentBusinessDoc.stripePriceIds.recurringPriceId = planId
							}
							// with new dynamic price 
							if (currentBusinessDoc.stripePriceIds && currentBusinessDoc.stripePriceIds.recurringPriceId === planId && data.items && data.items.data.find(item => item.plan.id && item.plan.metadata['type'] == 1)) {
								currentBusinessDoc.membershipTier = MembershipTier.Plus;
								await StaffService.updateBusinessStaffToFreeTier(currentBusinessDoc.id);
							}
							else {
								if (currentBusinessDoc.stripePriceIds == undefined) {
									currentBusinessDoc.stripePriceIds = {
										oneTimePriceId: '',
										recurringPriceId: '',
										usagePriceId: ''
									}
								}
								if (currentBusinessDoc && (currentBusinessDoc.stripePriceIds['recurringPriceId'] === null || currentBusinessDoc.stripePriceIds['recurringPriceId'] === '' || currentBusinessDoc.stripePriceIds['recurringPriceId'] === undefined) && data.items && data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan')) {
									currentBusinessDoc.stripePriceIds['recurringPriceId'] = planId;
								}
							}
							if (currentBusinessDoc.stripePriceIds && currentBusinessDoc.stripePriceIds.recurringPriceId === planId && data.items && data.items.data.find(item => item.plan.id && item.plan.metadata['type'] == 2)) {
								currentBusinessDoc.membershipTier = MembershipTier.Pro;
								// currentBusinessDoc.membershipStaffCount = data.plan.metadata['staff_count'] ? data.plan.metadata['staff_count'] : 0;
							}
							// currentBusinessDoc.subscriptionId = data.id;
							if (data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan')) {
								currentBusinessDoc.subscriptionId = data.id;
							}
							currentBusinessDoc.stripePlanStatus = data.status
							const isOnTrial = data.status === "trialing"
							let expDate = new Date(0);
							expDate.setUTCSeconds(data.current_period_end);
							/**  update membership Expiration Date  */
							if (data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan')) {
								currentBusinessDoc.membershipExpirationDate = expDate;
							}
							if (isOnTrial) {
								currentBusinessDoc.stripeOnTrial = true
								// currentBusinessDoc.membershipExpirationDate = expDate;

								if (data.items.data.find(item => item.plan.id && item.metadata['category'] === 'staff')) currentBusinessDoc.staffMembershipExpirationDate = expDate;
								// await BusinessesService.updateTrailOnce(data.customer)
							}
							else if (data.status === "active") {
								currentBusinessDoc.stripeOnTrial = false
								// hide for prod
								// if (data.plan.usage_type == planType.LICENSED && data.plan.metadata) currentBusinessDoc.whatsAppCredits = Number(data.plan.metadata['whatsapp_credits'])

								// currentBusinessDoc.membershipExpirationDate = expDate;

								// this for when next billing for pro and plus users
								if (currentBusinessDoc.membershipTier == MembershipTier.Plus || currentBusinessDoc.membershipTier == MembershipTier.Pro) {
									currentBusinessDoc.settings.isWhatsAppReminder = true;
								}
							}
							// whatsApp subscriptions updates... and add credits to customer 
							const updates = await this.updateWhatsappSubscription(currentBusinessDoc, data, "");
							currentBusinessDoc = updates;
							await currentBusinessDoc.save()
						} catch (err) {
							Logger.logger.error(`Failed on customer.subscription.updated: ${data.customer}`, err)
							// throw new DatabaseError(`Failed on customer.subscription.updated: ${currentBusinessDoc.stripeCustomerId}`)
						}
					}
					break
				}

				case "checkout.session.completed": {
					// when checkout is completed allow credits to user , save and update data after payment event completed
					currentBusinessDoc = data.customer ? await BusinessesService.getBusinessDocByStripeCustomerId(data.customer) : null;
					if (data.metadata && !data.metadata.bookingId && currentBusinessDoc) {
						try {
							if (currentBusinessDoc.stripePriceIds == undefined) {
								currentBusinessDoc.stripePriceIds = {
									oneTimePriceId: '',
									recurringPriceId: '',
									usagePriceId: ''
								}
							}
							if (data.mode === 'payment' && data.status === "complete" && !data.metadata.membershipId) {
								// save user bags qty 
								const bagsQty = data.metadata && data.metadata.quantity ? data.metadata.quantity : 1;
								// currentBusinessDoc.stripePriceIds['oneTimePriceId'] = data.metadata && data.metadata.priceId;
								currentBusinessDoc.whatsAppBagsCredits = currentBusinessDoc.whatsAppBagsCredits + (Number(data.metadata.whatsapp_credits) * Number(bagsQty))
								currentBusinessDoc.whatsappBagsQuantity = bagsQty;
							}
							// update existing sunscription with new item and payment with new card
							if (data && data.mode === 'setup' && data.status === "complete" && data.metadata && data.metadata.update_subscription) {
								const currentCustomer = await stripe.customers.retrieve(data.customer)
								const defaultPaymentId = currentCustomer.invoice_settings.default_payment_method;
								const paymentDetails = await stripe.setupIntents.retrieve(data.setup_intent);
								const subscriptionId = data.metadata.subscription_id;
								const staffQty = Number(data.metadata.quantity);
								await stripe.subscriptions.update(subscriptionId, {
									default_payment_method: paymentDetails.payment_method,
								});
								// const subscriptions = await stripe.subscriptions.list({
								// 	customer: currentBusinessDoc.stripeCustomerId,
								// 	status: 'active'
								// });
								// if need open that
								// const statuses = ['active', 'trialing'];

								// const subscriptionPromises = statuses.map(status =>
								// 	stripe.subscriptions.list({
								// 		customer: currentBusinessDoc.stripeCustomerId,
								// 		status,
								// 	})
								// );

								// const results = await Promise.all(subscriptionPromises);
								// const res: any = results.flatMap(result => result.data);
								// const planData = res.find(subscription =>
								// 	subscription.items?.data?.some(item =>
								// 		item.plan &&
								// 		item.plan.usage_type === planType.LICENSED &&
								// 		item.plan.metadata?.category === 'regular-plan'
								// 	)
								// );
								const subscription = await stripe.subscriptions.retrieve(subscriptionId);
								const itemToUpdate = subscription.items.data.find(
									(item) => item.price.id === data.metadata.price_id
								);

								if (!itemToUpdate && data.metadata.method_type === 'create') {
									await stripe.subscriptionItems.create({
										subscription: data.metadata.subscription_id,
										price: data.metadata.price_id,
										quantity: staffQty,
										proration_behavior: 'always_invoice', //pay at a time
									});
									currentBusinessDoc.membershipStaffCount = Number(staffQty);
								}
								if (data.metadata.method_type === 'update') {
									await stripe.subscriptionItems.update(
										itemToUpdate.id,  //data.metadata.item_id
										{
											quantity: staffQty,
											proration_behavior: 'always_invoice',
										}
									);
									currentBusinessDoc.membershipStaffCount = Number(staffQty);
								}
								await stripe.subscriptions.update(subscriptionId, {
									default_payment_method: defaultPaymentId,
								});
								if (data && data.items && data.items.data && data.items.data.find(item => item.plan.id && item.metadata['category'] === 'staff')) {
									currentBusinessDoc.membershipStaffCount = Number(staffQty);
									currentBusinessDoc.stripePriceIds['staffUsagePriceId'] = data.metadata.price_id
								}
							}
							currentBusinessDoc.stripePriceIds = PricesDbModel.convertToDbModel(currentBusinessDoc.stripePriceIds)
							// const updates = await this.updateWhatsappSubscription(currentBusinessDoc, data, "");
							// currentBusinessDoc = updates;
							await currentBusinessDoc.save();
						} catch (err) {
							Logger.logger.error(`Failed on case "checkout.session.completed: ${data.customer}`, err)
							// throw new DatabaseError(`Failed on checkout.session.completed: ${currentBusinessDoc.stripeCustomerId}`)
						}
					}
					// update booking after payment success
					// the JSON string into an object
					// Now you can access the flags
					if (data.payment_status === 'paid' && data.metadata.bookingId) {
						const { bookingId, isDepositPaid, isRemainingPaid, isFullPaid, fromBusiness } = data.metadata;
						currentBookingDoc = await BookingsService.getBookingDocById(bookingId)
						if (currentBookingDoc) {
							const businessDoc = await BusinessesService.getBusinessDocById(currentBookingDoc.businessId);
							// const isTransfered = await StripeService.processTransfer(paymentIntentId, businessDoc.stripeConnectAccountId)
							try {
								// update payment status after customer submit payment details
								currentBookingDoc.paymentStatus = data.payment_status;
								const promoCodeId = data.discounts.length > 0 ? data.discounts[0].promotion_code : null;
								const promoCode = promoCodeId ? await stripe.promotionCodes.retrieve(promoCodeId) : null;
								const stripePromoCode = promoCode ? promoCode.code : null;
								currentBookingDoc.promoCode = stripePromoCode;
								currentBookingDoc.paidAmount = data.amount_total ? data.amount_total : '';
								if (isDepositPaid == 'true') {
									currentBookingDoc.isDepositPaid = true;
									currentBookingDoc.link = null;
									currentBookingDoc.status = BookingStatus.Approved;
								}
								if (isRemainingPaid == 'true') {
									currentBookingDoc.isRemainingPaid = true;
									currentBookingDoc.link = null;
									currentBookingDoc.status = BookingStatus.Approved;
								}
								if (isFullPaid == 'true') {
									currentBookingDoc.isFullPaid = true;
									currentBookingDoc.link = null;
									currentBookingDoc.status = BookingStatus.Approved;
								}
								currentBookingDoc.isNoRequired = false;
								// check business auto approve booking and send email to customer
								if (businessDoc.settings.bookingAutoapprove) {
									currentBookingDoc.status = BookingStatus.Approved;
								}
								if (fromBusiness == 'true') {
									currentBookingDoc.status = BookingStatus.Approved;
								}
								if (data.metadata && data.metadata.membershipId) {
									currentBookingDoc.isPaidByMembership = true;
								}
								await currentBookingDoc.save()
								const eixtingBooking = BookingDbModel.convertToDomainModel(currentBookingDoc)
								await BookingsService.partialUpdate(eixtingBooking);
							} catch (err) {
								Logger.logger.error(`Failed on checkout.session.completed`, err)
							}
						}
					}
					if (data.payment_status === 'paid' && data.metadata.membershipId) {
						const { clientMembershipId, clientId } = data.metadata;
						const { currentMembershipDoc, membershipSnapshot } = await ClientMembershipService.getByClientMembershipDocId(clientMembershipId);
						const currentClientDoc = await ClientService.getByClientId(clientId);
						const currentBusiness = await BusinessesService.getBusinessDocById(currentMembershipDoc.businessId);
						const bookingLimit = membershipSnapshot.membershipPackageSetting.reduce((sum: number, item: { bookingQuantity: number }) => sum + item.bookingQuantity, 0);
						if (currentMembershipDoc) {
							// const isTransfered = await StripeService.processTransfer(paymentIntentId, businessDoc.stripeConnectAccountId)
							try {
								// update payment status after customer submit payment details
								currentMembershipDoc.paymentStatus = 'Paid';
								//Save as UTC
								currentMembershipDoc.purchaseDate = new Date();
								// send email to customer for package purchase
								await EmailService.sendPackagePurchaseToCustomer(currentBusiness, currentClientDoc, membershipSnapshot, bookingLimit)
								await currentMembershipDoc.save();
							} catch (err) {
								Logger.logger.error(`Failed on checkout.session.completed`, err)
							}
						}
					}

					break
				}

				case "customer.subscription.deleted": {
					currentBusinessDoc = await BusinessesService.getBusinessDocByStripeCustomerId(data.customer)
					if (currentBusinessDoc) {
						try {
							//Set to FREE tier
							// this condition for old price and plan
							let isSubscriptionDelete = false;
							const isProd = process.env.NODE_ENV.toLowerCase() == "production";
							// with old price
							if (isProd) {
								if (data.items.data.find(item => ProductToPriceMap.prod.PLUS.includes(item.plan.id))) {
									isSubscriptionDelete = true;
								}
								if (data.items.data.find(item => ProductToPriceMap.prod.PRO.includes(item.plan.id))) {
									isSubscriptionDelete = true;
								}
							} else {
								if (data.items.data.find(item => ProductToPriceMap.test.PLUS.includes(item.plan.id))) {
									isSubscriptionDelete = true;

								}
								if (data.items.data.find(item => ProductToPriceMap.test.PRO.includes(item.plan.id))) {
									isSubscriptionDelete = true;
								}
							}
							// this condition based on new plan and priceId
							if (currentBusinessDoc.stripePriceIds && data.items.data.find(item => item.plan.id === currentBusinessDoc.stripePriceIds.recurringPriceId)) {
								isSubscriptionDelete = true;
							}
							if (isSubscriptionDelete) {
								currentBusinessDoc.stripePlanStatus = data.status
								currentBusinessDoc.membershipTier = MembershipTier.Free
								// reset payment  accept process
								currentBusinessDoc.isPaymentMethodConnected = false;
								currentBusinessDoc.stripeOnTrial = false;
								currentBusinessDoc.membershipExpirationDate = null;
								currentBusinessDoc.settings.bookingAutoapprove = false;
								currentBusinessDoc.settings.paymentTypes = [];
								currentBusinessDoc.whatsAppCredits = 0;
								currentBusinessDoc.stripePriceIds ? currentBusinessDoc.stripePriceIds['recurringPriceId'] = '' : null;
								// currentBusinessDoc.membershipStaffCount = 0;
								// currentBusinessDoc.buyExtraStaffCount = 0;
								currentBusinessDoc.subscriptionId = '';
								// currentBusinessDoc.isStaffPaymentPaid = true;
								// currentBusinessDoc.isAnnualActive = false;

								// reset retry count and billing status
								currentBusinessDoc.paymentRetryCount = 0;
								currentBusinessDoc.planBillingStatus = null;
								currentBusinessDoc.isAccessPaused = false;
								currentBusinessDoc.paymentFailedAt = null;
								await BusinessServicesService.updateBusinessServicesToFreeTier(currentBusinessDoc.id);
								await StaffService.updateBusinessStaffToFreeTier(currentBusinessDoc.id);

								// remove google saved event and stop webhook when plan Expired 
								const userDoc = await UserService.getUserById(currentBusinessDoc.userId)
								await GoogleService.deleteSavedGoogleEvents(currentBusinessDoc, userDoc.role)
								currentBusinessDoc.isAnnualActive = false;
								/** reset the service week days based on business */
								await BusinessServicesService.updateBusinessServicesDays(currentBusinessDoc)
							}
							if (currentBusinessDoc.stripePriceIds && data.items.data.find(item => item.plan.id === currentBusinessDoc.stripePriceIds.usagePriceId)) {
								currentBusinessDoc.stripePayAsYouGoOnTrial = false;
								currentBusinessDoc.whatsAppPayAsYouGoExpirationdate = null;
								currentBusinessDoc.whatsAppPayAsYouGoMembershipTier = MembershipTier.Free;
								currentBusinessDoc.stripePriceIds.usagePriceId = ''
								currentBusinessDoc.whatsAppPayAsYouGoCredits = 0;
								// currentBusinessDoc.settings.isWhatsAppReminder = false;
								currentBusinessDoc.buyExtraStaffCount = 0
							}
							// DELETE staff separate plan
							if (currentBusinessDoc.stripePriceIds && data.items.data.find(item => item.plan.id === currentBusinessDoc.stripePriceIds.staffUsagePriceId)) {
								currentBusinessDoc.isStaffPaymentPaid = true;
								currentBusinessDoc.stripePriceIds.staffUsagePriceId = ''
								currentBusinessDoc.staffMembershipExpirationDate = null;
								currentBusinessDoc.membershipStaffCount = 0;
							};
							await currentBusinessDoc.save()
						} catch (err) {
							Logger.logger.error(`Failed on customer.subscription.deleted: ${data.customer}`, err)
							// throw new DatabaseError(`Failed on customer.subscription.deleted: ${currentBusinessDoc.stripeCustomerId}`)
						}
					}
					break
				}

				// invoice.payment_succeeded update price after payment succeed 
				case "invoice.payment_succeeded": {
					currentBusinessDoc = await BusinessesService.getBusinessDocByStripeCustomerId(data.customer);
					if (currentBusinessDoc) {
						try {
							if (currentBusinessDoc.stripePriceIds == undefined) {
								currentBusinessDoc.stripePriceIds = {
									oneTimePriceId: '',
									recurringPriceId: '',
									usagePriceId: ''
								}
							}
							if (data & data.metadata && data.metadata.usage_type === planType.METERED) {
								currentBusinessDoc.stripePriceIds['usagePriceId'] = data.plan.id;
								// currentBusinessDoc.paymentRetryCount = 0;
								// currentBusinessDoc.planBillingStatus = PaymentStatus.Completed;
								// currentBusinessDoc.isAccessPaused = false;
								// currentBusinessDoc.paymentFailedAt = null;
							}
							if (data.lines.data.find(item => item.plan?.metadata?.category === 'regular-plan')) {
								currentBusinessDoc.paymentRetryCount = 0;
								currentBusinessDoc.planBillingStatus = PaymentStatus.Completed;
								currentBusinessDoc.isAccessPaused = false;
								currentBusinessDoc.paymentFailedAt = null;
							}
							currentBusinessDoc.stripePriceIds = PricesDbModel.convertToDbModel(currentBusinessDoc.stripePriceIds)
							await currentBusinessDoc.save();

						} catch (err) {
							Logger.logger.error(`Failed on case "payment_intent.succeeded: ${data.customer}`, err)
							// throw new DatabaseError(`Failed on custome payment_intent.succeeded: ${currentBusinessDoc.stripeCustomerId}`)
						}
					}
					break
				}

				case "invoice.paid": {
					currentBusinessDoc = await BusinessesService.getBusinessDocByStripeCustomerId(data.customer);
					if (currentBusinessDoc) {
						try {
							// && (data.subscription_details.metadata && data.subscription_details.metadata.usage_type === planType.LICENSED)
							if (data.status === 'paid' && data.lines.data.find(item => item.plan?.metadata?.category === 'regular-plan')) {
								// reset retry count and billing status
								currentBusinessDoc.paymentRetryCount = 0;
								currentBusinessDoc.planBillingStatus = null;
								currentBusinessDoc.isAccessPaused = false;
								currentBusinessDoc.paymentFailedAt = null;
								// auto active all services after plan renew 
								await BusinessServicesService.updateBusinessServicesActivateAllV2(currentBusinessDoc.id);

							}
							if (data.status === 'paid' && data.total !== 0) {
								const trialEndDate = new Date(currentBusinessDoc.trialMonthDate);
								const activeDate = new Date(data.period_end * 1000)
								// update after subscription renew again
								if ((data.lines.data.find(item => item.plan.usage_type == planType.LICENSED)) && (currentBusinessDoc.stripeOnTrial !== undefined || currentBusinessDoc.stripeOnTrial !== null) && (data.status === 'paid')) {
									// if subscription updated with active paid plan
									// await BusinessServicesService.updateBusinessServicesActivateAll(currentBusinessDoc.id);
									if (currentBusinessDoc && currentBusinessDoc.stripePriceIds && currentBusinessDoc.stripePriceIds.recurringPriceId) {
										const planDetails = data.lines.data.find(item => item.plan.id === currentBusinessDoc.stripePriceIds.recurringPriceId);
										if (planDetails && planDetails.plan && planDetails.plan.metadata) {
											//  parseInt(process.env.STRIPE_TRIAL_PERIOD)
											if (new Date(new Date(trialEndDate).toDateString()).getTime() === new Date(new Date(activeDate).toDateString()).getTime()) {
												currentBusinessDoc.whatsAppCredits = planDetails.plan.metadata['first_month_whatsapp_credits'] && Number(planDetails.plan.metadata['first_month_whatsapp_credits']);
												if (planDetails.interval === 'year') {
													currentBusinessDoc.isAnnualActive = false;
													// create staff plan for annual users
													// currentBusinessDoc.membershipStaffCount = 4;
													// await StripeService.createStaffPlanForPro(data.customer, currentBusinessDoc, data.plan.currency, data)
												}
											} else {
												currentBusinessDoc.whatsAppCredits = planDetails.plan.metadata['whatsapp_credits'] ?
													Number(planDetails.plan.metadata['whatsapp_credits']) : 0
											}
										}
									}
								}
								// update whatsapp credits of existing user with old plan 
								const isProd = process.env.NODE_ENV.toLowerCase() == "production";
								if (isProd) {
									if (data.lines.data.find(item => ProductToPriceMap.prod.PLUS.includes(item.plan.id))) {
										if (new Date(new Date(trialEndDate).toDateString()).getTime() === new Date(new Date(activeDate).toDateString()).getTime()) {
											currentBusinessDoc.whatsAppCredits = (whatsAppCreditsMap.PLUS - Number(whatsAppCreditsMap.TRIAL_PLUS))
										} else {
											currentBusinessDoc.whatsAppCredits = whatsAppCreditsMap.PLUS
										}
									}
									if (data.lines.data.find(item => ProductToPriceMap.prod.PRO.includes(item.plan.id))) {
										if (new Date(new Date(trialEndDate).toDateString()).getTime() === new Date(new Date(activeDate).toDateString()).getTime()) {
											currentBusinessDoc.whatsAppCredits = (whatsAppCreditsMap.PRO - Number(whatsAppCreditsMap.TRIAL_PRO))
										} else {
											currentBusinessDoc.whatsAppCredits = whatsAppCreditsMap.PRO
										}
									}
								} else {
									if (data.lines.data.find(item => ProductToPriceMap.test.PLUS.includes(item.plan.id))) {
										if (new Date(new Date(trialEndDate).toDateString()).getTime() === new Date(new Date(activeDate).toDateString()).getTime()) {
											currentBusinessDoc.whatsAppCredits = (whatsAppCreditsMap.PLUS - Number(whatsAppCreditsMap.TRIAL_PLUS))
										} else {
											currentBusinessDoc.whatsAppCredits = whatsAppCreditsMap.PLUS
										}
									}
									if (data.lines.data.find(item => ProductToPriceMap.test.PRO.includes(item.plan.id))) {
										if (new Date(new Date(trialEndDate).toDateString()).getTime() === new Date(new Date(activeDate).toDateString()).getTime()) {
											currentBusinessDoc.whatsAppCredits = (whatsAppCreditsMap.PRO - Number(whatsAppCreditsMap.TRIAL_PRO))
										} else if (data.lines.data.find(item => item.plan.id && item.plan.metadata && item.plan.metadata['type'] == 2)) {
											currentBusinessDoc.whatsAppCredits = whatsAppCreditsMap.PRO
										} else if (data.lines.data.find(item => item.plan.id && item.plan.metadata && item.plan.metadata['type'] == 1)) {
											currentBusinessDoc.whatsAppCredits = whatsAppCreditsMap.PLUS
										}
									}
								}
								currentBusinessDoc.settings.isWhatsAppReminder = true;
								// currentBusinessDoc.membershipStaffCount = staffCount.count;
								// currentBusinessDoc.subscriptionId = data.id;
							}
							if (data.status === 'paid') {
								// const usagePaid = data.lines.data.find(item => item.plan.usage_type == planType.METERED && item.plan.id === currentBusinessDoc.stripePriceIds.staffUsagePriceId);

								// old condtion
								// const usagePaid = data.lines.data.find(item => item.plan.usage_type == planType.LICENSED && item.plan.id === currentBusinessDoc.stripePriceIds.staffUsagePriceId);

								const staffUsagePriceId =
									currentBusinessDoc &&
									currentBusinessDoc.stripePriceIds &&
									currentBusinessDoc.stripePriceIds.staffUsagePriceId;

								const usagePaid = data.lines.data.find(item => {
									return (
										item.plan.usage_type === planType.LICENSED &&
										staffUsagePriceId &&
										item.plan.id === staffUsagePriceId
									);
								});

								if (usagePaid) {
									currentBusinessDoc.isPaymentDue = false;
									currentBusinessDoc.isStaffPaymentPaid = true;
									// const usageDate = usagePaid.period.end + 3600;
									// const totalUsagesStaffCount: number = currentBusinessDoc.membershipStaffCount + currentBusinessDoc.buyExtraStaffCount;
									// add staff if usage plan is active in next month
									// await StripeService.createStaffRecordUsage(currentBusinessDoc, totalUsagesStaffCount, usageDate);
								}
							}
							await currentBusinessDoc.save();
						} catch (err) {
							Logger.logger.error(`Failed on case "invoice.paid: ${data.customer}`, err)
							// throw new DatabaseError(`Failed on invoice.paid: ${currentBusinessDoc.stripeCustomerId}`)
						}
					}
					break
				}

				case "payment_intent.payment_failed": {
					const { bookingId, fromBusiness } = data.metadata;
					try {
						if (bookingId) {
							await BookingsService.bookingMail(bookingId, fromBusiness);
						}

						// Check if payment failed due to specific decline codes
						// && (data.last_payment_error?.decline_code === 'insufficient_funds' || data.last_payment_error?.decline_code === 'transaction_not_allowed')
						if (data.last_payment_error?.code === 'card_declined') {
							try {
								currentBusinessDoc = await BusinessesService.getBusinessDocByStripeCustomerId(data.customer);
								if (!currentBusinessDoc) return;

								const invoiceDetails = await stripe.invoices.retrieve(data?.invoice);

								// Check if main plan payment failed
								const planDetails = invoiceDetails?.lines?.data.find(
									(item) => item.plan?.id === currentBusinessDoc?.stripePriceIds?.recurringPriceId
								);
								if (planDetails) {
									const NOW = new Date();
									const GRACE_PERIOD_MS = 24 * 60 * 60 * 1000;

									currentBusinessDoc.planBillingStatus = PaymentStatus.Failed;
									currentBusinessDoc.isAccessPaused = true;
									const isGracePeriodOver = NOW.getTime() - new Date(currentBusinessDoc.paymentFailedAt).getTime() > GRACE_PERIOD_MS;
									Logger.logger.info(`Grace Period Over: ${isGracePeriodOver}`);
									// Track failure time (only first time)
									if (!currentBusinessDoc.paymentFailedAt) {
										currentBusinessDoc.paymentFailedAt = NOW;
									}

									currentBusinessDoc.paymentRetryCount = (currentBusinessDoc.paymentRetryCount || 0) + 1;
									// Retry only once — cancel subscription if payment fails again
									// Cancel ONLY if:
									// 1. Retry already happened
									// 2. 24 hours have passed
									if (currentBusinessDoc.paymentRetryCount > 1 && isGracePeriodOver) {
										// Immediately cancel the subscription
										await stripe.subscriptions.cancel(currentBusinessDoc.subscriptionId);
										currentBusinessDoc.stripePlanStatus = "canceled";
									}
									await currentBusinessDoc.save();
								}
							} catch (err) {
								console.error("Error handling card_declined event:", err);
							}
						}
					} catch (error) {
						Logger.logger.error(`payment failed error: ${error}`)
					}
					break
				}
				case "checkout.session.expired": {
					const { bookingId } = data.metadata;
					if (bookingId) {
						currentBookingDoc = await BookingsService.getBookingDocById(bookingId)
						if (currentBookingDoc) {
							try {
								currentBookingDoc.link = null;
								await currentBookingDoc.save()
							} catch (err) {
								Logger.logger.error(`Failed on checkout.session.completed`, err)
							}
						}
					}
					break
				}
				default:
					break;
			}
			// Return a 200 response to acknowledge receipt of the event
			response.send();
		});
	}

	private static async updateWhatsappSubscription(currentBusinessDoc: IBusiness, data: any, type: string) {
		try {
			// if (data.plan === null) {
			// 	const planInfo = data.items.data.filter(item => item.plan.usage_type == planType.METERED);
			// 	const staffPlanInfo = planInfo.find(dt => dt.plan.metadata['category'] === 'staff');
			// 	if (staffPlanInfo) {
			// 		data.plan = staffPlanInfo.plan;
			// 	} else {
			// 		data.plan = planInfo[0].plan;
			// 	}
			// }
			if (data.plan === null) {
				const planInfo = data.items.data.filter(item => item.plan.usage_type === planType.METERED);
				const planInfoLiC = data.items.data.filter(item => item.plan.usage_type === planType.LICENSED);
				data.plan = planInfoLiC.find(dt => dt.plan.metadata['category'] === 'staff')?.plan || planInfoLiC[0]?.plan;
			}
			// Set current user whatsapp plan values
			if (data.plan && data.plan.usage_type == planType.METERED && (data.plan.metadata && data.plan.metadata['type'])) {
				currentBusinessDoc.whatsAppPayAsYouGoMembershipTier = Number(data.plan.metadata['type']);
				// currentBusinessDoc.whatsAppPayAsYouGoCredits = Number(data.plan.metadata['whatsapp_credits'])
			}

			// if (data.plan && data.plan.usage_type == planType.METERED && (data.plan.metadata && data.plan.metadata['category'] === 'staff')) {
			// 	currentBusinessDoc.stripePriceIds['staffUsagePriceId'] = data.plan.id;
			// 	// currentBusinessDoc.whatsAppPayAsYouGoCredits = Number(data.plan.metadata['whatsapp_credits'])
			// }
			const staffId = data.items.data.find(item => item.plan.id && item.plan.metadata['category'] == 'staff');
			if (data.plan && data.plan.usage_type == planType.LICENSED && staffId) {
				currentBusinessDoc.stripePriceIds['staffUsagePriceId'] = data.plan.id;
				// currentBusinessDoc.whatsAppPayAsYouGoCredits = Number(data.plan.metadata['whatsapp_credits'])
				currentBusinessDoc.membershipStaffCount = staffId.quantity ? staffId.quantity : 0;
			}
			else if (staffId === undefined) {
				// const subscriptions = await stripe.subscriptions.list({
				// 	customer: data.customer,
				// 	status: 'active', // Optional: can be 'active', 'canceled', etc.
				// });
				const subscriptionObj: any = await StripeService.getCustomerSubscriptions(data.customer);
				const itemToUpdate = subscriptionObj.subscriptionList.find(
					(item) => item.items.data.some(it => it.plan && it.plan.usage_type === planType.LICENSED && it.plan.metadata.category === 'staff')
				);
				if (itemToUpdate === undefined) {
					currentBusinessDoc.stripePriceIds['staffUsagePriceId'] = null;
					currentBusinessDoc.membershipStaffCount = 0;
				}
			}
			if (type === 'create') {
				if (data.plan.usage_type == planType.METERED) {
					currentBusinessDoc.stripePayAsYouGoOnTrial = true;
					currentBusinessDoc.whatsAppPayAsYouGoExpirationdate = new Date(data.current_period_end * 1000);
					currentBusinessDoc.stripePriceIds['usagePriceId'] = data.plan.id;
				}
			} else {
				let expDate = new Date(0);
				expDate.setUTCSeconds(data.current_period_end);
				const isTrialStart = data.status === "trialing"
				if (isTrialStart) {
					if (data.plan.usage_type == planType.METERED) {
						currentBusinessDoc.whatsAppPayAsYouGoExpirationdate = expDate;
						currentBusinessDoc.stripePayAsYouGoOnTrial = true;
					}
				} else if (data.status === "active") {
					// if (data.plan.usage_type == planType.METERED) currentBusinessDoc.stripePayAsYouGoOnTrial = true
					if (data.plan.usage_type == planType.METERED) {
						currentBusinessDoc.stripePayAsYouGoOnTrial = false;
						currentBusinessDoc.whatsAppPayAsYouGoExpirationdate = expDate;
					}
				}
				// if (data.plan.usage_type == planType.METERED && data.plan.metadata && data.plan.metadata['whatsapp_credits']) {
				// currentBusinessDoc.whatsAppPayAsYouGoCredits = Number(data.plan.metadata['whatsapp_credits'])
				// }
				if (data.plan.usage_type == planType.METERED && data.status === 'past_due') {
					currentBusinessDoc.isPaymentDue = true;
					currentBusinessDoc.isStaffPaymentPaid = false;  //step staff uasges if payment is due
				}
			}
			return currentBusinessDoc;

		} catch (error) {
			Logger.logger.error('error while update credits: ', error)
		}
	}
}
