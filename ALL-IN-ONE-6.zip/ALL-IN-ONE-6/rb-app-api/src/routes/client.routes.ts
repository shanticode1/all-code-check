import { Router } from "express";
import { AuthMiddleware } from "../middleware/auth.middleware";
import { ClientService } from "../services/client.service";
import { Client } from "../types/clients";
import { CustomerValidator } from "../validators/customer.validator";
import { roles } from "../data/user.roles";
import { ClientMembershipService } from "../services/client-services-membership.service ";
import { BookingsService } from "../services/bookings.service";


export abstract class ClientRoutes {
    public static clientPath = "/clients";

    public static addClientRoutes(): Router {
        const router = Router();
        ClientRoutes.addRoutes(router);
        return router;
    }

    private static addRoutes(router: Router): void {
        router.get("/:businessId",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([roles.Business, roles.staff]),
            async (req, res, next) => {
                const businessIdParam = (req.params as any).businessId as string;
                console.log(businessIdParam);

                if (businessIdParam != res.locals.sub) {
                    res.status(403).send()
                    return
                }
                let client;
                try {
                    client = await ClientService.getAll(req.params.businessId);
                } catch (error) {
                    next(error);
                    return;
                }

                if (client == null) {
                    res.status(404).send();
                    return;
                }

                res.json(client)
            })

        router.get("/",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([roles.Client]),
            async (req, res, next) => {
                let client;
                try {
                    client = await ClientService.getByClientId(res.locals.sub);
                } catch (error) {
                    next(error);
                    return;
                }

                if (client == null) {
                    res.status(404).send();
                    return;
                }

                res.json(client)
            })

        router.get("/membership/history",
            AuthMiddleware.getAuthFunction(),
            async (req, res, next) => {
                const clientId = res.locals.sub;
                console.log(clientId);
                let result;
                try {
                    result = await ClientMembershipService.getMembershipHistory(clientId);
                } catch (error) {
                    next(error);
                    return
                }
                res.json(result)
            })
        router.get("/membership/history/:membershipId",
            AuthMiddleware.getAuthFunction(),
            async (req, res, next) => {
                const clientId = res.locals.sub;
                const membershipParam = (req.params as any).membershipId as string;
                console.log(clientId);
                let result;
                try {
                    result = await ClientMembershipService.getMembershipHistoryById(clientId, membershipParam);
                } catch (error) {
                    next(error);
                    return
                }
                res.json(result)
            })

        router.get("/:businessId/:clientId",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([roles.Business, roles.staff]),
            async (req, res, next) => {
                if (req.params.clientId == null) {
                    res.status(403).send()
                    return
                }

                const businessIdParam = (req.params as any).businessId as string;
                if (businessIdParam != res.locals.sub) {
                    res.status(403).send()
                    return
                }

                let client;

                try {
                    client = await ClientService.getById(req.params.clientId);
                } catch (error) {
                    next(error);
                    return
                }

                res.json(client)
            })

        router.patch("/", AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([roles.Business, roles.staff]), async (req, res, next) => {
                if (req.body.clientId == null) {
                    res.status(403).send()
                    return
                }

                if (req.body.businessId != res.locals.userId) {
                    res.status(403).send()
                    return
                }

                let result;

                try {
                    console.log(req.body)
                    result = await ClientService.updateNotes(req.body)
                } catch (error) {
                    next(error)
                    return
                }

                res.json(result)
                return
            })

        router.post("/",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([roles.Business, roles.staff]),
            async (req, res, next) => {
                if (req.body.businessId != res.locals.userId) {
                    res.status(403).send()
                    return
                }
                if (CustomerValidator.isInvalidForCreate(req.body)) {
                    res.status(400).send();
                    return;
                }
                try {
                    res
                        .status(201)
                        .json(
                            await ClientService.create(
                                new Client(
                                    "",
                                    req.body.businessId,
                                    req.body.email,
                                    req.body.name,
                                    req.body.surname,
                                    req.body.phone,
                                    req.body.countryCode == null ? undefined : req.body.countryCode,
                                    req.body.lastBookingDate,
                                    req.body.notes,
                                    req.body.isWhatsAppAllow == null ? undefined : req.body.isWhatsAppAllow,
                                    req.body.isEmailAllow == null ? undefined : req.body.isEmailAllow,
                                ),
                                false
                            )
                        )
                } catch (error) {
                    next(error);
                    return;
                }
            })

        router.patch("/:clientId/:businessId",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([roles.Business, roles.staff]),
            async (req, res, next) => {
                if (req.params.businessId != res.locals.sub) {
                    res.status(403).send()
                    return
                }
                try {
                    res
                        .status(201)
                        .json(
                            await ClientService.partialUpdate(
                                new Client(
                                    req.params.clientId,
                                    req.params.businessId,
                                    req.body.email == null ? undefined : req.body.email,
                                    req.body.name == null ? undefined : req.body.name,
                                    req.body.surname == null ? undefined : req.body.surname,
                                    req.body.phone == null ? undefined : req.body.phone,
                                    req.body.countryCode == null ? undefined : req.body.countryCode,
                                    req.body.lastBookingDate == null ? undefined : req.body.lastBookingDate,
                                    req.body.notes == null ? undefined : req.body.notes,
                                    req.body.isWhatsAppAllow == null ? undefined : req.body.isWhatsAppAllow,
                                    req.body.isEmailAllow == null ? undefined : req.body.isEmailAllow,
                                ),
                            )
                        )
                } catch (error) {
                    next(error);
                    return;
                }
            })

        router.get("/fetch/booking/:bookingId",
            async (req, res, next) => {                
                const bookingId = (req.params as any).bookingId as string;
                if (!bookingId) {
                    res.status(400).send()
                    return
                }
                let client;
                try {
                    client = await BookingsService.getBookingById(bookingId);
                } catch (error) {
                    next(error);
                    return;
                }

                if (client == null) {
                    res.status(404).send();
                    return;
                }

                res.json(client)
            })
    }
}