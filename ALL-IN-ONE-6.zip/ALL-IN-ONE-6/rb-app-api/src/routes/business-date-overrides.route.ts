import { Router } from "express"
import { BusinessServiceValidator } from "../validators/business-service.validator"
import { IdValidator } from "../validators/id.validator"
import { BusinessesRoutes } from "./businesses.routes"
import { BusinessDateOverrides } from "../types/business-date-overrides"
import { BusinessDateOverridesService } from "../services/business-date-overrides.service"
import { AuthMiddleware } from "../middleware/auth.middleware"


export abstract class BusinessOverridesRoutes {
	public static businessOverridesPath = `${BusinessesRoutes.businessesPath}/:businessId/business-overrides`

	public static addBusinessOverridesRoutes(): Router {
		const router = Router({ mergeParams: true })
		BusinessOverridesRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router): void {
		router.get('/:serviceId',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([2, 3]),
			async (req, res, next) => {
				const businessIdParam = (req.params as any).businessId as string
				const serviceIdParam = (req.params as any).serviceId as string
				if (IdValidator.isInvalidForRead(businessIdParam) ||
					IdValidator.isInvalidForRead(serviceIdParam)) {
					res.status(400).send()
					return
				}
				if (businessIdParam != res.locals.userId) {
					res.status(403).send()
					return
				}
			})

		router.put('/', AuthMiddleware.getAuthFunction(), async (req, res, next) => {
			const businessIdParam = (req.params as any).businessId as string
			if (businessIdParam != res.locals.userId) {
				res.status(403).send()
				return
			}

			let result: BusinessDateOverrides

			const override: BusinessDateOverrides = {
				businessId: businessIdParam ?? '',
				blockoutDates: req.body.blockoutDates == null ?
					[] :
					req.body.blockoutDates
			};

			try {
				result = await BusinessDateOverridesService.update(override)
			} catch (err) {
				next(err)
				return
			}

			if (result == null) {
				res.status(204).send()
				return
			}

			res.json(result)
			return

		})

	}

}