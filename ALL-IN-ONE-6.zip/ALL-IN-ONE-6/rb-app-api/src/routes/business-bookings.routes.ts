import { Router } from "express"
import Joi = require("joi")

import { BookingsService } from "../services/bookings.service"
import { BookingStatus } from "../types/enums/booking.status"
import { BaseValidator } from "../validators/base.validator"
import { IdValidator } from "../validators/id.validator"
import { BusinessesRoutes } from "./businesses.routes"
import { roles } from "../data/user.roles"
import { AuthMiddleware } from "../middleware/auth.middleware"


export abstract class BusinessBookingsRoutes {
	public static businessBookingsPath = `${BusinessesRoutes.businessesPath}/:businessId/bookings`

	public static addBusinessBookingsRoutes(): Router {
		const router = Router({ mergeParams: true })
		BusinessBookingsRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router): void {

		router.get('/:bookingId',
			AuthMiddleware.getAuthFunction(),
			AuthMiddleware.userRole([roles.Business, roles.Client, roles.staff]),
			async (req, res, next) => {
				const businessIdParam = (req.params as any).businessId as string
				const bookingId = (req.params as any).bookingId as string

				if (IdValidator.isInvalidForRead(businessIdParam) ||
					IdValidator.isInvalidForRead(bookingId)) {
					res.status(400).send()
					return
				}

				if (businessIdParam != res.locals.sub) {
					res.status(403).send()
					return
				}
				let result;
				try {
					if (res.locals.role === roles.Business) {
						result = await BookingsService.getByIdForBusiness(businessIdParam, bookingId)
					} else if (res.locals.role === roles.staff) {
						result = await BookingsService.getByIdForStaff(businessIdParam, bookingId)
					} else if (res.locals.role === roles.Client) {
						result = await BookingsService.getByIdForClient(businessIdParam, bookingId)
					}
					if (result == null) {
						res.status(204).send();
						return;
					}
					res.json(result)
					return
				} catch (err) {
					next(err)
					return
				}
			})

			router.get('/upcoming/landing/reservations', async (req, res, next) => {	
				const businessIdParam = (req.params as any).businessId as string
				const statusParam = req.query.status as string
				const pastParam = req.query.past as string
				const fromParam = req.query.from as string
				const toParam = req.query.to as string
				const sortParam = req.query.sort as string
	
				if (IdValidator.isInvalidForRead(businessIdParam) ||
					BusinessBookingsRoutes.areGetParamsInvalid(statusParam, pastParam, fromParam, toParam)) {
					res.status(400).send()
					return
				}
				if (businessIdParam != res.locals.sub) {
					res.status(403).send()
					return
				}
	
				const status: BookingStatus = statusParam === undefined ?
					undefined :
					BookingStatus[statusParam]
	
				const past = pastParam != null ?
					pastParam.toLowerCase() == 'true' :
					null
	
				const from = fromParam != null ?
					new Date(fromParam) :
					null
	
				const to = toParam != null ?
					new Date(toParam) :
					null
	
				try {
					const staffId = businessIdParam;
					res.json(await BookingsService.getForClientUpcomingBooking(staffId, status, past, from, to, sortParam))
					return
				} catch (err) {
					next(err)
					return
				}
			})

		router.get('/', async (req, res, next) => {

			const businessIdParam = (req.params as any).businessId as string
			const statusParam = req.query.status as string
			const pastParam = req.query.past as string
			const fromParam = req.query.from as string
			const toParam = req.query.to as string
			const sortParam = req.query.sort as string
			const eventTypeParam = req.query.eventType as string
			if (IdValidator.isInvalidForRead(businessIdParam) ||
				BusinessBookingsRoutes.areGetParamsInvalid(statusParam, pastParam, fromParam, toParam)) {
				res.status(400).send()
				return
			}
			if (businessIdParam != res.locals.sub) {
				res.status(403).send()
				return
			}

			const status: BookingStatus = statusParam === undefined ?
				undefined :
				BookingStatus[statusParam]

			const past = pastParam != null ?
				pastParam.toLowerCase() == 'true' :
				null

			const from = fromParam != null ?
				new Date(fromParam) :
				null

			const to = toParam != null ?
				new Date(toParam) :
				null

			const sort = sortParam != null ?
				sortParam.toLowerCase() :
				null

			const eventType = eventTypeParam != null ?
				eventTypeParam.toLowerCase() :
				null
			try {
				if (res.locals.role === roles.Business) {
					res.json(await BookingsService.getForBusinessV1(businessIdParam, status, past, from, to, sortParam))
				} else if (res.locals.role === roles.staff) {
					const staffId = businessIdParam;
					res.json(await BookingsService.getForStaff(staffId, status, past, from, to, sortParam))
				}
				else if (res.locals.role === roles.Client) {
					const staffId = businessIdParam;
					res.json(await BookingsService.getForClient(staffId, status, past, from, to, sortParam))
				}
				return
			} catch (err) {
				next(err)
				return
			}
		})


		router.patch('/update-status/:bookingId', async (req, res, next) => {
			if (IdValidator.isInvalidForRead(req.params.bookingId)) {
				res.status(400).send()
				return
			}
			const status = parseInt(req.body.status, 10);
			try {
				await BookingsService.updateBookingPaymentStatus(req.params.bookingId, status)
			} catch (err) {
				next(err)
				return
			}
			res.status(204).send()
			return
		})

	}

	private static areGetParamsInvalid(statusParam: string, pastParam: string, fromParam: string, toParam: string): boolean {
		const validationSchema = Joi.object({
			status: Joi.string().valid(...Object.values(BookingStatus).filter(bs => typeof bs === 'string')).optional(),
			past: Joi.boolean().optional(),
			from: Joi.date().optional(),
			to: Joi.when(
				'from', {
				is: Joi.date().required(),
				then: Joi.date().greater(Joi.ref('from')).optional(),
				otherwise: Joi.date().optional()
			})
		})
			.oxor('past', 'from')
			.oxor('past', 'to')

		const validationPayload = {
			status: statusParam,
			past: pastParam,
			from: fromParam,
			to: toParam
		}

		return BaseValidator.isInvalidForSchema(validationPayload, validationSchema)
	}
}