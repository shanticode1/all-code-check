import { Router } from "express";
import { AuthMiddleware } from "../middleware/auth.middleware";
import { CurrencyRateService } from "../services/currency-rate.service";

export abstract class CurrencyRateRoutes {
    public static currencyRatePath = "/currencyRates";

    public static addCurrencyRateRoutes(): Router {
        const router = Router();
        CurrencyRateRoutes.addRoutes(router);
        return router;
    }

    private static addRoutes(router: Router): void {
        router.get("/",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([2, 3]),
            async (req, res, next) => {
                const businessIdParam = (req.params as any).businessId as string;

                // if (businessIdParam != res.locals.sub) {
                //     res.status(403).send()
                //     return
                // }

                let currencyRate;

                try {
                    currencyRate = await CurrencyRateService.getAll();
                } catch (error) {
                    next(error);
                    return;
                }

                if (currencyRate == null) {
                    res.status(404).send();
                    return;
                }

                res.json(currencyRate)
            })
    }
}