import { Router } from "express";
import { User } from "../types/user";
import { UserService } from "../services/users.service";
import { UserValidator } from "../validators/user.validator";
import { AuthMiddleware } from "../middleware/auth.middleware";
import { CredentialsValidator } from "../validators/credentials.validator";
import { Credentials } from "../types/credentials";

export abstract class UserRoutes {
    public static userPath = "/user";

    public static addUserRoutes(): Router {
        const router = Router();
        UserRoutes.addRoutes(router);
        return router;
    }

    private static addRoutes(router: Router): void {
        router.post("/", async (req, res, next) => {
            if (UserValidator.isInvalidForCreate(req.body)) {
                res.status(400).send();
                return;
            }
            try {
                res
                    .status(201)
                    .json(
                        await UserService.create(
                            new User(
                                undefined,
                                req.body.email,
                                req.body.password,
                                req.body.userName,
                                req.body.role,
                                undefined,
                                undefined,
                                undefined
                            )
                        )
                    );
                return;
            } catch (err) {
                next(err);
                return;
            }
        });

        router.post("/login", async (req, res, next) => {
            if (CredentialsValidator.isInvalid(req.body)) {
                res.status(401).send()
                return
            }
            try {
                res
                    .status(201)
                    .json(
                        await UserService.login(
                            new Credentials(req.body.email, req.body.password)
                        )
                    );
                return;
            } catch (err) {
                next(err);
                return;
            }
        });

        router.patch(
            "/",
            AuthMiddleware.getAuthFunction(),
            async (req, res, next) => {
                if (UserValidator.isInvalidForPartialUpdate(req.body)) {
                    res.status(400).send();
                    return;
                }

                let result: User;

                try {
                    result = await UserService.partialUpdate(
                        new User(
                            res.locals.userId,
                            req.body.email == null ? undefined : req.body.email,
                            req.body.password == null ? undefined : req.body.password,
                            req.body.userName == null ? undefined : req.body.userName,
                            req.body.role == null ? undefined : req.body.email,
                            req.body.isActive == null ? undefined : req.body.isActive,
                            req.body.isDeleted == null ? undefined : req.body.isDeleted,
                            undefined,
                        )
                    );
                } catch (err) {
                    next(err);
                    return;
                }

                if (result == null) {
                    res.status(204).send();
                    return;
                }

                res.json(result);
                return;
            }
        );
    }
}
