import { Router } from "express";
import { BookingsService } from "../services/bookings.service";
import { IdValidator } from "../validators/id.validator";
import { BusinessBusinessServicesRoutes } from "./business-busines-services.route";
import { TimeSlotService } from "../services/time-slot-service";
import { roles } from "../data/user.roles";
import { AuthMiddleware } from "../middleware/auth.middleware";

export abstract class BusinessTimeslotsRoutes {
  public static businessTimeslotsPath = `/timeslots/:businessId/`;

  public static addBusinessTimeslotsRoutes(): Router {
    const router = Router({ mergeParams: true });
    BusinessTimeslotsRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {
    router.get("/", async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;

      if (IdValidator.isInvalidForRead(businessIdParam)) {
        res.status(400).send();
        return;
      }

      try {
        res.json(
          await TimeSlotService.getTimeslotsBooked(businessIdParam, null, null)
        );
        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    // router.get("/v2/time", async (req, res, next) => {
    //   const businessIdParam = (req.params as any).businessId as string;
    //   const calendarId = (req.params as any).calendarId as string;

    //   if (IdValidator.isInvalidForRead(businessIdParam)) {
    //     res.status(400).send();
    //     return;
    //   }
    //   console.log('call v2---');

    //   try {
    //     res.json(
    //       await TimeSlotService.getTimeslotsBookedV2(businessIdParam, calendarId, null)
    //     );
    //     return;
    //   } catch (err) {
    //     next(err);
    //     return;
    //   }
    // });

    router.get("/:serviceId", async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const serviceIdParam = (req.params as any).serviceId as string;
      if (IdValidator.isInvalidForRead(businessIdParam)) {
        res.status(400).send();
        return;
      }

      try {
        // res.json(
        //   await TimeSlotService.getAvailability(businessIdParam, serviceIdParam)
        // );
        let result;
        if (2 === roles.Business) {
          result = await TimeSlotService.getAvailability(
            businessIdParam,
            serviceIdParam,
          )
        } else if (3 === roles.staff) {
          result = await TimeSlotService.getAvailabilityStaff(
            businessIdParam,
            serviceIdParam,
          )
        }
        res.json(result)
        return;
      } catch (err) {
        next(err);
        return;
      }
    });


    // router.get("/:serviceId/v2", async (req, res, next) => {
    //   const businessIdParam = (req.params as any).businessId as string;
    //   const serviceIdParam = (req.params as any).serviceId as string;
    //   const calendarIdParam = (req.query as any).calendarId as string;

    //   if (IdValidator.isInvalidForRead(businessIdParam)) {
    //     res.status(400).send();
    //     return;
    //   }
    //   console.log('new api',calendarIdParam);

    //   try {
    //     res.json(
    //       await TimeSlotService.getAvailabilityV2(businessIdParam, serviceIdParam, calendarIdParam)
    //     );
    //     return;
    //   } catch (err) {
    //     next(err);
    //     return;
    //   }
    // });

    router.get("/:serviceId/:staffId", async (req, res, next) => {
      // AuthMiddleware.getAuthFunction()
      const businessIdParam = (req.params as any).businessId as string;
      const serviceIdParam = (req.params as any).serviceId as string;
      const staffId = (req.params as any).staffId as string;

      if (IdValidator.isInvalidForRead(businessIdParam)) {
        res.status(400).send();
        return;
      }
      let result;
      try {
        if (2 === roles.Business) {
          result =
            await TimeSlotService.getAvailability(
              businessIdParam,
              serviceIdParam,
              staffId);
        } else if (3 === roles.staff) {
          result = await TimeSlotService.getAvailabilityStaff(
            res.locals.sub,
            serviceIdParam);
        }
        res.json(result)
        return;
      } catch (err) {
        next(err);
        return;
      }
    });
  }
}
