import { Router } from "express"
import { BusinessesService } from "../services/businesses.service"
import { IdValidator } from "../validators/id.validator"
import { CitiesLookUp } from '../data/citiesList';
import { BusinessTypesLookUp } from '../data/businessTypes'
import { BusinessTypesService } from "../services/business-types.service";
import { BusinessMembershipService } from "../services/business-services-membership.service ";
import { CitiesByCountry } from "../utils/Cities";


export abstract class MarketplaceRoutes {
	public static marketplacePath = '/marketplace'

	public static addMarketplaceRoutes(): Router {
		const router = Router()
		MarketplaceRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router): void {
		//Get 1 Business
		router.get('/business/:businessId', async (req, res, next) => {
			try {
				res.json(await BusinessesService.getBySlug(req.params.businessId))
				return
			} catch (err) {
				next(err)
				return
			}
		})

		//Get all businesses by City and Country
		router.get('/businesses', async (req, res, next) => {
			const businessTypeParam = req.query.category as string
			const countryParam = req.query.country as string
			const cityParam = req.query.city as string
			try {
				if (countryParam) {
					if (businessTypeParam) {
						var resp = await BusinessesService.getAll(cityParam, countryParam, businessTypeParam)
						res.json(resp)
					} else {
						//show all businesses
						var resp = await BusinessesService.getAll(cityParam, countryParam)
						res.json(resp)
					}

				}
				else {
					res.status(400).send()
					return
				}
			} catch (err) {
				next(err)
				return
			}
		})
		//Get all Types
		router.get('/types', async (req, res, next) => {
			try {
				res.json(BusinessTypesLookUp)
			} catch (err) {
				next(err)
				return
			}
		})
		//Get all Cities
		router.get('/locations', async (req, res, next) => {
			try {
				res.json(CitiesLookUp)
			} catch (err) {
				next(err)
				return
			}
		})

		//Get 1 Business
		router.get('/memberships/:membershipId', async (req, res, next) => {
			try {
				const membershipIdParam = (req.params as any).membershipId as string;
				if (IdValidator.isInvalidForRead(membershipIdParam)) {
					res.status(400).send();
					return;
				  }
				res.json(await BusinessMembershipService.getByDocId(membershipIdParam))
				return
			} catch (err) {
				next(err)
				return
			}
		})

		//Get all Cities
		router.get('/memberships', async (req, res, next) => {
			try {
				const pageParam = (req.query as any).pageNumber as number || 1;
				const sizeParam = (req.query as any).pageSize as number || 20;
				const searchParam = req.query.search as string || '';
				const findByParam = req.query.findBy as string || 'business';
				const sortByParam = req.query.sortBy as string || 'desc';
				const findByCategory = req.query.category as string || '';
				const businessParam = req.query.businessId as string || '';
				res.json(await BusinessMembershipService.getAllwithPagination(pageParam, sizeParam, searchParam, findByParam, sortByParam, findByCategory, businessParam))
			} catch (err) {
				next(err)
				return
			}
		})

		//Get all Cities by county
		router.get('/cities', async (req, res, next) => {
			try {				
				const countryParam = req.query.country as string;
				
				if (!countryParam) {
					res.status(400).send()
					return
				}
				const cities = await CitiesByCountry(countryParam)
				if (cities == null || cities.length == 0) {
					res.status(404).send()
					return
				}
				res.json(cities)
			} catch (err) {
				next(err)
				return
			}
		})

		router.get("/public/locations", async (req, res, next) => {
			let locations = [];
			try {
				locations = await BusinessesService.getLocations();
			} catch (err) {
				next(err);
				return;
			}
			if (locations == null) {
				res.status(404).send();
				return;
			}

			res.json(locations);
		});

	}
}
