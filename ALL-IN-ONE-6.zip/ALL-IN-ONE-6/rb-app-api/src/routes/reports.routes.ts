import { Router } from "express";
import Joi = require("joi");
import { AuthMiddleware } from "../middleware/auth.middleware";

import { ReportsService } from "../services/reports.service";
import { ReportsRequest } from "../types/reports";
import { BaseValidator } from "../validators/base.validator";
import { IdValidator } from "../validators/id.validator";
import { BusinessesRoutes } from "./businesses.routes";

export abstract class ReportsRoutes {
  public static reportsPath = `${BusinessesRoutes.businessesPath}/:businessId/reports`;

  public static addReportsRoutes(): Router {
    const router = Router({ mergeParams: true });
    ReportsRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {
    router.get("/", AuthMiddleware.getAuthFunction(),async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const toDate = req.query.toDate as string;
      const fromDate = req.query.fromDate as string;
      const serviceId = req.query.serviceId as string;
      const staffId = req.query.staffId as string;

      if (businessIdParam != res.locals.userId) {
				res.status(403).send()
				return
			} 
      
      if (IdValidator.isInvalidForRead(businessIdParam) || ReportsRoutes.areGetParamsInvalid(toDate, fromDate, serviceId, staffId)) {
        res.status(400).send();
        return;
      }

      try {
        res
          .status(201)
          .json(
            await ReportsService.getReports(
              businessIdParam,
              new ReportsRequest(
                req.query.toDate as string,
                req.query.fromDate as string,
                req.query.serviceId as string,
                req.query.staffId as string
              )
            )
          );
        return;
      } catch (err) {
        next(err);
        return;
      }
    });
  }

  private static areGetParamsInvalid(toDate:string, fromDate:string, serviceId:string, staffId:string): boolean {
		const validationSchema = Joi.object({
			toDate: Joi.date().required(),
			fromDate: Joi.date().required(),
			serviceId: Joi.string().optional(),
      staffId: Joi.string().optional(),
		})

		const validationPayload = {
			toDate: toDate,
			fromDate: fromDate,
			serviceId: serviceId,
			staffId: staffId
		}

		return BaseValidator.isInvalidForSchema(validationPayload, validationSchema)
	}
}
