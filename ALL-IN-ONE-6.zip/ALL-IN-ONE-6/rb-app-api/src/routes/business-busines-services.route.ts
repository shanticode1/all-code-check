import { Router } from "express";

import { BusinessServicesService } from "../services/business-services.service";
import { BusinessesService } from "../services/businesses.service";
import { BookingReminder } from "../types/booking-reminder";
import { BusinessService } from "../types/business-service";
import { BookingReminderType } from "../types/enums/booking-reminder-type.enum";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { ServiceCategory } from "../types/service-category";
import { BusinessServiceValidator } from "../validators/business-service.validator";
import { IdValidator } from "../validators/id.validator";
import { BusinessesRoutes } from "./businesses.routes";
import { roles } from "../data/user.roles";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { BookingsService } from "../services/bookings.service";
import { AuthMiddleware } from "../middleware/auth.middleware";
import * as multer from "multer";
import { BusinessValidator } from "../validators/business.validator";
import { BodyParserUtil } from "../utils/body-parser.util";
const upload = multer({});
export abstract class BusinessBusinessServicesRoutes {
  public static businessBusinessServicesPath = `${BusinessesRoutes.businessesPath}/:businessId/business-services`;

  public static addBusinessBusinessServicesRoutes(): Router {
    const router = Router({ mergeParams: true });
    BusinessBusinessServicesRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {
    router.get("/:serviceId", async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const serviceIdParam = (req.params as any).serviceId as string;

      if (
        IdValidator.isInvalidForRead(businessIdParam) ||
        IdValidator.isInvalidForRead(serviceIdParam)
      ) {
        res.status(400).send();
        return;
      }

      // if (businessIdParam != res.locals.userId) {
      //   res.status(403).send();
      //   return;
      // }
      if (businessIdParam != res.locals.sub) {
        res.status(403).send();
        return;
      }
      try {
        res.json(
          await BusinessServicesService.getById(businessIdParam, serviceIdParam)
        );
        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    router.get("/", async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;

      if (IdValidator.isInvalidForRead(businessIdParam)) {
        res.status(400).send();
        return;
      }

      // if (businessIdParam != res.locals.userId) {
      //   res.status(403).send();
      //   return;
      // }
      if (businessIdParam != res.locals.sub) {
        res.status(403).send();
        return;
      }

      try {
        if (res.locals.role === roles.Business) {
          res.json(await BusinessServicesService.get(businessIdParam));

        } else if (res.locals.role === roles.staff) {
          res.json(await BusinessServicesService.getStaffServicesDoc(businessIdParam));
        }
        return;
      } catch (err) {
        next(err);
        return;
      }
    });


    router.get("/v2/memberships", async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const pageParam = Number(req.query.page) || 1;
      const limitParam = Number(req.query.limit) || 20;

      if (IdValidator.isInvalidForRead(businessIdParam)) {
        res.status(400).send();
        return;
      }

      // if (businessIdParam != res.locals.userId) {
      //   res.status(403).send();
      //   return;
      // }
      if (businessIdParam != res.locals.sub) {
        res.status(403).send();
        return;
      }
      try {
        if (res.locals.role === roles.Business) {
          res.json(await BusinessServicesService.getV2(businessIdParam, pageParam, limitParam));

        } else if (res.locals.role === roles.staff) {
          res.json(await BusinessServicesService.getStaffServicesDoc(businessIdParam));
        }
        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    router.post("/", upload.any(), async (req: any, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const parsedBody = BodyParserUtil.parseBodyJson(req.body);
      req.body = parsedBody;
      if (req.files && req.files.length > 0) {
        for (const file of req.files) {
          // File size validation
          if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
            res.status(400).send();
            return;
          }
          if (file.fieldname === "logo") {
            req.body['logo'] = file;
          }
        }
      }
      if (
        IdValidator.isInvalidForRead(businessIdParam) ||
        BusinessServiceValidator.isInvalidForCreate(req.body)
      ) {
        res.status(400).send();
        return;
      }

      if (businessIdParam != res.locals.userId) {
        res.status(403).send();
        return;
      }

      let business = await BusinessesService.getById(businessIdParam);

      if (business.membershipTier === MembershipTier.Free) {
        //If Free, limit to 3 active services
        let services = await BusinessServicesService.get(businessIdParam);
        let activeServices = services.filter((x) => !x.isDeleted && x.isActive);

        if (activeServices.length >= 1) {
          req.body.isActive = false;
        } else {
          req.body.isActive = true;
        }
      }
      try {
        if (business) {

        }
        let serviceReminderTime = 60 * 24;
        if (business.settings && business.settings.emailReminderDuration && business.settings.whatsappReminderDuration.durationUnit === DurationUnit.Hour) {
          serviceReminderTime = 60 * business.settings.emailReminderDuration.duration; // set reminder time added by business
        }
        if (business.settings && business.settings.emailReminderDuration && business.settings.whatsappReminderDuration.durationUnit === DurationUnit.Minute) {
          serviceReminderTime = business.settings.emailReminderDuration.duration; // set reminder time added by business
        }
        res
          .status(201)
          .json(
            await BusinessServicesService.create(
              businessIdParam,
              new BusinessService(
                null,
                req.body.name,
                req.body.description == null ? undefined : req.body.description,
                req.body.category == null
                  ? undefined
                  : new ServiceCategory(
                    req.body.category.id,
                    req.body.category.name == null
                      ? undefined
                      : req.body.category.name,
                    req.body.category.description == null
                      ? undefined
                      : req.body.category.description
                  ),
                req.body.duration,
                req.body.durationUnit,
                req.body.price == null ? undefined : req.body.price,
                req.body.currency == null ? undefined : req.body.currency,
                req.body.type == null ? undefined : req.body.type,
                req.body.capacity == null ? undefined : req.body.capacity,
                req.body.hash == null ? undefined : req.body.hash,
                [
                  // new BookingReminder(60 * 24, [BookingReminderType.Email]),  // email set reminder befor 24 hrs
                  // new BookingReminder(60 * 2, [BookingReminderType.Email]),    //email set reminder befor 2 hrs
                  new BookingReminder(serviceReminderTime, [BookingReminderType.Email]),    //email set reminder befor 2 hrs
                ],
                req.body.isActive == null ? undefined : req.body.isActive,
                req.body.isDeleted == null ? undefined : req.body.isDeleted,
                business.membershipTier !== MembershipTier.Free ? req.body.location == null ? undefined : req.body.location : 'none',
                // req.body.groupMeetLink == null ? undefined : req.body.groupMeetLink,
                // req.body.meetEventId == null ? undefined : req.body.meetEventId,
                req.body.serviceDaysBlocks == null ? undefined : req.body.serviceDaysBlocks,
                req.body.paymentSetting == null ? undefined : req.body.paymentSetting,
                req.body.depositAmount == null ? undefined : req.body.depositAmount,
                req.body.eventSetting == null ? undefined : req.body.eventSetting,
                // req.body.isCapacityVisible == null ? undefined : req.body.isCapacityVisible,
                req.body.serviceAddress == null ? undefined : req.body.serviceAddress,
                req.body.cutOff == null ? undefined : req.body.cutOff,
                req.body.cutOffUnit == null ? undefined : req.body.cutOffUnit,
                req.body.logo == null ? undefined : req.body.logo,

              )
            )
          );
        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    router.put("/:serviceId", upload.any(), async (req: any, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const serviceIdParam = (req.params as any).serviceId as string;

      const parsedBody = BodyParserUtil.parseBodyJson(req.body);
      req.body = parsedBody;
      // Handle file uploads and validation
      if (req.files && req.files.length > 0) {
        for (const file of req.files) {
          // File size validation
          if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
            res.status(400).send();
            return;
          }
          if (file.fieldname === "logo") {
            req.body['logo'] = file;
          }
        }
      }

      if (
        IdValidator.isInvalidForRead(businessIdParam) ||
        IdValidator.isInvalidForRead(serviceIdParam) ||
        BusinessServiceValidator.isInvalidForUpdate(req.body)
      ) {
        res.status(400).send();
        return;
      }

      if (businessIdParam != res.locals.userId) {
        res.status(403).send();
        return;
      }

      let result: BusinessService;
      let business = await BusinessesService.getById(businessIdParam);
      try {
        result = await BusinessServicesService.update(
          businessIdParam,
          new BusinessService(
            serviceIdParam,
            req.body.name,
            req.body.description == null ? undefined : req.body.description,
            req.body.category == null
              ? undefined
              : new ServiceCategory(
                req.body.category.id,
                req.body.category.name == null
                  ? undefined
                  : req.body.category.name,
                req.body.category.description == null
                  ? undefined
                  : req.body.category.description
              ),
            req.body.duration,
            req.body.durationUnit,
            req.body.price == null ? undefined : req.body.price,
            req.body.currency == null ? undefined : req.body.currency,
            req.body.type == null ? undefined : req.body.type,
            req.body.capacity == null ? undefined : req.body.capacity,
            req.body.hash == null ? undefined : req.body.hash,
            undefined,
            req.body.isActive == null ? undefined : req.body.isActive,
            req.body.isDeleted == null ? undefined : req.body.isDeleted,
            business.membershipTier !== MembershipTier.Free ? req.body.location == null ? undefined : req.body.location : '',
            // req.body.groupMeetLink == null ? undefined : req.body.groupMeetLink,
            // req.body.meetEventId == null ? undefined : req.body.meetEventId,
            req.body.serviceDaysBlocks == null ? undefined : req.body.serviceDaysBlocks,
            req.body.paymentSetting == null ? undefined : req.body.paymentSetting,
            req.body.depositAmount == null ? undefined : req.body.depositAmount,
            req.body.eventSetting == null ? undefined : req.body.eventSetting,
            // req.body.isCapacityVisible == null ? undefined : req.body.isCapacityVisible,
            req.body.serviceAddress == null ? undefined : req.body.serviceAddress,
            req.body.cutOff == null ? undefined : req.body.cutOff,
            req.body.cutOffUnit == null ? undefined : req.body.cutOffUnit,
            req.body.logo == null ? undefined : req.body.logo,
          )
        );
      } catch (err) {
        next(err);
        return;
      }

      if (result == null) {
        res.status(204).send();
        return;
      }
      res.json(result);
      return;
    });

    router.delete("/:serviceId", async (req, res, next) => {
      const businessIdParam = (req.params as any).businessId as string;
      const serviceIdParam = (req.params as any).serviceId as string;

      if (
        IdValidator.isInvalidForRead(businessIdParam) ||
        IdValidator.isInvalidForRead(serviceIdParam)
      ) {
        res.status(400).send();
        return;
      }

      if (businessIdParam != res.locals.userId) {
        res.status(403).send();
        return;
      }

      try {
        res.json(
          await BusinessServicesService.delete(businessIdParam, serviceIdParam)
        );
        return;
      } catch (err) {
        next(err);
        return;
      }
    });

    router.get(
      "/bookings/check-slot",
      async (req, res, next) => {
        const businessIdParam = (req.params as any).businessId as string;
        const staffIdsParam = (req.query as any).staffIds as string;
        const startDateParams = req.query.startDate as string;
        const endDateParams = req.query.endDate as string;
        const serviceParams = req.query.serviceId as string;

        if (
          IdValidator.isInvalidForRead(businessIdParam)) {
          res.status(400).send();
          return;
        }

        if (businessIdParam != res.locals.userId) {
          res.status(403).send();
          return;
        }

        try {
          res.json(
            await BookingsService.getAddedBooking(
              businessIdParam,
              startDateParams,
              endDateParams,
              staffIdsParam,
              serviceParams
            )
          );
          return;
        } catch (err) {
          next(err);
          return;
        }
      }
    );
  }
}
