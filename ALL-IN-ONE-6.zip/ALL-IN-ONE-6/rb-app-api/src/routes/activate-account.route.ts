import { Router } from "express"

import { BusinessesService } from "../services/businesses.service"
import { IdValidator } from "../validators/id.validator"
import { CredentialsValidator } from "../validators/credentials.validator"
import { UserService } from "../services/users.service"
import { ClientService } from "../services/client.service"


export abstract class ActivateAccountRoutes {

	public static activateAccountPath = '/activate-account'

	public static addActivateAccountRoutes(): Router {
		const router = Router()
		ActivateAccountRoutes.addRoutes(router)
		return router
	}

	private static addRoutes(router: Router) {

		router.post('/:businessId/:activationTokenId', async (req, res, next) => {
			if (IdValidator.isInvalidForRead(req.params.businessId) ||
				IdValidator.isInvalidForRead(req.params.activationTokenId)) {
				res.status(400).send()
				return
			}
			const isClient = req.query.isClient as string
			try {
				if (isClient == 'true') {
					await ClientService.activateAccount(req.params.businessId, req.params.activationTokenId)
				} else {
					await BusinessesService.activateAccount(req.params.businessId, req.params.activationTokenId)
				}
			} catch (err) {
				next(err)
				return
			}

			res.status(204).send()
			return
		})

		router.post('/resend-email', async (req, res, next) => {
			const isValid = CredentialsValidator.isInvalidForResendConfirmation(req.body);
			if (isValid) {
				res.status(400).json({ message: `${isValid}` })
				return
			}
			try {
				await BusinessesService.resendConformationEmail(req.body.email)
			} catch (err) {
				// next(err)
				res.status(500).json({ message: err.message })
				return
			}
			res.status(204).send()
			return
		})

		router.post('/user/:userId/:activationTokenId', async (req, res, next) => {
			console.log(req.params.userId, 'user');

			if (IdValidator.isInvalidForRead(req.params.userId) ||
				IdValidator.isInvalidForRead(req.params.activationTokenId)) {
				res.status(400).send()
				return
			}

			try {
				await UserService.activateUserAccount(req.params.userId, req.params.activationTokenId)
			} catch (err) {
				next(err)
				return
			}

			res.status(204).send()
			return
		})
	}
}
