import { Router } from "express"
import { GoogleService } from "../services/google.service"
import { AuthMiddleware } from "../middleware/auth.middleware"
import axios from "axios"
import { roles } from "../data/user.roles"

export abstract class GoogleRoutes {

    public static googleRoutePath = '/google'

    public static addGoogleAuthenticateRoutes(): Router {
        const router = Router()
        GoogleRoutes.addRoutes(router)
        return router
    }

    private static addRoutes(router: Router) {
        // working fine 
        router.patch(
            "/token",
            AuthMiddleware.getAuthFunction(),
            async (req, res, next) => {
                let result;
                try {
                    // result = await GoogleService.saveGoogleToken(req.body)
                } catch (err) {
                    next(err);
                    return;
                }
                if (result == null) {
                    res.status(204).send();
                    return;
                }
                res.json(result);
                return;
            }
        );

        // working fine
        router.get(
            "/list/:gmail",
            AuthMiddleware.getAuthFunction(),
            async (req, res, next) => {
                if (!req.params.gmail) {
                    res.status(403).send('params is required ');
                    return;
                }
                let result;
                try {
                    result = await GoogleService.getGoogleCalendars(req.params)
                } catch (err) {
                    next(err);
                    return;
                }
                if (result == null) {
                    res.status(204).send();
                    return;
                }
                res.json(result);
                return;
            }
        );

        // working fine
        router.patch(
            "/calendar/config",
            AuthMiddleware.getAuthFunction(),
            AuthMiddleware.userRole([2, 3]),
            async (req, res, next) => {
                // set a response timeout of 3 seconds
                res.setTimeout(58000, () => {
                    res.status(200).send({ message: "La sincronización está tardando.  Continuará en segundo plano." });
                });
                let result;
                try {
                    req.body['role'] = res.locals.role;
                    req.body['id'] = res.locals.sub;
                    result = await GoogleService.updateConfig(req.body)
                } catch (err) {
                    if (!res.headersSent) {
                        // next(err);
                        res.status(500).send({ message: err.message });
                        return;
                    }
                }
                if (!res.headersSent) {
                    res.status(200).send({ message: "Información Actualizada!" });
                }
                return;
            }
        );

        // delete google token
        router.delete(
            "/token",
            AuthMiddleware.getAuthFunction(),
            async (req, res, next) => {
                let result;
                try {
                    const userId = res.locals.sub;
                    const roleId = parseInt(res.locals.role);
                    if (roleId === roles.Business) {
                        result = await GoogleService.deleteGoogleToken(userId, roleId)
                    } else if (roleId === roles.staff) {
                        result = await GoogleService.deleteStaffGoogleToken(userId, roleId)
                    }
                } catch (err) {
                    next(err);
                    return;
                }
                if (result == null) {
                    res.status(204).send();
                    return;
                }
                res.json(result);
                return;
            }
        );
        router.get(
            "/code/token",
            async (req, res, next) => {
                const code = req.query.code;
                const state = req.query.state as string;
                if (state) {
                    const decodedState = decodeURIComponent(state);
                    const parsedState = JSON.parse(decodedState);
                    const role = roles[parsedState.role] || roles.Business;
                    await GoogleService.getTokenByCode(code, parsedState.businessId, role);
                }
                res.redirect(`${process.env.CALENDAR_WEBHOOK}/business/account`)
                // res.redirect(`http://localhost:4200/business/account`)
                return;
            }
        );

        router.post(
            "/webhook",
            async (req, res, next) => {
                const event = req.body;
                console.log('Received webhook notification:', event);
                // Process the event as needed  
                const watchChanneId: any = req.headers['x-goog-channel-id'];
                const resourceId: any = req.headers['x-goog-resource-id']; //resource id unique for each calendar 
                console.log('watchChanneId:', watchChanneId);
                console.log('resourceId:', resourceId);
                if (req.headers['x-goog-resource-state'] == 'sync') {
                    res.status(200).send('Received');
                    // res.json(event);
                    return;
                }
                const baseUrl: any = req.headers['x-goog-resource-uri'];
                const parsedUrl = new URL(baseUrl);
                let calendarId = parsedUrl.pathname.split('/').slice(-2, -1)[0];                
                // calendarId = calendarId.replace('%', '@');
                const decodedId = decodeURIComponent(calendarId);
                const eventWatchId = decodeURIComponent(watchChanneId);   
                await GoogleService.updateAndSaveEvent(decodedId, eventWatchId, resourceId);
                res.status(200).send('Received');
                // res.json(event);
                return;
            }
        );
    }
}