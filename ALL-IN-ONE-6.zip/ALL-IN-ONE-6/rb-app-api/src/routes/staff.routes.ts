import { Router } from "express";
import * as Joi from "joi";
import { AuthMiddleware } from "../middleware/auth.middleware";
import { BusinessesService } from "../services/businesses.service";
import { StaffService } from "../services/staff.service";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { Staff } from "../types/staff";
import { StaffHoursBlock } from "../types/staff-hours-block";
import { IdValidator } from "../validators/id.validator";
import { StaffValidator } from "../validators/staff.validator";
import * as multer from "multer";
import { BusinessValidator } from "../validators/business.validator";
import { roles } from "../data/user.roles";
const upload = multer({});
export abstract class StaffRoutes {
  public static staffPath = "/staff";

  public static addStaffRoutes(): Router {
    const router = Router();
    StaffRoutes.addRoutes(router);
    return router;
  }

  private static addRoutes(router: Router): void {
    router.get(
      "/:staffId",
      AuthMiddleware.getAuthFunction(),
      async (req, res, next) => {
        if (IdValidator.isInvalidForRead(req.params.staffId)) {
          res.status(400).send();
          return;
        }

        try {
          res.json(await StaffService.getById(req.params.staffId, res.locals.sub));
          return;
        } catch (err) {
          next(err);
          return;
        }
      }
    );

    router.get("/", AuthMiddleware.getAuthFunction(), AuthMiddleware.userRole([roles.Business, roles.Client]), async (req, res, next) => {
      let Staff;
      try {
        const withDeleted = (req.query as any).withDeleted as string;
        Staff = await StaffService.getAll(res.locals.sub, withDeleted);
      } catch (err) {
        next(err);
        return;
      }

      if (Staff == null) {
        res.status(404).send();
        return;
      }

      res.json(Staff);
    });

    router.get("/service/:serviceId", async (req, res, next) => {
      let Staff;

      if (IdValidator.isInvalidForRead(req.params.serviceId)) {
        res.status(400).send();
        return;
      }

      try {
        // Staff = await StaffService.getStaffByService(req.params.serviceId);
        Staff = await StaffService.getStaffByServiceV2(req.params.serviceId);
      } catch (err) {
        next(err);
        return;
      }

      res.json(Staff);
    });


    router.post("/",
      upload.any(),
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([2]),
      async (req: any, res, next) => {
        const parsedBody = this.parseBodyJson(req.body);
        req.body = parsedBody;
        const validateError = StaffValidator.isInvalidForCreate(req.body);
        if (validateError) {
          res.status(400).json({
            message: "Validación fallida",
            status: false
          });
          return;
        }
        // staff profile image validation
        // FILE validation
        if (req.files && req.files.length > 0) {
          for (const file of req.files) {
            // File size validation
            if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
              res.status(400).send();
              return;
            }
            if (file.fieldname === "logo") {
              req.body['logo'] = file;
            }
          }
        }
        try {
          res
            .status(201)
            .json(
              await StaffService.create(
                new Staff(
                  req.body.id,
                  req.body.businessId,
                  req.body.servicesId,
                  req.body.name,
                  req.body.email == null ? undefined : req.body.email,
                  req.body.password == null ? undefined : req.body.password,
                  undefined,
                  req.body.isOperatingNonStop,
                  req.body.staffHoursBlocks,
                  true,
                  req.body.isDeleted,
                  req.body.logo,
                  undefined,
                  undefined,
                  req.body.gmail == null ? undefined : req.body.gmail,
                  req.body.isConflict == null ? undefined : req.body.isConflict,
                  req.body.gPicture == null ? undefined : req.body.gPicture,
                  req.body.gName == null ? undefined : req.body.gName,
                  undefined,
                  req.body.gEventWatchId == null
                    ? undefined
                    : req.body.gEventWatchId,
                  req.body.gResourceId == null ? undefined : req.body.gResourceId,
                  req.body.syncEventToken == null
                    ? undefined
                    : req.body.syncEventToken,
                    undefined,
                    undefined,
                    undefined,
                    undefined,
                    undefined,
                    undefined,
                  req.body.notificationEnabled
                )
              )
            );
          return;
        } catch (err) {
          // next(err);
          if (err.httpCode === 405) {
            res.status(405).json({
              message: err.message,
              status: false
            })
            return
          }
          res.status(500).json({
            message: err.message,
            status: false
          })
          return;
        }
      });

    router.patch(
      "/:StaffId",
      AuthMiddleware.getAuthFunction(),
      upload.any(),
      async (req: any, res, next) => {
        const parsedBody = this.parseBodyJson(req.body);
        req.body = parsedBody;
        if (StaffValidator.isInvalidForPartialUpdate(req.body)) {
          res.status(400).send();
          return;
        }
        // staff profile image validation
        // FILE validation
        if (req.files && req.files.length > 0) {
          for (const file of req.files) {
            // File size validation
            if (BusinessValidator.isInvalidForPartialUpdateFile(file)) {
              res.status(400).send();
              return;
            }
            if (file.fieldname === "logo") {
              req.body['logo'] = file;
            }
          }
        }
        let result: Staff;
        try {
          result = await StaffService.partialUpdate(
            new Staff(
              req.params.StaffId,
              req.body.businessId,
              req.body.servicesId,
              req.body.name,
              req.body.email == null ? undefined : req.body.email,
              req.body.password == null ? undefined : req.body.password,
              req.body.userId == null ? undefined : req.body.userId,
              req.body.isOperatingNonStop,
              req.body.staffHoursBlocks == null ?
                undefined :
                req.body.staffHoursBlocks.map(bh => new StaffHoursBlock(
                  bh.startDayOfTheWeek,
                  bh.startHour,
                  bh.startMinute,
                  bh.endDayOfTheWeek,
                  bh.endHour,
                  bh.endMinute
                )),
              req.body.isActive,
              req.body.isDeleted,
              req.body.logo,
              undefined,
              undefined,
              req.body.gmail == null ? undefined : req.body.gmail,
              req.body.isConflict == null ? undefined : req.body.isConflict,
              req.body.gPicture == null ? undefined : req.body.gPicture,
              req.body.gName == null ? undefined : req.body.gName,
              undefined,
              req.body.gEventWatchId == null
                ? undefined
                : req.body.gEventWatchId,
              req.body.gResourceId == null ? undefined : req.body.gResourceId,
              req.body.syncEventToken == null
                ? undefined
                : req.body.syncEventToken,
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              undefined,
              req.body.notificationEnabled
            )
          );
        } catch (err) {
          // next(err);
          if (err.httpCode === 405) {
            res.status(405).json({
              message: err.message,
              status: false
            })
            return
          }
          res.status(500).json({
            message: err.message,
            status: false
          })
          return;
        }

        if (result == null) {
          res.status(204).send();
          return;
        }
        if (!result.isAllow) {
          res.status(405).json({
            message: "Se ha alcanzado el límite de personal.",
            status: false
          })
          return;
        }
        res.json(result);
        return;
      }
    );

    router.delete('/:staffId', AuthMiddleware.getAuthFunction(), async (req, res, next) => {
      const staffIdParam = (req.params as any).staffId as string

      if (IdValidator.isInvalidForRead(staffIdParam)) {
        res.status(400).send()
        return
      }

      try {
        res.json(await StaffService.delete(staffIdParam, res.locals.userId))
        return
      } catch (err) {
        next(err)
        return
      }
    })

    router.get(
      "/v2/:staffId",
      AuthMiddleware.getAuthFunction(),
      AuthMiddleware.userRole([2, 3]),
      async (req, res, next) => {
        // if (IdValidator.isInvalidForRead(req.params.staffId)) {
        //   res.status(400).send();
        //   return;
        // }
        try {
          res.json(await StaffService.getByIdV2(res.locals.iss, res.locals.role));
          return;
        } catch (err) {
          next(err);
          return;
        }
      }
    );
  }
  private static parseBodyJson(body) {
    // Create a shallow copy to avoid mutating the original
    const parsedBody = { ...body };
    for (const [key, value] of Object.entries(parsedBody)) {
      if (typeof value === "string" && (key === "servicesId" || key === "staffHoursBlocks")) {
        try {
          parsedBody[key] = JSON.parse(value);
        } catch (error) {
          console.error(`Error while parsing ${key}: ${error.message}`);
        }
      }
    }

    return parsedBody;
  }
}
