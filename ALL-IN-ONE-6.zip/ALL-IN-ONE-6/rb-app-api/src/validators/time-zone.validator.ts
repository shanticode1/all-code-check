import * as Joi from "joi"

import { TimeZone } from "../types/time-zone"
import { BaseValidator } from "./base.validator"
import { IdValidator } from "./id.validator"


export abstract class TimeZoneValidator extends BaseValidator {

	public static readValidationSchema: Joi.ObjectSchema<TimeZone> =
		Joi.object({
			id: IdValidator.readValidationSchema,
			name: Joi.string().trim().min(2).max(40).optional().allow(null),
			displayName: Joi.string().trim().min(2).max(60).optional().allow(null),
			isBusinessDefault: Joi.boolean().optional().allow(null)
		})

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<TimeZone>(payload, TimeZoneValidator.readValidationSchema)
	}

}