import * as Joi from "joi"
import { BaseValidator } from "./base.validator"
import { GoogleToken } from "../types/googleToken"


export abstract class GoogleTokenValidator extends BaseValidator {

	public static readValidationSchema: Joi.ObjectSchema<GoogleToken> =
		Joi.object({
			access_token: Joi.string().trim().min(2).max(200).optional().allow(null),
			refresh_token: Joi.string().trim().max(20).optional().allow(null),
			scope: Joi.string().trim().max(80).optional().allow(null),
			token_type: Joi.string().trim().max(80).optional().allow(null),
			id_token: Joi.string().trim().max(80).optional().allow(null),
			expiry_date: Joi.number().optional().allow(null),
			// syncEventToken: Joi.string().trim().max(500).optional().allow(null),

		})

	public static createOrUpdateValidationSchema: Joi.ObjectSchema<GoogleToken> =
		Joi.object({
			access_token: Joi.string().trim().min(2).max(200).optional().allow(null),
			refresh_token: Joi.string().trim().max(20).optional().allow(null),
			scope: Joi.string().trim().max(80).optional().allow(null),
			token_type: Joi.string().trim().max(80).optional().allow(null),
			id_token: Joi.string().trim().max(80).optional().allow(null),
			expiry_date: Joi.number().optional().allow(null),
			// syncEventToken: Joi.string().trim().max(500).optional().allow(null),
		})

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<GoogleToken>(payload, GoogleTokenValidator.readValidationSchema)
	}

	public static isInvalidForCreateOrUpdate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<GoogleToken>(payload, GoogleTokenValidator.createOrUpdateValidationSchema)
	}
}
