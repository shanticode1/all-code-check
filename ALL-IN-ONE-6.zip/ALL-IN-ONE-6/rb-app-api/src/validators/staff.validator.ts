import * as Joi from "joi";

import { Staff } from "../types/staff";
import { BaseValidator } from "./base.validator";
import { IdValidator } from "./id.validator";
import { StaffHoursBlockValidator } from "./staff-hours-block.validator";

export abstract class StaffValidator extends BaseValidator {
  public static readValidationSchema: Joi.ObjectSchema<Staff> = Joi.object({
    id: IdValidator.createValidationSchema,
    businessId: Joi.string().required(),
    servicesId: Joi.array().optional().allow(null),
    name: Joi.string().trim().min(2).max(40).optional().allow(null),
    email: Joi.string().trim().pattern(BaseValidator.emailRegex)
      .min(6).max(50).optional().allow(null).allow(''),
    password: Joi.string().min(6).max(100).pattern(BaseValidator.passwordRegex).optional().allow(null),
    userId: Joi.string().trim().min(2).max(40).optional().allow(null),
    role: Joi.number().optional().allow(null),
    isOperatingNonStop: Joi.boolean().optional().allow(null),
    staffHoursBlocks: Joi.array()
      .items(StaffHoursBlockValidator.createOrUpdateValidationSchema)
      .unique(
        (a, b) =>
          a.startDayOfTheWeek == b.startDayOfTheWeek &&
          a.startHour == b.startHour &&
          a.startMinute == b.startMinute &&
          a.endDayOfTheWeek == b.endDayOfTheWeek &&
          a.endHour == b.endHour &&
          a.endMinute == b.endMinute
      )
      .optional()
      .allow(null),
    isActive: Joi.boolean().optional().allow(null),
    isDeleted: Joi.boolean().optional().allow(null),
    logo: Joi.any().optional().allow(null).allow(''),
    notificationEnabled: Joi.boolean().optional().allow(null),
  });

  private static createValidationSchema: Joi.ObjectSchema<Staff> = Joi.object({
    id: IdValidator.createValidationSchema,
    businessId: Joi.string().required(),
    servicesId: Joi.array().optional().allow(null),
    name: Joi.string().trim().min(2).max(40).optional().allow(null),
    email: Joi.string().trim().pattern(BaseValidator.emailRegex)
      .min(6).max(50).optional().allow(null).allow(''),
    password: Joi.string().min(6).max(100).pattern(BaseValidator.passwordRegex).optional().allow(null),
    userId: Joi.string().trim().min(2).max(40).optional().allow(null),
    role: Joi.number().optional().allow(null),
    isOperatingNonStop: Joi.boolean().optional().allow(null),
    staffHoursBlocks: Joi.array()
      .items(StaffHoursBlockValidator.createOrUpdateValidationSchema)
      .unique(
        (a, b) =>
          a.startDayOfTheWeek == b.startDayOfTheWeek &&
          a.startHour == b.startHour &&
          a.startMinute == b.startMinute &&
          a.endDayOfTheWeek == b.endDayOfTheWeek &&
          a.endHour == b.endHour &&
          a.endMinute == b.endMinute
      )
      .optional()
      .allow(null),
    isActive: Joi.boolean().optional().allow(null),
    isDeleted: Joi.boolean().optional().allow(null),
    logo: Joi.any().optional().allow(null).allow(''),
    notificationEnabled: Joi.boolean().optional().allow(null),
  });

  public static partialUpdateValidationSchema: Joi.ObjectSchema<Staff> =
    Joi.object({
      id: IdValidator.createValidationSchema,
      businessId: Joi.string().optional().allow(null),
      servicesId: Joi.array().optional().allow(null),
      name: Joi.string().trim().min(2).max(40).optional().allow(null),
      email: Joi.string().trim().pattern(BaseValidator.emailRegex)
        .min(6).max(50).optional().allow(null).allow(''),
      password: Joi.string().min(6).max(100).pattern(BaseValidator.passwordRegex).optional().allow(null),
      userId: Joi.string().trim().min(2).max(40).optional().allow(null),
      role: Joi.number().optional().allow(null),
      isOperatingNonStop: Joi.boolean().optional().allow(null),
      staffHoursBlocks: Joi.array()
        .items(StaffHoursBlockValidator.createOrUpdateValidationSchema)
        .unique(
          (a, b) =>
            a.startDayOfTheWeek == b.startDayOfTheWeek &&
            a.startHour == b.startHour &&
            a.startMinute == b.startMinute &&
            a.endDayOfTheWeek == b.endDayOfTheWeek &&
            a.endHour == b.endHour &&
            a.endMinute == b.endMinute
        )
        .optional()
        .allow(null),
      isActive: Joi.boolean().optional().allow(null),
      isDeleted: Joi.boolean().optional().allow(null),
      logo: Joi.any().optional().allow(null).allow(''),
      notificationEnabled: Joi.boolean().optional().allow(null),
    }).or("name", "services", "isOperatingNonStop", "businessHoursBlocks");

  public static isInvalidForRead(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<Staff>(
      payload,
      StaffValidator.readValidationSchema
    );
  }

  public static isInvalidForCreate(payload: any): string {
    return BaseValidator.isInvalidForSchemaVariables<Staff>(
      payload,
      StaffValidator.createValidationSchema
    );
  }

  public static isInvalidForPartialUpdate(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<Staff>(
      payload,
      StaffValidator.partialUpdateValidationSchema
    );
  }
}
