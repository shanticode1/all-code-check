import * as Joi from "joi"

import { BusinessNotes } from "../types/business-notes"
import { BaseValidator } from "./base.validator"


export abstract class ServiceBusinessNotesValidator extends BaseValidator {

	public static readValidationSchema: Joi.ObjectSchema<BusinessNotes> =
		Joi.object({
			email: Joi.string().trim().optional().allow(null),
			notes: Joi.string().optional().allow(null)
	})

	public static createOrUpdateValidationSchema: Joi.ObjectSchema<BusinessNotes> =
		Joi.object({
			email: Joi.string().trim().optional().allow(''),
			notes: Joi.string().optional().allow('')
	})

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessNotes>(payload, ServiceBusinessNotesValidator.readValidationSchema)
	}

	public static isInvalidForCreateOrUpdate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessNotes>(payload, ServiceBusinessNotesValidator.createOrUpdateValidationSchema)
	}
}