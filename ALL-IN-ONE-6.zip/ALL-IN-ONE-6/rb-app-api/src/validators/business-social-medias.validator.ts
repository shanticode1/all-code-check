import * as Joi from "joi"

import { BusinessSocialMedias } from "../types/business-social-medias"
import { BaseValidator } from "./base.validator"


export abstract class BusinessSocialMediasValidator extends BaseValidator {

	public static readValidationSchema: Joi.ObjectSchema<BusinessSocialMedias> =
		Joi.object({
			ig: Joi.string().trim().min(2).max(100).optional().allow(null),
			fb: Joi.string().trim().min(2).max(100).optional().allow(null),
			wa: Joi.string().trim().min(2).max(20).optional().allow(null),
			countryCode: Joi.string().pattern(BaseValidator.countryRegex).optional().allow(null).allow(''),
		})

	public static createOrUpdateValidationSchema: Joi.ObjectSchema<BusinessSocialMedias> =
		Joi.object({
			ig: Joi.string().trim().min(2).max(100).optional().allow(null),
			fb: Joi.string().trim().min(2).max(100).optional().allow(null),
			wa: Joi.string().trim().min(2).max(20).optional().allow(null),
			countryCode: Joi.string().pattern(BaseValidator.countryRegex).optional().allow(null).allow(''),
		})

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessSocialMedias>(payload, BusinessSocialMediasValidator.readValidationSchema)
	}

	public static isInvalidForCreateOrUpdate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessSocialMedias>(payload, BusinessSocialMediasValidator.createOrUpdateValidationSchema)
	}
}
