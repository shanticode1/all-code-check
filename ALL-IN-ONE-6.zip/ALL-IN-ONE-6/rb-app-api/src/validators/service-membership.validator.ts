import * as Joi from "joi";

import { Staff } from "../types/staff";
import { BaseValidator } from "./base.validator";
import { IdValidator } from "./id.validator";

export abstract class ServiceMembershipValidator extends BaseValidator {
  public static readValidationSchema: Joi.ObjectSchema<Staff> = Joi.object({
    id: IdValidator.createValidationSchema,
    businessId: Joi.string().required(),
    name: Joi.string().optional().allow(null, ''),
    description: Joi.string().optional().allow(null, ''),
    price: Joi.number().required(),
    packageSetting: Joi.array().items(
      Joi.object({
        serviceId: Joi.string().required(),
        bookingQuantity: Joi.number().required(),
      })
    ),
    isActive: Joi.boolean().optional().allow(null),
    isDeleted: Joi.boolean().optional().allow(null),
    logo: Joi.any().optional().allow(null).allow(''),
    currency: Joi.number().optional()
  });

  private static createValidationSchema: Joi.ObjectSchema<Staff> = Joi.object({
    id: IdValidator.createValidationSchema,
    membershipId: Joi.string().optional(),
    businessId: Joi.string().required(),
    name: Joi.string().optional().allow(null, ''),
    description: Joi.string().optional().allow(null, ''),
    price: Joi.number().required(),
    packageSetting: Joi.array().items(
      Joi.object({
        serviceId: Joi.string().required(),
        bookingQuantity: Joi.number().required(),
      })
    ),
    logo: Joi.any().optional().allow(null).allow(''),
    currency: Joi.number().required()

  });

  public static partialUpdateValidationSchema: Joi.ObjectSchema<Staff> =
    Joi.object({
      id: IdValidator.createValidationSchema,
      businessId: Joi.string().required(),
      name: Joi.string().optional().allow(null, ''),
      description: Joi.string().optional().allow(null, ''),
      price: Joi.number().required(),
      packageSetting: Joi.array().items(
        Joi.object({
          serviceId: Joi.string().required(),
          bookingQuantity: Joi.number().required(),
        })
      ),
      isActive: Joi.boolean().optional().allow(null),
      isDeleted: Joi.boolean().optional().allow(null),
      logo: Joi.any().optional().allow(null).allow(''),
      currency: Joi.number().optional()
    })

  public static isInvalidForRead(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<Staff>(
      payload,
      ServiceMembershipValidator.readValidationSchema
    );
  }

  public static isInvalidForCreate(payload: any): string {
    return BaseValidator.isInvalidForSchemaVariables<Staff>(
      payload,
      ServiceMembershipValidator.createValidationSchema
    );
  }

  public static isInvalidForPartialUpdate(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<Staff>(
      payload,
      ServiceMembershipValidator.partialUpdateValidationSchema
    );
  }
}
