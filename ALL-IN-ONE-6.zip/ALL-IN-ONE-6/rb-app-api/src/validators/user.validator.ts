import * as Joi from "joi";
import { User } from "../types/user";
import { BaseValidator } from "./base.validator";
import { IdValidator } from "./id.validator";

export abstract class UserValidator extends BaseValidator {
    public static readValidationSchema: Joi.ObjectSchema<User> = Joi.object({
        id: IdValidator.createValidationSchema,
        email: Joi.string().trim().optional(),
        password: Joi.string().optional(),
        userName: Joi.string().optional(),
        role: Joi.number().min(1).optional().allow(null),
    });

    private static createValidationSchema: Joi.ObjectSchema<User> = Joi.object({
        id: IdValidator.createValidationSchema,
        email: Joi.string().trim().required(),
        password: Joi.string().optional(),
        userName: Joi.string().required(),
        role: Joi.number().min(1).optional().allow(null),
    });

    public static partialUpdateValidationSchema: Joi.ObjectSchema<User> =
        Joi.object({
            id: IdValidator.createValidationSchema,
            email: Joi.string().trim().optional(),
            password: Joi.string().optional(),
            userName: Joi.string().optional(),
            role: Joi.number().min(1).optional().allow(null),
        });

    public static isInvalidForRead(payload: any): boolean {
        return BaseValidator.isInvalidForSchema<User>(
            payload,
            UserValidator.readValidationSchema
        );
    }

    public static isInvalidForCreate(payload: any): boolean {
        return BaseValidator.isInvalidForSchema<User>(
            payload,
            UserValidator.createValidationSchema
        );
    }

    public static isInvalidForPartialUpdate(payload: any): boolean {
        return BaseValidator.isInvalidForSchema<User>(
            payload,
            UserValidator.partialUpdateValidationSchema
        );
    }
}
