import * as Joi from "joi"

import { Business } from "../types/business"
import { BaseValidator } from "./base.validator"
import { IdValidator } from "./id.validator"
import { BusinessTypeValidator } from "./business-type.validator"
import { AddressValidator } from "./address.validator"
import { BusinessHoursBlockValidator } from "./business-hours-block.validator"
import { BusinessServiceValidator } from "./business-service.validator"
import { Currency } from "../types/enums/currency"
import { CoordinatesValidator } from "./coordinates.validator"
import { ServiceCategoryValidator } from "./service-category.validator"
import { ServiceBusinessSettingsValidator } from "./business-settings.validator"
import { TimeZoneValidator } from "./time-zone.validator"
import { ServiceBusinessNotesValidator } from "./business-notes.validator"
import { BusinessSocialMediasValidator } from "./business-social-medias.validator"
import { MembershipTier, WhatsAppMembershipTier } from "../types/enums/membership-tier.enum"
import { GoogleTokenValidator } from "./google-token.validator"
import { User } from "../types/user"

export abstract class BusinessValidator extends BaseValidator {

	public static readValidationSchema: Joi.ObjectSchema<Business> =
		Joi.object({
			id: IdValidator.readValidationSchema,
			contactName: Joi.string().trim().min(3).max(50).optional().allow(null),
			name: Joi.string().trim().min(2).max(40).optional().allow(null),
			slug: Joi.string().pattern(BaseValidator.slugRegex).min(2).max(50).optional().allow(null),
			phoneNumber: Joi.string().pattern(BaseValidator.phoneRegex).min(2).max(13).optional().allow(null),
			countryCode: Joi.string().pattern(BaseValidator.countryRegex).optional().allow(null).allow(''),
			address: AddressValidator.readValidationSchema.optional().allow(null),
			coordinates: CoordinatesValidator.readValidationSchema.optional().allow(null),
			email: Joi.string().trim().pattern(BaseValidator.emailRegex)
				.min(6).max(50).optional().allow(null),
			password: Joi.string().min(6).max(100).pattern(BaseValidator.passwordRegex).optional().allow(null),
			type: BusinessTypeValidator.readValidationSchema.optional().allow(null),
			timeZone: TimeZoneValidator.readValidationSchema.optional().allow(null),
			currency: Joi.number().valid(...Object.values(Currency).filter(v => Number.isInteger(v)))
				.optional().allow(null),
			isOperatingNonStop: Joi.boolean().optional().allow(null),
			businessHoursBlocks: Joi.array().items(BusinessHoursBlockValidator.readValidationSchema)
				.unique((a, b) => a.startDayOfTheWeek == b.startDayOfTheWeek &&
					a.startHour == b.startHour &&
					a.startMinute == b.startMinute &&
					a.endDayOfTheWeek == b.endDayOfTheWeek &&
					a.endHour == b.endHour &&
					a.endMinute == b.endMinute)
				.optional().allow(null),
			about: Joi.string().trim().max(4000).optional().allow(null),
			services: Joi.array().items(BusinessServiceValidator.readValidationSchema).optional().allow(null),
			serviceCategories: Joi.array().items(ServiceCategoryValidator.readValidationSchema).optional().allow(null),
			settings: ServiceBusinessSettingsValidator.readValidationSchema.optional().allow(null),
			socialMedia: BusinessSocialMediasValidator.readValidationSchema.optional().allow(null),
			isActive: Joi.boolean().optional().allow(null),
			isDeleted: Joi.boolean().optional().allow(null),
			membershipTier: Joi.number().valid(...Object.values(MembershipTier).filter(v => Number.isInteger(v))).optional().allow(null),
			membershipExpirationDate: Joi.date().optional().allow(null),
			referral: Joi.string().trim().max(50).optional().allow(null),
			lastCompletedOnboardingStep: Joi.number().optional().allow(null),
			googleToken: GoogleTokenValidator.readValidationSchema.optional().allow(null),
			googleCalendar: Joi.array().optional().allow(null),
			gmail: Joi.string().optional().allow(null),
			isTrialActivatedOnce: Joi.boolean().optional().allow(null),
			whatsAppMembershipTier: Joi.number().valid(...Object.values(WhatsAppMembershipTier).filter(v => Number.isInteger(v))).optional().allow(null),
			heroImage: Joi.any().optional().allow(null).allow(''),
			bannerImage: Joi.any().optional().allow(null).allow(''),
			logo: Joi.any().optional().allow(null).allow(''),
			marketPlaceImages: Joi.any().optional().allow(null).allow(''),
			isPublishedOnMarketplace: Joi.boolean().optional().allow(null),
			fileIds: Joi.string().optional().allow(null).allow(''),
		})

	private static createValidationSchema: Joi.ObjectSchema<Business> =
		Joi.object({
			id: IdValidator.createValidationSchema,
			contactName: Joi.string().trim().min(3).max(50).required(),
			name: Joi.string().trim().min(2).max(40).optional().allow(null),
			slug: Joi.string().pattern(BaseValidator.slugRegex).min(2).max(50).optional().allow(null),
			phoneNumber: Joi.string().pattern(BaseValidator.phoneRegex).min(2).max(13).optional().allow(null),
			countryCode: Joi.string().pattern(BaseValidator.countryRegex).optional().allow(null).allow(''),
			address: AddressValidator.readValidationSchema.optional().allow(null),
			coordinates: CoordinatesValidator.readValidationSchema.optional().allow(null),
			email: Joi.string().trim().pattern(BaseValidator.emailRegex)
				.min(6).max(50).required(),
			password: Joi.string().min(6).max(100).pattern(BaseValidator.passwordRegex).required(),
			type: BusinessTypeValidator.readValidationSchema.optional().allow(null),
			timeZone: TimeZoneValidator.readValidationSchema.optional().allow(null),
			currency: Joi.number().valid(...Object.values(Currency).filter(v => Number.isInteger(v)))
				.optional().allow(null),
			isOperatingNonStop: Joi.boolean().optional().allow(null),
			businessHoursBlocks: Joi.array().items(BusinessHoursBlockValidator.createOrUpdateValidationSchema)
				.unique((a, b) => a.startDayOfTheWeek == b.startDayOfTheWeek &&
					a.startHour == b.startHour &&
					a.startMinute == b.startMinute &&
					a.endDayOfTheWeek == b.endDayOfTheWeek &&
					a.endHour == b.endHour &&
					a.endMinute == b.endMinute)
				.optional().allow(null),
			about: Joi.string().trim().max(4000).optional().allow(null),
			services: Joi.array().items(BusinessServiceValidator.readValidationSchema).optional().allow(null),
			serviceCategories: Joi.array().items(ServiceCategoryValidator.readValidationSchema).optional().allow(null),
			settings: ServiceBusinessSettingsValidator.createValidationSchema.optional().allow(null),
			socialMedia: BusinessSocialMediasValidator.createOrUpdateValidationSchema.optional().allow(null),
			isActive: Joi.boolean().optional().allow(null),
			isDeleted: Joi.boolean().optional().allow(null),
			membershipTier: Joi.number().valid(...Object.values(MembershipTier).filter(v => Number.isInteger(v))).optional().allow(null),
			membershipExpirationDate: Joi.date().optional().allow(null),
			referral: Joi.string().trim().max(50).optional().allow(null),
			lastCompletedOnboardingStep: Joi.number().optional().allow(null),
			googleToken: GoogleTokenValidator.readValidationSchema.optional().allow(null),
			googleCalendar: Joi.array().optional().allow(null),
			gmail: Joi.string().optional().allow(null),
			isTrialActivatedOnce: Joi.boolean().optional().allow(null),
			whatsAppMembershipTier: Joi.number().valid(...Object.values(WhatsAppMembershipTier).filter(v => Number.isInteger(v))).optional().allow(null),
			heroImage: Joi.any().optional().allow(null).allow(''),
			bannerImage: Joi.any().optional().allow(null).allow(''),
			logo: Joi.any().optional().allow(null).allow(''),
			role: Joi.string().optional().allow(null).allow(''),
			marketPlaceImages: Joi.any().optional().allow(null).allow(''),
			isPublishedOnMarketplace: Joi.boolean().optional().allow(null),
			fileIds: Joi.string().optional().allow(null).allow(''),
		})

	private static createUserValidationSchema: Joi.ObjectSchema<User> = Joi.object({
		id: IdValidator.createValidationSchema,
		email: Joi.string().trim().required(),
		password: Joi.string().optional(),
		contactName: Joi.string().required(),
		role: Joi.string().min(1).optional().allow(null).allow(''),
		phone: Joi.string().pattern(BaseValidator.phoneRegex).optional().allow(null).allow(''),
		countryCode: Joi.string().optional().allow(null).allow(''),
		address: AddressValidator.createOrUpdateValidationSchema.optional().allow(null).allow('')
	});

	public static partialUpdateValidationSchema: Joi.ObjectSchema<Business> =
		Joi.object({
			id: IdValidator.createValidationSchema,
			contactName: Joi.string().trim().min(3).max(50).optional().allow(null),
			name: Joi.string().trim().min(2).max(40).optional().allow(null),
			slug: Joi.string().pattern(BaseValidator.slugRegex).min(2).max(50).optional().allow(null),
			phoneNumber: Joi.string().pattern(BaseValidator.phoneRegex).min(2).max(13).optional().allow(null),
			countryCode: Joi.string().pattern(BaseValidator.countryRegex).optional().allow(null).allow(''),
			address: AddressValidator.createOrUpdateValidationSchema.optional().allow(null),
			coordinates: CoordinatesValidator.createOrUpdateValidationSchema.optional().allow(null),
			email: Joi.string().trim().pattern(BaseValidator.emailRegex)
				.min(6).max(50).optional().allow(null),
			password: Joi.string().min(6).max(100).pattern(BaseValidator.passwordRegex).optional().allow(null),
			type: BusinessTypeValidator.readValidationSchema.optional().allow(null),
			timeZone: TimeZoneValidator.readValidationSchema.optional().allow(null),
			currency: Joi.number().valid(...Object.values(Currency).filter(v => Number.isInteger(v)))
				.optional().allow(null),
			isOperatingNonStop: Joi.boolean().optional().allow(null),
			businessHoursBlocks: Joi.array().items(BusinessHoursBlockValidator.createOrUpdateValidationSchema)
				.unique((a, b) => a.startDayOfTheWeek == b.startDayOfTheWeek &&
					a.startHour == b.startHour &&
					a.startMinute == b.startMinute &&
					a.endDayOfTheWeek == b.endDayOfTheWeek &&
					a.endHour == b.endHour &&
					a.endMinute == b.endMinute)
				.optional().allow(null),
			about: Joi.string().trim().max(4000).optional().allow(null, ''),
			services: Joi.array().items(BusinessServiceValidator.readValidationSchema).optional().allow(null),
			serviceCategories: Joi.array().items(ServiceCategoryValidator.readValidationSchema).optional().allow(null),
			settings: ServiceBusinessSettingsValidator.updateValidationSchema.optional().allow(null),
			notes: Joi.array().items(ServiceBusinessNotesValidator.createOrUpdateValidationSchema)
				.unique((a, b) => a.email == b.email && a.notes == b.notes).optional().allow(null),
			socialMedia: BusinessSocialMediasValidator.createOrUpdateValidationSchema.optional().allow(null),
			isActive: Joi.boolean().optional().allow(null),
			isDeleted: Joi.boolean().optional().allow(null),
			membershipTier: Joi.number().valid(...Object.values(MembershipTier).filter(v => Number.isInteger(v))).optional().allow(null),
			membershipExpirationDate: Joi.date().optional().allow(null),
			referral: Joi.string().trim().max(50).optional().allow(null),
			lastCompletedOnboardingStep: Joi.number().optional().allow(null),
			googleToken: GoogleTokenValidator.createOrUpdateValidationSchema.optional().allow(null),
			googleCalendar: Joi.array().optional().allow(null),
			gmail: Joi.string().optional().allow(null),
			isTrialActivatedOnce: Joi.boolean().optional().allow(null),
			// heroImage: Joi.string().optional().allow(null).allow(''),
			// bannerImage: Joi.string().optional().allow(null).allow('')
			whatsAppMembershipTier: Joi.number().valid(...Object.values(WhatsAppMembershipTier).filter(v => Number.isInteger(v))).optional().allow(null),
			heroImage: Joi.any().optional().allow(null).allow(''),
			bannerImage: Joi.any().optional().allow(null).allow(''),
			businessId: Joi.string().optional().allow(null).allow(''),
			logo: Joi.any().optional().allow(null).allow(''),
			role: Joi.string().optional().allow(null).allow(''),
			marketPlaceImages: Joi.any().optional().allow(null).allow(''),
			isPublishedOnMarketplace: Joi.boolean().optional().allow(null),
			fileIds: Joi.array().optional().allow(null).allow(''),
		})
			.or('name', 'slug', 'phoneNumber', 'address', 'coordinates', 'email', 'password', 'type', 'timeZone', 'currency', 'isOperatingNonStop', 'businessHoursBlocks', 'about', 'settings', 'notes', 'socialMedia', 'membershipTier', 'membershipExpirationDate', 'referral', 'lastCompletedOnboardingStep')

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<Business>(payload, BusinessValidator.readValidationSchema)
	}

	public static isInvalidForCreate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<Business>(payload, BusinessValidator.createValidationSchema)
	}

	public static isInvalidForCreateUser(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<User>(payload, BusinessValidator.createUserValidationSchema)
	}

	// public static isInvalidForUpdate(payload: any): boolean {
	// 	return BaseValidator.isInvalidForSchema<Business>(payload, BusinessValidator.updateValidationSchema)
	// }

	public static isInvalidForPartialUpdate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<Business>(payload, BusinessValidator.partialUpdateValidationSchema)
	}

	public static isInvalidForPartialUpdateFile(payload: any): boolean {
		// Define the schema for validation
		const schema = Joi.object({
			file: Joi.object({
				mimetype: Joi.string().regex(/^image\//).required(),
				size: Joi.number().max(5 * 1024 * 1024).required() // 5 MB limit
			}).optional().allow(null)
		});
		const validationResult = schema.validate({ file: { mimetype: payload.mimetype, size: payload.size } });
		return BaseValidator.isInvalidForFileSchema<any>(validationResult)
	}
}