import * as Joi from "joi"

import { Customer } from "../types/customer"
import { BaseValidator } from "./base.validator"
import { Client } from "../types/clients";


export abstract class CustomerValidator {

	public static createValidationSchema: Joi.ObjectSchema<Customer> =
		Joi.object({
			name: Joi.string().trim().min(2).max(40).required(),
			surname: Joi.string().trim().min(1).max(40).required(),
			email: Joi.string().trim().pattern(BaseValidator.emailRegex).min(6).max(50)
				.required(),
			phoneNumber: Joi.string().pattern(BaseValidator.phoneRegex)
				.optional().allow(null),
			// countryCode: Joi.string().pattern(BaseValidator.countryRegex).required(),
			countryCode: Joi.string().optional(),
			isWhatsAppAllow: Joi.boolean().optional().allow(null).allow(false),
			isEmailAllow: Joi.boolean().optional().allow(null).allow(false),
		});

	public static createValidationSchemaV1: Joi.ObjectSchema<Customer> =
		Joi.object({
			businessId: Joi.string().trim().required(),
			name: Joi.string().trim().min(2).max(40).required(),
			surname: Joi.string().trim().min(1).max(40).required(),
			email: Joi.string().trim().pattern(BaseValidator.emailRegex).min(6).max(50).required(),
			phone: Joi.string().pattern(BaseValidator.phoneRegex).optional().allow(null),
			// countryCode: Joi.string().pattern(BaseValidator.countryRegex).required(),
			countryCode: Joi.string().optional(),
			isWhatsAppAllow: Joi.boolean().optional().allow(null).allow(false),
			isEmailAllow: Joi.boolean().optional().allow(null).allow(false),
			lastBookingDate: Joi.date().optional().allow('').allow(null),
			notes: Joi.string().optional().allow('').allow(null)

		});
	public static isInvalidForCreate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<any>(payload, CustomerValidator.createValidationSchemaV1)
	}
}