import * as Joi from "joi";

import { BusinessService } from "../types/business-service";
import { Currency } from "../types/enums/currency";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { BaseValidator } from "./base.validator";
import { IdValidator } from "./id.validator";
import { ServiceCategoryValidator } from "./service-category.validator";
import { ServiceDaysBlock } from "../types/business-hours-block";
import { DayOfTheWeek } from "../types/enums/day-of-the-week.enum";
import { BusinessServicePayment } from "../types/business-service-payment";
import { BusinessServiceEventSetting } from "../types/business-service-event-setting";
import { EventType, RecurrenceType } from "../types/enums/event-type.enum";
import { AddressValidator } from "./address.validator";

export abstract class BusinessServiceValidator extends BaseValidator {

  public static paymentSettingValidationSchema: Joi.ObjectSchema<BusinessServicePayment> =
    Joi.object({
      isPaymentAllow: Joi.boolean().optional(),
      paymentType: Joi.array().optional().allow(null),
      isPaymentLinkSend: Joi.boolean().optional(),
      isCurrency: Joi.boolean().optional(),
      isPercentage: Joi.boolean().optional(),
    })

  public static eventSettingValidationSchema: Joi.ObjectSchema<BusinessServiceEventSetting> =
    Joi.object({
      eventType: Joi.string().valid(EventType.DoesNotRepeat, EventType.Daily, EventType.Weekly, EventType.Monthly, EventType.Custom).required(),
      startDate: Joi.date().required(),
      startTime: Joi.string().pattern(BaseValidator.eventTimeRegex).required(), // HH:mm format
      endDate: Joi.date().required(),
      endTime: Joi.string().pattern(BaseValidator.eventTimeRegex).required(),
      staffs: Joi.array().items(Joi.string()).optional().allow(null),
      isStaffConflict: Joi.boolean().optional().allow(null),
      isBusinessConflict: Joi.boolean().optional().allow(null),
      recurrenceType: Joi.string().valid(RecurrenceType.OneTime, RecurrenceType.Repeated).optional().allow(null),
      isNoConflict: Joi.boolean().optional().allow(null),
      customSetting: Joi.object().optional().default({}),
    });

  public static serviceDaysValidationSchema: Joi.ObjectSchema<ServiceDaysBlock> =
    Joi.object({
      dayOfTheWeek: Joi.number().valid(...Object.values(DayOfTheWeek).filter(v => Number.isInteger(v)))
        .optional().allow(null),
    })

  public static readValidationSchema: Joi.ObjectSchema<BusinessService> =
    Joi.object({
      id: IdValidator.readValidationSchema,
      name: Joi.string().trim().min(2).max(40).optional().allow(null),
      description: Joi.string().trim().max(500).optional().allow(null),
      category: ServiceCategoryValidator.readValidationSchema
        .optional()
        .allow(null),

      // duration: Joi.number().integer().min(1).optional().allow(null),
      // durationUnit: Joi.number()
      //   .valid(
      //     ...Object.values(DurationUnit).filter((v) => Number.isInteger(v))
      //   )
      //   .optional()
      //   .allow(null),

      duration: Joi.when('type', {
        not: 'event',
        then: Joi.number().integer().min(1).optional().allow(null), // ✅ Only when type !== 'event'
        otherwise: Joi.optional(),
      }),
      durationUnit: Joi.when('type', {
        not: 'event',
        then: Joi.number()
          .valid(...Object.values(DurationUnit).filter((v) => Number.isInteger(v)))
          .optional().allow(null),
        otherwise: Joi.optional().allow(null),
      }),

      price: Joi.number().integer().min(0).optional().allow(null),
      currency: Joi.number()
        .valid(...Object.values(Currency).filter((v) => Number.isInteger(v)))
        .optional()
        .allow(null),
      type: Joi.string().trim().empty().allow(null),
      capacity: Joi.number().empty().allow(null),
      hash: Joi.string().hex().length(22).optional().allow(null),
      isActive: Joi.boolean().optional().allow(null),
      isDeleted: Joi.boolean().optional().allow(null),
      location: Joi.string().trim().empty().optional().allow(null).allow(''),
      serviceDaysBlocks: Joi.array().items(this.serviceDaysValidationSchema)
        // .unique((a, b) => a.dayOfTheWeek == b.dayOfTheWeek)
        .optional().allow(null),
      paymentSetting: this.paymentSettingValidationSchema.optional().allow(null),
      depositAmount: Joi.number().integer().min(0).optional().allow(null),
      // Conditional validation for eventSetting
      eventSetting: Joi.when('type', {
        is: 'event',
        then: this.eventSettingValidationSchema.required(),
        otherwise: Joi.any().strip() // Remove from final value if not applicable
      }),
      // isCapacityVisible: Joi.boolean().optional().allow(null),
      serviceAddress: AddressValidator.readWriteServiceAddressValidationSchema.optional().allow(null),
      cutOff: Joi.number().integer().min(0).optional().allow(null).allow(''),
      cutOffUnit: Joi.number()
        .valid(...Object.values(DurationUnit).filter((v) => Number.isInteger(v)))
        .optional().allow(null).allow(''),
      logo: Joi.any().optional().allow(null).allow(''),


    });

  public static createValidationSchema: Joi.ObjectSchema<BusinessService> =
    Joi.object({
      id: IdValidator.createValidationSchema,
      name: Joi.string().trim().min(2).max(40).required(),
      description: Joi.string().trim().max(500).optional().allow(null),
      category: ServiceCategoryValidator.readValidationSchema
        .optional()
        .allow(null),

      // duration: Joi.number().integer().min(1).required(),
      // durationUnit: Joi.number()
      //   .valid(
      //     ...Object.values(DurationUnit).filter((v) => Number.isInteger(v))
      //   )
      //   .required(),

      duration: Joi.when('type', {
        not: 'event',
        then: Joi.number().integer().min(1).required(), // ✅ Only when type !== 'event'
        otherwise: Joi.optional(),
      }),
      durationUnit: Joi.when('type', {
        not: 'event',
        then: Joi.number()
          .valid(...Object.values(DurationUnit).filter((v) => Number.isInteger(v)))
          .required(),
        otherwise: Joi.optional().allow(null),
      }),
      price: Joi.number().integer().min(0).optional().allow(null),
      currency: Joi.when("price", {
        is: Joi.number().integer().greater(0).required(),
        then: Joi.number()
          .valid(...Object.values(Currency).filter((v) => Number.isInteger(v)))
          .optional()
          .allow(null),
        otherwise: Joi.number()
          .valid(...Object.values(Currency).filter((v) => Number.isInteger(v)))
          .optional()
          .allow(null),
      }),
      type: Joi.string().trim().empty().allow(null),
      capacity: Joi.number().empty().allow(null),
      hash: Joi.string().hex().length(22).optional().allow(null),
      isActive: Joi.boolean().optional().allow(null),
      isDeleted: Joi.boolean().optional().allow(null),
      location: Joi.string().trim().empty().optional().allow(null).allow(''),
      serviceDaysBlocks: Joi.array().items(this.serviceDaysValidationSchema)
        // .unique((a, b) => a.dayOfTheWeek == b.dayOfTheWeek)
        .optional().allow(null),
      paymentSetting: this.paymentSettingValidationSchema.optional().allow(null),
      depositAmount: Joi.number().integer().min(0).optional().allow(null),
      // Conditional validation for eventSetting
      eventSetting: Joi.when('type', {
        is: 'event',
        then: this.eventSettingValidationSchema.required(),
        otherwise: Joi.any().strip() // Remove from final value if not applicable
      }),
      // isCapacityVisible: Joi.boolean().optional().allow(null),
      serviceAddress: AddressValidator.readWriteServiceAddressValidationSchema.optional().allow(null),
      cutOff: Joi.number().integer().min(0).optional().allow(null).allow(''),
      cutOffUnit: Joi.number()
        .valid(...Object.values(DurationUnit).filter((v) => Number.isInteger(v)))
        .optional().allow(null).allow(''),
      logo: Joi.any().optional().allow(null).allow(''),

    });

  public static updateValidationSchema: Joi.ObjectSchema<BusinessService> =
    Joi.object({
      id: IdValidator.createValidationSchema,
      name: Joi.string().trim().min(2).max(40).required(),
      description: Joi.string().trim().max(500).optional().allow(null),
      category: ServiceCategoryValidator.readValidationSchema
        .optional()
        .allow(null),

      // duration: Joi.number().integer().min(1).required(),
      // durationUnit: Joi.number()
      //   .valid(
      //     ...Object.values(DurationUnit).filter((v) => Number.isInteger(v))
      //   )
      //   .required(),
      duration: Joi.when('type', {
        not: 'event',
        then: Joi.number().integer().min(1).required(), // ✅ Only when type !== 'event'
        otherwise: Joi.optional(),
      }),
      durationUnit: Joi.when('type', {
        not: 'event',
        then: Joi.number()
          .valid(...Object.values(DurationUnit).filter((v) => Number.isInteger(v)))
          .required(),
        otherwise: Joi.optional().allow(null),
      }),

      price: Joi.number().integer().min(0).optional().allow(null),
      currency: Joi.when("price", {
        is: Joi.number().integer().greater(0).required(),
        then: Joi.number()
          .valid(...Object.values(Currency).filter((v) => Number.isInteger(v)))
          .required(),
        otherwise: Joi.number()
          .valid(...Object.values(Currency).filter((v) => Number.isInteger(v)))
          .optional()
          .allow(null),
      }),
      type: Joi.string().trim().empty().allow(null),
      capacity: Joi.number().empty().allow(null),
      hash: Joi.string().hex().length(22).optional().allow(null),
      isActive: Joi.boolean().optional().required(),
      isDeleted: Joi.boolean().optional().allow(null),
      location: Joi.string().trim().optional().empty().allow(null).allow(''),
      serviceDaysBlocks: Joi.array().items(this.serviceDaysValidationSchema)
        // .unique((a, b) => a.dayOfTheWeek == b.dayOfTheWeek)
        .optional().allow(null),
      paymentSetting: this.paymentSettingValidationSchema.optional().allow(null),
      depositAmount: Joi.number().integer().min(0).optional().allow(null),
      // Conditional validation for eventSetting
      eventSetting: Joi.when('type', {
        is: 'event',
        then: this.eventSettingValidationSchema.required(),
        otherwise: Joi.any().strip() // Remove from final value if not applicable
      }),
      // isCapacityVisible: Joi.boolean().optional().allow(null),
      serviceAddress: AddressValidator.readWriteServiceAddressValidationSchema.optional().allow(null),
      cutOff: Joi.number().integer().min(0).optional().allow(null).allow(''),
      cutOffUnit: Joi.number()
        .valid(...Object.values(DurationUnit).filter((v) => Number.isInteger(v)))
        .optional().allow(null).allow(''),
      logo: Joi.any().optional().allow(null).allow(''),
    });

  public static isInvalidForRead(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<BusinessService>(
      payload,
      BusinessServiceValidator.readValidationSchema
    );
  }

  public static isInvalidForCreate(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<BusinessService>(
      payload,
      BusinessServiceValidator.createValidationSchema
    );
  }

  public static isInvalidForUpdate(payload: any): boolean {
    return BaseValidator.isInvalidForSchema<BusinessService>(
      payload,
      BusinessServiceValidator.updateValidationSchema
    );
  }
}
