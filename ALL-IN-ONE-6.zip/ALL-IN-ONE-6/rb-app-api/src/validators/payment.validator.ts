import * as Joi from "joi"
import { BaseValidator } from "./base.validator"
import { MembershipType, Payment } from "../types/payment"


export abstract class PaymentValidator extends BaseValidator {

    public static readValidationSchema: Joi.ObjectSchema<Payment> =
        Joi.object({
            customerId: Joi.string().required(),
        })

    public static createOrUpdateValidationSchema: Joi.ObjectSchema<Payment> =
        Joi.object({
            priceId: Joi.string().required(),
            customerId: Joi.string().required(),
        })

    public static createMembershipValidationSchema: Joi.ObjectSchema<MembershipType> =
        Joi.object({
            membershipId: Joi.string().required(),
            quantity: Joi.number().required(),
        })

    public static isInvalidForRead(payload: any): string {
        return BaseValidator.isInvalidForSchemaVariables<Payment>(payload, PaymentValidator.readValidationSchema)
    }

    public static isInvalidForCreateOrUpdate(payload: any): string {
        return BaseValidator.isInvalidForSchemaVariables<Payment>(payload, PaymentValidator.createOrUpdateValidationSchema)
    }

    public static isInvalidForCreateMembership(payload: any): string {
        return BaseValidator.isInvalidForSchemaVariables<MembershipType>(payload, PaymentValidator.createMembershipValidationSchema)
    }
}
