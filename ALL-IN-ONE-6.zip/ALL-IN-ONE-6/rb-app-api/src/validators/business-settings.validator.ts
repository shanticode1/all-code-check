import * as Joi from "joi"

import { BusinessSettings, ReminderSetting } from "../types/business-settings"
import { BaseValidator } from "./base.validator"
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { ServiceType } from "../types/enums/service.type";
const { htmlToText } = require('html-to-text');

// format html content for check validaton
function stripHtml(html) {
	const value = htmlToText(html, {
		wordwrap: false,
		ignoreHref: true,
		ignoreImage: true
	});
	//remove bracketed URLs
	const urlPattern = /\[.*?\]/g;
	const cleanedValue = value.replace(urlPattern, '');
	return cleanedValue
}

const htmlContentSchema = Joi.string().custom((value, helpers: any) => {
	// Then, strip HTML tags
	const strippedContent = stripHtml(value);
	const contentLength = strippedContent.length;
	// Validate the length of the plain text content
	if (contentLength >= 550) { // Example length check for WhatsApp reminder info
		return helpers.message(`Content length must be between 10 and 550 characters, current length is ${contentLength}`);
	}
	return value;
}, 'HTML Content Validation');
const htmlContentSchemaV2 = Joi.string().custom((value, helpers: any) => {
	// Then, strip HTML tags
	const strippedContent = stripHtml(value);
	const contentLength = strippedContent.length;
	// Validate the length of the plain text content	
	if (contentLength >= 650) { // Example length check for WhatsApp reminder info
		return helpers.message(`Content length must be between 1 and 650 characters, current length is ${contentLength}`);
	}
	return value;
}, 'HTML Content Validation');
export abstract class ServiceBusinessSettingsValidator extends BaseValidator {

	public static reminderValidationSchema: Joi.ObjectSchema<ReminderSetting> =
		Joi.object({
			duration: Joi.number().integer().min(0).required(),
			durationUnit: Joi.number()
				.valid(
					...Object.values(DurationUnit).filter((v) => Number.isInteger(v))
				)
				.required(),
		})

	public static readValidationSchema: Joi.ObjectSchema<BusinessSettings> =
		Joi.object({
			bookingAutoapprove: Joi.boolean().optional(),
			hideAddress: Joi.boolean().optional(),
			paymentTypes: Joi.array().optional().allow(null),
			manualPaymentInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			isWhatsAppReminder: Joi.boolean().optional(),
			isEmailReminder: Joi.boolean().optional(),
			whatsAppReminderInfo: htmlContentSchema.trim().optional().allow(null).allow(''),
			emailInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			emailReminderDuration: this.reminderValidationSchema
				.optional()
				.allow(null).allow(''),
			whatsappReminderDuration: this.reminderValidationSchema
				.optional()
				.allow(null).allow(''),
			cancelationPolicyInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			serviceCapacityVisibility: Joi.object({
				types:Joi.array()
				.items(
					Joi.number()
						.valid(...Object.values(ServiceType).filter(v => Number.isInteger(v)))
						.optional().allow(null).allow('')
				)
				.optional().allow(null).allow(''),
			}).optional().allow(null).allow(''),
		})

	public static createValidationSchema: Joi.ObjectSchema<BusinessSettings> =
		Joi.object({
			bookingAutoapprove: Joi.boolean().optional(),
			hideAddress: Joi.boolean().optional(),
			paymentTypes: Joi.array().optional().allow(null),
			manualPaymentInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			isWhatsAppReminder: Joi.boolean().optional(),
			isEmailReminder: Joi.boolean().optional(),
			whatsAppReminderInfo: htmlContentSchema.trim().optional().allow(null).allow(''),
			emailInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			emailReminderDuration: this.reminderValidationSchema
				.optional()
				.allow(null).allow(''),
			whatsappReminderDuration: this.reminderValidationSchema
				.optional()
				.allow(null).allow(''),
			cancelationPolicyInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			serviceCapacityVisibility: Joi.object({
				types:Joi.array()
				.items(
					Joi.number()
						.valid(...Object.values(ServiceType).filter(v => Number.isInteger(v)))
						.optional().allow(null).allow('')
				)
				.optional().allow(null).allow(''),
			}).optional().allow(null).allow(''),
		})

	public static updateValidationSchema: Joi.ObjectSchema<BusinessSettings> =
		Joi.object({
			bookingAutoapprove: Joi.boolean().required(),
			hideAddress: Joi.boolean().optional(),
			paymentTypes: Joi.array().optional().allow(null),
			manualPaymentInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			isWhatsAppReminder: Joi.boolean().optional(),
			isEmailReminder: Joi.boolean().optional(),
			whatsAppReminderInfo: htmlContentSchema.trim().optional().allow(null).allow(''),
			emailInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			emailReminderDuration: this.reminderValidationSchema
				.optional()
				.allow(null).allow(''),
			whatsappReminderDuration: this.reminderValidationSchema
				.optional()
				.allow(null).allow(''),
			cancelationPolicyInfo: htmlContentSchemaV2.trim().optional().allow(null).allow(''),
			serviceCapacityVisibility: Joi.object({
				types:Joi.array()
				.items(
					Joi.number()
						.valid(...Object.values(ServiceType).filter(v => Number.isInteger(v)))
						.optional().allow(null).allow('')
				)
				.optional().allow(null).allow(''),
			}).optional().allow(null).allow(''),
		})

	public static isInvalidForUpdate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessSettings>(payload, ServiceBusinessSettingsValidator.updateValidationSchema)
	}

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessSettings>(payload, ServiceBusinessSettingsValidator.readValidationSchema)
	}

	public static isInvalidForCreate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<BusinessSettings>(payload, ServiceBusinessSettingsValidator.createValidationSchema)
	}
}