import * as Joi from "joi"

import { Address } from "../types/address"
import { BaseValidator } from "./base.validator"


export abstract class AddressValidator extends BaseValidator {

	public static readValidationSchema: Joi.ObjectSchema<Address> =
		Joi.object({
			address: Joi.string().trim().min(2).max(300).optional().allow(null),
			suite: Joi.string().trim().max(300).optional().allow(null),
			district: Joi.string().trim().max(100).optional().allow(null),
			city: Joi.string().trim().max(100).optional().allow(null),
			region: Joi.string().trim().max(100).optional().allow(null),
			postcode: Joi.string().trim().max(20).optional().allow(null),
			country: Joi.string().trim().max(100).optional().allow(null),
			countryShortName: Joi.string().trim().max(20).optional().allow(null).allow('')
		})

	public static createOrUpdateValidationSchema: Joi.ObjectSchema<Address> =
		Joi.object({
			address: Joi.string().trim().min(2).max(300).optional().allow(null),
			suite: Joi.string().trim().max(300).optional().allow(null),
			district: Joi.string().trim().max(100).optional().allow(null),
			city: Joi.string().trim().max(100).optional().allow(null),
			region: Joi.string().trim().max(100).optional().allow(null),
			postcode: Joi.string().trim().max(20).optional().allow(null),
			country: Joi.string().trim().max(100).optional().allow(null),
			countryShortName: Joi.string().trim().max(20).optional().allow(null).allow('')
		})

	public static isInvalidForRead(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<Address>(payload, AddressValidator.readValidationSchema)
	}

	public static isInvalidForCreateOrUpdate(payload: any): boolean {
		return BaseValidator.isInvalidForSchema<Address>(payload, AddressValidator.createOrUpdateValidationSchema)
	}
	public static readWriteServiceAddressValidationSchema: Joi.ObjectSchema<Address> =
	Joi.object({
		address: Joi.string().trim().min(2).max(300).optional().allow(null),
		suite: Joi.string().trim().max(300).optional().allow(null),
		district: Joi.string().trim().max(100).optional().allow(null),
		city: Joi.string().trim().max(100).optional().allow(null),
		region: Joi.string().trim().max(100).optional().allow(null),
		postcode: Joi.string().trim().max(20).optional().allow(null),
		country: Joi.string().trim().max(100).optional().allow(null),
		countryShortName: Joi.string().trim().max(20).optional().allow(null).allow(''),
		coordinates: Joi.object({
			latitude: Joi.number().optional().allow(null),
			longitude: Joi.number().optional().allow(null)
		}).optional().allow(null)
	})
}
