import * as winston from 'winston'
import { ErrorService } from './error.service';
const DailyRotateFile = require('winston-daily-rotate-file')
export abstract class Logger {
	public static logger: winston.Logger
	public static initializeLogger() {

		const runningInProduction = process.env.NODE_ENV === 'production' || process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'development'
		const loggingFormats = [
			winston.format.timestamp({
				format: 'YYYY-MM-DD HH:mm:ss'
			}),
			winston.format.errors({ stack: true })
		]

		loggingFormats.push(
			runningInProduction ?
				winston.format.json() :
				winston.format.cli()
		)

		// Create a custom format that captures only error and warning messages
		const captureFormat = winston.format((info: any) => {
			if (info.level === 'error' || info.level === 'warn') {
				const symbolMessage = info[Symbol.for('message')]; // Access the value of Symbol(message)
				ErrorService.saveErrors(symbolMessage, info.level) //save error in data base 
			}
			return info; // Ensure the log message is passed on to other formats/transports
		});

		Logger.logger = winston.createLogger({
			level: 'http',
			format: winston.format.combine(...loggingFormats,
				captureFormat(),
				winston.format.simple()),
			defaultMeta: { service: 'rezrvapp-api' },
			transports: [
				new winston.transports.Console({
					format: winston.format.combine(
						winston.format.colorize({ all: true }),
						// winston.format.printf(({ level, message, timestamp }) => {
						// 	return `level: ${level}, message: ${message},"service":"rezrvapp-api", timestamp: ${timestamp}`; // Format your log message as needed
						// })
					)
				})
			]
		})

		if (runningInProduction) {
			Logger.logger.add(
				new (DailyRotateFile)({
					filename: 'logs/rezrvapp-api-%DATE%.log',
					datePattern: 'YYYY-MM-DD-HH',
					maxSize: '20m',
					maxFiles: '10d'
				})
			)
		}
	}
}