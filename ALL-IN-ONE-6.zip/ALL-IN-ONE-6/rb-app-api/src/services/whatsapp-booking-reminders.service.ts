import { BookingReminderDbModel, IBookingReminder } from "../db-models/booking-reminder.db-model"
import { IBooking } from "../db-models/booking.db-model"
import { Logger } from "../logger"
import { BookingReminder } from "../types/booking-reminder"
import { BookingReminderType, whatsAppPhoneListForTest } from "../types/enums/booking-reminder-type.enum"
import { DurationUnit } from "../types/enums/duration-unit.enum"
import { MembershipTier } from "../types/enums/membership-tier.enum"
import { PaymentType } from "../types/enums/payment-type.enum"
import { DateUtils } from "../utils/date.utils"
import { BookingRemindersService } from "./boking-reminders.service"
import { BookingsService } from "./bookings.service"
import { BusinessServiceSnapshotsService } from "./business-service-snapshots.service"
import { BusinessServicesService } from "./business-services.service"
import { BusinessesService } from "./businesses.service"
import { EmailService } from "./email.service"
import { StaffService } from "./staff.service"
import { WhatsAppService } from "./whatsapp.service"

export abstract class WhatsAppRemindersService {
    public static async sendWhatsAppReminders(): Promise<void> {
        // const minutesInAdvance = new BookingReminder(60 * 2, [BookingReminderType.WhatsApp])
        let minutesInAdvance = [
            {
                minutesInAdvance: 60 * 24, // set default 24 hrs reminder before event start
                types: [BookingReminderType.WhatsApp]
            }
        ];
        Logger.logger.info("Sending whatsapp booking reminders.....")
        const unfinishedBookingDocs = await BookingsService.getTodayUnfinishedBookingDocs();
        let sentRemindersCount = 0;
        if (unfinishedBookingDocs.length == 0) {
            Logger.logger.info(`...No unfinished bookings were found for whatsapp. ${sentRemindersCount} reminders were sent`)
            return
        }

        const businesses = await BusinessesService.getByIds(unfinishedBookingDocs.map(b => b.businessId))
        const businessServices = await BusinessServicesService.getByIds(unfinishedBookingDocs.map(b => b.serviceId), false)
        const snapshots = await BusinessServiceSnapshotsService.getByIds(unfinishedBookingDocs.map(b => b.serviceSnapshotId))

        const now = new Date()

        for (const booking of unfinishedBookingDocs) {
            const matchingBusiness = businesses.find(b => b.id == booking.businessId)
            if (matchingBusiness == null) {
                Logger.logger.warn(`Failed to find matching business (${booking.businessId}) for booking ${booking._id}`)
                continue
            }

            const matchingService = businessServices.find(s => s.id == booking.serviceId)
            if (matchingService == null) {
                Logger.logger.warn(`Failed to find matching service (${booking.serviceId}) for booking ${booking._id}`)
                continue
            }
            let matchingSnapshot;
            if (booking.serviceSnapshotId) {
                matchingSnapshot = snapshots.find(s => s.id == booking.serviceSnapshotId)
                if (matchingSnapshot == null) {
                    Logger.logger.warn(`Failed to find matching snapshot (${booking.serviceSnapshotId}) for booking ${booking._id}`)
                    continue
                }
            }

            let matchingStaffSnapshot = null;
            if (booking.staffId) {
                matchingStaffSnapshot = await StaffService.getStaffDocById(booking.staffId, booking.businessId);
                if (matchingStaffSnapshot == null) {
                    Logger.logger.warn(`Failed to find matching staff snapshot (${booking.staffId}) for booking ${booking._id}`)
                    continue
                }
            }
            const minutesBeforeBookingStart = DateUtils.differenceInMinutes(now, booking.startDate)

            const dueReminders: any = []

            // booking.sentReminders.some(r => r.minutesInAdvance < bookingReminder.minutesInAdvance)
            if (matchingBusiness.settings && matchingBusiness.settings.whatsappReminderDuration && matchingBusiness.settings.whatsappReminderDuration.durationUnit === DurationUnit.Hour) {
                minutesInAdvance = [
                    {
                        minutesInAdvance: 60 * matchingBusiness.settings.whatsappReminderDuration.duration, // set 24 hrs reminder before event start
                        types: [BookingReminderType.WhatsApp]
                    }
                ]
            }
            if (matchingBusiness.settings && matchingBusiness.settings.whatsappReminderDuration && matchingBusiness.settings.whatsappReminderDuration.durationUnit === DurationUnit.Minute) {
                minutesInAdvance = [
                    {
                        minutesInAdvance: matchingBusiness.settings.whatsappReminderDuration.duration, // set 24 hrs reminder before event start
                        types: [BookingReminderType.WhatsApp]
                    }
                ]
            }
            for (const bookingReminder of minutesInAdvance) {
                if (bookingReminder.minutesInAdvance < minutesBeforeBookingStart) {
                    continue //comment remove karna hai
                }
                // else if (bookingReminder.minutesInAdvance > minutesBeforeBookingStart) {
                //     continue
                // }

                const matchingSentReminder = booking.sentReminders.find(sr => sr.minutesInAdvance == bookingReminder.minutesInAdvance)

                if (matchingSentReminder == null) {
                    dueReminders.push(bookingReminder)
                    continue
                }

                // minutesInAdvance
                const dueReminder = new BookingReminder(bookingReminder.minutesInAdvance, bookingReminder.types)
                const temp = bookingReminder.types.filter(rt => !matchingSentReminder.types.some(st => st == rt))
                dueReminder.types = temp;

                if (dueReminder.types.length == 0) {
                    continue
                }
                dueReminders.push(dueReminder)
            }
            const reminderToBeSent = BookingRemindersService.getLatestReminder(dueReminders)
            if (reminderToBeSent == null) {
                continue
            }
            try {
                let result;
                const isProd = process.env.NODE_ENV.toLowerCase() == "production";
                // check condtion based on current plan of user
                // && matchingBusiness.settings.paymentTypes.includes(PaymentType.Manual)
                await WhatsAppRemindersService.sendWhatsReminderToUstomer(matchingBusiness, booking, matchingSnapshot, matchingService);
                sentRemindersCount++;
            } catch (error) {
                Logger.logger.error(`Failed to Sending reminder`, error)
            }
            // await this.updateSentReminder(booking);
            // Logger.logger.error(`Sending reminder of type ${BookingReminderType[reminderType]} is not implemented`)
            // throw new Error(`Sending reminder of type ${BookingReminderType[reminderType]} is not implemented`);
            // }
        }
        Logger.logger.info(`...Finished sending whatsapp reminders. ${sentRemindersCount} reminders were sent`)
    }

    public static async sendWhatsReminderToUstomer(matchingBusiness, booking, matchingSnapshot, matchingService) {
        let result;
        const isProd = process.env.NODE_ENV.toLowerCase() == "production";
        if (matchingBusiness &&
            matchingBusiness.settings.isWhatsAppReminder && (matchingBusiness.whatsAppCredits !== 0 || matchingBusiness.whatsAppBagsCredits !== 0 || ((matchingBusiness['whatsAppPayAsYouGoMembershipTier'] === MembershipTier.Plus || matchingBusiness['whatsAppPayAsYouGoMembershipTier'] === MembershipTier.Pro && (matchingBusiness.isPaymentDue === false || matchingBusiness.isPaymentDue === undefined))
            )) && booking.customer.isWhatsAppAllow && (booking['isReminderSent'] == undefined)) {
            if (isProd) {
                result = await WhatsAppService.sendWhatsAppBookingReminderToCustomer(matchingBusiness, matchingSnapshot, booking, matchingService);
            } else {
                if (whatsAppPhoneListForTest.NUMBERS.includes(booking.customer.phoneNumber)) {
                    result = await WhatsAppService.sendWhatsAppBookingReminderToCustomer(matchingBusiness, matchingSnapshot, booking, matchingService);
                }
            }
            if (result && result.status) {
                await this.updateSentReminder(booking, result.messageId);
            }
        }
    }

    public static async updateSentReminder(bookingDoc: IBooking, messageId): Promise<void> {
        try {
            if (bookingDoc) {
                bookingDoc['isReminderSent'] = true;
                bookingDoc['whatsappMessageId'] = messageId;
                await bookingDoc.save()
            }
        } catch (err) {
            Logger.logger.error(`Failed to update sentReminders for booking ${bookingDoc._id} after send whatsapp Reminder`, err)
        }
    }
}