import * as bcrypt from 'bcrypt'
import * as jwt from 'jsonwebtoken'

import { Credentials } from "../types/credentials"
import { Tokens } from "../types/tokens"
import { InvalidTokenError } from '../errors/invalid-token.error'
import { Logger } from '../logger'
import { BusinessesService } from "./businesses.service"
import { Business } from "../types/business"
import { StripeService } from './stripe.service'
import { UserService } from './users.service'
import { roles, roleNames } from '../data/user.roles'
import { StaffService } from './staff.service'
import { IUser } from '../db-models/users.db-model'
import { ClientService } from './client.service'
import { NotAllowedError } from '../errors/not-allow.error'

export abstract class AuthenticationService {

	public static async authenticate(credentials: Credentials): Promise<Tokens> {
		const businessDoc = await BusinessesService.getByEmail(credentials.email)
		if (businessDoc == null) {
			return null
		}

		try {
			if (await bcrypt.compare(credentials.password, businessDoc.password) == false) {
				return null
			}
		} catch (err) {
			Logger.logger.error("Failed to compare passwords", err)
			throw new Error("Failed to compare passwords")
		}

		try {
			return await AuthenticationService.generateTokens(businessDoc.id)

		} catch (err) {
			Logger.logger.error("Failed to generate tokens", err)
			throw new Error("Failed to generate tokens")
		}
	}

	public static async authenticateV2(credentials: Credentials): Promise<{ tokens: Tokens, role: string }> {
		let details = null;
		const userDoc = await UserService.getUserByEmail(credentials.email)
		if (userDoc == null) {
			return null
		}
		else if (userDoc && userDoc.role === roles.Client && userDoc.activationToken !== undefined) {
			Logger.logger.warn(`Client with id: '${credentials.email}' is currently not verified`)
			throw new NotAllowedError(`${`${process.env.REZRVA_SPA_URL}/activate/${userDoc.id}/${userDoc.activationToken._id}?isClient=true`}`)
		} else if (userDoc.role === roles.Business) {
			const businessDoc = await BusinessesService.getByEmail(credentials.email)
			if (businessDoc == null) {
				return null
			}
		}
		try {
			if (await bcrypt.compare(credentials.password, userDoc.password) == false) {
				return null
			}
		} catch (err) {
			Logger.logger.error("Failed to compare passwords", err)
			throw new Error("Failed to compare passwords")
		}

		try {
			if (userDoc && userDoc.role === roles.Business) {
				details = await BusinessesService.getByUserId(userDoc.id, false);
			}
			else if (userDoc && userDoc.role === roles.staff) {
				// set staff data 
				details = await StaffService.getByUserId(userDoc.id, false);
			}
			else if (userDoc && userDoc.role === roles.Client) {
				// set staff data 
				details = await ClientService.getByUserId(userDoc.id, false);
			}

			else if (details == null) {
				return null
			}
			const tokens = await AuthenticationService.generateTokensV2(details.id, userDoc);
			const userRole = roleNames[userDoc.role];
			return { tokens, role: userRole }
		} catch (err) {
			Logger.logger.error("Failed to generate tokens", err)
			throw new Error("Failed to generate tokens")
		}
	}

	public static async refreshToken(token: string): Promise<Tokens> {
		let payload: object
		try {
			payload = await AuthenticationService.getTokenPayload(token)
		} catch (err) {
			Logger.logger.error("Invalid refresh token", err)
			throw new InvalidTokenError("Invalid refresh token")
		}

		// This should be checking db if the user is allowed to regenerate token
		if (!(payload as any).isRefreshToken) {
			Logger.logger.error("Invalid refresh token - doesn't contain 'isRefreshToken' flag")
			throw new InvalidTokenError("Invalid refresh token - doesn't contain 'isRefreshToken' flag")
		}

		const operatorId: string = (payload as any).sub

		let business: Business
		business = await BusinessesService.getById(operatorId, false)

		if (business == null) {
			Logger.logger.error(`Invalid refresh token - operator ${operatorId} does not exist`)
			throw new InvalidTokenError(`Invalid refresh token - operator ${operatorId} does not exist`)
		}

		try {
			let tokens = await AuthenticationService.generateToken(operatorId)
			delete tokens.refreshToken
			return tokens
		} catch (err) {
			Logger.logger.error("Failed to generate token", err)
			throw new Error("Failed to generate token")
		}
	}

	public static async refreshTokenV2(token: string): Promise<Tokens> {
		let payload: object
		try {
			payload = await AuthenticationService.getTokenPayload(token)
		} catch (err) {
			Logger.logger.error("Invalid refresh token v2", err)
			throw new InvalidTokenError("Invalid refresh token v2")
		}

		// This should be checking db if the user is allowed to regenerate token
		if (!(payload as any).isRefreshToken) {
			Logger.logger.error("Invalid refresh token v2- doesn't contain 'isRefreshToken' flag")
			throw new InvalidTokenError("Invalid refresh token v2- doesn't contain 'isRefreshToken' flag")
		}
		let userDetails: any
		const operatorId: string = (payload as any).sub; // staff / business id 
		let issueId: string = (payload as any).iss; // userId
		// const operatorRole: number = (payload as any).role; // role
		if (issueId == undefined) {
			const businessDoc = await BusinessesService.getBusinessDocById(operatorId);
			issueId = businessDoc.userId;
		}
		const user = await UserService.getUserById(issueId);
		if (user && user.role === roles.Business) {
			userDetails = await BusinessesService.getByUserId(issueId, false);
		}
		else if (user && user.role === roles.staff) {
			// set staff data 
			// userDetails
			userDetails = await StaffService.getByIdV2(issueId, user.role)
		}
		else if (user && user.role === roles.Client) {
			userDetails = await ClientService.getByIdV2(issueId, user.role)

		}

		else if (userDetails == null) {
			Logger.logger.error(`Invalid refresh token v2 - operator ${operatorId} does not exist`)
			throw new InvalidTokenError(`Invalid refresh token v2- operator ${operatorId} does not exist`)
		}
		try {
			let tokens = await AuthenticationService.generateTokenV2(operatorId, user)
			delete tokens.refreshToken
			return tokens
		} catch (err) {
			Logger.logger.error("Failed to generate token", err)
			throw new Error("Failed to generate token")
		}
	}

	private static async getTokenPayload(token: string): Promise<object> {
		return new Promise((resolve, reject) => {
			jwt.verify(
				token,
				process.env.JWT_SECRET,
				(err, payload) => {
					if (err) {
						return reject()
					}
					resolve(payload as object)
				})
		})
	}

	public static async getUserIdFromToken(token: string): Promise<string> {
		const payload = await AuthenticationService.getTokenPayload(token)
		return new Promise((resolve, reject) => {
			if ((payload as any).sub == null || (payload as any).isRefreshToken) {
				return reject()
			}
			resolve((payload as any))
		})
	}

	private static async generateToken(userId: string): Promise<Tokens> {
		return new Promise<Tokens>((resolve, reject) => {
			jwt.sign(
				{},
				process.env.JWT_SECRET,
				{
					subject: userId,
					expiresIn: "30m"
				},
				(error, t) => {
					if (error) {
						reject()
						return
					}
					resolve(new Tokens(t, null))
				})
		})
	}

	private static async generateTokenV2(id: string, user: IUser): Promise<Tokens> {
		return new Promise<Tokens>((resolve, reject) => {
			jwt.sign(
				{ role: user.role },
				process.env.JWT_SECRET,
				{
					subject: id, // business / staff id
					issuer: user.id, // userId
					expiresIn: "30m"
				},
				(error, t) => {
					if (error) {
						reject()
						return
					}
					resolve(new Tokens(t, null))
				})
		})
	}

	private static async generateTokens(userId: string): Promise<Tokens> {
		return new Promise<Tokens>((resolve, reject) => {
			jwt.sign(
				{},
				process.env.JWT_SECRET,
				{
					subject: userId,
					expiresIn: "30m"
				},
				(error, token) => {
					if (error) {
						reject()
						return
					}
					jwt.sign(
						{
							isRefreshToken: true,
						},
						process.env.JWT_SECRET,
						{
							subject: userId,
							expiresIn: "30 days"
						},
						(error, refreshToken) => {
							if (error) {
								reject()
								return
							}
							resolve(new Tokens(token, refreshToken))
						})
				})
		})
	}

	private static async generateTokensV2(id: string, user: IUser): Promise<Tokens> {
		console.log('subjectId:', id, 'issuer:', user.id);
		return new Promise<Tokens>((resolve, reject) => {
			const role = user.role;
			jwt.sign(
				{ role: role },
				process.env.JWT_SECRET,
				{
					subject: id, // staff, business id
					issuer: user.id,  // userId
					expiresIn: "30m"
				},
				(error, token) => {
					if (error) {
						reject()
						return
					}
					jwt.sign(
						{
							isRefreshToken: true,
						},
						process.env.JWT_SECRET,
						{
							subject: id,  //staff, business id
							issuer: user.id,  // userId
							expiresIn: "30 days"
						},
						(error, refreshToken) => {
							if (error) {
								reject()
								return
							}
							resolve(new Tokens(token, refreshToken))
						})
				})
		})
	}
}