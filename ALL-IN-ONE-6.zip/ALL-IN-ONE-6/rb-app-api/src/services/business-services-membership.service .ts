import * as mongoose from "mongoose";
import { IMembershipService, MembershipServiceDbModel } from "../db-models/service-membership.db-model";
import { DatabaseError } from "../errors/database.error";
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error";
import { Logger } from "../logger";
import { MembershipService } from "../types/membership-package";
import { BusinessesService } from "./businesses.service";
import { ClientMembershipService } from "./client-services-membership.service ";
import { UploadFileService } from "./upload.file.service";
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error";

export abstract class BusinessMembershipService {

    public static async create(
        businessId: string,
        businessMembership: MembershipService
    ): Promise<MembershipService> {
        let business = await BusinessesService.getById(businessId);
        // check stripe connect account is connected or not
        if (!business.isPaymentMethodConnected || !business.stripeConnectAccountId) {
            Logger.logger.warn(`Business has not connected stripe account for business id: ${business.id}`);
            throw new ResourceAlreadyExistsError(`El negocio no ha conectado la cuenta de Stripe para el ID del negocio: ${business.id}`);
        }
        if (businessMembership.logo !== undefined && businessMembership.logo != null && businessMembership.logo != '') {
            const url = await UploadFileService.uploadMembershipImages(businessMembership.logo, businessMembership.name, "logo-image");
            businessMembership.logo = url
        }

        // calculateMembershipHash
        businessMembership.calculateMembershipHash();
        /** add service week days based on businessMembership */
        const businessServiceDoc = MembershipServiceDbModel.convertToDbModel(businessMembership);
        try {
            // add service package in db 
            await MembershipServiceDbModel.MembershipServiceModel.create(businessServiceDoc);
        } catch (err) {
            Logger.logger.error(
                `Failed to create package for businessMembership ${businessId}`,
                err
            );
            throw new DatabaseError(
                `Failed to create package for businessMembership ${businessId}`
            );
        }


        const newBusinessMembershipService = MembershipServiceDbModel.convertToDomainModel(businessServiceDoc);
        return newBusinessMembershipService;
    }

    public static async partialUpdate(businessMembership: MembershipService): Promise<MembershipService> {
        const businessDoc = await BusinessesService.getBusinessDocById(businessMembership.businessId)

        if (businessDoc == null) {
            Logger.logger.warn(`Business ${businessMembership.businessId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Business ${businessMembership.businessId} doesn't exist`)
        }
        // check stripe connect account is connected or not
        if (!businessDoc.isPaymentMethodConnected || !businessDoc.stripeConnectAccountId) {
            Logger.logger.warn(`Business has not connected stripe account for business id: ${businessDoc.id}`);
            throw new ResourceAlreadyExistsError(`El negocio no ha conectado la cuenta de Stripe para el ID del negocio: ${businessDoc.id}`);
        }

        const currentBusinessMembershipDoc = await this.getBusinessMembershipDocById(businessMembership.businessId, businessMembership.id);
        if (currentBusinessMembershipDoc == null) {
            Logger.logger.warn(`Business ${businessMembership.businessId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Business ${businessMembership.businessId} doesn't exist`)
        }

        let resourceNotModified = true
        if (businessMembership.packageSetting != null) {
            currentBusinessMembershipDoc.packageSetting = businessMembership.packageSetting
            resourceNotModified = false
        }
        if (businessMembership.name != null) {
            currentBusinessMembershipDoc.name = businessMembership.name
            resourceNotModified = false
        }
        if (businessMembership.description != null) {
            currentBusinessMembershipDoc.description = businessMembership.description
            resourceNotModified = false
        }
        if (businessMembership.isActive != null) {
            currentBusinessMembershipDoc.isActive = businessMembership.isActive
            resourceNotModified = false
        }
        if (businessMembership.price != null) {
            currentBusinessMembershipDoc.price = businessMembership.price
            resourceNotModified = false
        }
        if (businessMembership.currency != null) {
            currentBusinessMembershipDoc.currency = businessMembership.currency
            resourceNotModified = false
        }

        if (businessMembership.logo !== undefined &&
            businessMembership.logo != currentBusinessMembershipDoc.logo
            && businessMembership.logo != null && businessMembership.logo != ''
        ) {
            const url = await UploadFileService.uploadMembershipImages(businessMembership.logo, currentBusinessMembershipDoc.name, "logo-image");
            currentBusinessMembershipDoc.logo = url
            resourceNotModified = false
        }

        if ((businessMembership.logo === null || businessMembership.logo == '')) {
            const url = await UploadFileService.deleteuploadMembershipImage(currentBusinessMembershipDoc.logo);
            currentBusinessMembershipDoc.logo = ''
            resourceNotModified = false
        }

        if (resourceNotModified == true) {
            return null
        }

        businessMembership.calculateMembershipHash();
        currentBusinessMembershipDoc.membershipHash = businessMembership.membershipHash;

        try {
            await currentBusinessMembershipDoc.save();
        } catch (err) {
            Logger.logger.error(`Failed to partially update businessMembership ${businessMembership.id}`, err)
            throw new DatabaseError(`Failed to partially update businessMembership ${businessMembership.id}`)
        }

        return MembershipServiceDbModel.convertToDomainModel(currentBusinessMembershipDoc)
    }

    public static async getBusinessServiceMembershipDocById(membershipId: string): Promise<IMembershipService> {
        try {
            return await MembershipServiceDbModel.MembershipServiceModel.findOne({ _id: membershipId, isDeleted: false }).exec()
        } catch (err) {
            Logger.logger.error(`Failed to retrieve businessMembership by id (${membershipId})`, err)
            throw new DatabaseError(`Failed to retrieve businessMembership by id (${membershipId})`)
        }
    }

    public static async getById(businessId: string, membershipId: string): Promise<MembershipService> {
        const businessMembershipDoc = await this.getBusinessMembershipDocById(businessId, membershipId);

        if (businessMembershipDoc == null) {
            Logger.logger.warn(
                `Membership ${membershipId} doesn't exist for business ${businessId}`
            );
            throw new ReferencedResourceNotFoundError(
                `Membership ${membershipId} doesn't exist for business ${businessId}`
            );
        }

        const memberships = MembershipServiceDbModel.convertToDomainModel(businessMembershipDoc);

        return memberships;
    }

    public static async getBusinessMembershipDocById(businessId: string, membershipId: string): Promise<IMembershipService> {
        try {
            return await MembershipServiceDbModel.MembershipServiceModel.findOne({ businessId: businessId, _id: membershipId, isDeleted: false }).exec()
        } catch (err) {
            Logger.logger.error(`Failed to retrieve businessMembership by id (${businessId})`, err)
            throw new DatabaseError(`Failed to retrieve businessMembership by id (${businessId})`)
        }
    }

    public static async getAll(businessId: string | undefined): Promise<MembershipService[]> {
        let memberships: MembershipService[] = [];
        let membershipDocs: IMembershipService[];
        let parmsObj: { businessId: string; isDeleted: boolean } = { businessId: businessId, isDeleted: false };
        try {
            membershipDocs = await MembershipServiceDbModel.MembershipServiceModel.find(parmsObj).sort({ '_id': -1 }).exec();
        } catch (err) {
            Logger.logger.error("Failed to get membership", err);
            throw new DatabaseError("Failed to get membership");
        }
        if (membershipDocs == null) {
            return null;
        }
        for await (const b of membershipDocs) {
            const membership_temp = MembershipServiceDbModel.convertToDomainModel(b);
            memberships.push(membership_temp)
        }
        return memberships;
    }

    public static async getAllPackagesByBusinessId(businessId: string | undefined): Promise<MembershipService[]> {
        let memberships: MembershipService[] = [];
        let membershipDocs: IMembershipService[];
        let parmsObj: { businessId: string; isDeleted: boolean, isActive: boolean } = { businessId: businessId, isDeleted: false, isActive: true };
        try {
            membershipDocs = await MembershipServiceDbModel.MembershipServiceModel.find(parmsObj).sort({ '_id': -1 }).exec();
        } catch (err) {
            Logger.logger.error("Failed to get membership", err);
            throw new DatabaseError("Failed to get membership");
        }
        if (membershipDocs == null) {
            return null;
        }
        for await (const b of membershipDocs) {
            const membership_temp = MembershipServiceDbModel.convertToDomainModel(b);
            memberships.push(membership_temp)
        }
        return memberships;
    }

    public static async getAllPackagesByBusinessDocId(businessId: string | undefined): Promise<IMembershipService[]> {
        let membershipDocs: IMembershipService[];
        let parmsObj: { businessId: string; isDeleted: boolean, isActive: boolean } = { businessId: businessId, isDeleted: false, isActive: true };
        try {
            membershipDocs = await MembershipServiceDbModel.MembershipServiceModel.find(parmsObj).sort({ '_id': -1 }).exec();
        } catch (err) {
            Logger.logger.error("Failed to get membership", err);
            throw new DatabaseError("Failed to get membership");
        }
        if (membershipDocs == null) {
            return null;
        }
        return membershipDocs;
    }

    public static async delete(membershipId: string, businessId: string): Promise<MembershipService> {
        const packageDoc = await this.getBusinessMembershipDocById(businessId, membershipId);

        if (packageDoc == null) {
            Logger.logger.warn(`Package membership ${membershipId} doesn't exist`);
            throw new ReferencedResourceNotFoundError(
                `Staff ${membershipId} doesn't exist`
            );
        }

        const businessDoc = await BusinessesService.getBusinessDocById(businessId)
        if (businessDoc == null) {
            Logger.logger.warn(`Business ${businessId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Business ${businessId} doesn't exist`)
        }
        packageDoc.isDeleted = true;
        try {
            // remove membership in stripe
            await packageDoc.save();

        } catch (err) {
            Logger.logger.error(
                `Failed to mark membership service ${membershipId} as deleted`,
                err
            );
            throw new DatabaseError(
                `Failed to mark membership service ${membershipId} as deleted`
            );
        }
        const membership = MembershipServiceDbModel.convertToDomainModel(packageDoc);
        return membership;
    }

    public static async getAllwithPagination(pageNumber: number, size: number, searchParam: string, findByParam: string, sortByParam: string, findByCategory: string, businessId: string): Promise<any> {
        try {
            const page = pageNumber;
            const limit = size;
            const skip = (page - 1) * limit;
            const filters: any = { isDeleted: false, isActive: true }
            if (businessId) {
                filters.businessId = businessId;
            }
            const sortDirection: Record<string, 1 | -1> = sortByParam === 'asc' ? { _id: 1 } : { _id: -1 };
            // Force category param to string (important!)
            const categoryId = findByCategory ? String(findByCategory) : null;
            const result = await MembershipServiceDbModel.MembershipServiceModel.aggregate([
                { $match: filters }, // membership filters

                // Convert businessId to ObjectId
                {
                    $addFields: {
                        businessId: { $toObjectId: "$businessId" }
                    }
                },

                // Lookup businesses with optional filters
                {
                    $lookup: {
                        from: "businesses",
                        let: { bId: "$businessId" },
                        pipeline: [
                            {
                                $match: {
                                    $expr: { $eq: ["$_id", "$$bId"] },

                                    // ✅ Strict filter by businessTypeId (STRING compare)
                                    ...(categoryId ? { businessTypeId: categoryId } : {}),

                                    // ✅ Business name search (optional)
                                    ...(searchParam
                                        ? { name: { $regex: searchParam, $options: "i" } }
                                        : {})
                                }
                            }
                        ],
                        as: "businessDoc"
                    }
                },

                // Flatten business (only keep matched ones)
                { $unwind: { path: "$businessDoc", preserveNullAndEmptyArrays: false } },

                // Add required fields
                {
                    $addFields: {
                        businessName: "$businessDoc.name",
                        businessId: "$businessDoc._id",
                        businessSlug: "$businessDoc.slug",
                        currency: "$businessDoc.currency",
                        businessTypeId: "$businessDoc.businessTypeId"
                    }
                },

                { $project: { businessDoc: 0 } },
                { $sort: sortDirection },
                { $skip: skip },
                { $limit: limit }
            ]).exec();
            // Get total count for pagination
            const totalCount = await MembershipServiceDbModel.MembershipServiceModel.countDocuments(filters);
            const mappedData = result.map(membership => ({
                name: membership.name,
                description: membership.description,
                logo: membership.logo || null,
                membershipId: membership._id,
                businessId: membership.businessId,
                image: membership.logo || null,          // assuming `image` field exists in membership
                price: membership.price / 100 || 0,
                bookingLimit: membership.packageSetting.reduce((sum, x) => sum + (x.bookingQuantity || 0), 0),
                currency: membership.currency,
                businessName: membership.name,
                businessSlug: membership.businessSlug
            }));

            return {
                data: mappedData,
                pagination: {
                    total: totalCount,
                    totalPages: Math.ceil(totalCount / limit)
                }
            };
        } catch (error) {
            Logger.logger.error("Failed to get membership", error);
            throw new DatabaseError("Failed to get membership");
        }
    }

    public static async getByDocId(id: string): Promise<any> {
        try {
            // const businessMembershipDoc = await MembershipServiceDbModel.MembershipServiceModel.findOne({ _id: id, isDeleted: false }).exec();


            const businessMembershipDoc = await MembershipServiceDbModel.MembershipServiceModel.aggregate([
                {
                    $match: {
                        _id: new mongoose.Types.ObjectId(id), // match membership id
                        isDeleted: false
                    }
                },
                {
                    $unwind: "$packageSetting" // flatten packageSetting
                },
                {
                    $addFields: {
                        "packageSetting.serviceId": { $toObjectId: "$packageSetting.serviceId" }
                    }
                },
                {
                    $lookup: {
                        from: "business-services",
                        localField: "packageSetting.serviceId",
                        foreignField: "_id",
                        as: "serviceDetails"
                    }
                },
                { $unwind: { path: "$serviceDetails", preserveNullAndEmptyArrays: true } },
                {
                    $group: {
                        _id: "$_id",
                        businessId: { $first: "$businessId" },
                        name: { $first: "$name" },
                        description: { $first: "$description" },
                        membershipHash: { $first: "$membershipHash" },
                        price: { $first: "$price" },
                        logo: { $first: "$logo" },
                        currency: { $first: "$currency" },
                        isDeleted: { $first: "$isDeleted" },
                        isActive: { $first: "$isActive" },
                        createdAt: { $first: "$createdAt" },
                        updatedAt: { $first: "$updatedAt" },
                        packageSetting: {
                            $push: {
                                serviceId: "$packageSetting.serviceId",
                                bookingQuantity: "$packageSetting.bookingQuantity",
                                serviceName: "$serviceDetails.name",
                                serviceSlug: "$serviceDetails.slug",
                                servicePrice: "$serviceDetails.price",
                                serviceDescription: "$serviceDetails.description",
                                serviceDuration: "$serviceDetails.duration",
                                serviceDurationUnit: "$serviceDetails.durationUnit",
                                serviceCapacity: "$serviceDetails.capacity",
                                serviceLogo: "$serviceDetails.logo",
                                serviceCurrency: "$serviceDetails.currency",   
                                serviceType:"$serviceDetails.type",
                                eventSetting:"$serviceDetails.eventSetting",                         
                            }
                        },
                        totalBookingQuantity: { $sum: "$packageSetting.bookingQuantity" } // ✅ sum all bookingQuantity
                    }
                }
            ]);


            return businessMembershipDoc ? businessMembershipDoc.length > 0 ? businessMembershipDoc[0] : null : null;
        } catch (err) {
            Logger.logger.error(`Failed to retrieve businessMembership by id (${id})`, err)
            throw new DatabaseError(`Failed to retrieve businessMembership by id (${id})`)
        }
    }
    public static async getMembershipHistoryById(businessId, membershipId: string): Promise<any> {
        try {
            const businessMembershipDoc = await ClientMembershipService.getBusinessMembershipHistory(businessId, membershipId)
            return businessMembershipDoc;
        } catch (err) {
            Logger.logger.error(`Failed to retrieve businessMembership by id (${membershipId})`, err)
            throw new DatabaseError(`Failed to retrieve businessMembership by id (${membershipId})`)
        }
    }

    public static async updateBusinessPackagesToInactive(businessId: string): Promise<void> {
        let packageDocs: any[];
        try {
            packageDocs = await BusinessMembershipService.getAllPackagesByBusinessDocId(businessId);            
        } catch (err) {
            Logger.logger.error("Failed to get package in updateBusiness package To InActive", err);
            throw new DatabaseError("Failed to get package in updateBusiness package To InActive");
        }
        packageDocs.forEach(async (s: any) => {
            const referencedPackageDoc = packageDocs.find(sd => sd.id == s.id)

            if (referencedPackageDoc != null) {
                referencedPackageDoc.isActive = false
                try {
                    await referencedPackageDoc.save()
                } catch (err) {
                    Logger.logger.error(`updateBusinessStaffToFourActive - Failed to update staff ${s.id} for business ${businessId}`, err)
                }
            }
        })
    }

}