import { StripeConnectedType, zeroDecimalCurrencies } from "../data/connectedAccountTypes"
import { ProductToPriceMap } from "../data/productToPriceMap"
import { roles } from "../data/user.roles"
import { planType } from "../data/whatsAppProductAndCurrency"
import { staffCount } from "../data/whatsappTemplateMap"
import { IBusinessServiceSnapshot } from "../db-models/business-service-snapshot.db-model"
import { IBusiness } from "../db-models/business.db-model"
import { DatabaseError } from "../errors/database.error"
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error"
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error"
import { Logger } from "../logger"
import { Business } from "../types/business"
import { BusinessService } from "../types/business-service"
import { BusinessServiceSnapshot } from "../types/business-service-snapshot"
import { ClientMembership } from "../types/clientMembership"
import { Currency } from "../types/enums/currency"
import { MembershipTier } from "../types/enums/membership-tier.enum"
import { PaymentType, ServicePaymentType } from "../types/enums/payment-type.enum"
import { MembershipServiceSnapshot } from "../types/service-membership-snapshot"
import { TextFormatService } from "../utils/convert-html-to-text"
import { CurrencyService } from "../utils/currency"
import { BookingsService } from "./bookings.service"
import { BusinessMembershipService } from "./business-services-membership.service "
import { BusinessesService } from "./businesses.service"
import { ClientMembershipService } from "./client-services-membership.service "
import { ClientService } from "./client.service"
import { EmailService } from "./email.service"
import { StaffService } from "./staff.service"
import { TimeSlotService } from "./time-slot-service"
import { UserService } from "./users.service"
const { v4: uuidv4 } = require('uuid');
const axios = require("axios");
// process.env.STRIPE_SECRET_KEY
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
const stripeNew = require('stripe')(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-08-16',
});
const rezrvaSpaUrl = process.env.REZRVA_SPA_URL;
const stripeTrialPeriod = parseInt(process.env.STRIPE_TRIAL_PERIOD) || 7;
const onboardingCategory = process.env.ONBOARDING_PLAN_CATEGORY || 'regular-plan';
const isProd = process.env.NODE_ENV.toLowerCase() == "production";

export abstract class StripeService {
  public static async getProducts(businessId: string, name: string, email: string): Promise<any> {
    const customer = await stripe.customers.create({
      name,
      email
    });

    //Save CustomerID in Database
    const currentBusinessDoc = await BusinessesService.getBusinessDocById(businessId)
    try {
      currentBusinessDoc.stripeCustomerId = customer.id;
      await currentBusinessDoc.save()
    } catch (err) {
      Logger.logger.error(`Failed to update StripeCustomerId - Business: ${currentBusinessDoc.id}`, err)
      throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${currentBusinessDoc.id}`)
    }

    return customer.id;
  }

  public static async createCustomer(businessId: string, name: string, email: string): Promise<any> {
    const customer = await stripe.customers.create({
      name,
      email
    });

    //Save CustomerID in Database
    const currentBusinessDoc = await BusinessesService.getNewBusinessDocById(businessId)
    try {
      currentBusinessDoc.stripeCustomerId = customer.id;
      await currentBusinessDoc.save()
    } catch (err) {
      Logger.logger.error(`Failed to update StripeCustomerId - Business: ${currentBusinessDoc.id}`, err)
      throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${currentBusinessDoc.id}`)
    }

    return customer.id;
  }

  public static async createCustomerV2(businessId: string, name: string, email: string, businessInfo: any): Promise<any> {
    let customer, customerId;
    //Save CustomerID in Database
    const currentBusinessDoc = await BusinessesService.getNewBusinessDocById(businessId)
    try {
      // find existing customer in stripe
      if (currentBusinessDoc.stripeCustomerId === null || currentBusinessDoc.stripeCustomerId === undefined) {
        customer = await stripe.customers.create({
          name,
          email
        });
        currentBusinessDoc.stripeCustomerId = customer.id;
        customerId = customer.id;
      } else if (businessInfo && !businessInfo.isCustomerExist) {
        customer = await stripe.customers.create({
          name,
          email
        });
        currentBusinessDoc.stripeCustomerId = customer.id;
        customerId = customer.id;
      }
      else {
        customerId = currentBusinessDoc.stripeCustomerId
      }
      await currentBusinessDoc.save()
    } catch (err) {
      Logger.logger.error(`Failed to update StripeCustomerId - Business: ${currentBusinessDoc.id}`, err)
      throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${currentBusinessDoc.id}`)
    }
    return customerId;
  }

  public static async createBookingPaymentCheckoutLink(customer, price): Promise<any> {
    let businessInfo = await BusinessesService.getBusinessDocByStripeCustomerId(customer);

    // Create the subscription
    let session;
    if (businessInfo.stripeOnTrial === undefined || businessInfo.stripeOnTrial === null) {
      //New Customer: Trial
      session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        customer,
        line_items: [
          {
            price,
            quantity: 1,
          },
        ],
        subscription_data: {
          trial_settings: { end_behavior: { missing_payment_method: 'cancel' } },
          trial_period_days: stripeTrialPeriod,
        },
        payment_method_collection: 'if_required',
        success_url: rezrvaSpaUrl + '/business/pricing?status=success&session_id={CHECKOUT_SESSION_ID}',
        cancel_url: rezrvaSpaUrl + '/business/pricing',
      });
    } else {
      //No Trial
      session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        customer,
        line_items: [
          {
            price,
            quantity: 1,
          },
        ],
        payment_method_collection: 'if_required',
        success_url: rezrvaSpaUrl + '/business/pricing?status=success&session_id={CHECKOUT_SESSION_ID}',
        cancel_url: rezrvaSpaUrl + '/business/pricing',
      });
    }

    return {
      sessionId: session.id,
    };
  }

  public static async createCheckoutSessionV2(customer, price, quantity, category: string, locationCode: string, type: string): Promise<any> {
    let session = null, isCustmerExist = true;
    try {
      // check customer exist or not on  stripe
      try {
        await stripe.customers.retrieve(customer);
      } catch (error) {
        Logger.logger.warn(`StripeCustomerId ${customer} doesn't exist`);
        isCustmerExist = false;
        // throw error
      }
      let businessInfo = await BusinessesService.getBusinessDocByStripeCustomerId(customer);

      if (!isCustmerExist) {
        businessInfo['isCustmerExist'] = isCustmerExist;
        // create user on test if not exist
        customer = await StripeService.createCustomerV2(businessInfo.id, businessInfo.contactName, businessInfo.email, businessInfo);
        businessInfo.stripeCustomerId = customer;
      }
      if (businessInfo == null) {
        Logger.logger.warn(`StripeCustomerId ${customer} doesn't exist`)
        throw new ReferencedResourceNotFoundError(`StripeCustomerId ${customer} doesn't exist`)
      }
      // let currencyString = await CurrencyService.getCurrency(businessInfo.currency)

      // get currency based on curreny seleted by user
      // let currencyKey = await CurrencyService.getCurrency(businessInfo.currency);

      // get currency by user location 
      let currencyString = await CurrencyService.getCurrencyByCountryShortName(locationCode)
      const subscriptionObj: any = await StripeService.getCustomerSubscriptions(customer)
      if (subscriptionObj && subscriptionObj.subscription && subscriptionObj.subscription.currency) {
        currencyString = subscriptionObj.subscription.currency.toUpperCase()
      }
      console.log('user currency:', currencyString);
      if (category === 'whatsapp') {
        const priceInfo = await stripe.prices.retrieve(price);
        if (priceInfo.type === planType.USAGE) {
          session = await this.createPayAsYouGoPaymentCheckoutSession(customer, price, businessInfo, currencyString)
        } else if (priceInfo.type === planType.ONE_TIME) {

          session = await this.createOneTimePaymentCheckoutSession(customer, price, businessInfo, currencyString, quantity, priceInfo)
        }
      }
      else if (category === 'staff') {
        // session = await this.createStaffPaymentCheckoutSession(customer, price, businessInfo, currencyString, quantity)
        session = await this.createStaffPlanCheckoutSession(customer, price, businessInfo, currencyString, quantity, subscriptionObj.subscriptionList, type)
      }
      else {
        // category === 'regular-plan'
        session = await this.createRegularPlanCheckoutSession(customer, price, businessInfo, currencyString)
      }
    } catch (error) {
      if (error.statusCode === 404) {
        throw new ReferencedResourceNotFoundError(`${error.raw.message}`)
      }
      Logger.logger.error(`Failed to update StripeCustomerId - Business: ${customer}`, error)
      throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${customer}`)
    }
    return {
      sessionId: session ? session.id : '',
    };
  }

  public static async createUpgradeCheckoutSession(customer, price, category: string, locationCode: string): Promise<any> {
    let session;
    try {
      // check customer exist or not on stripe
      try {
        await stripe.customers.retrieve(customer);
      } catch (error) {
        Logger.logger.warn(`StripeCustomerId ${customer} doesn't exist`)
        throw error
      }
      let businessInfo = await BusinessesService.getBusinessDocByStripeCustomerId(customer);
      if (businessInfo == null) {
        Logger.logger.warn(`StripeCustomerId ${customer} doesn't exist`)
        throw new ReferencedResourceNotFoundError(`StripeCustomerId ${customer} doesn't exist`)
      }

      let currencyString = await CurrencyService.getCurrencyByCountryShortName(locationCode)
      const subscription = await this.getOldSubscriptionAndDelete(customer)
      // if (subscription && subscription.currency) {
      //   currencyString = subscription.currency.toUpperCase()
      // }
      if (category === 'whatsapp') {
        const priceInfo = await stripe.prices.retrieve(price);
        if (priceInfo.type === planType.USAGE) {
          session = await this.createPayAsYouGoPaymentCheckoutSession(customer, price, businessInfo, currencyString)
        } else if (priceInfo.type === planType.ONE_TIME) {
          session = await this.createOneTimePaymentCheckoutSession(customer, price, businessInfo, currencyString, "", priceInfo)
        }
      }
      else {
        // category === 'regular-plan'
        session = await this.createRegularPlanCheckoutSession(customer, price, businessInfo, currencyString)
      }
    } catch (error) {
      if (error.statusCode === 404) {
        throw new ReferencedResourceNotFoundError(`${error.raw.message}`)
      }
      Logger.logger.error(`Failed to update StripeCustomerId - Business: ${customer}`, error)
      throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${customer}`)
    }
    return {
      sessionId: session.id,
    };
  }


  public static async createRegularPlanCheckoutSession(customer, price, businessInfo, customerCurrency): Promise<any> {
    let session;
    try {
      // Create the subscription
      if (businessInfo.stripeOnTrial === undefined || businessInfo.stripeOnTrial === null) {
        //New Customer: Trial START
        // get price for onbording new customer
        const products: any = await stripe.products.search({
          query: `active:'true' AND metadata['category']:'${onboardingCategory}' AND metadata['type']:'2'`,
        });
        const filteredProduct = products.data.find(dt => dt.metadata.type == 2 && dt.metadata.category == 'regular-plan');
        const priceInfo = await stripe.prices.list({
          product: filteredProduct.id,
          active: true,
        });
        // const priceInfo = await stripe.prices.list({
        //   product: products.data[0].id,
        //   active: true,
        // });
        const priceDetails = priceInfo.data.find(value => value.metadata.type == 2 && value.recurring.interval === 'month' && value.metadata.category == 'regular-plan');
        price = priceDetails.id;
        session = await stripe.subscriptions.create({
          customer: customer,
          items: [{ price: price }],
          trial_period_days: stripeTrialPeriod,
          currency: `${customerCurrency}`,
          metadata: {
            usage_type: 'licensed',
            priceId: price
          },
          // collection_method: 'charge_automatically', // Charge automatically for the subscription
          // payment_behavior: 'default_incomplete', // Automatically pay invoices when payment_method is attached
          trial_settings: {
            end_behavior: {
              missing_payment_method: 'cancel',
            },
          }
        });
      } else {
        //No Trial
        session = await stripe.checkout.sessions.create({
          mode: "subscription",
          payment_method_types: ["card"],
          customer,
          line_items: [
            {
              price,
              quantity: 1,
            },
          ],
          metadata: {
            usage_type: 'licensed',
            priceId: price
          },
          payment_method_collection: 'if_required',
          currency: `${customerCurrency}`, //customer cuurent plan currency or location currency
          success_url: rezrvaSpaUrl + '/business/account',
          cancel_url: rezrvaSpaUrl + '/business/pricing',
        });
      }

    } catch (error) {
      Logger.logger.error(`Failed to update StripeCustomerId - Business: ${customer}`, error)
      throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${customer}`)
    }
    return session;
  }

  public static async createStaffPlanForPro(customer, businessInfo, customerCurrency, subscriptionObj) {
    customerCurrency = customerCurrency.toUpperCase();
    const products: any = await stripe.products.search({
      query: `active:'true' AND metadata['category']:'staff' AND metadata['type']:'2'`,
    });
    const filteredProduct = products.data.find(dt => dt.metadata.type == 2 && dt.metadata.category == 'staff');
    const priceInfo = await stripe.prices.list({
      product: filteredProduct.id,
      active: true,
    });
    const staffPrice = priceInfo.data.find(value => value.metadata.type == 2 && value.metadata.category == 'staff');
    await stripe.subscriptionItems.create({
      subscription: subscriptionObj.id,
      price: staffPrice.id,
      quantity: 0,
      proration_behavior: 'always_invoice', //pay at a time
    });
  }


  public static async createBillingSession(customer): Promise<any> {
    const session = await stripe.billingPortal.sessions.create({
      customer,
      return_url: rezrvaSpaUrl + "/business/account",
    });
    return session;
  }

  public static async getPricesByProductId(category: string, id: string, locationCode: string): Promise<any> {
    try {
      let businessInfo = await BusinessesService.getBusinessDocByIdV2(id);
      if (businessInfo == null) {
        Logger.logger.warn(`businessId ${id} doesn't exist`)
        throw new ReferencedResourceNotFoundError(`businessId ${id} doesn't exist`)
      }
      const membershipType = businessInfo.membershipTier ? businessInfo.membershipTier : 0;
      let products: any;
      // || category === 'staff'
      if (category === 'whatsapp') {
        products = await stripe.products.search({
          query: `active:'true' AND metadata['category']:'${category}' AND metadata['TYPE']:'${membershipType}'`,
        });
      }
      else if (category === 'staff') {
        products = await stripe.products.search({
          query: `active:'true' AND metadata['category']:'${category}' AND metadata['isActive']:'true'`,
        });
      }
      else {
        products = await stripe.products.search({
          query: `active:'true' AND metadata['category']:'${category}' AND metadata['isActive']:'true'`,
        });
      }
      // get currency based on curreny seleted by user
      // let currencyKey = await CurrencyService.getCurrency(businessInfo.currency);

      // get currency by user location 
      let currencyKey = await CurrencyService.getCurrencyByCountryShortName(locationCode)
      const subscriptionObj: any = await this.getCustomerSubscriptions(businessInfo.stripeCustomerId);
      // save old stripe plan id 
      await this.saveOldPriceIdOfCustomer(businessInfo);
      if (subscriptionObj && subscriptionObj.subscription && subscriptionObj.subscription.currency) {
        currencyKey = subscriptionObj.subscription.currency.toUpperCase()
      }
      console.log('currency:', currencyKey);
      const prices = await Promise.all(products.data.map(async (product) => {
        const filteredMetadata = Object.fromEntries(Object.entries(product.metadata).filter(([key, value]) => !key.startsWith("feature_")));
        const uniqueNames = new Set();
        const uniqueData = [];
        Object.entries(product.metadata).forEach(([key, value]) => {
          if (key.startsWith("feature")) {
            const currentFeature: any = value;
            const currentValue = JSON.parse(currentFeature);
            if (!uniqueNames.has(currentValue.name.trim())) {
              uniqueNames.add(currentValue.name.trim());
              uniqueData.push(currentValue);
            }
          }
        });

        const priceInfo = await stripe.prices.list({
          product: product.id,
          active: true,
          expand: ['data.currency_options'],
        });
        const pricesData = await Promise.all(priceInfo.data.map(async (price) => {
          const amount = await this.getConvertedPrice(price, currencyKey, 'buyPrice', category);
          const tenMonthsAmount = await this.getConvertedPrice(price, currencyKey, '10Months', category);
          const twelveMonthsAmount = await this.getConvertedPrice(price, currencyKey, '12Months', category);
          return {
            id: price.id,
            name: price.name,
            interval: price.recurring && price.recurring.interval ? price.recurring.interval : 'per_unit',
            amount,
            tenMonthsAmount,
            twelveMonthsAmount,
            type: Number(price.metadata.type),
            unit: price.recurring && price.recurring.usage_type === 'metered' ? 'per_msg' :
              category == 'staff' ? 'staff_per_month' :
                price.recurring && price.recurring.interval ? "month" : price.billing_scheme
          };
        }));
        // merge the current product info with price data
        const planData = {
          description: product.description,
          name: product.name,
          features: uniqueData,
          metadata: filteredMetadata,
          prices: pricesData,
          currency: currencyKey
        };
        return planData;
      }));
      // sort plan low to high
      prices.sort((a, b) => {
        const typeA = parseInt(a.metadata.type);
        const typeB = parseInt(b.metadata.type);
        return typeA - typeB;
      });
      return prices;
    } catch (error) {
      console.error('Error fetching plans:', error);
      throw error;
    }
  }

  public static async createOneTimePaymentCheckoutSession(customer, price, businessInfo, customerCurrency, quantity, priceInfo): Promise<any> {
    let sessionDetails: any;
    try {
      const qty = quantity ? quantity : 1;
      const creditsPerQty = priceInfo.metadata && priceInfo.metadata['whatsapp_credits'] ? Number(priceInfo.metadata['whatsapp_credits']) * Number(qty) : Number(priceInfo.metadata['whatsapp_credits']) * Number(qty);
      const unitQty = Number(creditsPerQty);
      //create one time payment link
      sessionDetails = await stripe.checkout.sessions.create({
        mode: "payment",
        payment_method_types: ["card"],
        customer,
        line_items: [
          {
            price,
            quantity: unitQty,
          },
        ],
        currency: `${customerCurrency}`,
        metadata: {
          priceId: price,
          quantity: qty,
          whatsapp_credits: priceInfo.metadata['whatsapp_credits']
        },
        success_url: rezrvaSpaUrl + '/business/account',
        cancel_url: rezrvaSpaUrl + '/business/pricing',
      });
    } catch (error) {
      Logger.logger.error(`Failed to update One time payment of StripeCustomerId - Business: ${customer}`, error)
      throw new DatabaseError(`Failed to update One time payment of StripeCustomerId - Business: ${customer}`)
    }
    return sessionDetails;
  }

  public static async createPayAsYouGoPaymentCheckoutSession(customer, price, businessInfo, customerCurrency: string): Promise<any> {
    let subscriptionSessionDetails: any;
    try {
      // || businessInfo.stripePayAsYouGoOnTrial === false
      // if (businessInfo.stripePayAsYouGoOnTrial === undefined || businessInfo.stripePayAsYouGoOnTrial === null
      // ) {
      //   //FREE Trial for frist time when user create plan
      //   subscriptionSessionDetails = await stripe.subscriptions.create({
      //     customer: customer,
      //     items: [{ price: price }],
      //     currency: `${customerCurrency}`,
      //     // trial_period_days: stripeTrialPeriod,
      //     // trial_settings: {
      //     //   end_behavior: {
      //     //     missing_payment_method: 'cancel',
      //     //   },
      //     // },
      //     metadata: {
      //       usage_type: 'metered',
      //       priceId: price

      //     },
      //     // proration_behavior: 'charge_automatically',
      //     // billing_cycle_anchor: timestamp + 120
      //   });
      // } else {
      //create paid plan after free trial end
      subscriptionSessionDetails = await stripe.checkout.sessions.create({
        customer,
        mode: "subscription",
        // subscription: filteredSubscriptions.id,
        payment_method_types: ["card"],
        line_items: [
          {
            price,
          },
        ],
        metadata: {
          priceId: price,
          usage_type: 'metered'
        },
        currency: `${customerCurrency}`,
        // invoice_settings: {
        //   days_until_due: 1, // Number of days until invoice is due
        //   reminder_interval: 1, // Number of days between reminders
        // },
        // payment_method_collection: 'if_required',
        // success_url: rezrvaSpaUrl + '/business/pricing?status=success&session_id={CHECKOUT_SESSION_ID}',
        success_url: rezrvaSpaUrl + '/business/account',

        cancel_url: rezrvaSpaUrl + '/business/pricing',
      });
      // }

      return subscriptionSessionDetails;

    } catch (error) {
      Logger.logger.error(`Failed to update One time payment of StripeCustomerId - Business: ${customer}`, error)
      throw new DatabaseError(`Failed to update One time payment of StripeCustomerId - Business: ${customer}`)
    }
  }

  public static async createStaffPaymentCheckoutSession(customer, price, businessInfo, customerCurrency: string, quantity: number): Promise<any> {
    let subscriptionSessionDetails: any;
    let customerSubId = businessInfo.subscriptionId;
    try {
      const subscriptions = await stripe.subscriptions.list({
        customer: businessInfo.stripeCustomerId,
        // limit: 1 //optional
      });
      const subscriptionPlanItem = subscriptions.data.filter(sdt => (sdt.status === 'active' || sdt.status === 'trialing'))
      let regularPlanInfo = null;
      for (const item of subscriptionPlanItem) {
        const matchItem = item.items.data.find(item => item.plan && item.plan.usage_type === planType.LICENSED && item.plan.id === (businessInfo.stripePriceIds && businessInfo.stripePriceIds.recurringPriceId));
        if (matchItem) {
          regularPlanInfo = item;
          break; // Stop searching once we find the first match
        }
      }
      if (regularPlanInfo) {
        // find staff plan matadata
        const planData = regularPlanInfo.items.data.find(item => item.plan.id === price);
        //add on existing subscription item 
        //  if (!planData) {
        //   subscriptionSessionDetails = await stripe.subscriptionItems.create({
        //     subscription: regularPlanInfo.id,
        //     price: price,
        //     // quantity: 0,
        //     proration_behavior: 'create_prorations',
        //   });
        // } // old changes with usages plan type
        if (!planData) {
          subscriptionSessionDetails = await stripe.subscriptionItems.create({
            subscription: regularPlanInfo.id,
            price: price,
            quantity: quantity,
            proration_behavior: 'always_invoice', //pay at a time
          });
        } else {
          // const deleted = await stripe.subscriptionItems.del( planData.id);
          await stripe.subscriptionItems.update(
            planData.id,
            {
              quantity: quantity,
              proration_behavior: 'always_invoice',
            }
          );
        }
      }
      else {
        // subscriptionSessionDetails = await this.createPayAsYouGoPaymentCheckoutSession(customer, price, businessInfo, customerCurrency)
      }
      return subscriptionSessionDetails;
    } catch (error) {
      Logger.logger.error(`Failed to update staff plan payment of StripeCustomerId - Business: ${customer}`, error)
      throw new DatabaseError(`Failed to staff plan payment of StripeCustomerId - Business: ${customer}`)
    }
  }

  public static async createStaffPlanCheckoutSession(customer, price, businessInfo, customerCurrency, quantity: number, customerSubscriptions, type: string): Promise<any> {
    let session = null;
    type = type.trim();
    if (type === 'add') {
      try {
        let qty = 0;
        let matchItem = null;
        // check if subscription already exist
        const staffInputValue = type == 'add' ? businessInfo.membershipStaffCount + quantity : businessInfo.membershipStaffCount;
        if (customerSubscriptions && customerSubscriptions.length > 0) {

          let matchregulerPlanItem = customerSubscriptions.find(item =>
            item.items.data.some(it =>
              it.plan && it.plan.id === (businessInfo.stripePriceIds && businessInfo.stripePriceIds.recurringPriceId)
            )
          );
          if (matchregulerPlanItem === undefined || matchregulerPlanItem === null) {
            matchregulerPlanItem = customerSubscriptions.find(item =>
              item.items.data.some(it =>
                it.plan &&
                it.plan.usage_type === planType.LICENSED &&
                it.plan.id === (businessInfo.stripePriceIds && businessInfo.stripePriceIds.recurringPriceId)
              )
            )
          }
          const item = matchregulerPlanItem
          if (matchregulerPlanItem) {
            const planData = item.items.data.find(item => item.plan.id === price);
            if (!planData) {
              qty = quantity;
              let initialStaffQty = quantity;
              // Create the subscription
              // manage staff amount based on plan
              // if (businessInfo.membershipTier === MembershipTier.Pro && (qty > staffCount.pro_count)) {
              //   initialStaffQty = Math.abs(qty - staffCount.pro_count);

              // }
              // if ((businessInfo.membershipTier === MembershipTier.Free || businessInfo.membershipTier === MembershipTier.Plus)) {
              //   initialStaffQty = qty;
              // }
              // session = await stripe.subscriptionItems.create({
              //   subscription: matchregulerPlanItem.id,
              //   price: price,
              //   quantity: initialStaffQty,
              //   proration_behavior: 'always_invoice', //pay at a time
              // });

              // create checkout session for staff
              session = await this.createStaffCardSession(customer, price, matchregulerPlanItem.id, customerCurrency, initialStaffQty, "add", "create", "", staffInputValue);

              // session = await this.generateStaffPaymentLink(customer, price, matchregulerPlanItem.id, customerCurrency, initialStaffQty, type, "create", "", staffInputValue);
            } else {
              // qty = type == 'add' ? planData.quantity + quantity : type == 'remove' ? planData.quantity - quantity : planData.quantity;
              qty = type == 'add' ? planData.quantity + quantity : planData.quantity;

              // const deleted = await stripe.subscriptionItems.del( planData.id);
              if ((businessInfo.membershipTier === MembershipTier.Free
                || businessInfo.membershipTier === MembershipTier.Plus)
                || (businessInfo.membershipTier === MembershipTier.Pro
                  && (businessInfo.membershipStaffCount > staffCount.pro_count))) {
                // const subtractQty = Math.abs(qty - staffCount.basic_count)
                // session = await stripe.subscriptionItems.update(
                //   planData.id,
                //   {
                //     quantity: qty,
                //     proration_behavior: 'always_invoice',
                //   }
                // );
                session = await this.createStaffCardSession(customer, price, matchregulerPlanItem.id, customerCurrency, qty, "add", "update", planData.id, staffInputValue);
                // session = await this.generateStaffPaymentLink(customer, price, matchregulerPlanItem.id, customerCurrency, qty, type, "update", planData.id, staffInputValue);
              } else {
                session = await this.createStaffCardSession(customer, price, matchregulerPlanItem.id, customerCurrency, qty, "add", "update", planData.id, staffInputValue);
              }
            }
          }
          else {
            // const matched = item.items.data.find(item => item.plan && item.plan.usage_type === planType.LICENSED && item.plan.id === price);
            const matched = customerSubscriptions.find(item =>
              item.items.data.some(it =>
                it.plan &&
                it.plan.usage_type === planType.LICENSED &&
                it.plan.id === price
              )
            );
            if (matched) {
              matchItem = matched;
              // break; // Stop searching once we find the first match
            }
            if (matchItem) {
              qty = type == 'add' ? matchItem.quantity + quantity : type == 'remove' ? matchItem.quantity - quantity : matchItem.quantity;
              // update subscription with qty
              if ((businessInfo.membershipTier === MembershipTier.Free
                || businessInfo.membershipTier === MembershipTier.Plus)
                || (businessInfo.membershipTier === MembershipTier.Pro
                  && (businessInfo.membershipStaffCount > staffCount.pro_count))) {

                // session = await stripe.subscriptionItems.update(
                //   matchItem.id,
                //   {
                //     quantity: qty,
                //     proration_behavior: 'always_invoice',
                //   }
                // );

                session = await this.createStaffCardSession(customer, price, matchItem.id, customerCurrency, qty, "add", "update", matchItem.id, staffInputValue);

                // session = await this.generateStaffPaymentLink(customer, price, matchItem.id, customerCurrency, qty, type, "update", matchItem.id, staffInputValue);
              }
              // qty = businessInfo.membershipStaffCount + qty;
            }
            else {
              session = await this.createNewStaffPlanCheckoutSession(customerSubscriptions, price, customer, quantity, businessInfo, type, customerCurrency);
            }
          }
        }
        else {
          session = await this.createNewStaffPlanCheckoutSession(customerSubscriptions, price, customer, quantity, businessInfo, type, customerCurrency);
        }
        await businessInfo.save();
      } catch (error) {
        Logger.logger.error(`Failed to update StripeCustomerId - Business: ${customer}`, error)
        throw new DatabaseError(`Failed to update StripeCustomerId - Business: ${customer}`)
      }
    } else {
      /** remove staff o current plan */
      // await this.reduceStaff(customerSubscriptions, businessInfo, quantity, price);
      // staffIds.forEach(async (st) => await StaffService.removeStaff(businessInfo.id, st))
    }
    return session;
  }

  public static async reduceStaff(customerSubscriptions, businessInfo, quantity, price) {
    let session;
    if (customerSubscriptions && customerSubscriptions.length > 0) {
      const matchregulerPlanItem = customerSubscriptions.find(item =>
        item.items.data.some(it =>
          it.plan &&
          it.plan.usage_type === planType.LICENSED &&
          it.plan.id === (businessInfo.stripePriceIds && businessInfo.stripePriceIds.recurringPriceId)
        )
      );
      const item = matchregulerPlanItem
      if (matchregulerPlanItem) {
        const planData = item.items.data.find(item => item.plan.id === price);
        const qty = quantity ? planData.quantity - quantity : 1;
        // const deleted = await stripe.subscriptionItems.del( planData.id);
        if (qty > 0) {
          session = await stripe.subscriptionItems.update(
            planData.id,
            {
              quantity: qty,
              proration_behavior: 'always_invoice',
            }
          );
        }
      }
    }
    else if (customerSubscriptions && customerSubscriptions.subscriptionList.length > 0) {
      let matchItem = null, itemId = null;
      // let matched = customerSubscriptions.subscriptionList.find(item =>
      //   item.items.data.some(it =>
      //     it.plan &&
      //     it.plan.usage_type === planType.LICENSED &&
      //     it.plan.id === price
      //   )
      // );
      let matched = null;
      for (const subscription of customerSubscriptions.subscriptionList) {
        matched = subscription.items.data.find(item =>
          item.plan &&
          item.plan.usage_type === planType.LICENSED &&
          item.plan.id === price
        );
        if (matched) break;
      }
      if (matched === undefined || matched === null) {
        const matchedSub = customerSubscriptions.items.data.find(item => item.plan && item.plan.id === price);
        itemId = matchedSub.items.data[0].id;
      }
      if (matched) {
        matchItem = matched;
        // break; // Stop searching once we find the first match
      }
      if (matchItem) {
        itemId = matched.id;
        let qty = quantity ? matchItem.quantity - quantity : 1;
        qty = qty === -1 ? 0 : qty;
        // update subscription with qty
        session = await stripe.subscriptionItems.update(
          itemId,
          {
            quantity: qty,
            proration_behavior: 'always_invoice',
          }
        );
      }
    }
    return '';
  }

  public static async createStaffCardSession(customer: string, price: string, subscriptionId: string, customerCurrency: string, quantity: number, type: string, methodType: string, itemId: string, staffInputValue: number) {
    let session;
    try {
      session = await stripe.checkout.sessions.create({
        customer: customer,
        payment_method_types: ['card'],
        mode: 'setup',
        currency: customerCurrency,
        metadata: {
          update_subscription: true,  // Flag for webhook-side update
          subscription_id: subscriptionId,  // Existing subscription ID
          item_id: itemId,
          price_id: price,    // Add-on item price ID
          currency: `${customerCurrency}`, //customer cuurent plan currency or location currency
          quantity: quantity,
          opration_type: type,
          method_type: methodType,
          staff_count: staffInputValue,
          category: 'staff'
        },
        success_url: rezrvaSpaUrl + '/business/staff',
        cancel_url: rezrvaSpaUrl + '/business/pricing',

      });
    } catch (error) {
      Logger.logger.error(`Error while create staff session : ${error.message}`)
    }
    return session;
  }



  public static async generateStaffPaymentLink(customer: string, price: string, subscriptionId: string, customerCurrency: string, quantity: number, type: string, methodType: string, itemId: string, staffInputValue: number) {
    let session;
    try {
      session = await stripe.paymentLinks.create({
        line_items: [
          {
            price: price,
            quantity: quantity,
          },
        ],
        currency: customerCurrency,
        metadata: {
          update_subscription: true,  // Flag for server-side update
          subscription_id: subscriptionId,  // Existing subscription ID
          item_id: itemId,
          price_id: price,    // Add-on item price ID
          currency: `${customerCurrency}`, //customer cuurent plan currency or location currency
          quantity: quantity,
          opration_type: type,
          method_type: methodType,
          staffCount: staffInputValue,
          customer: customer,
          category: 'staff'
        },
        after_completion: {
          type: 'redirect',
          redirect: {
            url: rezrvaSpaUrl + '/business/account',
          },
        },
      });
    } catch (error) {
      Logger.logger.error(`Error while create staff session : ${error.message}`)
    }
    return session;
  }


  public static async createNewStaffPlanCheckoutSession(item, price, customer, quantity, businessInfo, type, customerCurrency) {
    let session = null;
    try {
      let qty = 0;
      let initialStaffQty = quantity;
      // Create the subscription
      // manage staff amount based on plan
      // if (businessInfo.membershipTier === MembershipTier.Pro && (quantity > staffCount.pro_count)) {
      //   initialStaffQty = Math.abs(quantity - staffCount.pro_count)
      // }
      // if ((businessInfo.membershipTier === MembershipTier.Free || businessInfo.membershipTier === MembershipTier.Plus)) {
      //   initialStaffQty = quantity
      // }
      if (initialStaffQty > 0) {
        session = await stripe.checkout.sessions.create({
          mode: "subscription",
          payment_method_types: ["card"],
          customer,
          line_items: [
            {
              price,
              quantity: initialStaffQty,
            },
          ],
          metadata: {
            usage_type: 'licensed',
            priceId: price,
            oprationType: type
          },
          payment_method_collection: 'if_required',
          currency: `${customerCurrency}`, //customer cuurent plan currency or location currency
          success_url: rezrvaSpaUrl + '/business/staff',
          cancel_url: rezrvaSpaUrl + '/business/pricing',
        });
      } else {
        qty = quantity;
        session = await stripe.subscriptions.create({
          customer: customer,
          items: [{ price: price, quantity: 0 }],
          currency: `${customerCurrency}`,
          metadata: {
            usage_type: 'licensed',
            priceId: price,
            oprationType: type
          },
        });
      }
      // add new qty with existing staff in db
      businessInfo.membershipStaffCount = type == 'add' ? businessInfo.membershipStaffCount + quantity : type == 'remove' ? businessInfo.membershipStaffCount - quantity : businessInfo.membershipStaffCount;
    } catch (error) {
      Logger.logger.error(`while create staff plan : ${error}`)
    }
    return session;
  }

  public static async createStaffRecordUsage(currentBusinessDoc: IBusiness, quantity: number, usageDate) {
    const timestamp = usageDate ? usageDate : Math.floor(Date.now() / 1000);
    let isUsageAdd = false;
    const subscriptions = await stripe.subscriptions.list({
      customer: currentBusinessDoc.stripeCustomerId,
      // limit: 1 //optional
    });

    const subscriptionPlanItem = subscriptions.data.filter(sdt => (sdt.status === 'active' || sdt.status === 'trialing'))
    let filteredSubscriptions = null;
    for (const item of subscriptionPlanItem) {
      filteredSubscriptions = item.items.data.find(item => item.plan && item.plan.usage_type === planType.METERED && item.plan.id === (currentBusinessDoc.stripePriceIds &&
        currentBusinessDoc.stripePriceIds.staffUsagePriceId));
      if (filteredSubscriptions) break; // Stop searching once we find the first match
    }

    if (filteredSubscriptions) {
      const subscriptionItemId = filteredSubscriptions.id;
      try {
        // manage billing when user using pay as you go system 
        const usageRecord = await stripe.subscriptionItems.createUsageRecord(subscriptionItemId, {
          quantity: quantity,
          timestamp: timestamp,
          action: 'increment',
        },
          {
            idempotencyKey: uuidv4(),
          }
        );
        isUsageAdd = true;
      } catch (error) {
        console.error('Error recording usage:', error);
        // throw error;
      }
    }
    return isUsageAdd;
  }


  public static async createRecordUsage(currentBusinessDoc: IBusiness) {
    const timestamp = Math.floor(Date.now() / 1000);
    let isUsageAdd = false;
    const subscriptions = await stripe.subscriptions.list({
      customer: currentBusinessDoc.stripeCustomerId,
      // limit: 1 //optional
    });
    const subscriptionPlanItem = subscriptions.data.filter(sdt => (sdt.status === 'active' || sdt.status === 'trialing'))
    let filteredSubscriptions = null;
    for (const item of subscriptionPlanItem) {
      filteredSubscriptions = item.items.data.find(item => item.plan && item.plan.usage_type === planType.METERED && item.plan.id === (currentBusinessDoc.stripePriceIds &&
        currentBusinessDoc.stripePriceIds.staffUsagePriceId));
      if (filteredSubscriptions) break; // Stop searching once we find the first match
    }
    if (filteredSubscriptions) {
      const subscriptionItemId = filteredSubscriptions.id;
      try {
        // manage billing when user using pay as you go system 
        const usageRecord = await stripe.subscriptionItems.createUsageRecord(subscriptionItemId, {
          quantity: 1,
          timestamp: timestamp,
          action: 'increment',
        },
          {
            idempotencyKey: uuidv4(),
          }
        );
        isUsageAdd = true;
        console.log('Added stripe usages');
      } catch (error) {
        console.error('Error recording usage:', error);
        // throw error;
      }
    }
    return isUsageAdd;
  }

  public static async generatePaymentLink(id) {
    let hostedInvoiceUrl: string = '';
    let currentBusinessDoc = await BusinessesService.getBusinessDocByIdV2(id);
    if (currentBusinessDoc == null) {
      Logger.logger.warn(`Business Id ${id} doesn't exist`)
      throw new ReferencedResourceNotFoundError(`Business Id ${id} doesn't exist`)
    }

    const subscriptions = await stripe.subscriptions.list({
      customer: currentBusinessDoc.stripeCustomerId,
    });

    const filteredSubscriptions = subscriptions.data.find(subscription => {
      if (subscription.plan.usage_type === planType.LICENSED && subscription.plan.id === (currentBusinessDoc.stripePriceIds && currentBusinessDoc.stripePriceIds.recurringPriceId)) {
        return subscription;
      }
    });
    if (filteredSubscriptions) {
      try {
        const invoiceDoc = await stripe.invoices.retrieve(filteredSubscriptions.latest_invoice);
        if (invoiceDoc.status === 'draft') {
          await stripe.invoices.finalizeInvoice(invoiceDoc.id);
        }
        if (invoiceDoc.status === 'open') {
          hostedInvoiceUrl = invoiceDoc.hosted_invoice_url;
          // send payment link to customer for payment
          await EmailService.sendPaymentEmailToStripeCustomer(currentBusinessDoc, hostedInvoiceUrl)
        }
        return hostedInvoiceUrl
      } catch (error) {
        console.error('Error recording usage:', error);
        // throw error;
      }
    }
  }

  public static async updateCustomerDetails(customerId: string, business: Business) {
    try {
      // update business customer details on stripe with stripe  
      const result = await stripe.customers.update(
        customerId,
        {
          email: business.email,
          name: business.contactName
        }
      );
      Logger.logger.info(`Details updated successfully: ${customerId}`);
      return result;
    } catch (error) {
      Logger.logger.error(`Failed to update stripe details of StripeCustomerId : ${customerId}`, error.message)
      return
    }
  }

  private static async customRoundUp(price: number): Promise<number> {
    // Round up price for UI view
    if (price >= 50 && price < 100) {
      return Math.ceil(price / 10) * 10;
    } else if (price >= 100 && price < 1000) {
      return Math.ceil(price / 5) * 5;
    } else if (price >= 1000 && price < 10000) {
      return Math.ceil(price / 100) * 100;
    } else if (price >= 12501 && price < 20000) {
      return Math.ceil(price / 1000) * 1000;
    } else if (price != 12500 && price >= 20000 && price < 22000) {
      return Math.ceil(price / 1000) * 1000;
    }
    else if (price != 12500 && price >= 80000) {
      return Math.ceil(price / 1000) * 1000;
    }
    else {
      return Math.ceil(price);
    }
  }

  public static async getConvertedPrice(price, currencyKey, type, category) {
    // change price based on currency 
    let isCurrencyExist = await CurrencyService.getPlansCurrency(price.currency_options, currencyKey)
    if (isCurrencyExist) {
      currencyKey = isCurrencyExist;
    }
    let convertedPrice = 0;
    try {
      if (price.currency_options && price.currency_options[currencyKey.toLowerCase()]) {
        if (type === 'buyPrice') {
          if (price.recurring && price.recurring.interval === 'year' && currencyKey.toUpperCase() !== 'CLP') {
            // convertedPrice = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 100) / 12;

            // round up value with nearest number for regular plans
            const priceNum = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 100) / 12;
            if (category === 'regular-plan') {
              convertedPrice = await this.customRoundUp(priceNum)
            } else {
              convertedPrice = priceNum
            }
          }
          else if (price.recurring && price.recurring.interval === 'month' && price.recurring.usage_type !== 'metered' && currencyKey.toUpperCase() !== 'CLP') {
            convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 100;
          }
          if (price.type === 'one_time' && currencyKey.toUpperCase() !== 'CLP') {
            convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 100;
          }
          if (price.type === 'one_time' && (currencyKey.toUpperCase() === 'CLP' || currencyKey.toUpperCase() === 'PYG')) {
            convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount);
          }
          if (price.recurring && price.recurring.usage_type !== 'metered' && currencyKey.toUpperCase() === 'CLP') {
            convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount);
          }
          if (price.recurring && price.recurring.usage_type === 'metered') {
            convertedPrice = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 100);
          }
          if (price.recurring && price.recurring.interval === 'month' && (currencyKey.toUpperCase() === 'CLP' || currencyKey.toUpperCase() === 'PYG')) {
            // convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount);
            convertedPrice = price.currency_options[currencyKey.toLowerCase()].unit_amount ? Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) : Number(price.currency_options[currencyKey.toLowerCase()].unit_amount_decimal)
          }
          if (price.recurring && price.recurring.interval === 'year' && (currencyKey.toUpperCase() === 'CLP' || currencyKey.toUpperCase() === 'PYG')) {
            convertedPrice = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount)) / 12;
            // round up value with nearest number 
            let priceNum = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount)) / 12;
            convertedPrice = await this.customRoundUp(priceNum)
          }
        }
        // / && currencyKey.toUpperCase() !== 'CLP'
        if (type === '10Months') {
          if (price.recurring && price.recurring.usage_type !== 'metered' && price.recurring.interval === 'year') {
            convertedPrice = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 1000);
            // convertedPrice = convertedPrice - 2; //mins 2 months 
            const allMonthsAmount = Number(Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 1000 * 12);
            const twoMonthsAmount = Number((Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 1000 * 2))
            convertedPrice = allMonthsAmount - twoMonthsAmount;
          }
          if (price.recurring && price.recurring.interval === 'year' && (currencyKey.toUpperCase() === 'CLP' || currencyKey.toUpperCase() === 'PYG')) {
            convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount);
          }
        }
        //  && currencyKey.toUpperCase() !== 'CLP'
        if (type === '12Months') {
          if (price.recurring && price.recurring.usage_type !== 'metered' && price.recurring.interval === 'year') {
            convertedPrice = (Number(price.currency_options[currencyKey.toLowerCase()].unit_amount) / 1000) * 12
          }
          if (price.recurring && price.recurring.interval === 'year' && (currencyKey.toUpperCase() === 'CLP' || currencyKey.toUpperCase() === 'PYG')) {
            convertedPrice = Number(price.currency_options[currencyKey.toLowerCase()].unit_amount / 10) * 12;


          }
        }
      }
    } catch (error) {
      console.error('Error retrieving exchange rate:', error);
      return null;
    }
    return Number(convertedPrice.toFixed(2)).toLocaleString('en-US');
    // return Number(Math.ceil(convertedPrice)).toLocaleString('en-US');

  }

  public static async getCustomerSubscriptions(customer: string) {
    let subscriptionData = {
      subscription: {},
      subscriptionList: []
    }
    try {
      let subscription;
      if (customer) {
        const subscriptionList = await stripe.subscriptions.list({
          customer: customer,
          // status: 'active'
        });
        if (subscriptionList && subscriptionList.data.length > 0) {
          // filter customer active or trial subscription plan
          subscription = subscriptionList.data.filter(value => value.status === 'active' || value.status === 'trialing');
          subscriptionData = {
            subscription: subscription[0],
            subscriptionList: subscription

          };
        }
      }
      return subscriptionData;
    } catch (error) {
      console.error(`Error retrieving existing subscriptions of customer : ${customer}:`, error.message);
      return null;
    }
  }

  private static async getOldSubscriptionAndDelete(customer: string) {
    try {
      let isPlanDelete = false;
      let subscription;
      if (customer) {
        const subscriptionList = await stripe.subscriptions.list({
          customer: customer,
          // status: 'active'
        });
        if (subscriptionList && subscriptionList.data.length > 0) {
          subscription = subscriptionList.data.find(value => value.status === 'active' || value.status === 'trialing');
          if (subscription && subscription.plan && subscription.plan.id) {
            const planId = subscription.plan.id;
            if (isProd) {
              // based on old user
              if (ProductToPriceMap.prod.PLUS.includes(planId)) {
                isPlanDelete = true;
              }
              if (ProductToPriceMap.prod.PRO.includes(planId)) {
                isPlanDelete = true;

              }
            } else {
              if (ProductToPriceMap.test.PLUS.includes(planId)) {
                isPlanDelete = true;

              }
              if (ProductToPriceMap.test.PRO.includes(planId)) {
                isPlanDelete = true;
              }
              if (isPlanDelete) {
                // delete old price plan of existing user 
                await stripe.subscriptions.cancel(
                  subscription.id
                );
              }
            }
          }
        }
      }
      return isPlanDelete;
    } catch (error) {
      console.error(`Error retrieving old subscriptions of customer: ${customer}:`, error.message);
      return null;
    }
  }

  private static async saveOldPriceIdOfCustomer(businessDoc: IBusiness) {
    try {
      if (businessDoc.stripeCustomerId) {
        let subscription;
        const subscriptionList = await stripe.subscriptions.list({
          customer: businessDoc.stripeCustomerId,
          // status: 'active'
        });
        if (subscriptionList && subscriptionList.data.length > 0) {
          // subscription = subscriptionList.data.find(value => value.status === 'active' || value.status === 'trialing');
          subscription = subscriptionList.data.find(item =>
            item.items.data.some(it =>
              it.plan &&
              (it.plan.usage_type === planType.LICENSED && it.plan.metadata.category == 'regular-plan')));
          if (subscription && subscription.plan && subscription.plan.id && subscription.plan.usage_type === planType.LICENSED) {
            if (businessDoc.stripePriceIds == undefined) {
              businessDoc.stripePriceIds = {
                oneTimePriceId: '',
                recurringPriceId: '',
                usagePriceId: '',
                staffUsagePriceId: ''
              }
            }
            if (businessDoc && (businessDoc.stripePriceIds['recurringPriceId'] === null || businessDoc.stripePriceIds['recurringPriceId'] === '' || businessDoc.stripePriceIds['recurringPriceId'] === undefined || businessDoc.stripePriceIds['recurringPriceId'] == 'false')) {
              businessDoc.stripePriceIds['recurringPriceId'] = subscription.plan.id;
            }
            businessDoc['stripePlanStatus'] = subscription.status
            await businessDoc.save()
          }
        }
      }

      return '';
    } catch (error) {
      console.error(`Error retrieving subscriptions of customer: ${businessDoc.stripeCustomerId}:`, error.message);
      return null;
    }
  }

  public static async createAccountOnboardingLink(id: string): Promise<string> {
    try {
      let accountId = '', account = null, accountLink = null;
      const businessDoc = await BusinessesService.getBusinessDocById(id);

      if (businessDoc === null) {
        Logger.logger.warn(`User with email: '${id}' not exists`)
        throw new ResourceAlreadyExistsError(`User with email: '${id}' not exists`)
      }
      // if (businessDoc && businessDoc.membershipTier === MembershipTier.Free) {
      //   Logger.logger.warn(`Only pro or plus user can access this service`)
      //   throw new DatabaseError(`Only pro or plus user can access this service`)
      // }

      // if (businessDoc.settings.paymentTypes && businessDoc.settings.paymentTypes.length > 0) {
      //   Logger.logger.warn(`Payment method is already connected for this business`);
      //   throw new ResourceAlreadyExistsError(`El método de pago ya está conectado para este negocio`);
      // }
      if (businessDoc.isConnectedAccDetailSubmitted === undefined || !businessDoc.isConnectedAccDetailSubmitted) {
        if (businessDoc.stripeConnectAccountId && businessDoc.isPaymentMethodConnected) {
          accountId = businessDoc.stripeConnectAccountId;
        } else {
          if (['US'].includes(businessDoc.address.countryShortName)) {
            account = await stripe.accounts.create({
              type: StripeConnectedType.EXPRESS,
              country: businessDoc.address.countryShortName,
              email: businessDoc.email,
              capabilities: {
                transfers: { requested: true },
                // card_payments: { requested: true },
              },
              // tos_acceptance: {
              //   service_agreement: 'recipient', // Required for Chile
              // },
            });
          }
          else if (['BR'].includes(businessDoc.address.countryShortName)) {
            account = await stripe.accounts.create({
              type: StripeConnectedType.STANDARD,
              country: businessDoc.address.countryShortName,
              email: businessDoc.email,
              capabilities: {
                transfers: { requested: true },
                card_payments: { requested: true },
              },
              // tos_acceptance: {
              //   service_agreement: 'recipient', // Required for Chile
              // },
            });
          }
          else {
            account = await stripe.accounts.create({
              type: StripeConnectedType.EXPRESS,
              country: businessDoc.address.countryShortName,
              email: businessDoc.email,
              capabilities: {
                transfers: { requested: true },
                // card_payments: { requested: true },
              },
              tos_acceptance: {
                service_agreement: 'recipient', // Required for Chile
              },
            });
          }
          accountId = account.id;
        }
        // Create account link for onboarding
        accountLink = await stripe.accountLinks.create({
          account: accountId,
          refresh_url: `${rezrvaSpaUrl}/business/payments/provider-connect/connect-stripe?methodType=stripe`,
          return_url: `${rezrvaSpaUrl}/business/payments/provider-connect/connect-stripe?methodType=stripe`,
          type: 'account_onboarding',
        });
        // Update business doc with stripe connect account id
        businessDoc.stripeConnectAccountId = accountId;
      }
      businessDoc.isPaymentMethodConnected = true;
      businessDoc.settings.paymentTypes = [PaymentType.Stripe];
      console.log(accountLink, 'accountLink.url');
      await businessDoc.save();
      return accountLink && accountLink.url ? accountLink.url : '';
    } catch (error) {
      Logger.logger.error('Error creating onboarding URL:', error);
      if (error.httpCode === 409) {
        throw new ResourceAlreadyExistsError(error.message)
      }
      throw new DatabaseError('Failed to create onboarding URL');
    }
  }

  public static async createConnectedAccountCheckoutSession(booking: any, service: BusinessService, serviceSnapshot: BusinessServiceSnapshot, business, fromBusiness, type) {
    let serviceAmount = 0, depositText = '', successUrl = null,
      cancelUrl = null, expiresAt = null;
    let isDepositPaid = false, isRemainingPaid = false, isFullPaid = false;
    if (service && service.paymentSetting && service.paymentSetting.paymentType.includes(ServicePaymentType.NoPayment)) {
      return null
    }
    let businessDoc = await BusinessesService.getByEmail(business.email)
    if (businessDoc == null) {
      Logger.logger.warn(`Business with email: '${business.email}' already exists`)
      throw new ResourceAlreadyExistsError(`Business with email: '${business.email}' already exists`)
    }
    // partial payment 

    if (type === 'reminderAmount' && serviceSnapshot && serviceSnapshot.paymentSetting && serviceSnapshot.paymentSetting.paymentType.includes(ServicePaymentType.Deposit)) {
      const tempDepost = serviceSnapshot.paymentSetting.isPercentage ? serviceSnapshot.depositAmount / 100 : serviceSnapshot.depositAmount;
      // Calculate remaining amount for second payment
      const teamPric = serviceSnapshot.servicePrice;
      const teamDepo = tempDepost;
      serviceAmount = serviceSnapshot.paymentSetting.isPercentage ?
        (serviceSnapshot.servicePrice - (teamPric * teamDepo / 100)) :
        (teamPric - teamDepo);
      isRemainingPaid = true;
    }
    else if (service && service.paymentSetting && service.paymentSetting.paymentType.includes(ServicePaymentType.Deposit)) {
      const tempDepost = service.paymentSetting.isPercentage ? service.depositAmount / 100 : service.depositAmount;
      // Calculate initial deposit amount
      serviceAmount = service.paymentSetting.isPercentage ?
        (service.price * tempDepost / 100) :
        tempDepost;
      isDepositPaid = true;
    }
    // full payment
    if (service && service.paymentSetting && service.paymentSetting.paymentType.includes(ServicePaymentType.FullPayment)) {
      serviceAmount = service.price;
      isFullPaid = true
    }
    // Get currency based on location
    const currency = Currency[serviceSnapshot.serviceCurrency];
    console.log('currency', currency);
    // Convert amount to the smallest currency unit
    // const convertedPrice = zeroDecimalCurrencies.includes(currency.toUpperCase()) ? serviceAmount / 100 : serviceAmount;
    const convertedPrice = zeroDecimalCurrencies.includes(currency.toUpperCase()) ? serviceAmount ? Math.round(serviceAmount / 100) : 0 : Math.round(serviceAmount);

    // update the text based on payment
    if (isDepositPaid) {
      depositText = `isDepositPaid=true`
    }
    if (isRemainingPaid) {
      depositText = `isRemainingPaid=true`
    }
    if (isFullPaid) {
      depositText = `isFullPaid=true`
    }

    if (fromBusiness) {
      successUrl = rezrvaSpaUrl + `/business/booking?bookingId=${booking.id}&isSuccess=true`;
      cancelUrl = rezrvaSpaUrl + `/business/booking?bookingId=${booking.id}&isBack=true`;
    } else {
      // successUrl = rezrvaSpaUrl + `/reservation-sent?amount=${serviceAmount / 100}&symbol=${service.currency}&slug=${business.slug}&${depositText}`,


      // successUrl = rezrvaSpaUrl + `/@${business.slug}`.split('?')[0] + `/book/${serviceSnapshot.serviceName.replace(/\s+/g, '-')}?serviceName=${serviceSnapshot.serviceName.replace(/\s+/g, '-')}&startDate=${encodeURIComponent(booking.startDate || '')}&endDate=${encodeURIComponent(booking.endDate || '')}&customer=${encodeURIComponent((booking.customer || ''))}&price=${encodeURIComponent(serviceAmount / 100)}&staffName=${encodeURIComponent(booking.staffSnapshot?.name || '')}&notes=${encodeURIComponent(booking?.notes || '')}&${depositText}`;

      // cancelUrl = rezrvaSpaUrl + `/@${business.slug}`.split('?')[0] + `?isBack=true&booking_id=${booking.id}`;

      const serviceName = TextFormatService.removeSpecialCharacters(serviceSnapshot.serviceName).replace(/\s+/g, '-');

      successUrl = rezrvaSpaUrl + `/@${business.slug}`.split('?')[0] + `/book/${serviceName}?isClient=true&bookingId=${booking.id}`;
      cancelUrl = rezrvaSpaUrl + `/@${business.slug}`.split('?')[0] + `/booking/${serviceName}?isBack=true&booking_id=${booking.id}`;

    }
    if (type === "reminderAmount") {
      // expiresAt = Math.floor(new Date("2025-03-26T14:00:00.000Z").getTime() / 1000);
      expiresAt = Math.floor(Date.now() / 1000) + 1800; // 30 minutes from now
    } else {
      expiresAt = Math.floor(Date.now() / 1000) + 1800; // 30 minutes from now
    }
    const session = await stripeNew.checkout.sessions.create({
      ui_mode: 'hosted', //hosted  embedded
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: currency.toLowerCase(),
          product_data: {
            name: serviceSnapshot.serviceName,
            description: serviceSnapshot.serviceDescription
          },
          unit_amount: convertedPrice, // Convert to cents
        },
        quantity: 1,
      }],
      allow_promotion_codes: true, // 👈 Show promo code input field in UI
      metadata: {
        isDepositPaid: isDepositPaid,
        isRemainingPaid: isRemainingPaid,
        isFullPaid: isFullPaid,
        bookingId: booking.id,
        fromBusiness: fromBusiness
      },
      payment_intent_data: {
        description: `Payment By ${booking.customer.name} ${booking.customer.surname} to  ${business.name} for ${serviceSnapshot.serviceName}`, // 👈 Will show up in Stripe Dashboard
        // application_fee_amount: platformFee, // Platform fee in cents  4.9%+30 cent
        transfer_data: {
          destination: business.stripeConnectAccountId, // connected account
        },
      },
      // return_url: successUrl,
      success_url: successUrl,
      cancel_url: cancelUrl,
      expires_at: expiresAt, // Set dynamic expiry time
      custom_text: {
        submit: {
          message: 'Esta sesión expirará en 15 minutos y, si el pago no se completa, su reserva será cancelada. ¡Gracias por su compra!',
        },
      },
    });
    Logger.logger.info(`Checkout session created: ${session.id}`);
    // save orderId and payment statusin db of booking table for manage status 
    const tampId = booking._id ? booking._id.toString() : booking.id;
    console.log(tampId, '--tampId');
    booking.id = tampId;
    const bookingDoc = await BookingsService.getBookingDocById(booking.id);
    bookingDoc.paymentStatus = 'PENDING';
    bookingDoc.checkoutInitiatedAt = new Date();
    bookingDoc['paidAmount'] = serviceAmount;
    bookingDoc.checkoutSessionId = session.id;
    bookingDoc.link = session.url;
    await bookingDoc.save()
    return { sessionLink: session.url, paidPrice: serviceAmount / 100 }
  }

  public static async processTransfer(paymentIntentId, connectedAccountId) {
    try {
      // Retrieve the PaymentIntent
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      if (!paymentIntent.latest_charge) {
        Logger.logger.error("PaymentIntent has no associated charge.");
        return false;
      }

      // Retrieve charge details
      const charge = await stripe.charges.retrieve(paymentIntent.latest_charge);
      const balanceTransaction = await stripe.balanceTransactions.retrieve(charge.balance_transaction);
      const totalAmount = balanceTransaction.amount / 100; // Convert cents to dollars
      const stripeFees = balanceTransaction.fee / 100; // Convert cents to dollars
      const netAmount = balanceTransaction.net / 100; // Convert cents to dollars
      Logger.logger.info(`Total Amount: $${totalAmount.toFixed(2)} USD`);
      Logger.logger.info(`Stripe Fees: $${stripeFees.toFixed(2)} USD`);
      Logger.logger.info(`Net Amount: $${netAmount.toFixed(2)} USD`);
      const formatINNumber = Number(totalAmount).toFixed(2)
      // Example value const B6 = 61.12; (81.83 - (81.83 * 4.9%) - 0.3) / 0.99
      // const amountInCents = Number(((Number(formatINNumber) - (Number(formatINNumber) * 0.049) - 0.3) / 0.99).toFixed(2)) * 100; // Calculate platform fee
      const amountInCents = Math.round(
        ((Number(formatINNumber) - (Number(formatINNumber) * 0.049) - 0.3) / 0.99) * 100
      );
      Logger.logger.info(`Amount to Transfer: $${(amountInCents / 100).toFixed(2)} USD`);
      try {
        // Create the transfer to connected account
        const transfer = await stripe.transfers.create({
          amount: amountInCents, // Full net amount after Stripe fees
          currency: 'usd',
          destination: connectedAccountId, // Connected account ID
          description: 'Transfer booking Stripe fees',
          source_transaction: paymentIntent.latest_charge,
          // application_fee_amount: platformFeeInCents, // Platform fee charged to the platform
        });
        Logger.logger.info(`✅ Transfer Created: ${transfer.id}`);
        return true;
      } catch (transferError) {
        Logger.logger.error("❌ Transfer Error:", transferError);
        return false;
      }
    } catch (error) {
      Logger.logger.error("❌ Error in processTransfer:", error);
      return false;
    }
  }


  public static async disconnectStripeAccount(id: string) {
    let businessDoc = await BusinessesService.getBusinessDocByIdV2(id)
    if (businessDoc == null) {
      Logger.logger.warn(
        `Business dose not exists with this id ${id}`
      );
      throw new ReferencedResourceNotFoundError(
        `Business dose not exists with this id ${id}`
      );
    }
    try {
      businessDoc['isPaymentMethodConnected'] = false;
      businessDoc.settings.paymentTypes = [];
      await businessDoc.save()
      // set packages as inactive
      await BusinessMembershipService.updateBusinessPackagesToInactive(businessDoc.id);
      return
    } catch (err) {
      Logger.logger.error("Failed to disconnect stripe payment", err)
      throw new DatabaseError("Failed to stripe payment")
    }
  }

  public static async getConnectedAccountStatus(business) {
    try {
      const accountId = business.stripeConnectAccountId;
      // const account = await stripe.accounts.retrieve(accountId);      
      const connectedAccDetails = await stripe.accounts.retrieve(accountId);
      const dashBoardLink = (business.isPaymentMethodConnected && business.isConnectedAccDetailSubmitted) ? await stripe.accounts.createLoginLink(accountId) : null;
      return { connectedAccDetails, dashBoardLink };
    } catch (error) {
      console.error('Error fetching account details:', error);
      throw error;
    }
  }
  public static async expirePendingBookingCheckoutSession(sessionId: string): Promise<void> {
    try {
      await stripe.checkout.sessions.expire(sessionId);
      Logger.logger.info(`Checkout session expired successfully: ${sessionId}`);
    } catch (error) {
      Logger.logger.warn(`Failed to expire checkout session: ${sessionId}`, error.message);
      if (error.message.includes('This Checkout Session has a status of `expired`')) {
        return
      }
      // throw new DatabaseError(`Failed to expire checkout session: ${sessionId}`);
    }
  }

  public static async createMembershipCheckoutSession(clientId: string, membershipId: string, quantity: number) {
    const clientDoc = await ClientService.getByClientId(clientId);
    if (clientDoc == null) {
      Logger.logger.warn(`Client dose not exists with this id ${clientId}`)
      throw new ResourceAlreadyExistsError(`Client dose not exists with this id ${clientId}`)
      
    }
    let membershipDoc = await BusinessMembershipService.getByDocId(membershipId);
    let business = await BusinessesService.getById(membershipDoc.businessId);
    if (business == null) {
      Logger.logger.warn(`Business dose not exists with this id ${clientDoc.businessId}`)
      throw new ResourceAlreadyExistsError(`Business dose not exists with this id ${clientDoc.businessId}`)
    }
    // Get currency based on location
    const currency = Currency[business.currency];
    // Convert amount to the smallest currency unit
    // const convertedPrice = zeroDecimalCurrencies.includes(currency.toUpperCase()) ? membershipDoc.price ? membershipDoc.price / 100 : 0 : membershipDoc.price;
    console.log(membershipDoc.price);
    const convertedPrice = zeroDecimalCurrencies.includes(currency.toUpperCase()) ? membershipDoc.price ? Math.round(membershipDoc.price / 100) : 0 : Math.round(membershipDoc.price);
   console.log(convertedPrice);
   
    const successUrl = rezrvaSpaUrl + `/client/membership-history`;
    const cancelUrl = rezrvaSpaUrl + `/client/membership/${membershipId}`;
    const expiresAt = Math.floor(Date.now() / 1000) + 1800; // 30 minutes from now
    // store membership of client
    const utcTimeFormat = TimeSlotService.getTimeZoneOffset(
      business.timeZone.name,
      new Date(),
      false
    )
    const membershipdoc = await ClientMembershipService.createClientMembership(
      new ClientMembership(
        null,
        membershipDoc.businessId,
        clientId,
        membershipId,
        quantity,
        'Pending',
        utcTimeFormat,
        true,
        false,
        new MembershipServiceSnapshot(
          null,
          membershipDoc.name,
          membershipDoc.description,
          membershipDoc.membershipHash,
          membershipDoc.packageSetting,
          membershipDoc.price,
          membershipDoc.currency,
          membershipDoc.isDeleted,
          membershipDoc.isActive,
          membershipDoc.logo,
          membershipDoc.type
        ),
        undefined,
        undefined,
        undefined,
        Number(membershipDoc.totalBookingQuantity * quantity),
      ));

    const clientMembershipId = membershipdoc.id;

    const session = await stripe.checkout.sessions.create({
      ui_mode: 'hosted', //hosted  embedded
      mode: 'payment',
      line_items: [{
        price_data: {
          currency: currency.toLowerCase(),
          product_data: {
            name: membershipDoc.name || business.name,
            description: membershipDoc.description || business.name
          },
          unit_amount: convertedPrice, // Convert to cents
        },
        quantity: quantity,
      }],
      metadata: {
        clientId: clientId,
        membershipId: membershipId,
        clientMembershipId: clientMembershipId
      },
      payment_intent_data: {
        description: `Payment By ${clientDoc.name} ${clientDoc.surname} to  ${business.name} `, // 👈 Will show up in Stripe Dashboard
        // application_fee_amount: platformFee, // Platform fee in cents  4.9%+30 cent
        transfer_data: {
          destination: business.stripeConnectAccountId, // connected account
        },
      },
      // return_url: successUrl,
      success_url: successUrl,
      cancel_url: cancelUrl,
      expires_at: expiresAt, // Set dynamic expiry time
      custom_text: {
        submit: {
          message: 'Esta sesión expirará en 30 minutos y, si el pago no se completa, su reserva será cancelada. ¡Gracias por su compra!',
        },
      },
    });
    Logger.logger.info(`Checkout session created: ${session.id}`);


    return {
      sessionId: session.id,
    };
  }


}