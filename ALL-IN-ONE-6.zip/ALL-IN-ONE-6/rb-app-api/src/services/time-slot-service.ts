import dayjs = require("dayjs");
import { IBooking, BookingDbModel } from "../db-models/booking.db-model";
import { DatabaseError } from "../errors/database.error";
import { Logger } from "../logger";
import { Business } from "../types/business";
import { BusinessHoursBlock } from "../types/business-hours-block";
import { BusinessService } from "../types/business-service";
import { BookingStatus } from "../types/enums/booking.status";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { Staff } from "../types/staff";
import { TimeZone } from "../types/time-zone";
import { TimeslotBooked } from "../types/timeslot-booked";
import { BusinessesService } from "./businesses.service";
const momentZone = require('moment-timezone');
import moment = require("moment");

import { StaffService } from "./staff.service";
import { BusinessAvailability } from "../types/business-availability";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { DateUtils } from "../utils/date.utils";
import * as isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import { BusinessServicesService } from "./business-services.service";

dayjs.extend(isSameOrBefore);

const weekdayMap = {
  Sunday: 0,
  Monday: 1,
  Tuesday: 2,
  Wednesday: 3,
  Thursday: 4,
  Friday: 5,
  Saturday: 6
};
const GRID = 15; // or 30 or 60


export abstract class TimeSlotService {

  public static async getAvailability(
    businessId: string,
    serviceId: string,
    staffId?: string
  ): Promise<any> {
    try {
      let calendarId = null;
      const referencedBusiness = await BusinessesService.getById(businessId);
      const referencedService = referencedBusiness.services?.find(
        (s) => s.id == serviceId
      );

      const referencedStaff = staffId &&
        (referencedBusiness.membershipTier === MembershipTier.Pro ||
          referencedBusiness.stripePriceIds?.staffUsagePriceId ||
          referencedBusiness.isAnnualActive)
        ? await StaffService.getById(staffId, businessId)
        : null;
      if (referencedBusiness?.isConflict) {
        const googleResult = referencedBusiness.googleCalendar?.find(
          (dt) => dt.status === 'enable'
        );
        calendarId = googleResult?.calendarId || null;
      }
      const dateTimeNow = new Date();
      const businessTimeNow = dateTimeNow.toLocaleString("en-US", {
        timeZone: referencedBusiness.timeZone!.name,
        hourCycle: "h23",
      });

      const startDate = this.getTimeZoneOffset(
        referencedBusiness.timeZone!.name,
        new Date(businessTimeNow),
        false
      );

      const endDate = new Date(
        this.getTimeZoneOffset(
          referencedBusiness.timeZone!.name,
          new Date(businessTimeNow),
          false
        ).setMonth(startDate.getMonth() + 3)
      );
      const timeslotsAlreadyBooked = await TimeSlotService.getTimeslotsBooked(
        businessId,
        referencedService.id,
        calendarId
      );

      const returnObj: BusinessAvailability = {
        unavailableDates: [],
        availableDates: [],
      };
      // 🔹 Check if it's an event-based service
      if (referencedService?.type === 'event' && referencedService.eventSetting) {
        const events: any = await this.generateRecurringEvents(
          referencedService,
          referencedBusiness.timeZone.name,
          startDate,
          endDate,
          timeslotsAlreadyBooked,
          businessId
        );
        returnObj.availableDates = events.availableDates;
        returnObj.unavailableDates = events.unavailableDates;
      }
      else {
        //Get date range from now to 3 months
        //Loop through date range
        for (
          var d = new Date(startDate.setDate(startDate.getDate() - 1));
          d <= endDate;
          d.setDate(d.getDate() + 1)
        ) {
          let dayInDayJs = dayjs(d).startOf("day");
          let date = dayInDayJs.format("YYYY/MM/DD");
          if (referencedBusiness.blockoutDates.includes(date)) {
            //Date blocked out
            returnObj.unavailableDates.push(date);
            continue;
          }

          let timeSlots = staffId
            ? await TimeSlotService.generateTimeSlots(
              referencedBusiness,
              referencedService,
              referencedStaff,
              dayInDayJs,
              timeslotsAlreadyBooked
            )
            : await TimeSlotService.generateTimeSlots(
              referencedBusiness,
              referencedService,
              null,
              dayInDayJs,
              timeslotsAlreadyBooked
            );
          if (timeSlots && timeSlots.length > 0) {
            returnObj.availableDates.push({
              date,
              timeSlots,
            });
          } else {
            //No Timeslots available
            returnObj.unavailableDates.push(date);
          }
        }
      }
      return returnObj;
    } catch (error) {
      console.error("Error in getAvailability:", error);
      return null;
    }
  }


  public static async getAvailabilityStaff(
    staffId: string,
    serviceId: string,
  ): Promise<any> {
    try {
      let calendarId = null;
      const referencedStaff = await StaffService.getStaffDocByObjectId(staffId);

      const referencedService = referencedStaff.servicesId?.find(
        (sId) => sId == serviceId
      );
      const referencedBusiness = referencedStaff.businessId
        ? await BusinessesService.getById(referencedStaff.businessId)
        : null;
      if (referencedStaff && referencedStaff.isConflict) {
        const googleResult = referencedStaff ? referencedStaff.googleCalendar.find(dt => dt.status === 'enable') : null
        calendarId = googleResult.calendarId ? googleResult.calendarId : null;
      }
      //Get date range from now to 3 months
      const dateTimeNow = new Date();
      const businessTimeNow = dateTimeNow.toLocaleString("en-US", {
        timeZone: referencedBusiness.timeZone!.name,
        hourCycle: "h23",
      });
      const startDate = this.getTimeZoneOffset(
        referencedBusiness.timeZone!.name,
        new Date(businessTimeNow),
        false
      );
      const endDate = new Date(
        this.getTimeZoneOffset(
          referencedBusiness.timeZone!.name,
          new Date(businessTimeNow),
          false
        ).setMonth(startDate.getMonth() + 3)
      );

      const timeslotsAlreadyBooked = await TimeSlotService.getTimeslotsBookedForStaff(
        referencedStaff.businessId,
        referencedService.id,
        calendarId,
        staffId
      );
      var returnObj: BusinessAvailability = {
        unavailableDates: [],
        availableDates: [],
      };
      //Loop through date range
      for (
        var d = new Date(startDate.setDate(startDate.getDate() - 1));
        d <= endDate;
        d.setDate(d.getDate() + 1)
      ) {
        let dayInDayJs = dayjs(d).startOf("day");
        let date = dayInDayJs.format("YYYY/MM/DD");
        if (referencedBusiness.blockoutDates.includes(date)) {
          //Date blocked out
          returnObj.unavailableDates.push(date);
          continue;
        }
        let timeSlots = staffId
          ? await TimeSlotService.generateTimeSlots(
            referencedBusiness,
            referencedService,
            referencedStaff,
            dayInDayJs,
            timeslotsAlreadyBooked
          )
          : await TimeSlotService.generateTimeSlots(
            referencedBusiness,
            referencedService,
            null,
            dayInDayJs,
            timeslotsAlreadyBooked
          );
        if (timeSlots && timeSlots.length > 0) {
          returnObj.availableDates.push({
            date,
            timeSlots,
          });
        } else {
          //No Timeslots available
          returnObj.unavailableDates.push(date);
        }
      }
      return returnObj;
    } catch {
      return null;
    }
  }

  public static async generateRecurringEvents(
    serviceInfo,
    zone,
    slotStartDate,
    slotEndDate,
    timeslotsAlreadyBooked,
    businessId
  ) {
    const {
      eventType = [],
      startDate,
      endDate,
    } = serviceInfo.eventSetting;

    const type = eventType[0]?.toLowerCase(); // normalize to lower case
    const referencedEventService = await BusinessServicesService.getAllBusinesServices(businessId);
    const returnObj = {
      unavailableDates: [],
      availableDates: []
    };

    if (!startDate || !endDate || !type) {
      throw new Error('Missing required event setting fields.');
    }

    const slotStart = momentZone.tz(startDate, zone);
    const slotEnd = momentZone.tz(endDate, zone);
    const fullSlotStart = momentZone.tz(slotStartDate, zone);
    const fullSlotEnd = momentZone.tz(slotEndDate, zone);

    const pushedAvailableDates = new Set();

    const pushAvailableSlot = (start, end) => {
      const startUtc = moment(start).utc();
      const endUtc = moment(end).utc();

      const dateStr = start.format('YYYY/MM/DD');
      if (!pushedAvailableDates.has(dateStr)) {
        const isNotOverlappingTimeslot = this.checkIfTimeslotIsAvailable(
          timeslotsAlreadyBooked,
          startUtc.toDate(),
          endUtc.toDate(),
          zone,
          null,
          serviceInfo.capacity,
          serviceInfo,
          referencedEventService,
          null,
          null
        );
        if (isNotOverlappingTimeslot.check) {
          pushedAvailableDates.add(dateStr);
          returnObj.availableDates.push({
            date: dateStr,
            timeSlots: [
              {
                display: `${start.format('HH:mm')}-${end.format('HH:mm')}`,
                startDateTime: start.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
                endDateTime: end.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
                currentCapacity: isNotOverlappingTimeslot.capacity
              }
            ]
          });
        }
      }
    };

    // Handle one-time event
    if (type === 'doesnotrepeat') {
      pushAvailableSlot(slotStart.clone(), slotEnd.clone());

      let cursor = fullSlotStart.clone();
      const oneTimeDateStr = slotStart.format('YYYY/MM/DD');

      while (cursor.isSameOrBefore(fullSlotEnd, 'day')) {
        const dateStr = cursor.format('YYYY/MM/DD');
        if (dateStr !== oneTimeDateStr) {
          returnObj.unavailableDates.push(dateStr);
        }
        cursor.add(1, 'day');
      }

      return returnObj;
    }

    // Setup recurring slot variables
    const repeatUntil = slotStart.clone().add(1, 'year');
    let recurrenceSlotStart = slotStart.clone();
    let recurrenceSlotEnd = slotEnd.clone();

    // Store weekday and nth week of month for "monthly on 2nd Saturday" pattern
    const originalWeekday = slotStart.day(); // 0 = Sunday
    const originalWeekOfMonth = Math.floor((slotStart.date() - 1) / 7) + 1;

    while (recurrenceSlotStart.isSameOrBefore(repeatUntil, 'day')) {
      if (type !== 'custom') {
        pushAvailableSlot(recurrenceSlotStart.clone(), recurrenceSlotEnd.clone());
      }

      if (type === 'daily') {
        recurrenceSlotStart.add(1, 'day');
        recurrenceSlotEnd.add(1, 'day');

      } else if (type === 'weekly') {
        recurrenceSlotStart.add(1, 'week');
        recurrenceSlotEnd.add(1, 'week');

      }
      else if (type === 'monthly') {
        const durationMs = slotEnd.diff(slotStart); // preserve duration
        const nextMonthStart = recurrenceSlotStart.clone().add(1, 'month').startOf('month');
        const targetMonth = nextMonthStart.month(); // store target month once
        let count = 0;
        let candidate = nextMonthStart.clone();

        // Loop through the next month to find nth occurrence of original weekday
        while (candidate.month() === targetMonth) {
          if (candidate.day() === originalWeekday) {
            count++;
            if (count === originalWeekOfMonth) {
              break;
            }
          }
          candidate.add(1, 'day');
        }

        if (count === originalWeekOfMonth) {
          recurrenceSlotStart = candidate.clone()
            .hour(slotStart.hour())
            .minute(slotStart.minute());

          recurrenceSlotEnd = recurrenceSlotStart.clone().add(durationMs);
        } else {
          // fallback if nth weekday not found
          recurrenceSlotStart = candidate.endOf('month')
            .hour(slotStart.hour())
            .minute(slotStart.minute());

          recurrenceSlotEnd = recurrenceSlotStart.clone().add(durationMs);
        }

      }

      else if (type === 'custom') {
        const recurrence = serviceInfo.eventSetting.customSetting || {};
        const {
          repeatValue,
          repeatUnit,
          selectedDays = [],
          endOption,
          endDate
        } = recurrence;

        if (!repeatUnit) return returnObj;

        const eventDuration = slotEnd.diff(slotStart);


        const selectedIndexes = selectedDays.map(day => weekdayMap[day]);

        const startDateLimit = fullSlotStart.clone().startOf('day');
        const endDateLimit = fullSlotEnd.clone().endOf('day');

        let recurrenceLimit: moment.Moment;
        if (endOption === 'on' && endDate) {
          const endFromSetting = momentZone.tz(endDate, zone).endOf('day');
          recurrenceLimit = moment.min(endFromSetting, endDateLimit);
        } else {
          recurrenceLimit = momentZone.tz(slotStart, zone).add(3, 'months').endOf('day');
          recurrenceLimit = moment.min(recurrenceLimit, endDateLimit);
        }

        // === DAILY recurrence ===
        if (repeatUnit === 'days') {
          // if (selectedIndexes.length === 0) return returnObj;

          let current = slotStart.clone();
          while (current.isSameOrBefore(recurrenceLimit, 'day')) {
            // && selectedIndexes.includes(current.day())
            if (current.isSameOrAfter(startDateLimit, 'day')) {
              const start = current.clone().hour(slotStart.hour()).minute(slotStart.minute());
              const end = start.clone().add(eventDuration);
              pushAvailableSlot(start, end);
            }
            current.add(repeatValue, 'days');
          }
        }

        // === WEEKLY recurrence ===
        else if (repeatUnit === 'weeks') {
          if (selectedIndexes.length === 0) return returnObj;

          let current = slotStart.clone().startOf('week');
          while (current.isSameOrBefore(recurrenceLimit, 'day')) {
            for (let i = 0; i < 7; i++) {
              const day = current.clone().add(i, 'days');
              if (day.isBefore(startDateLimit, 'day')) continue;
              if (day.isAfter(recurrenceLimit, 'day')) continue;

              if (selectedIndexes.includes(day.day())) {
                const start = day.clone().hour(slotStart.hour()).minute(slotStart.minute());
                const end = start.clone().add(eventDuration);
                pushAvailableSlot(start, end);
              }
            }
            current.add(repeatValue, 'weeks');
          }
        }

        // === MONTHLY recurrence ===
        else if (repeatUnit === 'months') {
          let current = slotStart.clone();
          while (current.isSameOrBefore(recurrenceLimit, 'day')) {
            if (current.isSameOrAfter(startDateLimit, 'day')) {
              const start = current.clone().hour(slotStart.hour()).minute(slotStart.minute());
              const end = start.clone().add(eventDuration);
              pushAvailableSlot(start, end);
            }
            current.add(repeatValue, 'months');
          }
        }

        let cursor = fullSlotStart.clone();
        while (cursor.isSameOrBefore(fullSlotEnd, 'day')) {
          const dateStr = cursor.format('YYYY/MM/DD');
          if (!pushedAvailableDates.has(dateStr)) {
            returnObj.unavailableDates.push(dateStr);
          }
          cursor.add(1, 'day');
        }
        return returnObj;
      }

      else {
        throw new Error(`Unsupported recurrence type: ${type}`);
      }
    }
    // Step 2: Walk through full requested date range and identify unavailable dates
    let cursor = fullSlotStart.clone();
    while (cursor.isSameOrBefore(fullSlotEnd, 'day')) {
      const dateStr = cursor.format('YYYY/MM/DD');
      if (!pushedAvailableDates.has(dateStr)) {
        returnObj.unavailableDates.push(dateStr);
      }
      cursor.add(1, 'day');
    }
    return returnObj;
  }



  public static async getTimeslotsBooked(
    businessId: string,
    serviceId: string,
    calendarId: string
  ): Promise<TimeslotBooked[]> {
    let bookingDocs: IBooking[];
    let filter = {} as any;
    filter = {
      status: { $in: [BookingStatus.Approved, BookingStatus.Pending, BookingStatus.GoogleEvent] },
      endDate: { $gte: new Date() },
    };
    // if (serviceId != null) {
    //   (filter as any).serviceId = serviceId;
    // }
    if (calendarId != null) {
      // (filter as any).$in = [{ calendarId: calendarId, businessId: businessId }];
      filter.$or = [
        { calendarId: calendarId, businessIdForGoogle: businessId },
        { businessId: businessId }
      ]
    }
    else {
      (filter as any).businessId = businessId;
    }
    try {
      bookingDocs = await BookingDbModel.BookingModel.find(filter)
        .sort({ startDate: -1 })
        .exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve bookings for business (${businessId})`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve bookings for business (${businessId})`
      );
    }

    const bookings = bookingDocs.map((bd) => {
      return new TimeslotBooked(
        bd.startDate,
        bd.endDate,
        bd.staffId,
        bd.startDate.getHours(),
        bd.endDate.getHours(),
        bd.serviceId,
        bd.eventType,
        calendarId,
        bd.status,
        // bd && bd.googleTimeZone
      );
    }).filter(Boolean);
    return bookings;
  }

  public static async getTimeslotsBookedForStaff(
    businessId: string,
    serviceId: string,
    calendarId: string,
    staffId: string
  ): Promise<TimeslotBooked[]> {
    let bookingDocs: IBooking[];
    let filter = {} as any;
    filter = {
      status: { $in: [BookingStatus.Approved, BookingStatus.Pending, BookingStatus.GoogleEvent] },
      endDate: { $gte: new Date() },
    };
    if (calendarId != null) {
      // (filter as any).$in = [{ calendarId: calendarId, businessId: businessId }];

      filter.$or = [
        { calendarId: calendarId, staffIdForGoogle: staffId },
        { businessId: businessId, staffId: staffId }
      ]
    }
    else {

      filter = { businessId: businessId, staffId: staffId }
    }
    try {
      bookingDocs = await BookingDbModel.BookingModel.find(filter)
        .sort({ startDate: -1 })
        .exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve bookings for business (${businessId})`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve bookings for business (${businessId})`
      );
    }

    const bookings = bookingDocs.map((bd) => {
      return new TimeslotBooked(
        bd.startDate,
        bd.endDate,
        bd.staffId,
        bd.startDate.getHours(),
        bd.endDate.getHours(),
        bd.serviceId,
        bd.eventType,
        calendarId,
        bd.status,
        // bd && bd.googleTimeZone
      );
    }).filter(Boolean);
    return bookings;
  }

  private static async generateTimeSlots(
    business: Business,
    service: BusinessService,
    selectedStaff: any,
    dateToCheck: dayjs.Dayjs,
    timeslotsAlreadyBooked: TimeslotBooked[]
  ) {
    let operatingHoursForSelectedDay: any = [];
    const day = dateToCheck.day();
    const strDateToCheck = dateToCheck.toDate().toDateString();
    const strNextDayToCheck = dateToCheck.add(1, "day").toDate().toDateString(); //UTC can fall in next day as well for Latin America
    if (
      selectedStaff &&
      selectedStaff.id &&
      !selectedStaff.isOperatingNonStop
    ) {
      //Use Staff Operating Hours
      const filteredStaffDays = selectedStaff?.staffHoursBlocks?.filter(block =>
        service.serviceDaysBlocks.some(day => block.startDayOfTheWeek === day.dayOfTheWeek)
      );
      operatingHoursForSelectedDay = filteredStaffDays?.filter(
        (x: any) => x.startDayOfTheWeek == day
      );
    }
    else if (service && service.id && service.serviceDaysBlocks.length > 0) {
      //Use service Operating Hours
      const filteredDays = business.businessHoursBlocks.filter(block =>
        service.serviceDaysBlocks.some(day => block.startDayOfTheWeek === day.dayOfTheWeek)
      );
      operatingHoursForSelectedDay = filteredDays?.filter(
        (x: any) => x.startDayOfTheWeek == day
      );
    }
    else if (service && service.id && service.eventSetting && service.eventSetting.startDate) {
      //Use service Operating Hours
      const formatEventServiceTime = DateUtils.formatDatesToWeekTimeBlock(service.eventSetting.startDate, service.eventSetting.endDate, business.timeZone.name)
      const filteredDays = formatEventServiceTime.filter(block =>
        service.serviceDaysBlocks.some(day => block.startDayOfTheWeek === day.dayOfTheWeek)
      );
      operatingHoursForSelectedDay = filteredDays?.filter(
        (x: any) => x.startDayOfTheWeek == day
      );
    }

    if (operatingHoursForSelectedDay && operatingHoursForSelectedDay.length == 0) {
      return [];
    }
    let timeslotsBookedForDay: any[] = [];
    timeslotsAlreadyBooked.forEach((bookedTimeslot: TimeslotBooked) => {
      //Check all bookings. Get bookings for current date being checked
      const bookedTime = bookedTimeslot.startDate.toDateString();
      if (bookedTime === strDateToCheck || bookedTime == strNextDayToCheck) {
        timeslotsBookedForDay.push(bookedTimeslot);
      }
    });
    const dateTimeNow = new Date();
    // const businessTimeNow = dateTimeNow.toLocaleString("en-US", {
    //   timeZone: business.timeZone!.name,
    //   hourCycle: "h23",
    // });

    const businessTimeNowDate = dateTimeNow; //Used to check if timeslot has passed
    const referencedEventService = await BusinessServicesService.getAllBusinesServices(business.id);
    return this.calculateTimeSlots(
      operatingHoursForSelectedDay,
      dateToCheck,
      timeslotsBookedForDay,
      businessTimeNowDate,
      service,
      business.timeZone!,
      selectedStaff,
      referencedEventService,
      business.id
    );
  }

  private static async calculateTimeSlots(
    operatingHoursForSelectedDay: any,
    dateToCheck: any,
    timeslotsBookedForDay: any,
    businessTimeNowDate: Date,
    serviceInfo: BusinessService,
    timeZone: TimeZone,
    staff: Staff,
    referencedEventService: any,
    businessId
  ) {

    let timeslots: any[] = [];
    console.log(businessTimeNowDate, timeZone.name);

    const now = momentZone.tz(businessTimeNowDate, timeZone.name);
    // const now = moment(businessTimeNowDate)
    console.log(now);

    operatingHoursForSelectedDay.forEach((b: BusinessHoursBlock) => {

      const dayFormat = 'YYYY-MM-DD';

      let availableWindows = [{
        start: momentZone.tz(dateToCheck.format(dayFormat), timeZone.name)
          .set({ hour: b.startHour, minute: b.startMinute, second: 0, millisecond: 0 }),
        end: momentZone.tz(dateToCheck.format(dayFormat), timeZone.name)
          .set({ hour: b.endHour, minute: b.endMinute, second: 0, millisecond: 0 })
      }];

      // ✅ Split window only for HARD BLOCK (capacity 1 + staff conflict)
      timeslotsBookedForDay.forEach(booking => {

        const bookedStart = momentZone.tz(booking.startDate, timeZone.name);
        const bookedEnd = momentZone.tz(booking.endDate, timeZone.name);

        availableWindows = availableWindows.flatMap(window => {

          const isOverlap =
            bookedStart.isBefore(window.end) &&
            bookedEnd.isAfter(window.start);

          if (!isOverlap) return [window];

          const isSameStaff =
            staff?.id &&
            booking.staffId &&
            booking.staffId.toString() === staff.id.toString();

          const isBothWithoutStaff =
            !staff?.id && !booking.staffId;

          const isHardBlock =
            serviceInfo.capacity === 1 &&
            (isSameStaff || isBothWithoutStaff);

          if (!isHardBlock) return [window];

          const newWindows = [];

          if (window.start.isBefore(bookedStart)) {
            newWindows.push({
              start: window.start.clone(),
              end: bookedStart.clone()
            });
          }

          if (window.end.isAfter(bookedEnd)) {
            newWindows.push({
              start: bookedEnd.clone(),
              end: window.end.clone()
            });
          }

          return newWindows;
        });
      });

      // ✅ Generate dynamic slots (NO FIXED GRID)
      availableWindows.forEach(window => {

        const serviceDuration = moment.duration(
          serviceInfo.duration,
          serviceInfo.durationUnit === DurationUnit.Minute ? 'minutes' : 'hours'
        );

        let slotStart = window.start.clone();

        while (true) {

          const slotEnd = slotStart.clone().add(serviceDuration);

          if (slotEnd.isAfter(window.end)) break;
          if (slotStart.isBefore(now)) {
            slotStart = slotStart.clone().add(serviceDuration);
            continue;
          }

          const isAvailable = this.checkIfTimeslotIsAvailable(
            timeslotsBookedForDay,
            slotStart.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
            slotEnd.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
            timeZone,
            staff,
            serviceInfo.capacity,
            serviceInfo,
            referencedEventService,
            businessId,
            operatingHoursForSelectedDay
          );

          if (isAvailable.check) {

            timeslots.push({
              display: `${slotStart.format('HH:mm')}-${slotEnd.format('HH:mm')}`,
              startDateTime: slotStart.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
              endDateTime: slotEnd.format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
              currentCapacity: isAvailable.capacity
            });

            // Normal grid move
            slotStart = slotStart.clone().add(serviceDuration);

          } else {

            // 🔥 SMART JUMP — find overlapping booking and jump to its end
            const overlappingBooking = timeslotsBookedForDay.find(booking => {
              const bookedStart = momentZone.tz(booking.startDate, timeZone.name);
              const bookedEnd = momentZone.tz(booking.endDate, timeZone.name);

              return (
                slotStart.isBefore(bookedEnd) &&
                slotEnd.isAfter(bookedStart)
              );
            });

            if (overlappingBooking) {
              slotStart = momentZone.tz(overlappingBooking.endDate, timeZone.name);
            } else {
              slotStart = slotStart.clone().add(serviceDuration);
            }
          }
        }

      });


    });

    // ✅ Ensure correct chronological order
    timeslots.sort((a, b) =>
      moment(a.startDateTime).valueOf() -
      moment(b.startDateTime).valueOf()
    );

    return timeslots;
  }


  //Check timeslots already booked for day and see if current timeslot overlaps
  public static checkIfTimeslotIsAvailable(
    timeslotUnavailableForDate: TimeslotBooked[],
    openingTime: Date,
    closingTime: Date,
    timeZone: TimeZone,
    selectedStaff: Staff,
    capacity: number,
    service: BusinessService, //Add service id and service capacity
    referencedEventService: any,
    businessId,
    businessHours: BusinessHoursBlock[]
  ) {
    openingTime = this.getTimeZoneOffset(timeZone!.name, openingTime, false);
    closingTime = this.getTimeZoneOffset(timeZone!.name, closingTime, false);
    let isTimeslotAvailable = {
      check: true,
      capacity: capacity || 1,
    };
    // 🔹 Cutoff time check
    if (service.cutOff != null && service.cutOffUnit != null) {
      // 🔹 Convert cutoff to milliseconds (hours or minutes)
      const cutOffMs =
        DurationUnit[service.cutOffUnit] === DurationUnit[1]
          ? service.cutOff * 60 * 60 * 1000 // hours → ms
          : service.cutOff * 60 * 1000;     // minutes → ms

      // 🔹 Current time in business timezone
      const now = new Date(
        new Date().toLocaleString("en-US", { timeZone: timeZone.name })
      );
      // 🔹 Convert openingTime to business timezone
      const openingTimeInTZ = new Date(
        openingTime.toLocaleString("en-US", { timeZone: timeZone.name })
      );
      // 🔹 Last allowed booking time = openingTime - cutoff
      const lastAllowedBookingTime = new Date(openingTimeInTZ.getTime() - cutOffMs);

      // ✅ Booking check
      if (now > lastAllowedBookingTime) {
        isTimeslotAvailable = { check: false, capacity: 0 }; // ❌ Too late
      } else {
        isTimeslotAvailable = { check: true, capacity: capacity }; // ✅ Allowed
      }
    }

    // / x.eventType !== 'google' || && x.serviceId === serviceId
    if (selectedStaff && selectedStaff.id) {
      timeslotUnavailableForDate = timeslotUnavailableForDate.filter(
        (x) => x.staffId === selectedStaff.id
      );
    }

    const isOverlapWithGoogle = timeslotUnavailableForDate.find(
      (book) => (
        ((book.startDate < closingTime && book.endDate > openingTime) ||
          (openingTime < book.endDate && closingTime > book.startDate)) && book.eventType === 'google'
      )
    )
    if (isOverlapWithGoogle) {
      isTimeslotAvailable = {
        check: false,
        capacity: 0,
      };
      return isTimeslotAvailable;
    }
    // 🔹 Cutoff time check
    let isConflictCheck = false;
    // block time if business service time overlap to event
    const staffId = selectedStaff ? selectedStaff.id : null;
    for (let element of referencedEventService) {
      const { eventSetting } = element;
      if (service.id !== element.id) {
        if (eventSetting.isStaffConflict && eventSetting.staffs.find(staff => (staff === staffId))) {
          isConflictCheck = true;
        } else if (eventSetting.isStaffConflict && !staffId && eventSetting.staffs.find(staff => (staff === businessId))) {
          isConflictCheck = true;
        }
        else if (eventSetting.isBusinessConflict) {
          isConflictCheck = true;
        }
        if (isConflictCheck) {
          const block = this.isOverlapWithRecurringEvent(
            eventSetting,
            openingTime,
            closingTime,
            timeZone,
          );
          if (block) {
            isTimeslotAvailable = { check: false, capacity: 0 };
          }
        }
      }
    }
    const bookingHasStaff = Boolean(selectedStaff?.id);
    let _fullBlock = false; // 🔹 for SAME STAFF, DIFFERENT SERVICE
    console.log(timeslotUnavailableForDate);

    /* 🔹 STEP 1: FIND ALL VALID OVERLAPPING BOOKINGS */
    const overlappingBookings = timeslotUnavailableForDate.filter((ts) => {
      const open = ts.startDate;
      const close = ts.endDate;

      const isOverlap = openingTime < close && closingTime > open;
      if (!isOverlap) return false;

      if (
        ts.status !== BookingStatus.Approved &&
        ts.status !== BookingStatus.Pending
      ) return false;

      const isTsWithStaff = Boolean(ts.staffId);

      /* 🔴 GOOGLE EVENT — only block without staff bookings */
      // if (ts.eventType === 'google') {
      //   return !bookingHasStaff;
      // }
      console.log(ts.serviceId !== service.id, !bookingHasStaff,
        !isTsWithStaff,
        ts.serviceId, service.id);

      /* 🔢 NO STAFF, DIFFERENT SERVICE — FULL BLOCK FOR OTHER SERVICE ONLY IF OVERLAP */
      if (
        !bookingHasStaff &&
        !isTsWithStaff &&
        ts.serviceId !== service.id
      ) {
        console.log('ca---');

        _fullBlock = true; // mark as fully blocked for other service
        return false; // exclude from seatsUsed for current service
      }

      /* 🔢 SAME STAFF, DIFFERENT SERVICE — FULL BLOCK FOR OTHER SERVICE ONLY IF OVERLAP */
      if (
        bookingHasStaff &&
        isTsWithStaff &&
        ts.staffId === selectedStaff.id &&
        ts.serviceId !== service.id
      ) {
        _fullBlock = true; // mark as fully blocked for other service
        return false; // exclude from seatsUsed for current service
      }



      /* 🟡 WITHOUT staff booking should NOT block WITH staff */
      if (!bookingHasStaff && isTsWithStaff) return false;

      /* 🔴 SAME STAFF DOUBLE BOOK (SAME SERVICE) */
      if (bookingHasStaff && ts.staffId === selectedStaff.id && ts.serviceId === service.id) {
        return true;
      }

      /* 🟢 DIFFERENT STAFF → NO CONFLICT */
      if (bookingHasStaff && isTsWithStaff && ts.staffId !== selectedStaff.id) {
        return false;
      }

      /* 🧠 BUSINESS CAPACITY SHARED POOL (no staff services) */
      return !isTsWithStaff;
    });
    /* 🔹 STEP 2: FULL BLOCK CHECK */
    if (_fullBlock) {
      return { check: false, capacity: 0 }; // different service, same staff → full block
    }
    /* 🔹 STEP 3: CAPACITY — only count bookings of current service */
    const totalCapacity = capacity ?? 1;
    const seatsUsed = overlappingBookings.filter(ts => ts.serviceId === service.id).length;
    const remainingCapacity = Math.max(0, totalCapacity - seatsUsed);

    /* 🔹 STEP 4: RESULT */
    isTimeslotAvailable = {
      check: remainingCapacity > 0,
      capacity: remainingCapacity,
    };

    return isTimeslotAvailable;

  }

  public static checkIfTimeslotIsAvailableV2(
    timeslotUnavailableForDate: TimeslotBooked[],
    openingTime: Date,
    closingTime: Date,
    timeZone: TimeZone,
    selectedStaff: Staff,
    capacity: number,
    serviceId: string //Add service id and service capacity
  ) {
    openingTime = this.getTimeZoneOffsetV2(timeZone!.name, openingTime, false);
    closingTime = this.getTimeZoneOffsetV2(timeZone!.name, closingTime, false);
    if (selectedStaff && selectedStaff.id) {
      timeslotUnavailableForDate = timeslotUnavailableForDate.filter(
        (x) => x.staffId === selectedStaff.id
      );
    }
    let isTimeslotAvailable = {
      check: true,
      capacity: capacity || 1,
    };
    const isOverlapWithGoogle = timeslotUnavailableForDate.find(
      (book) => (
        ((book.startDate < closingTime && book.endDate > openingTime) ||
          (openingTime < book.endDate && closingTime > book.startDate)) && book.eventType === 'google'
      )
    )
    if (isOverlapWithGoogle) {
      isTimeslotAvailable = {
        check: false,
        capacity: 0,
      };
      return isTimeslotAvailable;
    }
    const bookingHasStaff = Boolean(selectedStaff?.id);
    let _fullBlock = false; // 🔹 for SAME STAFF, DIFFERENT SERVICE

    /* 🔹 STEP 1: FIND ALL VALID OVERLAPPING BOOKINGS */
    const overlappingBookings = timeslotUnavailableForDate.filter((ts) => {
      const open = ts.startDate;
      const close = ts.endDate;

      const isOverlap = openingTime < close && closingTime > open;
      if (!isOverlap) return false;

      if (
        ts.status !== BookingStatus.Approved &&
        ts.status !== BookingStatus.Pending
      ) return false;

      const isTsWithStaff = Boolean(ts.staffId);

      /* 🔴 GOOGLE EVENT — only block without staff bookings */
      if (ts.eventType === 'google') {
        return !bookingHasStaff;
      }

      /* 🔢 SAME STAFF, DIFFERENT SERVICE — FULL BLOCK FOR OTHER SERVICE ONLY IF OVERLAP */
      if (
        bookingHasStaff &&
        isTsWithStaff &&
        ts.staffId === selectedStaff.id &&
        ts.serviceId !== serviceId
      ) {
        _fullBlock = true; // mark as fully blocked for other service
        return false; // exclude from seatsUsed for current service
      }

      /* 🔢 NO STAFF, DIFFERENT SERVICE — FULL BLOCK FOR OTHER SERVICE ONLY IF OVERLAP */
      if (
        !bookingHasStaff &&
        !isTsWithStaff &&
        ts.serviceId !== serviceId
      ) {
        _fullBlock = true; // mark as fully blocked for other service
        return false; // exclude from seatsUsed for current service
      }

      /* 🟡 WITHOUT staff booking should NOT block WITH staff */
      if (!bookingHasStaff && isTsWithStaff) return false;

      /* 🔴 SAME STAFF DOUBLE BOOK (SAME SERVICE) */
      if (bookingHasStaff && ts.staffId === selectedStaff.id && ts.serviceId === serviceId) {
        return true;
      }

      /* 🟢 DIFFERENT STAFF → NO CONFLICT */
      if (bookingHasStaff && isTsWithStaff && ts.staffId !== selectedStaff.id) {
        return false;
      }

      /* 🧠 BUSINESS CAPACITY SHARED POOL (no staff services) */
      return !isTsWithStaff;
    });
    /* 🔹 STEP 2: FULL BLOCK CHECK */
    if (_fullBlock) {
      return { check: false, capacity: 0 }; // different service, same staff → full block
    }
    /* 🔹 STEP 3: CAPACITY — only count bookings of current service */
    const totalCapacity = capacity ?? 1;
    const seatsUsed = overlappingBookings.filter(ts => ts.serviceId === serviceId).length;
    const remainingCapacity = Math.max(0, totalCapacity - seatsUsed);

    /* 🔹 STEP 4: RESULT */
    isTimeslotAvailable = {
      check: remainingCapacity > 0,
      capacity: remainingCapacity,
    };

    return isTimeslotAvailable;
  }

  public static getTimeZoneOffsetV2 = (
    timeZone: string,
    selectedDate: Date,
    convertToBusinessLocal: boolean
  ): Date => {
    const m = momentZone(selectedDate);
    return convertToBusinessLocal
      ? m.tz(timeZone, true).toDate()  // reinterpret same UTC as local
      : momentZone.tz(m.format(), timeZone).toDate(); // convert to zone
  };


  public static getTimeZoneOffset = (
    timeZone: string,
    selectedDate: Date,
    convertToBusinessLocal: boolean
  ): Date => {
    const now = momentZone(selectedDate);
    const businessDate = momentZone.tz(now, timeZone);
    const offsetMinutes = convertToBusinessLocal
      ? businessDate.utcOffset() - now.utcOffset()
      : now.utcOffset() - businessDate.utcOffset();
    const updatedDate = momentZone(selectedDate).add(offsetMinutes, 'minutes');
    return updatedDate.toDate();
  };


  public static isOverlapWithRecurringEvent(
    eventSetting,
    openingTime,
    closingTime,
    timeZone,
  ): boolean {
    const {
      eventType = [],
      startDate,
      endDate,
      customSetting,
    } = eventSetting;

    const type = eventType[0]?.toLowerCase();

    if (!startDate || !endDate || !type) {
      throw new Error('Missing required event setting fields.');
    }

    // Event's original start and end in event's timezone
    const originalStart = momentZone.tz(startDate, timeZone.name);
    const originalEnd = momentZone.tz(endDate, timeZone.name);
    const duration = originalEnd.diff(originalStart);

    // Define helper to check overlap
    const overlaps = (slotStart: any, slotEnd: any): boolean => {
      const slotStartUtc = slotStart.clone().utc(); // ✅ FIXED
      const slotEndUtc = slotEnd.clone().utc();     // ✅ FIXED
      return openingTime < slotEndUtc.toDate() && closingTime > slotStartUtc.toDate();
    };

    // Handle one-time (non-repeating) event
    if (type === 'doesnotrepeat') {
      if (overlaps(originalStart, originalEnd)) return true;
      return false;
    }

    // For recurring cases
    const repeatUntil = originalStart.clone().add(3, 'months');
    let currentStart = originalStart.clone();
    let currentEnd = originalEnd.clone();

    const originalWeekday = originalStart.day();
    const originalWeekOfMonth = Math.floor((originalStart.date() - 1) / 7) + 1;

    if (type === 'daily' || type === 'weekly' || type === 'monthly') {
      while (currentStart.isSameOrBefore(repeatUntil, 'day')) {
        if (overlaps(currentStart, currentEnd)) {
          return true;
        }

        if (type === 'daily') {
          currentStart.add(1, 'day');
          currentEnd.add(1, 'day');
        } else if (type === 'weekly') {
          currentStart.add(1, 'week');
          currentEnd.add(1, 'week');
        }
        else if (type === 'monthly') {
          const duration = currentEnd.diff(currentStart);

          // Use a temp date to manage the next month slot first
          const base = currentStart.clone(); // Save currentStart to preserve time
          const nextMonthStart = base.clone().add(1, 'month').startOf('month');
          const targetMonth = nextMonthStart.month();

          let count = 0;
          let candidate = nextMonthStart.clone();

          // Find N-th weekday of the month
          while (candidate.month() === targetMonth) {
            if (candidate.day() === originalWeekday) {
              count++;
              if (count === originalWeekOfMonth) break;
            }
            candidate.add(1, 'day');
          }

          if (count === originalWeekOfMonth) {
            // Apply original time from `base`
            currentStart = candidate.clone()
              .hour(base.hour())
              .minute(base.minute());
          } else {
            // fallback: last matching weekday of the month
            const fallback = nextMonthStart.clone().endOf('month');
            while (fallback.day() !== originalWeekday) {
              fallback.subtract(1, 'day');
            }
            currentStart = fallback.clone()
              .hour(base.hour())
              .minute(base.minute());
          }

          currentEnd = currentStart.clone().add(duration);
        }
      }
    }

    else if (type === 'custom' && customSetting) {
      const {
        repeatValue,
        repeatUnit,
        selectedDays = [],
        endOption,
        endDate,
      } = customSetting;

      if (!repeatUnit) return false;

      const selectedIndexes = selectedDays.map(day => weekdayMap[day]);

      // Limit by endDate or 3 months from original start
      const repeatWindowEnd = endDate
        ? momentZone.tz(endDate, timeZone.name).endOf('day')
        : originalStart.clone().add(3, 'months').endOf('day');

      let current = originalStart.clone();

      // DAILY recurrence
      if (repeatUnit === 'days') {
        // if (selectedIndexes.length === 0) return false;

        while (current.isSameOrBefore(repeatWindowEnd, 'day')) {
          if (selectedIndexes.includes(current.day())) {
            const currentEnd = current.clone().add(duration);
            if (overlaps(current, currentEnd)) return true;
          }
          current.add(repeatValue, 'days');
        }
      }

      // WEEKLY recurrence
      else if (repeatUnit === 'weeks') {
        if (selectedIndexes.length === 0) return false;

        while (current.isSameOrBefore(repeatWindowEnd, 'day')) {
          for (let i = 0; i < 7; i++) {
            const day = current.clone().add(i, 'days');
            if (day.isAfter(repeatWindowEnd, 'day')) break;

            if (selectedIndexes.includes(day.day())) {
              const end = day.clone().add(duration);
              if (overlaps(day, end)) return true;
            }
          }
          current.add(repeatValue, 'weeks');
        }
      }

      // MONTHLY recurrence
      else if (repeatUnit === 'months') {
        while (current.isSameOrBefore(repeatWindowEnd, 'day')) {
          const end = current.clone().add(duration);
          if (overlaps(current, end)) return true;

          current.add(repeatValue, 'months');
        }
      }
    }
    return false;
  }

}
