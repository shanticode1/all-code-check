const axios = require("axios");
import { BusinessesService } from "./businesses.service"
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error"
import { Logger } from "../logger"
import { GoogleTokenDbModel, IGoogleToken } from "../db-models/google-token.db-model"
import { DatabaseError } from "../errors/database.error"
import { BookingDbModel, IBooking } from "../db-models/booking.db-model";
import { BookingsService } from "./bookings.service";
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error";
import { Business } from "../types/business";
import { GoogleCalendarDbModel, IGoogleCalendarType } from "../db-models/google-calendar.db-model";
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model";
import { BookingStatus } from "../types/enums/booking.status";
import { Booking } from "../types/booking";
import { GoogleTokenValidator } from "../utils/google-token-validator";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { UserService } from "./users.service";
import { roles } from "../data/user.roles";
import { StaffService } from "./staff.service";
import { StaffDbModel } from "../db-models/staff.db-model";
import { Staff } from "../types/staff";
import { TimeSlotService } from "./time-slot-service";
import { DateUtils } from "../utils/date.utils";
const { google } = require('googleapis');
const { v4: uuidv4 } = require('uuid');

const activeResources = new Map<string, number>();
export abstract class GoogleService {

    public static async getTokenByCode(code, id, role) {
        // Getting code from the frontend
        try {
            // const businessDoc = await BusinessesService.getBusinessDocByIdV2(id);
            const userDoc = await UserService.getUserDocById(id, role);
            if (userDoc === null) {
                Logger.logger.warn(`User with email: '${id}' not exists`)
                throw new ResourceAlreadyExistsError(`User with email: '${id}' not exists`)
            }
            if (userDoc && userDoc.membershipTier === MembershipTier.Free) {
                Logger.logger.warn(`Only pro or plus user can access this service`)
                throw new DatabaseError(`Only pro or plus user can access this service`)
            }
            /*** Creating the google auth with Project credentials */

            let redirectUri = `${process.env.CALENDAR_WEBHOOK}/api/google/code/token`;
            /* ........for local run............. **/
            // let redirectUri = 'http://localhost:5320/api/google/code/token'

            const oauth2ClientToken = new google.auth.OAuth2(
                process.env.GOOGLE_CLIENT_ID,
                process.env.GOOGLE_CLIENT_SECRET,
                redirectUri // we can pass here redirect_url as well, but as we are doing it by the google login popup so its not required
            );
            /**
                ** Getting tokens from the code that was submitted from client side
                ** In the token object we will get multiple things like access_token, refresh_token, scope, id_token & expiry_date
             */
            const { tokens } = await oauth2ClientToken.getToken(code);
            if (tokens) {
                const { data }: any = await axios.get(
                    'https://www.googleapis.com/oauth2/v3/userinfo',
                    {
                        headers: { Authorization: `Bearer ${tokens.access_token}` },
                        method: 'get',
                    }
                );
                // save business google token info inside business table
                const userInfo = data;
                userDoc.googleToken = tokens;
                userDoc.googleToken = GoogleTokenDbModel.convertToDbModel(userDoc.googleToken)
                userDoc.gmail = userInfo.email
                userDoc.gPicture = userInfo.picture
                userDoc.gName = userInfo.name
                const calendarList = await this.getAddedGoogleCalendarsList(tokens.access_token);
                userDoc.googleCalendar = calendarList && calendarList.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
                await userDoc.save();
            }
            return;
        } catch (error) {
            await GoogleTokenValidator.setGlobalVariable(false);
            console.log("Error when get token by code", error)
        }
    }

    private static async saveNewUpdatedTokenByRefreshToken(id: string, role: number) {
        try {
            let userDoc;
            if (role === roles.Business) {
                userDoc = await BusinessesService.getBusinessDocByIdV2(id)

            } else if (role === roles.staff) {
                userDoc = await UserService.getUserDocById(id, role)
            }
            if (userDoc == null) {
                Logger.logger.warn(`Business ${id} doesn't exist`)
                throw new ReferencedResourceNotFoundError(`Business ${id} doesn't exist`)
            }
            let isUpdated = false;
            if (userDoc && userDoc.googleToken && userDoc.googleToken.expiry_date) {
                const givenExpireTimeStamp = userDoc.googleToken.expiry_date;
                const currentTimestamp = Date.now();
                if (givenExpireTimeStamp < currentTimestamp) {
                    const oauth2Client = new google.auth.OAuth2(
                        process.env.GOOGLE_CLIENT_ID,
                        process.env.GOOGLE_CLIENT_SECRET,
                        `${process.env.CALENDAR_WEBHOOK}/api/google/code/token`
                    );
                    await oauth2Client.setCredentials(userDoc?.googleToken);
                    const tokens: IGoogleToken = await new Promise((resolve, reject) => {
                        oauth2Client.refreshAccessToken((err, tokens) => {
                            if (err) {
                                reject(err);
                            } else {
                                resolve(tokens);
                            }
                        });
                    });
                    userDoc.googleToken = tokens;
                    userDoc.googleToken = GoogleTokenDbModel.convertToDbModel(userDoc.googleToken)
                    await userDoc.save();
                    isUpdated = true;
                }
            }
            return isUpdated;
        } catch (error) {
            console.error("while update new token:-",id)
            await GoogleTokenValidator.setGlobalVariable(false);
        }
    }

    public static async saveGoogleToken(business: Business): Promise<any> {
        try {
            const businessDoc = await BusinessesService.getByEmail(business.email)
            if (businessDoc == null) {
                Logger.logger.warn(`Business with email: '${business.email}' already exists`)
                throw new ResourceAlreadyExistsError(`Business with email: '${business.email}' already exists`)
            }
            if (business.googleToken != null && (
                business.googleToken.access_token != businessDoc.googleToken?.access_token ||
                business.googleToken.refresh_token != businessDoc.googleToken?.refresh_token ||
                business.googleToken.scope != businessDoc.googleToken?.scope ||
                business.googleToken.token_type != businessDoc.googleToken?.token_type ||
                business.googleToken.id_token != businessDoc.googleToken?.id_token ||
                business.googleToken.expiry_date != businessDoc.googleToken?.expiry_date
                // business.googleToken.syncEventToken != businessDoc.googleToken?.syncEventToken
            )) {
                businessDoc.googleToken = GoogleTokenDbModel.convertToDbModel(business.googleToken)
            }
            // save gmail when user login with gmail
            if (business.gmail != null && (
                business.gmail != businessDoc.gmail)) {
                businessDoc.gmail = business.gmail
            };
            if (business.gPicture !== null && (
                business.gPicture != businessDoc.gPicture)) {
                businessDoc.gPicture = business.gPicture
            }
            if (business.gName !== null && (
                business.gName != businessDoc.gName)) {
                businessDoc.gName = business.gName
            }
            // save google calendar into db by access-token
            if (business.googleToken && business.googleToken.access_token) {
                const calendarList = await this.getAddedGoogleCalendarsList(business.googleToken.access_token)
                businessDoc.googleCalendar = calendarList.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
            }
            await businessDoc.save()
            return 'Save token successfully';
        } catch (error) {
            Logger.logger.error("Failed to save tooken", error)
            throw new DatabaseError("Failed to save token")
        }
    }

    public static async postGoogleCalendarEvents(data, id: string, bookingDoc: IBooking, business: Business, referencedService, existingBooking: IBooking): Promise<any> {
        let businessDoc = await BusinessesService.getBusinessDocByIdV2(id);
        const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(businessDoc.id, roles.Business);
        if (isUpdated) {
            // update new token if expried
            businessDoc = await BusinessesService.getBusinessDocByIdV2(id);
        }
        let postEvent;
        if (businessDoc == null) {
            Logger.logger.warn(`Business ${id} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Business ${id} doesn't exist`)
        }
        else if (businessDoc && businessDoc.googleToken && businessDoc.googleToken.access_token) {
            const accessToken = businessDoc.googleToken.access_token;
            let calendarId;
            if (businessDoc && (businessDoc.googleCalendar != undefined || businessDoc.googleCalendar != null)) {
                const googleData = businessDoc.googleCalendar ? businessDoc.googleCalendar.find(dt => dt.status === 'enable') : null;
                calendarId = googleData ? googleData.calendarId : null;
                if (calendarId != null) {
                    try {
                        const OAuth2Client = new google.auth.OAuth2(
                            process.env.GOOGLE_CLIENT_ID,
                            process.env.GOOGLE_CLIENT_SECRET,
                            process.env.GOOGLE_REDIRECT_URI
                        );
                        OAuth2Client.setCredentials({
                            access_token: accessToken
                        });
                        // Initialize Google Calendar API
                        const calendar = google.calendar({
                            version: 'v3',
                            auth: OAuth2Client
                        })
                        if (existingBooking && existingBooking.googleEventId !== "" &&
                            (referencedService.type === 'group' || referencedService.type === 'event')) {
                            // Add new attendees as needed
                            const newAttendees = [
                                {
                                    email: bookingDoc.customer.email,
                                    responseStatus: "accepted",
                                },
                            ];
                            try {
                                const response = await calendar.events.get({
                                    calendarId: calendarId, // Replace 'primary' with the appropriate calendar ID if needed
                                    eventId: existingBooking.googleEventId
                                });
                                const existingAttendees = response.data.attendees || [];
                                const combinedAttendees = existingAttendees.concat(newAttendees);
                                postEvent = await calendar.events.patch({
                                    calendarId: calendarId, // Replace 'primary' with the appropriate calendar ID if needed
                                    eventId: existingBooking.googleEventId,
                                    resource: {
                                        attendees: combinedAttendees
                                    }
                                });
                            } catch (error) {
                                console.log('existing booking Error:', error.message);
                            }
                        } else {
                            // summary: `${referencedService.customer.name} ${bookingDoc.customer.surname}`,
                            const eventDetails = {
                                summary: `${bookingDoc.customer.name} ${bookingDoc.customer.surname} - ${referencedService.name}`,
                                location: data.location,
                                description: data.description,
                                start: {
                                    dateTime: data.startTime,
                                    timeZone: data.timeZone
                                },
                                end: {
                                    dateTime: data.endTime,
                                    timeZone: data.timeZone
                                },
                                organizer: { name: business.name, email: business.email },
                                attendees: [
                                    {
                                        email: bookingDoc.customer.email,
                                        responseStatus: "accepted",
                                    },
                                ],
                                conferenceData: referencedService.location === 'google-meet' ?
                                    {
                                        createRequest: {
                                            requestId: uuidv4(),
                                            conferenceSolutionKey: {
                                                type: 'hangoutsMeet'
                                            }
                                        }
                                    }
                                    : '',
                                // eventType: "workingLocation",
                                // customVariable: 'rezrva-event',
                                guestsCanSeeOtherGuests: false,
                                // status:"CONFIRMED"
                            };
                            postEvent = await calendar.events
                                .insert({
                                    calendarId: calendarId,
                                    conferenceDataVersion: 1,
                                    resource: eventDetails,
                                })
                        }
                        console.log('Event posted to goolge calendar:');
                        return postEvent.data;
                    } catch (error) {
                        console.log('failed while save event to google:', error);
                    }
                } else {
                    return;
                }
            }
        } else {
            return;
        }
    }

    public static async postStaffGoogleCalendarEvents(data, id: string, bookingDoc: IBooking, staff: Staff, business: Business, referencedService, existingBooking: IBooking): Promise<any> {
        let staffDoc = await StaffService.getStaffById(bookingDoc.staffId, bookingDoc.businessId);
        const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(staff.id, roles.staff);
        if (isUpdated) {
            // update new token if expried
            await BusinessesService.getBusinessDocByIdV2(id);
            staffDoc = await StaffService.getStaffById(bookingDoc.staffId, bookingDoc.businessId);
        }
        let postEvent;
        if (staffDoc == null) {
            Logger.logger.warn(`Business ${id} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Business ${id} doesn't exist`)
        } else if (staffDoc && staffDoc.googleToken && staffDoc.googleToken.access_token) {
            const accessToken = staffDoc.googleToken.access_token;
            let calendarId;
            if (staffDoc && (staffDoc.googleCalendar != undefined || staffDoc.googleCalendar != null)) {
                const googleData = staffDoc.googleCalendar ? staffDoc.googleCalendar.find(dt => dt.status === 'enable') : null;
                calendarId = googleData ? googleData.calendarId : null;
                if (calendarId != null) {
                    try {
                        const OAuth2Client = new google.auth.OAuth2(
                            process.env.GOOGLE_CLIENT_ID,
                            process.env.GOOGLE_CLIENT_SECRET,
                            process.env.GOOGLE_REDIRECT_URI
                        );
                        OAuth2Client.setCredentials({
                            access_token: accessToken
                        });
                        // Initialize Google Calendar API
                        const calendar = google.calendar({
                            version: 'v3',
                            auth: OAuth2Client
                        })
                        if (existingBooking && existingBooking.googleEventId !== "" &&
                            (referencedService.type === 'group' || referencedService.type === 'event')) {
                            // Add new attendees as needed
                            const newAttendees = [
                                {
                                    email: bookingDoc.customer.email,
                                    responseStatus: "accepted",
                                },
                            ];
                            try {
                                const response = await calendar.events.get({
                                    calendarId: calendarId, // Replace 'primary' with the appropriate calendar ID if needed
                                    eventId: existingBooking.googleEventId
                                });
                                const existingAttendees = response.data.attendees || [];
                                const combinedAttendees = existingAttendees.concat(newAttendees);
                                postEvent = await calendar.events.patch({
                                    calendarId: calendarId, // Replace 'primary' with the appropriate calendar ID if needed
                                    eventId: existingBooking.googleEventId,
                                    resource: {
                                        attendees: combinedAttendees
                                    }
                                });
                            } catch (error) {
                                console.log('existing booking Error:', error.message);
                            }
                        } else {
                            // summary: `${referencedService.customer.name} ${bookingDoc.customer.surname}`,
                            const eventDetails = {
                                summary: `${bookingDoc.customer.name} ${bookingDoc.customer.surname} - ${referencedService.name}`,
                                location: data.location,
                                description: data.description,
                                start: {
                                    dateTime: data.startTime,
                                    timeZone: data.timeZone
                                },
                                end: {
                                    dateTime: data.endTime,
                                    timeZone: data.timeZone
                                },
                                organizer: { name: business.name, email: business.email },
                                attendees: [
                                    {
                                        email: bookingDoc.customer.email,
                                        responseStatus: "accepted",
                                    },
                                ],
                                conferenceData: referencedService.location === 'google-meet' ?
                                    {
                                        createRequest: {
                                            requestId: uuidv4(),
                                            conferenceSolutionKey: {
                                                type: 'hangoutsMeet'
                                            }
                                        }
                                    }
                                    : '',
                                // eventType: "workingLocation",
                                // customVariable: 'rezrva-event',
                                guestsCanSeeOtherGuests: false,
                                // status:"CONFIRMED"
                            };
                            postEvent = await calendar.events
                                .insert({
                                    calendarId: calendarId,
                                    conferenceDataVersion: 1,
                                    resource: eventDetails,
                                })
                        }
                        console.log('Event posted to goolge calendar:');
                        return postEvent.data;
                    } catch (error) {
                        console.log('failed while save event to google:', error);
                    }
                } else {
                    return;
                }
            }
        } else {
            return;
        }
    }

    public static async registerGoogleCalendarWebhook(businessDoc, calendarId, isIdExist) {
        const OAuth2Client = new google.auth.OAuth2(
            process.env.GOOGLE_CLIENT_ID,
            process.env.GOOGLE_CLIENT_SECRET,
            process.env.GOOGLE_REDIRECT_URI
        );
        // Set the OAuth2 access token obtained from the logged-in user
        OAuth2Client.setCredentials({
            access_token: businessDoc.googleToken.access_token
        });
        // Initialize Google Calendar API
        const calendar = google.calendar({
            version: 'v3',
            auth: OAuth2Client
        })
        try {
            if (businessDoc && businessDoc.gEventWatchId && (isIdExist !== -1)) {
                try {
                    await calendar.channels.stop({
                        calendarId: businessDoc.googleCalendar[isIdExist].calendarId,
                        requestBody: {
                            id: businessDoc.gEventWatchId,
                            resourceId: businessDoc.gResourceId,
                        }
                    })
                } catch (error) {
                    console.log('stop webhook error:', error.message);
                }
            }
            const response = await calendar.events.watch({
                calendarId: calendarId,
                requestBody: {
                    id: uuidv4(),
                    type: 'web_hook',
                    address: `${process.env.CALENDAR_WEBHOOK}/api/google/webhook`,
                    params: {
                        ttl: '2592000', // Time to live for the watch Sets expiration to 1 month in seconds (30 days * 24 hours * 60 minutes * 60 seconds)
                        // orderBy: 'updated'
                    }
                },
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            console.log('Webhook registered:');
            const details = {
                watchId: response.data.id,
                gResourceId: response.data.resourceId,
                watchEventExpiry: response.data.expiration
            }
            return details;
        } catch (error) {
            console.error('Error registering webhook:', error);
            // throw error;
        }
    }

    public static async getAddedGoogleCalendarsList(accessToken) {
        try {
            const apiUrl = 'https://www.googleapis.com/calendar/v3/users/me/calendarList';
            const response = await axios.get(apiUrl, {
                headers: {
                    Authorization: `Bearer ${accessToken}`
                },
            });
            const calendars = response.data.items;
            if (calendars.length > 0) {
                const calendarDetails = await Promise.all(calendars.map(async (calendar) => {
                    if (calendar.accessRole === 'owner') {
                        return {
                            calendarId: calendar.id,
                            status: 'disable',
                            name: calendar.summary,
                        };
                    }
                }));
                const filteredCalendarDetails = calendarDetails.filter(detail => detail !== undefined);
                return filteredCalendarDetails
            } else {
                return []
            }
        } catch (error) {
            Logger.logger.error(`Error fetching calendars: ${error}`)
            console.error('Error fetching calendars:');
        }
    };

    public static async getGoogleCalendars(requestParams): Promise<any> {
        try {
            const businessDoc = await BusinessesService.getBusinessDocByGmailId(requestParams.gmail);
            if (businessDoc == null) {
                Logger.logger.warn(`Business ${requestParams.gmail} doesn't exist`)
                throw new ReferencedResourceNotFoundError(`Business ${requestParams.gmail} doesn't exist`)
            }
            return businessDoc.googleCalendar;
        } catch (error) {
            console.log('error while get google Calendars  :', error);
        }
    }

    public static async updateConfig(payload): Promise<any> {
        try {
            if (payload.role === roles.Business) {
                return await this.updateBusinessConfig(payload)
            } else if (payload.role === roles.staff) {
                return await this.updateStaffConfig(payload)
            }
        } catch (error) {
            console.log('error while save initial Event:', error.message);
            throw new DatabaseError(`Failed to save events in Google Calendar due to an invalid token for the calendar ID ('${payload.calendarId}').`)
        }
    }

    public static async updateBusinessConfig(payload): Promise<any> {
        try {
            let businessDoc = await BusinessesService.getBusinessDocByEmailId(payload.email);
            if (businessDoc == null) {
                Logger.logger.warn(`Business ${payload.gmail} doesn't exist`)
                throw new ReferencedResourceNotFoundError(`Business ${payload.gmail} doesn't exist`)
            }
            if (payload.isConflict != null && (
                payload.isConflict != businessDoc.isConflict)) {
                businessDoc.isConflict = payload.isConflict
            };

            let res;
            // save select id Event into db
            if (payload.calendarId && businessDoc.googleToken.access_token !== null || businessDoc.googleToken.access_token != undefined || businessDoc.googleToken.access_token == '') {
                // check token  is expired or not 
                const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(businessDoc.id, payload.role);
                if (isUpdated) {
                    businessDoc = await BusinessesService.getBusinessDocByEmailId(payload.email);
                }
                businessDoc.googleCalendar = businessDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
                const isExistIndex = businessDoc.googleCalendar.findIndex(item => item.status === 'enable');
                if (isExistIndex !== -1 && (businessDoc.googleCalendar[isExistIndex].calendarId !== payload.calendarId)) {
                    res = await this.insertSelectedCalendarIdEvents(payload.calendarId, businessDoc, payload.role);
                    businessDoc.syncEventToken = res;
                    const webhookDetail = await this.registerGoogleCalendarWebhook(businessDoc, payload.calendarId, isExistIndex)
                    businessDoc.gEventWatchId = webhookDetail.watchId;
                    businessDoc.gResourceId = webhookDetail.gResourceId;
                    businessDoc.watchEventExpiry = webhookDetail.watchEventExpiry;

                } else if (isExistIndex === -1) {
                    res = await this.insertSelectedCalendarIdEvents(payload.calendarId, businessDoc, payload.role);
                    businessDoc.syncEventToken = res;
                    const webhookDetail = await this.registerGoogleCalendarWebhook(businessDoc, payload.calendarId, isExistIndex)
                    businessDoc.gEventWatchId = webhookDetail.watchId;
                    businessDoc.gResourceId = webhookDetail.gResourceId;
                    businessDoc.watchEventExpiry = webhookDetail.watchEventExpiry;
                }
                if (payload.calendarId != null && (
                    payload.calendarId != undefined)) {
                    // // find id and delete 
                    // businessDoc.googleCalendar[isExistIndex].calendarId
                    if (isExistIndex !== -1 && (businessDoc.googleCalendar[isExistIndex].calendarId !== payload.calendarId)) {
                        await BookingDbModel.BookingModel.deleteMany({ calendarId: businessDoc.googleCalendar[isExistIndex].calendarId, businessIdForGoogle: businessDoc.id });
                        businessDoc.googleCalendar[isExistIndex].status = 'disable';
                        delete businessDoc.googleCalendar[isExistIndex].lastLoggedInTime;
                        businessDoc.googleCalendar = businessDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
                        await businessDoc.save();
                    }
                    const index = businessDoc.googleCalendar.findIndex(item => item.calendarId === payload.calendarId);
                    if (index !== -1) {
                        // Update the value of the specified key
                        businessDoc.googleCalendar[index]['status'] = 'enable';
                        businessDoc.googleCalendar[index]['lastLoggedInTime'] = new Date();
                    }
                }
            }
            await businessDoc.save();
            return res;
        } catch (error) {
            console.log('error while save initial Event:', error.message);
            throw new DatabaseError(`Failed to save events in Google Calendar due to an invalid token for the calendar ID ('${payload.calendarId}').`)
        }
    }


    public static async updateStaffConfig(payload): Promise<any> {
        try {
            let staffDoc = await StaffService.getStaffDoc(payload.id);
            if (staffDoc == null) {
                Logger.logger.warn(`Staff ${payload.gmail} doesn't exist`)
                throw new ReferencedResourceNotFoundError(`staff ${payload.gmail} doesn't exist`)
            }
            if (payload.isConflict != null && (
                payload.isConflict != staffDoc.isConflict)) {
                staffDoc.isConflict = payload.isConflict
            };

            let res;
            // save select id Event into db
            if (payload.calendarId && staffDoc.googleToken.access_token !== null || staffDoc.googleToken.access_token != undefined || staffDoc.googleToken.access_token == '') {
                // check token  is expired or not 
                const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(payload.id, payload.role);
                if (isUpdated) {
                    staffDoc = await StaffService.getStaffDoc(payload.id);
                }
                staffDoc.googleCalendar = staffDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
                const isExistIndex = staffDoc.googleCalendar.findIndex(item => item.status === 'enable');
                if (isExistIndex !== -1 && (staffDoc.googleCalendar[isExistIndex].calendarId !== payload.calendarId)) {
                    res = await this.insertSelectedCalendarIdEvents(payload.calendarId, staffDoc, payload.role);
                    staffDoc.syncEventToken = res;
                    const webhookDetail = await this.registerGoogleCalendarWebhook(staffDoc, payload.calendarId, isExistIndex)
                    staffDoc.gEventWatchId = webhookDetail.watchId;
                    staffDoc.gResourceId = webhookDetail.gResourceId;
                    staffDoc.watchEventExpiry = webhookDetail.watchEventExpiry;

                } else if (isExistIndex === -1) {
                    res = await this.insertSelectedCalendarIdEvents(payload.calendarId, staffDoc, payload.role);
                    staffDoc.syncEventToken = res;
                    const webhookDetail = await this.registerGoogleCalendarWebhook(staffDoc, payload.calendarId, isExistIndex)
                    staffDoc.gEventWatchId = webhookDetail.watchId;
                    staffDoc.gResourceId = webhookDetail.gResourceId;
                    staffDoc.watchEventExpiry = webhookDetail.watchEventExpiry;
                }
                if (payload.calendarId != null && (
                    payload.calendarId != undefined)) {
                    // // find id and delete 
                    // businessDoc.googleCalendar[isExistIndex].calendarId
                    if (isExistIndex !== -1 && (staffDoc.googleCalendar[isExistIndex].calendarId !== payload.calendarId)) {
                        await BookingDbModel.BookingModel.deleteMany({ calendarId: staffDoc.googleCalendar[isExistIndex].calendarId, staffIdForGoogle: staffDoc.id });
                        staffDoc.googleCalendar[isExistIndex].status = 'disable';
                        delete staffDoc.googleCalendar[isExistIndex].lastLoggedInTime;
                        staffDoc.googleCalendar = staffDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
                        await staffDoc.save();
                    }
                    const index = staffDoc.googleCalendar.findIndex(item => item.calendarId === payload.calendarId);
                    if (index !== -1) {
                        // Update the value of the specified key
                        staffDoc.googleCalendar[index]['status'] = 'enable';
                        staffDoc.googleCalendar[index]['lastLoggedInTime'] = new Date();
                    }
                }
            }
            await staffDoc.save();
            return res;
        } catch (error) {
            console.log('error while save initial Event:', error.message);
            throw new DatabaseError(`Failed to save events in Google Calendar due to an invalid token for the calendar ID ('${payload.calendarId}').`)
        }
    }

    private static async processGoogleEvents(googleEvent: any, calendarId: string, todayDate: any, oneYearFromToday: any, businessDoc: IBusiness, role: number) {
        let businessId = '';
        let staffId = '';
        googleEvent.forEach(async (dt) => {
            const eventStartDate = new Date(dt.start.dateTime);
            if ((dt.status === 'confirmed') &&
                (eventStartDate >= todayDate) &&
                (eventStartDate <= oneYearFromToday)) {
                const sDate = dt.start.dateTime || dt.start.date;
                const eDate = dt.end.dateTime || dt.end.date;
                const googleTimeZone = dt.start.timeZone;
                let isExist = null;
                if (role == roles.Business) {
                    businessId = businessDoc.id;
                    isExist = await BookingDbModel.BookingModel.findOne({
                        googleEventId: dt.id,
                        // eventType: 'google',
                        // businessIdForGoogle: businessId,
                    });
                }
                if (role == roles.staff) {
                    staffId = businessDoc.id;
                    isExist = await BookingDbModel.BookingModel.findOne({
                        googleEventId: dt.id,
                        // eventType: 'google',
                        staffIdForGoogle: staffId,
                    });
                }
                if (!isExist) {
                    const status = dt.status === 'confirmed' ? BookingStatus.GoogleEvent : 0;
                    // const bookingDoc = await BookingDbModel.BookingModel.find({
                    //     startDate: sDate,
                    //     endDate: eDate
                    // });
                    //Save as UTC
                    const gStartDate = TimeSlotService.getTimeZoneOffsetV2(
                        googleTimeZone,
                        sDate,
                        false
                    )

                    const gEndDate = TimeSlotService.getTimeZoneOffsetV2(
                        googleTimeZone,
                        eDate,
                        false
                    )

                    const friendlyId = await BookingsService.generateRandomFriendlyId();
                    const bookingData = {
                        businessIdForGoogle: businessId,
                        // staffId: staffId,
                        staffIdForGoogle: staffId,
                        friendlyId: friendlyId,
                        startDate: gStartDate,
                        endDate: gEndDate,
                        googleTimeZone: googleTimeZone,
                        status: status,
                        serviceSnapshotId: null,
                        eventType: 'google',
                        googleEventId: dt.id,
                        calendarId: calendarId,
                        title: dt.summary,
                        googleMeetLink: dt.hangoutLink,
                        creator: dt.creator.email,
                        organizer: dt.organizer.email,
                        attendees: dt.attendees
                    };
                    await BookingDbModel.BookingModel.create(bookingData);
                }

            }
        })
        return 'done';
    }

    private static async processGoogleEventsOfStaff(googleEvent: any, calendarId: string, todayDate: any, oneYearFromToday: any, businessDoc: IBusiness, role: number) {
        let businessId = '';
        let staffId = '';
        googleEvent.forEach(async (dt) => {
            const eventStartDate = new Date(dt.start.dateTime);
            if ((dt.status === 'confirmed') &&
                (eventStartDate >= todayDate) &&
                (eventStartDate <= oneYearFromToday)) {
                const sDate = dt.start.dateTime || dt.start.date;
                const eDate = dt.end.dateTime || dt.end.date;
                const isExist = await BookingDbModel.BookingModel.findOne({
                    googleEventId: dt.id,
                    // eventType: 'google',
                    businessIdForGoogle: businessDoc.id,
                });
                if (!isExist) {
                    const status = dt.status === 'confirmed' ? BookingStatus.GoogleEvent : 0;
                    // const bookingDoc = await BookingDbModel.BookingModel.find({
                    //     startDate: sDate,
                    //     endDate: eDate
                    // });
                    const friendlyId = await BookingsService.generateRandomFriendlyId();
                    if (role == roles.Business) {
                        businessId = businessDoc.id;
                    }
                    if (role == roles.staff) {
                        staffId = businessDoc.id;
                    }
                    const bookingData = {
                        businessId: businessId,
                        staffId: staffId,
                        friendlyId: friendlyId,
                        startDate: sDate,
                        endDate: eDate,
                        status: status,
                        serviceSnapshotId: null,
                        eventType: 'google',
                        googleEventId: dt.id,
                        calendarId: calendarId,
                        title: dt.summary,
                        googleMeetLink: dt.hangoutLink,
                        creator: dt.creator.email,
                        organizer: dt.organizer.email,
                        attendees: dt.attendees
                    };
                    await BookingDbModel.BookingModel.create(bookingData);
                }

            }
        })
        return 'done';
    }

    public static async insertSelectedCalendarIdEvents(calendarId, businessDoc, role) {
        try {
            const OAuth2Client = new google.auth.OAuth2(
                process.env.GOOGLE_CLIENT_ID,
                process.env.GOOGLE_CLIENT_SECRET,
                process.env.GOOGLE_REDIRECT_URI
            );
            // Set the OAuth2 access token obtained from the logged-in user
            OAuth2Client.setCredentials({
                access_token: businessDoc.googleToken.access_token
            });
            // Initialize Google Calendar API
            const calendar = google.calendar({
                version: 'v3',
                auth: OAuth2Client
            })
            // const todayDate = new Date();
            // const oneYearFromToday = new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate() + 365);
            // timeMin: todayDate.toISOString(),
            // timeMax: oneYearFromToday.toISOString(),

            const { timeMin, timeMax } = DateUtils.getNextThreeMonthRange();

            return await new Promise(async (resolve, reject) => {
                try {
                    let nextPageToken = null;
                    let response;
                    do {
                        response = await calendar.events.list({
                            calendarId: calendarId,
                            maxResults: 50,
                            singleEvents: true,
                            timeMin: timeMin.toISOString(),
                            timeMax: timeMax.toISOString(),
                            pageToken: nextPageToken,
                            fields: 'nextPageToken,nextSyncToken,items(id,start/dateTime,start/timeZone,start/date,end/dateTime,end/date,end/timeZone,status,summary,hangoutLink,creator/email,organizer/email,attendees)'
                        });
                        const events = response.data.items;
                        nextPageToken = response.data.nextPageToken;
                        if (events.length > 0) {
                            this.processGoogleEvents(events, calendarId, timeMin, timeMax, businessDoc, role);
                        }
                    } while (nextPageToken);

                    // Get the next sync token
                    const gSyncToken = response.data.nextSyncToken;
                    // Resolve the promise with the next sync token
                    resolve(gSyncToken);
                } catch (error) {
                    // Reject the promise if there's an error
                    // reject(error);
                    console.log('REJECT key');

                }
            });

        } catch (error) {
            console.log('error while first time get Event  :', error.statusCode);
            Logger.logger.error(`Failed to save first time events  (id: '${calendarId}')`, error)
            // throw new DatabaseError(`Failed to save  events (id: '${calendarId}')`)
        }
    }

    private static async processWebhookFetchEvents(googleEvent: any, calendarId: string, todayDate: any, oneYearFromToday: any, businessDoc: IBusiness) {
        googleEvent.forEach(async (dt) => {
            if (dt.start && (dt.start.dateTime || dt.start.date)) {
                const sDate = dt.start.dateTime || dt.start.date;
                const googleTimeZone = dt.start.timeZone;
                const eventStartDate = new Date(sDate);
                if ((dt.status === 'confirmed') &&
                    (eventStartDate >= todayDate) &&
                    (eventStartDate <= oneYearFromToday)) {
                    const status = dt.status === 'confirmed' ? BookingStatus.GoogleEvent : 0;
                    const isExist: IBooking = await BookingDbModel.BookingModel.findOne({
                        googleEventId: dt.id,
                        // eventType: 'google',
                        // businessIdForGoogle: businessDoc.id,
                    });
                    const friendlyId = isExist ? isExist.friendlyId : await BookingsService.generateRandomFriendlyId();
                    //Save as UTC
                    const gStartDate = TimeSlotService.getTimeZoneOffsetV2(
                        googleTimeZone,
                        dt.start.dateTime || dt.start.date,
                        false
                    )

                    const gEndDate = TimeSlotService.getTimeZoneOffsetV2(
                        googleTimeZone,
                        dt.end.dateTime || dt.end.date,
                        false
                    )
                    const bookingData = {
                        businessIdForGoogle: businessDoc.id,
                        friendlyId: friendlyId,
                        startDate: gStartDate,
                        endDate: gEndDate,
                        googleTimeZone: googleTimeZone,
                        status: status,
                        serviceSnapshotId: null,
                        eventType: 'google',
                        googleEventId: dt.id,
                        calendarId: calendarId,
                        title: dt.summary,
                        googleMeetLink: dt.hangoutLink,
                        creator: dt.creator.email,
                        organizer: dt.organizer.email,
                        attendees: dt.attendees
                    };
                    // const isExist = bookingList.find((value) => value.googleEventId === dt.id)
                    console.log(isExist ? isExist.id : '');

                    if (!isExist) {
                        // Create new booking
                        await BookingDbModel.BookingModel.create(bookingData);
                    }
                    else {

                    }
                }
                else if (dt.status === 'cancelled') {
                    await BookingDbModel.BookingModel.deleteOne({ googleEventId: dt.id, eventType: 'google', businessIdForGoogle: businessDoc.id });
                }
            } else if (dt.status === 'cancelled') {
                await BookingDbModel.BookingModel.deleteOne({ googleEventId: dt.id, eventType: 'google', businessIdForGoogle: businessDoc.id });
            }
        })
    }

    public static async fullSync(calendarId: string, oauth2Client: any, businessDoc: IBusiness) {
        let newSyncToken = '';
        // const todayDate = new Date();
        // const oneYearFromToday = new Date(todayDate.getFullYear() + 1, todayDate.getMonth(), todayDate.getDate());
        const { timeMin, timeMax } = DateUtils.getNextThreeMonthRange();

        console.log('🔄 Performing full sync...');
        const calendar = google.calendar({
            version: 'v3',
            auth: oauth2Client,
        });

        const processedEventIds = new Set<string>();
        let pageToken: string | undefined;
        try {
            do {
                const res = await calendar.events.list({
                    calendarId,
                    auth: oauth2Client,
                    showDeleted: true,
                    singleEvents: true,
                    timeMin: timeMin.toISOString(),
                    timeMax: timeMax.toISOString(),
                    maxResults: 50,
                    pageToken
                });

                const events = res.data.items || [];
                newSyncToken = res.data.nextSyncToken || newSyncToken;
                pageToken = res.data.nextPageToken;

                console.log(`📦 Processing ${events.length} events (page batch)...`);

                // Filter out duplicates (in case of reappearing event IDs)
                const uniqueEvents = events.filter(e => {
                    if (processedEventIds.has(e.id)) return false;
                    processedEventIds.add(e.id);
                    return true;
                });

                if (uniqueEvents.length > 0) {
                    await this.processWebhookFetchEvents(uniqueEvents, calendarId, timeMin, timeMax, businessDoc);
                }
            } while (pageToken);

            console.log(`✅ Full sync completed. Total unique events processed: ${processedEventIds.size}`);

            if (newSyncToken) {
                console.log('💾 Saved new sync token.');
            }

            return newSyncToken;
        } catch (error: any) {
            console.error('❌ Error during full sync:', error.message || error);
            Logger.logger.error(`Full sync failed for calendarId: ${calendarId}, error: ${error.message}`);
            return '';
        }
    }

    public static async insertWebhookSyncCalendarIdEvents(calendarId: string, businessDoc: any) {
        let OAuth2Client = null;
        try {
            OAuth2Client = new google.auth.OAuth2(
                process.env.GOOGLE_CLIENT_ID,
                process.env.GOOGLE_CLIENT_SECRET,
                process.env.GOOGLE_REDIRECT_URI
            );

            OAuth2Client.setCredentials({
                access_token: businessDoc.googleToken.access_token,
            });

            const calendar = google.calendar({ version: "v3", auth: OAuth2Client });

            // const todayDate = new Date();
            // const oneYearFromToday = new Date(todayDate);
            // oneYearFromToday.setFullYear(todayDate.getFullYear() + 1);

            const { timeMin, timeMax } = DateUtils.getNextThreeMonthRange();

            let nextPageToken: string | null = null;
            let nextSyncToken: string | null = null;

            do {
                const response = await calendar.events.list({
                    calendarId,
                    maxResults: 50,
                    singleEvents: true,
                    // timeMin: timeMin.toISOString(),
                    // timeMax: timeMax.toISOString(),
                    syncToken: businessDoc.syncEventToken,
                    pageToken: nextPageToken ?? undefined,
                    fields:
                        "nextPageToken,nextSyncToken,items(id,start/dateTime,start/date,start/timeZone,end/dateTime,end/date,end/timeZone,status,summary,hangoutLink,creator/email,organizer/email,attendees)",
                });

                const events = response.data.items || [];
                nextPageToken = response.data.nextPageToken || null;
                nextSyncToken = response.data.nextSyncToken || nextSyncToken;

                Logger.logger.info(`Fetched ${events.length} events from calendar ${calendarId}`);
                if (events.length > 0) {
                    try {
                        // Ensure this call is awaited (if it returns a Promise)
                        await this.processWebhookFetchEvents(events, calendarId, timeMin, timeMax, businessDoc);
                    } catch (processError) {
                        Logger.logger.error(
                            `Error processing fetched events for businessId ${businessDoc.id}: ${processError.message}`
                        );
                    }
                }
            } while (nextPageToken);
            return nextSyncToken;
        } catch (error: any) {
            const errorMsg = error.message || "Unknown error";
            if (errorMsg.includes("Sync token is no longer valid")) {
                console.warn(`⚠️ Sync token expired for ${calendarId}, performing full sync.`);
                return await this.fullSync(calendarId, OAuth2Client, businessDoc);
            }
            Logger.logger.error(`❌ Failed to sync events (businessId: ${businessDoc.id}) - ${errorMsg}`);
            return null;
        }
    }


    // public static async updateAndSaveEvent(calendarId: string, eventWatchId: string, resourceId: string) {
    //     // Check db if another process is already running
    //     let businessDocs = await BusinessesService.getBusinessByCalendarId(resourceId, eventWatchId);
    //     console.log(businessDocs.length, '---businessDocs');
    //     businessDocs.forEach(async (businessDoc) => {
    //         Logger.logger.info(`email: ${businessDoc.email}`);
    //         const isProcessRunningIndex = businessDoc && businessDoc.googleCalendar.findIndex(value => value.calendarId === calendarId);
    //         try {
    //             if (businessDoc && businessDoc.googleCalendar) {
    //                 // if (isProcessRunningIndex !== -1 && businessDoc.googleCalendar[isProcessRunningIndex].isProcessing) {
    //                 //     return;
    //                 // } else if (isProcessRunningIndex !== -1 && !businessDoc.googleCalendar[isProcessRunningIndex].isProcessing) {
    //                 //     businessDoc.googleCalendar[isProcessRunningIndex].isProcessing = true;
    //                 //     businessDoc.googleCalendar = businessDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
    //                 //     await businessDoc.save();
    //                 // }
    //                 businessDoc.googleCalendar = businessDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh))
    //                 await businessDoc.save();
    //             }
    //             if (businessDoc) {
    //                 console.log(businessDoc.id, '-businessDoc.id');
    //                 const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(businessDoc.id, roles.Business);
    //                 if (isUpdated) {
    //                     businessDoc = await BusinessesService.getBusinessDocByIdV2(businessDoc.id);
    //                 }
    //                 if (businessDoc.googleToken && (businessDoc.googleToken.access_token !== null || businessDoc.googleToken.access_token != undefined || businessDoc.googleToken.access_token == '')) {
    //                     if (businessDoc.syncEventToken) {
    //                         console.log('inside if');
    //                         const newSyncToken: any = await this.insertWebhookSyncCalendarIdEvents(calendarId, businessDoc)
    //                         businessDoc.syncEventToken = newSyncToken;
    //                         await businessDoc.save();
    //                     }
    //                 }
    //             }
    //             return;
    //         } catch (error) {
    //             console.error('Error updating and saving event:', error);

    //         } finally {
    //             // Reset the db calendar Flag when the process is finished
    //             if (businessDoc && isProcessRunningIndex !== -1) {
    //                 businessDoc.googleCalendar[isProcessRunningIndex].isProcessing = false;
    //                 businessDoc.googleCalendar = businessDoc.googleCalendar.map(bh => GoogleCalendarDbModel.convertToDbModel(bh));
    //                 await businessDoc.save();
    //             }
    //         }
    //     });

    // }

    public static async updateAndSaveEvent(
        calendarId: string,
        eventWatchId: string,
        resourceId: string
    ) {
        const now = Date.now();
        // 🧠 If webhook was already triggered for this resource recently, ignore it
        if (activeResources.has(resourceId)) {
            const lastTime = activeResources.get(resourceId)!;
            if (now - lastTime < 60_000) {
                console.log(`⏭️ Duplicate webhook ignored for resourceId: ${resourceId}`);
                return; // Ignore duplicate call within 1 minute
            }
        }

        // ✅ Mark this resource as being processed
        activeResources.set(resourceId, now);

        try {
            Logger.logger.info(`🚀 Processing webhook for resourceId: ${resourceId}`);

            const businessDocs = await BusinessesService.getBusinessByCalendarId(resourceId, eventWatchId);
            Logger.logger.info(`${businessDocs.length} businessDocs found`);

            for (let businessDoc of businessDocs) {
                Logger.logger.info(`email: ${businessDoc.email}`);

                const isProcessRunningIndex = businessDoc.googleCalendar.findIndex(
                    (val) => val.calendarId === calendarId
                );

                if (isProcessRunningIndex === -1) continue;

                // Mark processing
                businessDoc.googleCalendar[isProcessRunningIndex].isProcessing = true;
                businessDoc.googleCalendar = businessDoc.googleCalendar.map((bh) =>
                    GoogleCalendarDbModel.convertToDbModel(bh)
                );
                await businessDoc.save();

                try {
                    const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(businessDoc.id, roles.Business);

                    if (isUpdated) {
                        businessDoc = await BusinessesService.getBusinessDocByIdV2(businessDoc.id);
                    }

                    const hasValidToken =
                        businessDoc.googleToken &&
                        businessDoc.googleToken.access_token &&
                        businessDoc.googleToken.access_token !== "";

                    if (hasValidToken && businessDoc.syncEventToken) {
                        Logger.logger.info("🔄 Syncing events...");
                        const newSyncToken: any = await this.insertWebhookSyncCalendarIdEvents(calendarId, businessDoc);
                        businessDoc.syncEventToken = newSyncToken;
                        await businessDoc.save();
                    }
                } catch (error) {
                    console.error("❌ Error during event update:", error);
                } finally {
                    // Reset processing flag
                    businessDoc.googleCalendar[isProcessRunningIndex].isProcessing = false;
                    businessDoc.googleCalendar = businessDoc.googleCalendar.map((bh) =>
                        GoogleCalendarDbModel.convertToDbModel(bh)
                    );
                    await businessDoc.save();
                }
            }
        } catch (error) {
            console.error("❌ Error in updateAndSaveEvent:", error);
        } finally {
            // 🧹 Clean up resource entry after processing
            activeResources.delete(resourceId);

            // Optional: clean stale entries older than 5 min
            const FIVE_MIN = 300_000;
            for (const [key, timestamp] of activeResources.entries()) {
                if (now - timestamp > FIVE_MIN) activeResources.delete(key);
            }
        }
    }

    public static async deleteGoogleToken(id: string, roleId: number) {
        let calendarId;
        let businessDoc = await BusinessesService.getBusinessDocByIdV2(id)
        if (businessDoc == null) {
            Logger.logger.warn(
                `Business dose not exists with this id ${id}`
            );
            throw new ReferencedResourceNotFoundError(
                `Business dose not exists with this id ${id}`
            );
        }
        try {
            const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(id, roleId);
            if (isUpdated) {
                // update new token if expried
                businessDoc = await BusinessesService.getBusinessDocByIdV2(id);
            }
            let isCheckWatchId = false;
            if (businessDoc && businessDoc.googleToken && businessDoc.googleToken.access_token) {
                const OAuth2Client = new google.auth.OAuth2(
                    process.env.GOOGLE_CLIENT_ID,
                    process.env.GOOGLE_CLIENT_SECRET,
                    process.env.GOOGLE_REDIRECT_URI
                );
                OAuth2Client.setCredentials({
                    access_token: businessDoc.googleToken.access_token
                });
                // Initialize Google Calendar API
                const calendar = google.calendar({
                    version: 'v3',
                    auth: OAuth2Client
                });
                // Stop the watch channel
                if (businessDoc.gEventWatchId) {
                    try {
                        const response = await calendar.channels.stop({
                            // calendarId: calendarId,
                            requestBody: {
                                id: businessDoc.gEventWatchId,
                                resourceId: businessDoc.gResourceId,
                            }
                        })
                        isCheckWatchId = true;
                        console.log('Watch stopped successfully:'); // Handle successful response
                    } catch (error) {
                        console.error('Error stopping watch:', error); // Handle errors
                        if (error.message.includes('not found')) {
                            isCheckWatchId = true;
                        }
                    }
                }
            }
            // delete save event when user disconnect to google
            await Promise.all(businessDoc.googleCalendar.map(async (dt) => {
                calendarId = dt.calendarId;
                await BookingDbModel.BookingModel.deleteMany({
                    calendarId: dt.calendarId,
                    businessIdForGoogle: businessDoc.id
                });
            }));
            console.log('All bookings deleted for googleCalendars');
            // remove token and other info when user logout
            const filter = {
                _id: id
            };
            let keysToRemove;
            // gEventWatchId gResourceId
            if (isCheckWatchId) {
                keysToRemove = ['googleToken', 'isConflict', 'googleCalendar', 'gmail', 'gPicture', 'gName', 'gEventWatchId', 'gResourceId', 'syncEventToken', 'watchEventExpiry'];
            } else {
                keysToRemove = ['googleToken', 'isConflict', 'googleCalendar', 'gmail', 'gPicture', 'gName'];
            }
            const update = { $unset: {} };
            keysToRemove.forEach(key => update.$unset[key] = 1);
            await BusinessDbModel.BusinessModel.updateMany(filter, update);
            await GoogleTokenValidator.setGlobalVariable(false);
            isCheckWatchId = false;
        } catch (err) {
            Logger.logger.error("Failed to delete token", err)
            throw new DatabaseError("Failed to delete token")
        }
    }

    public static async deleteStaffGoogleToken(id: string, roleId: number) {
        let calendarId;
        let staffDoc = await StaffService.getStaffDocByObjectId(id)
        if (staffDoc == null) {
            Logger.logger.warn(
                `Staff dose not exists with this id ${id}`
            );
            throw new ReferencedResourceNotFoundError(
                `Staff dose not exists with this id ${id}`
            );
        }
        try {
            const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(id, roleId);
            if (isUpdated) {
                // update new token if expried
                staffDoc = await StaffService.getStaffDocByObjectId(id);
            }
            let isCheckWatchId = false;
            if (staffDoc && staffDoc.googleToken && staffDoc.googleToken.access_token) {
                const OAuth2Client = new google.auth.OAuth2(
                    process.env.GOOGLE_CLIENT_ID,
                    process.env.GOOGLE_CLIENT_SECRET,
                    process.env.GOOGLE_REDIRECT_URI
                );
                OAuth2Client.setCredentials({
                    access_token: staffDoc.googleToken.access_token
                });
                // Initialize Google Calendar API
                const calendar = google.calendar({
                    version: 'v3',
                    auth: OAuth2Client
                });
                // Stop the watch channel
                if (staffDoc.gEventWatchId) {
                    try {
                        const response = await calendar.channels.stop({
                            // calendarId: calendarId,
                            requestBody: {
                                id: staffDoc.gEventWatchId,
                                resourceId: staffDoc.gResourceId,
                            }
                        })
                        isCheckWatchId = true;
                        console.log('Watch stopped successfully:'); // Handle successful response
                    } catch (error) {
                        console.error('Error stopping watch:', error); // Handle errors
                        if (error.message.includes('not found')) {
                            isCheckWatchId = true;
                        }
                    }
                }
            }
            // delete save event when user disconnect to google
            await Promise.all(staffDoc.googleCalendar.map(async (dt) => {
                calendarId = dt.calendarId;
                await BookingDbModel.BookingModel.deleteMany({
                    calendarId: dt.calendarId,
                    staffIdForGoogle: staffDoc.id
                });
            }));
            console.log('All bookings deleted for googleCalendars');
            // remove token and other info when user logout
            const filter = {
                _id: id
            };
            let keysToRemove;
            // gEventWatchId gResourceId
            if (isCheckWatchId) {
                keysToRemove = ['googleToken', 'isConflict', 'googleCalendar', 'gmail', 'gPicture', 'gName', 'gEventWatchId', 'gResourceId', 'syncEventToken', 'watchEventExpiry'];
            } else {
                keysToRemove = ['googleToken', 'isConflict', 'googleCalendar', 'gmail', 'gPicture', 'gName'];
            }
            const update = { $unset: {} };
            keysToRemove.forEach(key => update.$unset[key] = 1);
            await StaffDbModel.StaffModel.updateMany(filter, update);
            await GoogleTokenValidator.setGlobalVariable(false);
            isCheckWatchId = false;
            Logger.logger.info('Staff all google event remove successfully...')
        } catch (err) {
            Logger.logger.error("Failed to delete token", err)
            throw new DatabaseError("Failed to delete token")
        }
    }

    private static async getCalendarObject(accessToken: string) {
        const OAuth2Client = new google.auth.OAuth2(
            process.env.GOOGLE_CLIENT_ID,
            process.env.GOOGLE_CLIENT_SECRET,
            process.env.GOOGLE_REDIRECT_URI
        );
        OAuth2Client.setCredentials({
            access_token: accessToken
        });
        // Initialize Google Calendar API
        const calendar = google.calendar({
            version: 'v3',
            auth: OAuth2Client
        })
        return calendar;
    }

    public static async cancelEventToGoogleCalendar(business: Business, updatedBooking: IBooking, role: number) {
        const bookingDetails = await BookingsService.findEventByDates(
            updatedBooking.startDate,
            updatedBooking.endDate,
            business.id,
            updatedBooking.serviceId
        )
        let businessDoc = await BusinessesService.getBusinessDocByIdV2(business.id);
        const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(businessDoc.id, role);
        if (isUpdated) {
            // update new token if expried
            businessDoc = await BusinessesService.getBusinessDocByIdV2(business.id);
        }
        if (businessDoc == null) {
            Logger.logger.warn(`Business ${business.id} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Business ${business.id} doesn't exist`)
        } else if (businessDoc && businessDoc.googleToken && businessDoc.googleToken.access_token) {
            const accessToken = businessDoc.googleToken.access_token;
            let calendarId;
            if (businessDoc && (businessDoc.googleCalendar != undefined || businessDoc.googleCalendar != null)) {
                const googleData = businessDoc.googleCalendar ? businessDoc.googleCalendar.find(dt => dt.status === 'enable') : null;
                calendarId = googleData ? googleData.calendarId : null;
                if (calendarId != null) {
                    const calendar = await this.getCalendarObject(accessToken)
                    try {
                        const response = await calendar.events.list({
                            calendarId: calendarId,
                            timeMin: updatedBooking.startDate.toISOString(),
                            timeMax: updatedBooking.endDate.toISOString(),
                        });
                        const events = response.data.items;
                        if (events.length === 0) {
                            return;
                        }
                        for (let index = 0; index < events.length; index++) {
                            const eventDetails = events[index];
                            if (events && eventDetails.attendees && eventDetails.attendees.length > 1) {
                                let filteredAttendess = await Promise.all(bookingDetails.map(async (value) => {
                                    return eventDetails.attendees.filter((dt) => dt.email.toLowerCase() === value.customer.email.toLowerCase());
                                }));
                                // filteredAttendess = filteredAttendess.find(arr => arr.length > 0);
                                let currentAtt = filteredAttendess.flat();
                                await calendar.events.patch({
                                    calendarId: calendarId, // Replace 'primary' with the appropriate calendar ID if needed
                                    eventId: eventDetails.id,
                                    resource: {
                                        attendees: currentAtt
                                    }
                                });
                            } else {
                                // Assuming you want to delete the first event found in the list
                                const eventIdToDelete = eventDetails.id;
                                await calendar.events.delete({
                                    calendarId: calendarId,
                                    eventId: eventIdToDelete,
                                    sendNotifications: true,
                                    sendUpdates: 'all'
                                });
                            }
                        }
                        console.log('Event deleted successfully.');
                    } catch (error) {
                        console.error('Error:', error);
                    }
                }
            }
        }
    }

    public static async renewCalendarWebhhok(business: IBusiness, role: number): Promise<any> {
        try {
            if (business.googleToken && business.googleToken.access_token) {
                // check token  is expired or not 
                const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(business.id, role);
                if (isUpdated) {
                    business = await BusinessesService.getBusinessDocByEmailId(business.email);
                }
                const isExistIndex = business.googleCalendar.findIndex(item => item.status === 'enable');
                const webhookDetail = await this.registerGoogleCalendarWebhook(business, business.googleCalendar[isExistIndex].calendarId, isExistIndex)
                business.gEventWatchId = webhookDetail.watchId;
                business.gResourceId = webhookDetail.gResourceId;
                business.watchEventExpiry = webhookDetail.watchEventExpiry;
                await business.save()
            }
            return
        } catch (err) {
            Logger.logger.error(`Failed to retrieve webhook business Id : ${business.id}`, err)
            // throw new DatabaseError(`Failed to retrieve business list when renew calendar webhook`)
        }
    }

    public static async getnextUpcomingEvents(business: IBusiness, role: number): Promise<any> {
        try {
            if (business.googleToken && business.googleToken.access_token) {
                // check token  is expired or not 
                const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(business.id, role);
                if (isUpdated) {
                    business = await BusinessesService.getBusinessDocByEmailId(business.email);
                }
                const isExistIndex = business.googleCalendar.findIndex(item => item.status === 'enable');
                if (isExistIndex !== -1 && business.googleCalendar[isExistIndex].lastLoggedInTime) {
                    const currentDate = Date.now();
                    const lastCalendarIdAddedTime = business.googleCalendar[isExistIndex].lastLoggedInTime;
                    const lastLoggedIn = new Date(lastCalendarIdAddedTime.getTime());
                    const lastLoggedInTimestamp = new Date(lastCalendarIdAddedTime).getTime();

                    // Add 9 months to the date object
                    const afterNineMonths = lastLoggedIn.setMonth(lastLoggedIn.getMonth() + 9);
                    const nineMonthsLaterTimestamp = new Date(afterNineMonths).getTime();
                    // const oneDayLater = new Date(lastLoggedIn);
                    // const oneDayAfter = new Date(oneDayLater.setDate(lastLoggedIn.getDate() + 5)).getTime();
                    if (currentDate >= nineMonthsLaterTimestamp) {
                        const res: any = await this.insertSelectedCalendarIdEvents(business.googleCalendar[isExistIndex].calendarId, business, roles.Business);
                        business.syncEventToken = res;
                        await business.save()
                    }
                    // else {
                    //     Logger.logger.info("It has not been 9 months from the loggedIn date yet.");
                    // }
                }
            }
            return
        } catch (err) {
            Logger.logger.error(`Failed to retrieve webhook business Id : ${business.id}`, err)
            // throw new DatabaseError(`Failed to retrieve business list when renew calendar webhook`)
        }
    }

    public static async deleteSavedGoogleEvents(businessDoc: IBusiness, role: number) {
        let calendarId;
        const id = businessDoc.id;
        let isCheckWatchId = false;
        try {
            const isUpdated = await this.saveNewUpdatedTokenByRefreshToken(id, role);
            if (isUpdated) {
                // update new token if expried
                businessDoc = await BusinessesService.getBusinessDocByIdV2(id);
            }
            if (businessDoc && businessDoc.googleToken && businessDoc.googleToken.access_token) {
                const OAuth2Client = new google.auth.OAuth2(
                    process.env.GOOGLE_CLIENT_ID,
                    process.env.GOOGLE_CLIENT_SECRET,
                    process.env.GOOGLE_REDIRECT_URI
                );
                OAuth2Client.setCredentials({
                    access_token: businessDoc.googleToken.access_token
                });
                // Initialize Google Calendar API
                const calendar = google.calendar({
                    version: 'v3',
                    auth: OAuth2Client
                });
                // Stop the watch channel
                if (businessDoc.gEventWatchId) {
                    try {
                        await calendar.channels.stop({
                            // calendarId: calendarId,
                            requestBody: {
                                id: businessDoc.gEventWatchId,
                                resourceId: businessDoc.gResourceId,
                            }
                        })
                        isCheckWatchId = true;
                        console.log('Watch stopped successfully:'); // Handle successful response
                    } catch (error) {
                        console.error('Error stopping watch:', error); // Handle errors
                        if (error.message.includes('not found')) {
                            isCheckWatchId = true;
                        }
                    }
                }
            }
            // delete save event when user disconnect to google
            await Promise.all(businessDoc.googleCalendar.map(async (dt) => {
                calendarId = dt.calendarId;
                await BookingDbModel.BookingModel.deleteMany({
                    calendarId: dt.calendarId,
                    businessIdForGoogle: businessDoc.id
                });
            }));
            console.log('All bookings deleted for googleCalendars');
            // remove event info after plan was deleted
            const filter = {
                _id: id
            };
            let keysToRemove = ['gEventWatchId', 'gResourceId', 'syncEventToken', 'watchEventExpiry'];
            const update = { $unset: {} };
            keysToRemove.forEach(key => update.$unset[key] = 1);
            await BusinessDbModel.BusinessModel.updateMany(filter, update);
            await GoogleTokenValidator.setGlobalVariable(false);
            isCheckWatchId = false;
        } catch (err) {
            Logger.logger.error("Failed to delete token", err)
            throw new DatabaseError("Failed to delete token")
        }
        return;
    }
}
