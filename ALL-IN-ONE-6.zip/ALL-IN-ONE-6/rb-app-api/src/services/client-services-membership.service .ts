import { BookingDbModel } from "../db-models/booking.db-model";
import { ClientMembershipDbModel, IClientMembership } from "../db-models/client-membership.db-model";
import { IMembershipServiceSnapshot, MembershipServiceSnapshotDbModel } from "../db-models/service-membership-snapshot.db-model";
import { DatabaseError } from "../errors/database.error";
import { Logger } from "../logger";
import { ClientMembership } from "../types/clientMembership";
import { BookingStatus } from "../types/enums/booking.status";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { MembershipServiceSnapshot } from "../types/service-membership-snapshot";
import { TextFormatService } from "../utils/convert-html-to-text";
import { DateUtils } from "../utils/date.utils";
import { TimeZonesService } from "./time-zones.service";

export abstract class ClientMembershipService {

    public static async createClientMembership(cMembershipDoc: ClientMembership): Promise<IClientMembership> {
        // save membership snap
        cMembershipDoc.membershipSnapshot = await this.createMembershipSnap(cMembershipDoc.membershipSnapshot);

        let membershiipDoc = null;
        /** add service week days based on businessMembership */
        const businessServiceDoc = ClientMembershipDbModel.convertToDbModel(cMembershipDoc);
        try {
            // add service package in db 
            membershiipDoc = await ClientMembershipDbModel.ClientMembershipModel.create(businessServiceDoc);
        } catch (err) {
            Logger.logger.error(
                `Failed to create package for businessMembershipId ${cMembershipDoc.membershipId}`,
                err
            );
            throw new DatabaseError(
                `Failed to create package for businessMembershipId ${cMembershipDoc.membershipId}`
            );
        }
        return membershiipDoc;
    }

    public static async getByClientId(clientId: string): Promise<number> {
        let bookingQty = 0
        /** add service week days based on businessMembership */
        try {
            // add service package in db 
            const clientMemberships = await ClientMembershipDbModel.ClientMembershipModel.aggregate([
                {
                    $match: {
                        clientId: clientId,
                        isDeleted: false,
                        paymentStatus: "Paid"
                    }
                },
                {
                    $addFields: {
                        membershipId: { $toObjectId: "$membershipId" }
                    }
                },
                {
                    $lookup: {
                        from: "business-memberships",
                        localField: "membershipId",
                        foreignField: "_id",
                        as: "membershipDetails"
                    }
                },
                {
                    // ✅ only keep packageSetting array instead of full details
                    $addFields: {
                        packageSetting: "$membershipDetails.packageSetting"
                    }
                },
                {
                    $project: {
                        clientId: 1,
                        membershipId: 1,
                        paymentStatus: 1,
                        packageSetting: 1,
                        membershipUnits: 1,
                    }
                }
            ]);
            // get Total booking quantity for client
            bookingQty = clientMemberships.reduce((acc, item) => {
                const bookings = item.packageSetting.flat();
                const totalBookingQuantity = bookings.reduce((sum, pkg) => sum + pkg.bookingQuantity, 0);
                return acc + (totalBookingQuantity * item.membershipUnits);
            }, 0);

        } catch (err) {
            Logger.logger.error(
                `Failed to get count of booking for client Id: ${clientId}`,
                err
            );
            throw new DatabaseError(
                `Failed to get count of booking for client Id ${clientId}`
            );
        }
        return bookingQty;
    }


    public static async getMembershipActiveForClient(
        businessId: string,
        serviceId: string,
        clientId: string
    ): Promise<any[]> {
        try {
            const clientMemberships = await ClientMembershipDbModel.ClientMembershipModel.aggregate([
                // 1️⃣ Match all valid paid memberships for this client & business
                {
                    $match: {
                        clientId,
                        businessId,
                        isDeleted: false,
                        paymentStatus: "Paid",
                    },
                },

                // 2️⃣ Convert snapshot ID to ObjectId for lookup
                {
                    $addFields: {
                        membershipSnapshotIdObj: { $toObjectId: "$membershipSnapshotId" },
                    },
                },

                // 3️⃣ Lookup snapshot details
                {
                    $lookup: {
                        from: "business-membership-snapshots",
                        localField: "membershipSnapshotIdObj",
                        foreignField: "_id",
                        as: "membershipDetails",
                    },
                },
                { $unwind: "$membershipDetails" },

                // 4️⃣ Calculate total booking quantity for each membership
                {
                    $addFields: {
                        totalBookingQuantity: {
                            $sum: {
                                $map: {
                                    input: "$membershipDetails.membershipPackageSetting",
                                    as: "pkg",
                                    in: {
                                        $multiply: [
                                            { $ifNull: ["$$pkg.bookingQuantity", 0] },
                                            { $ifNull: ["$membershipUnits", 1] },
                                        ],
                                    },
                                },
                            },
                        },
                    },
                },

                // 5️⃣ Final projection — clean data
                {
                    $project: {
                        _id: 0,
                        clientId: 1,
                        businessId: 1,
                        membershipId: 1,
                        membershipSnapshotId: 1,
                        membershipUnits: 1,
                        totalBookingQuantity: 1,
                        "membershipDetails.membershipName": 1,
                        "membershipDetails.membershipDescription": 1,
                        "membershipDetails.membershipPackageSetting": 1,
                    },
                },
            ]);

            return clientMemberships;
        } catch (err) {
            Logger.logger.error(
                `Failed to get active memberships for clientId: ${clientId}`,
                err
            );
            throw new DatabaseError(
                `Failed to fetch active memberships for clientId ${clientId}`
            );
        }
    }


    public static async getByClientMembershipDocId(id: string): Promise<any> {
        try {
            try {
                let businessMembershipDoc: any = await ClientMembershipDbModel.ClientMembershipModel.findOne({ _id: id, isDeleted: false }).exec();
                const membershipSnapshot = await this.getByClientMembershipSnapDocId(businessMembershipDoc.membershipSnapshotId);
                return { currentMembershipDoc: businessMembershipDoc, membershipSnapshot: membershipSnapshot };
            } catch (err) {
                Logger.logger.error(`Failed to retrieve businessMembership by id (${id})`, err)
                throw new DatabaseError(`Failed to retrieve businessMembership by id (${id})`)
            }

        } catch (err) {
            Logger.logger.error("Failed to get business by slug", err)
            throw new DatabaseError("Failed to get business by slug")
        }
    }

    public static async getByClientMembershipSnapDocId(id: string): Promise<MembershipServiceSnapshot> {
        try {
            try {
                const membershipSnapshot = await MembershipServiceSnapshotDbModel.MembershipServiceSnapshotModel.findOne({ _id: id }).exec();
                return MembershipServiceSnapshotDbModel.convertToDomainModel(membershipSnapshot);
            } catch (err) {
                Logger.logger.error(`Failed to retrieve businessMembership by id (${id})`, err)
                throw new DatabaseError(`Failed to retrieve businessMembership by id (${id})`)
            }

        } catch (err) {
            Logger.logger.error("Failed to get business by slug", err)
            throw new DatabaseError("Failed to get business by slug")
        }
    }

    public static async getMembershipHistory(clientId: string): Promise<any> {
        try {
          const clientMemberships = await ClientMembershipDbModel.ClientMembershipModel.aggregate([
            // 1️⃣ Match valid memberships
            {
              $match: {
                clientId,
                isDeleted: false,
                paymentStatus: "Paid",
              },
            },
      
            // 2️⃣ Convert IDs
            {
              $addFields: {
                membershipSnapshotId: { $toObjectId: "$membershipSnapshotId" },
                businessId: { $toObjectId: "$businessId" },
              },
            },
      
            // 3️⃣ Lookup membership snapshot
            {
              $lookup: {
                from: "business-membership-snapshots",
                localField: "membershipSnapshotId",
                foreignField: "_id",
                as: "membershipDetails",
              },
            },
            { $unwind: "$membershipDetails" },
      
            // 4️⃣ Unwind package settings
            {
              $unwind: {
                path: "$membershipDetails.membershipPackageSetting",
                preserveNullAndEmptyArrays: true,
              },
            },
      
            // 5️⃣ Convert serviceId
            {
              $addFields: {
                "membershipDetails.membershipPackageSetting.serviceId": {
                  $toObjectId: "$membershipDetails.membershipPackageSetting.serviceId",
                },
              },
            },
      
            // 6️⃣ Lookup service details
            {
              $lookup: {
                from: "business-services",
                localField: "membershipDetails.membershipPackageSetting.serviceId",
                foreignField: "_id",
                as: "serviceDetails",
              },
            },
            {
              $unwind: {
                path: "$serviceDetails",
                preserveNullAndEmptyArrays: true,
              },
            },
      
            // 7️⃣ Calculate total booking quantity
            {
              $addFields: {
                totalBookingQty: {
                  $multiply: [
                    { $ifNull: ["$membershipDetails.membershipPackageSetting.bookingQuantity", 0] },
                    { $ifNull: ["$membershipUnits", 1] },
                  ],
                },
                serviceId: {
                  $toString: "$membershipDetails.membershipPackageSetting.serviceId",
                },
                membershipIdStr: { $toString: "$membershipId" },
                clientIdStr: { $toString: "$clientId" },
              },
            },
      
            // 8️⃣ Lookup bookings (compare as strings)
            {
              $lookup: {
                from: "bookings",
                let: {
                  cid: "$clientIdStr",
                  sid: "$serviceId",
                  mid: "$membershipIdStr",
                },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ["$clientId", "$$cid"] },
                          { $eq: ["$serviceId", "$$sid"] },
                          { $eq: ["$membershipId", "$$mid"] },
                        ],
                      },
                      status: { $in: [1, 2] }, // BookingStatus.Approved / Pending
                    },
                  },
                  { $group: { _id: null, usedQty: { $sum: 1 } } },
                ],
                as: "bookingUsage",
              },
            },
      
            // 9️⃣ Calculate used & remaining bookings
            {
              $addFields: {
                usedQty: { $ifNull: [{ $first: "$bookingUsage.usedQty" }, 0] },
              },
            },
            {
              $addFields: {
                remainingBookingQty: {
                  $max: [
                    {
                      $subtract: [
                        "$totalBookingQty",
                        { $ifNull: [{ $first: "$bookingUsage.usedQty" }, 0] },
                      ],
                    },
                    0,
                  ],
                },
              },
            },
      
            // 🔟 Lookup business details
            {
              $lookup: {
                from: "businesses",
                localField: "businessId",
                foreignField: "_id",
                as: "businessDetails",
              },
            },
            { $unwind: { path: "$businessDetails", preserveNullAndEmptyArrays: true } },
      
            // 11️⃣ Lookup all bookings (same membership)
            {
              $lookup: {
                from: "bookings",
                let: { cid: "$clientIdStr", mid: "$membershipIdStr" },
                pipeline: [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          { $eq: ["$clientId", "$$cid"] },
                          { $eq: ["$membershipId", "$$mid"] },
                        ],
                      },
                    },
                  },
                  {
                    $project: {
                      _id: 1,
                      serviceId: 1,
                      staffId: 1,
                      startDate: 1,
                      endDate: 1,
                      status: 1,
                      createdAt: 1,
                    },
                  },
                ],
                as: "bookings",
              },
            },
      
            // 12️⃣ Group by membership
            {
              $group: {
                _id: { clientId: "$clientId", membershipId: "$membershipId" },
                clientId: { $first: "$clientId" },
                membershipId: { $first: "$membershipId" },
                membershipSnapshotId: { $first: "$membershipSnapshotId" },
                paymentStatus: { $first: "$paymentStatus" },
                membershipUnits: { $first: "$membershipUnits" },
                membershipDetails: { $first: "$membershipDetails" },
                businessDetails: { $first: "$businessDetails" },
                bookings: { $first: "$bookings" },
                membershipPackageSetting: {
                  $push: {
                    serviceId: "$membershipDetails.membershipPackageSetting.serviceId",
                    bookingQuantity: "$membershipDetails.membershipPackageSetting.bookingQuantity",
                    totalBookingQty: "$totalBookingQty",
                    usedQty: "$usedQty",
                    remainingBookingQty: "$remainingBookingQty",
                    serviceDetails: "$serviceDetails",
                  },
                },
                totalServices: { $sum: "$totalBookingQty" },
                bookedServices: { $sum: "$usedQty" },
                remainingServices: { $sum: "$remainingBookingQty" },
              },
            },
      
            // 13️⃣ Sort latest
            { $sort: { _id: -1 } },
          ]);
      
          // ✅ Format Output
          return clientMemberships.map((item) => {
            const {
              membershipDetails,
              membershipPackageSetting,
              businessDetails,
              bookings,
              totalServices,
              bookedServices,
              remainingServices,
            } = item;
      
            const serviceDetails = (membershipPackageSetting || []).map((pkg) => {
              const service = pkg.serviceDetails || {};
              return {
                serviceId: service._id?.toString(),
                image: service.heroImage || null,
                title: service.name,
                rating: 4.5,
                price: service.price ? service.price / 100 : null,
                duration:
                  service.type === "event"
                    ? DateUtils.getTimeDifferenceInMinutes(
                        service.eventSetting?.startDate,
                        service.eventSetting?.endDate
                      )
                    : service.duration,
                unit: service.durationUnit === DurationUnit.Minute ? "Minutes" : "Hours",
                currency: service.currency,
                businessName: businessDetails?.name || "",
                serviceSlug: TextFormatService.removeSpecialCharacters(
                  service.name || ""
                ).replace(/\s+/g, "-"),
                businessSlug: businessDetails?.slug || "",
                totalBookingQty: pkg.totalBookingQty,
                usedQty: pkg.usedQty,
                remainingBookingQty: pkg.remainingBookingQty,
              };
            });
      
            return {
              membershipDetails: {
                id: item.membershipId,
                membershipSnapshotId: membershipDetails._id?.toString(),
                name: membershipDetails.membershipName,
                description: membershipDetails.membershipDescription,
                price: membershipDetails.membershipPrice
                  ? membershipDetails.membershipPrice / 100
                  : null,
                logo: membershipDetails.membershipLogo || null,
              },
              serviceDetails,
              bookings,
              totalServices,
              bookedServices,
              remainingServices,
            };
          });
        } catch (err) {
          Logger.logger.error(`Failed to get booking count for client ${clientId}`, err);
          throw new DatabaseError(`Failed to get booking count for client ${clientId}`);
        }
      }
      
      
      
      


    public static async processMembershipBookings(memberships, bookings) {
        return memberships.map((membership) => {
          const businessDetails = membership.businessDetails;
          const snapshotSettings =
            membership.membershipSnapshotDetails?.membershipPackageSetting || [];
      
          const relatedBookings = bookings.filter(
            (b) => b.membershipId?.toString() === membership.membershipId?.toString()
          );
      
          const bookingCountMap = relatedBookings.reduce((acc, b) => {
            const sid = b.serviceId?.toString();
            acc[sid] = (acc[sid] || 0) + 1;
            return acc;
          }, {});
      
          const reservedServiceDetails = [];
          const remainingServiceDetails = [];
      
          snapshotSettings.forEach((pkg) => {
            const serviceId = pkg.serviceId?.toString();
            const allowedQty = pkg.bookingQuantity || 0;
            const bookedQty = bookingCountMap[serviceId] || 0;
            const remainingQty = Math.max(allowedQty - bookedQty, 0);
      
            // 🔹 Find service details from membership.packageSetting
            const serviceData = membership.packageSetting?.find(
              (s) => s.serviceId?.toString() === serviceId
            );
      
            const service = serviceData?.serviceDetails;
            if (!service) {
              console.warn("⚠️ Service not found for ID:", serviceId);
              return;
            }
            const serviceAddress = (service.serviceAddress && service.serviceAddress.country)
            ? service.serviceAddress
            : businessDetails.address;
            // 🔹 Common service detail structure
            const serviceInfo = {
              serviceId,
              title: service.name,
              name: service.name,
              image: service.heroImage || service.logo || '',
              price: service.price ? service.price / 100 : null,
              duration:
                service.type === "event"
                  ? DateUtils.getTimeDifferenceInMinutes(
                      service.eventSetting?.startDate,
                      service.eventSetting?.endDate
                    )
                  : service.duration,
              unit:
                service.durationUnit === DurationUnit.Minute ? "Minutes" : "Hours",
              currency: service.currency,
              businessName: businessDetails?.name || "",
              businessSlug: businessDetails?.slug || "",
              serviceSlug: TextFormatService.removeSpecialCharacters(
                service.name || ""
              ).replace(/\s+/g, "-"),
              bookedQty,
              remainingQty,
              allowedQty,
              membershipId: membership.membershipId,
              clientId: membership.clientId,
              businessId: businessDetails?._id?.toString() || null,
              address: serviceAddress,
            };
      
            if (bookedQty > 0) reservedServiceDetails.push(serviceInfo);
            if (remainingQty > 0) remainingServiceDetails.push(serviceInfo);
          });
      
          return {
            ...membership,
            reservedServiceDetails,
            remainingServiceDetails,
          };
        });
      }
      

    public static async getMembershipHistoryById(clientId: string, membershipId: string): Promise<any> {
        let mappedClientMemberships = [];
        try {
            const clientMemberships = await ClientMembershipDbModel.ClientMembershipModel.aggregate([
                {
                    $match: {
                        clientId: clientId,
                        isDeleted: false,
                        paymentStatus: "Paid",
                        membershipId: membershipId,
                    },
                },
                {
                    $addFields: {
                        businessId: { $toObjectId: "$businessId" },
                    },
                },
                // ✅ Lookup Business Membership Snapshot
                {
                    $lookup: {
                        from: "business-membership-snapshots",
                        let: { snapshotId: "$membershipSnapshotId" },
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: [{ $toString: "$_id" }, "$$snapshotId"],
                                    },
                                },
                            },
                        ],
                        as: "membershipSnapshotDetails",
                    },
                },
                { $unwind: { path: "$membershipSnapshotDetails", preserveNullAndEmptyArrays: true } },

                {
                    $lookup: {
                        from: "business-memberships",
                        let: { membershipId: "$membershipId" },
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $eq: [{ $toString: "$_id" }, "$$membershipId"],
                                    },
                                },
                            },
                        ],
                        as: "membershipDetails",
                    },
                },
                { $unwind: "$membershipDetails" },
                { $unwind: "$membershipDetails.packageSetting" },
                {
                    $addFields: {
                        "membershipDetails.packageSetting.serviceId": {
                            $toObjectId: "$membershipDetails.packageSetting.serviceId",
                        },
                    },
                },
                {
                    $lookup: {
                        from: "business-services",
                        localField: "membershipDetails.packageSetting.serviceId",
                        foreignField: "_id",
                        as: "serviceDetails",
                    },
                },
                { $unwind: { path: "$serviceDetails", preserveNullAndEmptyArrays: true } },
                {
                    $addFields: {
                        "membershipDetails.packageSetting.totalBookingQty": {
                            $multiply: [
                                { $ifNull: ["$membershipDetails.packageSetting.bookingQuantity", 0] },
                                { $ifNull: ["$membershipUnits", 1] },
                            ],
                        },
                    },
                },
                {
                    $lookup: {
                        from: "businesses",
                        localField: "businessId",
                        foreignField: "_id",
                        as: "businessDetails",
                    },
                },
                { $unwind: { path: "$businessDetails", preserveNullAndEmptyArrays: true } },
                {
                    $group: {
                        _id: { clientId: "$clientId", membershipId: "$membershipId" },
                        clientId: { $first: "$clientId" },
                        membershipId: { $first: "$membershipId" },
                        paymentStatus: { $first: "$paymentStatus" },
                        membershipUnits: { $first: "$membershipUnits" },
                        membershipDetails: { $first: "$membershipDetails" },
                        membershipSnapshotDetails: { $first: "$membershipSnapshotDetails" }, // ✅ added snapshot
                        businessDetails: { $first: "$businessDetails" },
                        packageSetting: {
                            $push: {
                                bookingQuantity: "$membershipDetails.packageSetting.bookingQuantity",
                                serviceId: "$membershipDetails.packageSetting.serviceId",
                                totalBookingQty: "$membershipDetails.packageSetting.totalBookingQty",
                                bookedQty: "$membershipDetails.packageSetting.bookedQty",
                                remainingQty: "$membershipDetails.packageSetting.remainingQty",
                                serviceDetails: "$serviceDetails",
                            },
                        },
                        totalMembershipBookingQty: {
                            $sum: "$membershipDetails.packageSetting.totalBookingQty",
                        },
                    },
                },
                {
                    $project: {
                        clientId: 1,
                        membershipId: 1,
                        paymentStatus: 1,
                        membershipUnits: 1,
                        membershipDetails: {
                            _id: 1,
                            name: 1,
                            description: 1,
                            price: 1,
                            packageSetting: 1,
                            logo: 1,
                        },
                        membershipSnapshotDetails: 1, // ✅ include snapshot in final result
                        businessDetails: {
                            _id: 1,
                            name: 1,
                            slug: 1,
                            logo: 1,
                            address: 1,
                        },
                        packageSetting: 1,
                        totalMembershipBookingQty: 1,
                    },
                },
            ]);
            // ✅ Process and map results
            // 1️⃣ Fetch only relevant bookings once
            const existingBookings = await BookingDbModel.BookingModel.aggregate([
                {
                    $match: {
                        businessId: clientMemberships[0].businessDetails._id.toString(),
                        clientId: clientId,
                        membershipId: membershipId,
                        status: { $in: [BookingStatus.Approved, BookingStatus.Pending] },
                    }
                },
            ]);

            mappedClientMemberships = await this.processMembershipBookings(clientMemberships, existingBookings);

            // // 🧠 Map results with reserved and remaining services
            // mappedClientMemberships = clientMemberships.map(item => {
            //     const { membershipDetails, packageSetting, totalMembershipBookingQty, businessDetails } = item;
            //     const servicesMap = new Map<string, any>();

            //     (packageSetting || []).forEach(pkg => {
            //         const service = pkg.serviceDetails || {};
            //         const serviceId = service._id?.toString();
            //         if (!serviceId) return;

                    // const serviceAddress = (service.serviceAddress && service.serviceAddress.country)
                    //     ? service.serviceAddress
                    //     : businessDetails.address;

            //         if (!servicesMap.has(serviceId)) {
                        // servicesMap.set(serviceId, {
                        //     serviceId,
                        //     title: service.name,
                        //     name: service.name,
                        //     image: service.heroImage || null,
                        //     price: service.price ? service.price / 100 : null,
                        //     duration: service.type === "event"
                        //         ? DateUtils.getTimeDifferenceInMinutes(service.eventSetting?.startDate, service.eventSetting?.endDate)
                        //         : service.duration,
                        //     unit: service.durationUnit === DurationUnit.Minute ? "Minutes" : "Hours",
                        //     currency: service.currency,
                        //     businessName: businessDetails?.name || '',
                        //     serviceSlug: TextFormatService.removeSpecialCharacters(service.name || "").replace(/\s+/g, "-"),
                        //     businessSlug: businessDetails?.slug || '',
                        //     bookedQty: pkg.bookedQty,
                        //     remainingQty: pkg.remainingQty,
                        //     address: serviceAddress,
                        // });
            //         } else {
            //             const existing = servicesMap.get(serviceId);
            //             existing.bookedQty += pkg.bookedQty;
            //             existing.remainingQty += pkg.remainingQty;
            //         }
            //     });

            //     const remainingServiceDetails = [];
            //     const reservedServiceDetails = [];
            //     let totalRemainingQty = 0;
            //     let totalBookedQty = 0;

            //     servicesMap.forEach(service => {
            //         if (service.remainingQty > 0) {
            //             remainingServiceDetails.push(service);
            //             totalRemainingQty += service.remainingQty;
            //         }
            //         if (service.bookedQty > 0) {
            //             reservedServiceDetails.push(service);
            //             totalBookedQty += service.bookedQty;
            //         }
            //     });

            //     return {
            //         totalMembershipBookingQty,
            //         totalRemainingQty,
            //         totalBookedQty,
            //         membershipDetails: {
            //             id: membershipDetails._id?.toString(),
            //             name: membershipDetails.name,
            //             description: membershipDetails.description,
            //             price: membershipDetails.price ? membershipDetails.price / 100 : null,
            //             logo: membershipDetails.logo || null,
            //         },
            //         remainingServiceDetails,
            //         reservedServiceDetails,
            //     };
            // });

        } catch (err) {
            Logger.logger.error(`Failed to get booking count for clientId: ${clientId}`, err);
            throw new DatabaseError(`Failed to get booking count for clientId ${clientId}`);
        }

        return mappedClientMemberships;
    }


    public static async getBusinessMembershipHistory(businessId: string, membershipId: string): Promise<any> {
        let membershipDocs = []
        /** add service week days based on businessMembership */
        try {
            // add service package in db 
            const clientMemberships = await ClientMembershipDbModel.ClientMembershipModel.aggregate([
                {
                    $match: {
                        isDeleted: false,
                        paymentStatus: "Paid",
                        membershipId: membershipId,
                        businessId: businessId,
                    },
                },
                {
                    $addFields: {
                        membershipIdObj: { $toObjectId: "$membershipId" },
                        clientObjId: { $toObjectId: "$clientId" },
                        businessObjId: { $toObjectId: "$businessId" },
                    },
                },

                // ✅ Lookup membership details
                {
                    $lookup: {
                        from: "business-memberships",
                        localField: "membershipIdObj",
                        foreignField: "_id",
                        as: "membershipDetails",
                    },
                },
                { $unwind: { path: "$membershipDetails", preserveNullAndEmptyArrays: true } },

                // ✅ Lookup client details
                {
                    $lookup: {
                        from: "clients",
                        localField: "clientObjId",
                        foreignField: "_id",
                        as: "clientDetails",
                    },
                },
                { $unwind: { path: "$clientDetails", preserveNullAndEmptyArrays: true } },

                // ✅ Lookup business details
                {
                    $lookup: {
                        from: "businesses",
                        localField: "businessObjId",
                        foreignField: "_id",
                        as: "businessDetails",
                    },
                },
                { $unwind: { path: "$businessDetails", preserveNullAndEmptyArrays: true } },

                // ✅ Flatten packageSetting for calculation
                {
                    $unwind: {
                        path: "$membershipDetails.packageSetting",
                        preserveNullAndEmptyArrays: true,
                    },
                },

                // ✅ Group data and calculate totals
                {
                    $group: {
                        _id: {
                            clientId: "$clientId",
                            membershipId: "$membershipId",
                        },
                        clientDetails: { $first: "$clientDetails" },
                        membershipDetails: { $first: "$membershipDetails" },
                        businessDetails: { $first: "$businessDetails" },
                        membershipUnits: { $first: "$membershipUnits" },
                        purchaseDate: { $first: "$createdAt" },
                        totalBookingQty: {
                            $sum: {
                                $multiply: [
                                    { $ifNull: ["$membershipDetails.packageSetting.bookingQuantity", 0] },
                                    { $ifNull: ["$membershipUnits", 1] },
                                ],
                            },
                        },
                    },
                },

                // ✅ Final projection
                {
                    $project: {
                        _id: 0,
                        clientId: "$_id.clientId",
                        membershipId: "$_id.membershipId",
                        totalBookingQty: 1,
                        purchaseDate: 1, // 👈 Keep raw date here
                        clientDetails: {
                            _id: "$clientDetails._id",
                            name: "$clientDetails.name",
                            surname: "$clientDetails.surname",
                            email: "$clientDetails.email",
                            phone: "$clientDetails.phone",
                        },
                        membershipDetails: {
                            _id: "$membershipDetails._id",
                            name: "$membershipDetails.name",
                            description: "$membershipDetails.description",
                        },
                        businessDetails: {
                            _id: "$businessDetails._id",
                            name: "$businessDetails.name",
                            timezoneId: "$businessDetails.timeZoneId",
                        },
                    },
                },
            ]);

            membershipDocs = await Promise.all(
                clientMemberships.map(async (item) => {
                    const timezone = await TimeZonesService.getTimeZoneDocById(item.businessDetails.timezoneId);

                    return {
                        clientDetails: {
                            id: item.clientDetails._id.toString(),
                            email: item.clientDetails.email,
                            name: `${item.clientDetails.name} ${item.clientDetails.surname}`,
                            phone: item.clientDetails.phone,
                        },
                        membershipDetails: {
                            id: item.membershipDetails._id.toString(),
                            name: item.membershipDetails.name,
                            description: item.membershipDetails.description,
                            purchaseDate: DateUtils.toLocalDateStringFormat(
                                item.purchaseDate,
                                timezone.name
                            ),
                        },
                        totalBookingQty: item.totalBookingQty,
                    };
                })
            );



        } catch (err) {
            Logger.logger.error(
                `Failed to get count of booking for membership Id: ${membershipId}`,
                err
            );
            throw new DatabaseError(
                `Failed to get count of booking for membership Id ${membershipId}`
            );
        }
        return membershipDocs;
    }

    private static async createMembershipSnap(businessService: MembershipServiceSnapshot): Promise<MembershipServiceSnapshot> {
        const snapshotDoc = MembershipServiceSnapshotDbModel.convertToDbModel(businessService)
        try {
            await MembershipServiceSnapshotDbModel.MembershipServiceSnapshotModel.create(snapshotDoc)
        } catch (err) {
            Logger.logger.error(`Failed to create business service snapshot for business service ${businessService.id}`, err)
            throw new DatabaseError(`Failed to create business service snapshot for business service ${businessService.id}`)
        }
        return MembershipServiceSnapshotDbModel.convertToDomainModel(snapshotDoc)
    }

    public static async checkClientPackageValidity(services: any[], clientId: string): Promise<any[]> {
        try {
            if (!services?.length) return [];

            const matchStage: any = {
                isDeleted: false,
                paymentStatus: "Paid",
            };

            if (clientId) {
                // matchStage.clientId = '68930b374c8e7dd39b3246ad';
                matchStage.clientId = clientId;
            }

            const serviceObjectIds = services.map(
                (s: any) => s.id
            );
            // Step 1: Fetch all memberships that include any of the provided service IDs
            const clientMemberships = await ClientMembershipDbModel.ClientMembershipModel.aggregate([
                { $match: matchStage },

                { $addFields: { membershipSnapshotId: { $toObjectId: "$membershipSnapshotId" } } },

                {
                    $lookup: {
                        from: "business-membership-snapshots",
                        localField: "membershipSnapshotId",
                        foreignField: "_id",
                        as: "membershipDetails",
                    },
                },
                { $unwind: "$membershipDetails" },
                { $unwind: "$membershipDetails.membershipPackageSetting" },

                // Match only relevant services
                {
                    $match: {
                        "membershipDetails.membershipPackageSetting.serviceId": { $in: serviceObjectIds },
                    },
                },

                // Calculate total booking qty for each package
                {
                    $addFields: {
                        totalBookingQty: {
                            $multiply: [
                                { $ifNull: ["$membershipDetails.membershipPackageSetting.bookingQuantity", 0] },
                                { $ifNull: ["$membershipUnits", 1] },
                            ],
                        },
                        serviceId: "$membershipDetails.membershipPackageSetting.serviceId",
                    },
                },

                // Lookup booking usage for each client + service
                {
                    $lookup: {
                        from: "client-bookings",
                        let: {
                            cid: "$clientId",
                            sid: "$serviceId",
                            mid: "$membershipId",
                        },
                        pipeline: [
                            {
                                $match: {
                                    $expr: {
                                        $and: [
                                            { $eq: ["$clientId", "$$cid"] },
                                            { $eq: ["$serviceId", "$$sid"] },
                                            { $eq: ["$membershipId", "$$mid"] },
                                        ],
                                    },
                                },
                            },
                            {
                                $group: { _id: null, totalUsed: { $sum: "$usedQty" } },
                            },
                        ],
                        as: "bookingUsage",
                    },
                },

                {
                    $addFields: {
                        totalUsed: { $ifNull: [{ $arrayElemAt: ["$bookingUsage.totalUsed", 0] }, 0] },
                        remainingQty: {
                            $subtract: [
                                "$totalBookingQty",
                                { $ifNull: [{ $arrayElemAt: ["$bookingUsage.totalUsed", 0] }, 0] },
                            ],
                        },
                    },
                },

                // Keep only relevant fields
                {
                    $project: {
                        serviceId: 1,
                        remainingQty: 1,
                    },
                },
            ]);

            // Step 2: Map each service with validity info
            const serviceStatusMap = new Map<string, boolean>();
            clientMemberships.forEach((m) => {
                serviceStatusMap.set(
                    String(m.serviceId),
                    m.remainingQty > 0
                );
            });

            // Step 3: Return updated service list with `isValidPackage` flag
            const result = services.map((service: any) => {
                const id = String(service.id || service.serviceId || service);
                return {
                    ...service,
                    isValidPackage: serviceStatusMap.get(id) || false,
                };
            });
            return result;
        } catch (err) {
            console.error("❌ Error in checkClientPackageValidity:", err);
            return services.map((s) => ({ ...s, isValidPackage: false }));
        }
    }

}