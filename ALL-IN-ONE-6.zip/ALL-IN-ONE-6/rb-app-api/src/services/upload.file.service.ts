import { IBusiness } from "../db-models/business.db-model";
import { DatabaseError } from "../errors/database.error";
import { Logger } from "../logger";
import { DeleteObjectCommand, PutObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { Staff } from "../types/staff";
import { roles } from "../data/user.roles";

// Set permission for access bucket
const s3Client = new S3Client({
    endpoint: process.env.DIGITAL_OCEAN_END_POINT,
    forcePathStyle: false,
    region: "us-east-1",
    credentials: {
        accessKeyId: process.env.DIGITAL_OCEAN_SPACE_ACCESS_KEY,
        secretAccessKey: process.env.DIGITAL_OCEAN_SPACE_SECRET_KEY
    }
});

// bucket folder names
const businessAssets = process.env.DIGITAL_OCEAN_BUCKET_FOLDER;
const staffAssets = process.env.DIGITAL_OCEAN_STAFF_BUCKET_FOLDER || 'staffs';
const marketPlaceAssets = process.env.DIGITAL_OCEAN_BUSINESS_MARKET_PLACE_BUCKET_FOLDER;
const membershipAssets = process.env.DIGITAL_OCEAN_BUSINESS_MEMBERSHIP_BUCKET_FOLDER;
const serviceAssets = process.env.DIGITAL_OCEAN_BUSINESS_SERVICE_BUCKET_FOLDER;


export class UploadFileService {
    public static async uploadBusinessImages(file: any, business: IBusiness, imageType: string): Promise<string> {
        Logger.logger.info('File uploding to digital ocean space..')
        try {
            let url = '';

            // get existing file extenion for add with new name
            // const fileExtension = file.originalname.split('.');
            const mimetypeValue = file.mimetype.split('/');
            let fileExtension = mimetypeValue ? mimetypeValue : 'png';
            console.log('fileExtension:', fileExtension[1]);
            const filename = `${business.slug}-${imageType}-${Date.now()}.${fileExtension[1]}`;

            // Define the parameters for the object for upload.
            const params1: any = {
                Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                Key: `${businessAssets}/${filename}`,
                Body: file.buffer,
                ContentType: file.mimetype,
                ACL: 'public-read'
            };
            try {
                const data = await s3Client.send(new PutObjectCommand(params1));
                console.log("Successfully uploaded object: ");
                if (data) {
                    url = `${process.env.DIGITAL_OCEAN_CDN_URL}/${businessAssets}/${filename}`;
                }
                return url;
            } catch (err) {
                console.log("Error", err);
            }
        } catch (error) {
            Logger.logger.error(`Failed to upload file on space`, error);
            // throw new DatabaseError(`Failed to upload file om space ${error.message}`)
        }
    }

    public static async uploadStaffImages(file: any, staff: Staff, imageType: string): Promise<string> {
        Logger.logger.info('File uploding to digital ocean space..')
        try {
            let url = '';
            // get existing file extenion for add with new name
            const mimetypeValue = file.mimetype.split('/');
            let fileExtension = mimetypeValue ? mimetypeValue : 'png';
            console.log('fileExtension:', fileExtension[1]);
            const filename = `${imageType}-${Date.now()}.${fileExtension[1]}`;
            // Define the parameters for the object for upload.
            const params1: any = {
                Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                Key: `${staffAssets}/${filename}`,
                Body: file.buffer,
                ContentType: file.mimetype,
                ACL: 'public-read'
            };
            try {
                const data = await s3Client.send(new PutObjectCommand(params1));
                console.log("Successfully uploaded object: ");
                if (data) {
                    url = `${process.env.DIGITAL_OCEAN_CDN_URL}/${staffAssets}/${filename}`;
                }
                return url;
            } catch (err) {
                console.log("Error", err);
            }
        } catch (error) {
            Logger.logger.error(`Failed to upload file on space`, error);
            // throw new DatabaseError(`Failed to upload file om space ${error.message}`)
        }
    }

    public static async deleteUploadBusinessImages(url: string, role: number): Promise<string> {
        console.log('delete url', url);
        if (url) {
            const lastSlashIndex = url.lastIndexOf('/');
            // Extract the file name using substring
            const fileName = url.substring(lastSlashIndex + 1);
            Logger.logger.info('File uploding to digital ocean space..')
            try {
                let bucketName = businessAssets;
                if (role === roles.staff) {
                    bucketName = staffAssets;
                }
                // Define the parameters for the object for upload.
                const params1: any = {
                    Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                    Key: `${bucketName}/${fileName}`,
                    // Body: file.buffer,
                    // ContentType: file.mimetype,
                    ACL: 'public-read'
                };
                try {
                    const data = await s3Client.send(new DeleteObjectCommand(params1));
                    console.log('image deleted successfully');
                    return "";
                } catch (err) {
                    console.log("Error", err);
                }
            } catch (error) {
                Logger.logger.error(`Failed to upload file on space`, error);
                throw new DatabaseError(`Failed to upload file om space ${error.message}`)
            }
        }
    }

    public static async uploadMembershipImages(file: any, membership: string, imageType: string): Promise<string> {
        Logger.logger.info('File uploding to digital ocean space..')
        try {
            let url = '';
            // get existing file extenion for add with new name
            // const fileExtension = file.originalname.split('.');
            const mimetypeValue = file.mimetype.split('/');
            let fileExtension = mimetypeValue ? mimetypeValue : 'png';
            console.log('fileExtension:', fileExtension[1]);
            const filename = `${membership}-${imageType}-${Date.now()}.${fileExtension[1]}`;

            // Define the parameters for the object for upload.
            const params1: any = {
                Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                Key: `${membershipAssets}/${filename}`,
                Body: file.buffer,
                ContentType: file.mimetype,
                ACL: 'public-read'
            };
            try {
                const data = await s3Client.send(new PutObjectCommand(params1));
                console.log("Successfully uploaded object: ");
                if (data) {
                    url = `${process.env.DIGITAL_OCEAN_CDN_URL}/${membershipAssets}/${filename}`;
                }
                return url;
            } catch (err) {
                console.log("Error", err);
            }
        } catch (error) {
            Logger.logger.error(`Failed to upload file on space`, error);
        }
    }

    public static async deleteuploadMembershipImage(url: string): Promise<string> {
        console.log('delete url', url);
        if (url) {
            const lastSlashIndex = url.lastIndexOf('/');
            // Extract the file name using substring
            const fileName = url.substring(lastSlashIndex + 1);
            try {
                // Define the parameters for the object for upload.
                const params1: any = {
                    Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                    Key: `${membershipAssets}/${fileName}`,
                    ACL: 'public-read'
                };
                try {
                    await s3Client.send(new DeleteObjectCommand(params1));
                    console.log('image deleted successfully');
                    return "";
                } catch (err) {
                    console.log("Error", err);
                }
            } catch (error) {
                Logger.logger.error(`Failed to upload file on space`, error);
                throw new DatabaseError(`Failed to upload file om space ${error.message}`)
            }
        }
    }

    public static async uploadMarketPlaceImages(file: any, membership: string, imageType: string): Promise<string> {
        Logger.logger.info('File uploding to digital ocean space..')
        try {
            let url = '';
            // get existing file extenion for add with new name
            // const fileExtension = file.originalname.split('.');
            const mimetypeValue = file.mimetype.split('/');
            let fileExtension = mimetypeValue ? mimetypeValue : 'png';
            console.log('fileExtension:', fileExtension[1]);
            const filename = `${membership}-${imageType}-${Date.now()}.${fileExtension[1]}`;

            // Define the parameters for the object for upload.
            const params1: any = {
                Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                Key: `${marketPlaceAssets}/${filename}`,
                Body: file.buffer,
                ContentType: file.mimetype,
                ACL: 'public-read'
            };
            try {
                const data = await s3Client.send(new PutObjectCommand(params1));
                console.log("Successfully uploaded object: ");
                if (data) {
                    url = `${process.env.DIGITAL_OCEAN_CDN_URL}/${marketPlaceAssets}/${filename}`;
                }
                return url;
            } catch (err) {
                console.log("Error", err);
            }
        } catch (error) {
            Logger.logger.error(`Failed to upload file on space`, error);
        }
    }

    public static async deleteuploadMarketPlaceImages(url: string): Promise<string> {
        console.log('delete url', url);
        if (url) {
            const lastSlashIndex = url.lastIndexOf('/');
            // Extract the file name using substring
            const fileName = url.substring(lastSlashIndex + 1);
            try {
                // Define the parameters for the object for upload.
                const params1: any = {
                    Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                    Key: `${marketPlaceAssets}/${fileName}`,
                    ACL: 'public-read'
                };
                try {
                    await s3Client.send(new DeleteObjectCommand(params1));
                    console.log('image deleted successfully');
                    return "";
                } catch (err) {
                    console.log("Error", err);
                }
            } catch (error) {
                Logger.logger.error(`Failed to upload file on space`, error);
                throw new DatabaseError(`Failed to upload file om space ${error.message}`)
            }
        }
    }

    public static async uploadServiceImages(file: any, membership: string, imageType: string): Promise<string> {
        Logger.logger.info('Service File uploding to digital ocean space..')
        try {
            let url = '';
            // get existing file extenion for add with new name
            const mimetypeValue = file.mimetype.split('/');
            let fileExtension = mimetypeValue ? mimetypeValue : 'png';
            const filename = `${membership}-${imageType}-${Date.now()}.${fileExtension[1]}`;
            // Define the parameters for the object for upload.
            const params1: any = {
                Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                Key: `${serviceAssets}/${filename}`,
                Body: file.buffer,
                ContentType: file.mimetype,
                ACL: 'public-read'
            };
            try {
                const data = await s3Client.send(new PutObjectCommand(params1));
                console.log("Successfully uploaded service file ");
                if (data) {
                    url = `${process.env.DIGITAL_OCEAN_CDN_URL}/${serviceAssets}/${filename}`;
                }
                return url;
            } catch (err) {
                console.log("Error", err);
            }
        } catch (error) {
            Logger.logger.error(`Failed to upload file on space`, error);
        }
    }

    public static async deleteuploadServiceImage(url: string): Promise<string> {
        console.log('delete service url', url);
        if (url) {
            const lastSlashIndex = url.lastIndexOf('/');
            // Extract the file name using substring
            const fileName = url.substring(lastSlashIndex + 1);
            try {
                // Define the parameters for the object for upload.
                const params1: any = {
                    Bucket: process.env.DIGITAL_OCEAN_SPACE_NAME,
                    Key: `${serviceAssets}/${fileName}`,
                    ACL: 'public-read'
                };
                try {
                    await s3Client.send(new DeleteObjectCommand(params1));
                    console.log('Service image deleted successfully');
                    return "";
                } catch (err) {
                    console.log("Error", err);
                }
            } catch (error) {
                Logger.logger.error(`Service Failed to upload file on space`, error);
                throw new DatabaseError(`Service Failed to upload file om space ${error.message}`)
            }
        }
    }
}