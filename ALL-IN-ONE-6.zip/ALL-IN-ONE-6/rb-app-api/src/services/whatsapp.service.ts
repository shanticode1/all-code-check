import { whatsappTemplateMap } from "../data/whatsappTemplateMap";
import { IBooking } from "../db-models/booking.db-model";
import { EmailServiceError } from "../errors/email-service.error";
import { Logger } from "../logger";
import { Business } from "../types/business";
import { BusinessService } from "../types/business-service";
import { BusinessServiceSnapshot } from "../types/business-service-snapshot";
import { PaymentType } from "../types/enums/payment-type.enum";
import { TextFormatService } from "../utils/convert-html-to-text";
import { DateUtils } from "../utils/date.utils";
import { EmailService } from "./email.service";
const { convert } = require('html-to-text');
const axios = require("axios");

export abstract class WhatsAppService {

    private static async convertHtmlToWhatsAppText(html: string): Promise<string> {
        /** format the html into whatsapp template format */
        return html
            .replace(/<\/?(p|br)>/gi, '\n') // Replace <p> and <br> tags with newlines
            .replace(/<a [^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/gi, '$1') // Replace anchor tags with URL as text
            .replace(/<strong>|<b>/gi, '*') // Replace <strong> or <b> with *
            .replace(/<\/strong>|<\/b>/gi, '*') // Replace closing </strong> or </b> with *
            .replace(/<em>|<i>/gi, '_') // Replace <em> or <i> with _
            .replace(/<\/em>|<\/i>/gi, '_') // Replace closing </em> or </i> with _
            .replace(/&nbsp;/gi, ' ') // Replace non-breaking spaces with regular spaces
            .replace(/<[^>]+>/g, '') // Remove any other HTML tags
            .trim();
    }

    public static async sendWhatsAppBookingReminderToCustomer(
        business: Business,
        serviceSnapshot: BusinessServiceSnapshot,
        bookingDoc: IBooking, matchingService: BusinessService) {
        let businesWhatsappNumber = ' ';
        let businessContactNumber = '';
        const customerPhoneNumber = bookingDoc.customer.phoneNumber == null && bookingDoc.customer.countryCode == null ? "—" : `${bookingDoc.customer.countryCode}${bookingDoc.customer.phoneNumber}`;
        const updatedPhone = customerPhoneNumber.split('+'); // remove icon of country flag of give number
        // const manualPaymentTextWithTags = (business.settings && business.settings.paymentTypes.includes(PaymentType.Manual) && business.settings.manualPaymentInfo) ? business.settings.manualPaymentInfo : '-';
        const serviceAddress = matchingService.location === 'custom-location' && serviceSnapshot.serviceAddress ? serviceSnapshot.serviceAddress : business.address;
        const options = {
            wordwrap: false,
            preserveNewlines: true, //false
            noLinkBrackets: true,
            selectors: [
                {
                    selector: 'p',
                    format: 'inline', // Treat <p> as inline to avoid extra newlines
                }
            ],
            formatters: {
                // Custom formatter to handle non-breaking spaces and multiple spaces
                inline: (elem, walk, builder) => {
                    const content = elem.children.map(child => child.data || '').join('');
                    const cleanedContent = content.replace(/\s+/g, ' ').trim(); // Replace multiple spaces with a single space
                    builder.addInline(cleanedContent);
                }
            },
            whitespaceCharacters: ' \t\r\n\f\x0B', // Trim standard whitespace characters 
        }

        // let paymentInstructionsText = convert(manualPaymentTextWithTags, options); // update html to text with links..
        const urlPattern = /\[.*?\]/g;
        // Replace URLs enclosed in square brackets with the URLs themselves
        // const updatedText = paymentInstructionsText.replace(urlPattern, '')
        const whatsappReminderHtmlText = business.settings && business.settings.whatsAppReminderInfo ? business.settings.whatsAppReminderInfo.trim() : ''
        const removeTags = convert(whatsappReminderHtmlText, options);// update html to text with links..
        // remove square brackets duplicate url 
        // const whatsappReminderInfo = await TextFormatService.removeDuplicateLines(removeTags);
        const whatsappReminderInfo = business.settings && business.settings.whatsAppReminderInfo ? await this.convertHtmlToWhatsAppText(business.settings.whatsAppReminderInfo) : '';
        if (business.socialMedia && business.socialMedia.wa) {
            // add whatsapp number of busines
            const formatedNumber = business.socialMedia.wa == null ? "—" : `${business.socialMedia.countryCode ? business.socialMedia.countryCode : '-'}${business.socialMedia.wa}`;

            businesWhatsappNumber = formatedNumber ? `💬 ${formatedNumber.trim()}` : ' '
        }
        const formatedContactNo = business.phoneNumber == null ? "—" : `${business.countryCode ? business.countryCode : '-'}${business.phoneNumber}`
        businessContactNumber = formatedContactNo ? `📞 ${formatedContactNo.trim()}` : '📞 -'

        const isProd = process.env.NODE_ENV.toLowerCase() == "production";
        let templateName;
        if (isProd) {
            templateName = whatsappTemplateMap.prod;
        } else {
            templateName = whatsappTemplateMap.test;
        }
        let data = {
            "messaging_product": "whatsapp",
            "preview_url": true,
            "to": `+${updatedPhone[1]}`, // recipient format like this : +917693868599
            "recipient_type": "individual",
            "type": "template",
            "template": {
                "name": templateName,
                "language": {
                    "code": "es"
                },
                "components": [
                    {
                        "type": "body",
                        "parameters": [
                            {
                                "type": "text",
                                "text": bookingDoc.customer.name.trim()
                            },
                            {
                                "type": "text",
                                "text": business.name == null ? "—" : business.name
                            },
                            {
                                "type": "text",
                                "text": serviceSnapshot && serviceSnapshot.serviceName ? serviceSnapshot.serviceName : "—"
                            },
                            {
                                "type": "text",
                                "text": DateUtils.toLocalDateString(bookingDoc.startDate, business.timeZone.name)
                            },
                            {
                                "type": "text",
                                "text": DateUtils.toLocalTimeString(bookingDoc.startDate, business.timeZone.name)
                            },
                            // {
                            //     "type": "text",
                            //     text: `${paymentInstructionsText ? `${updatedText.replace(/\n+/g, '\\n').trim()}` : '-'}`

                            //     //MANUAL payment instructions
                            // },
                            {
                                "type": "text",
                                "text": `${whatsappReminderInfo ? `${whatsappReminderInfo.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim()}` : '-'}` //whatsapp reminder_text
                            },
                            {
                                "type": "text",
                                "text": `${businessContactNumber} ${businesWhatsappNumber}`
                            },
                            {
                                "type": "text",
                                "text": business.settings.hideAddress ? "-" : EmailService.concatenateAddress(serviceAddress)
                            },
                            {
                                "type": "text",
                                "text": business.email
                            },
                            {
                                "type": "text",
                                "text": bookingDoc.googleMeetLink ? `🎦 ${bookingDoc.googleMeetLink}` : '-'
                            }, //add meet link if google meet location enable
                            // {
                            //     "type": "text",
                            //     "text": businesWhatsappNumber ? `💬 ${businesWhatsappNumber}` : ' '
                            // },  //add whatsapp number of business  
                        ]
                    }
                ]
            }
        }
        // console.log(JSON.stringify(data), '-----JSON.stringify(data)');
        let requestPayload = {
            method: 'post',
            url: `https://graph.facebook.com/${process.env.WHATS_APP_VERSION}/${process.env.WHATS_APP_PHONE_NUMBER_ID}/messages`,
            headers: {
                'Authorization': `Bearer ${process.env.WHATS_APP_TOKEN}`,
                'Content-Type': 'application/json'
            },
            data: data
        };
        try {
            const res = await axios.request(requestPayload);
            const messageId = res.data.messages[0].id;
            return { status: true, messageId: messageId };
        } catch (err) {
            Logger.logger.warn(
                `Failed to send whatsapp reminder to customer ${bookingDoc.customer.name}${err.message != null ? ". " + err.message : ""
                }`
            );
            throw new EmailServiceError(
                `Failed to send whatsapp reminder to customer ${bookingDoc.customer.name}`
            );
        }
    }
}