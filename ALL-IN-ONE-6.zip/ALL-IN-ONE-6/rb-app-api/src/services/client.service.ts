import { Client } from "../types/clients";
import { IClient, ClientDbModel } from "../db-models/client.db-model";
import { Logger } from "../logger";
import { DatabaseError } from "../errors/database.error";
import { BookingDbModel } from "../db-models/booking.db-model";
import { BadRequestError } from "../errors/bad-request.error";
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error";
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error";
import { UserService } from "./users.service";
import { roles } from "../data/user.roles";
import { User } from "../types/user";
import { EmailService } from "./email.service";
import { IUser, UserDbModel } from "../db-models/users.db-model";
import { Types } from 'mongoose';
import { TimeZonesService } from "./time-zones.service";
import { AddressDbModel } from "../db-models/address.db-model";
import { NotAllowedError } from "../errors/not-allow.error";

export abstract class ClientService {
    public static async getAll(businessId: string | undefined): Promise<Client[]> {
        let client: Client[] = [];
        let clientDocs: IClient[];
        try {
            clientDocs = await ClientDbModel.ClientModel.find({ businessId: businessId }).sort({ 'lastBookingDate': -1 }).exec();
        } catch (err) {
            Logger.logger.error("Failed to get client", err);
            throw new DatabaseError("Failed to get clinet");
        }

        if (clientDocs == null) {
            return null;
        }

        for await (const b of clientDocs) {
            const client_temp = ClientDbModel.convertToDomainModel(b);
            client.push(client_temp)
        }

        return client;
    }

    public static async getById(clientId: string): Promise<Client> {
        const client = await ClientDbModel.ClientModel.findOne({ _id: clientId }).exec();
        const bookings = await BookingDbModel.BookingModel.find({ clientId: clientId }).sort({ '_id': -1 }).exec();
        client.bookings = bookings

        return ClientDbModel.convertToDomainModel(client);
    }

    public static async updateNotes(client: any): Promise<Client> {
        let clientDoc = await ClientDbModel.ClientModel.findOne({ _id: client.clientId, businessId: client.businessId }).exec();

        if (clientDoc) {
            clientDoc.notes = client.notes;
            if (clientDoc.isWhatsAppAllow != null && clientDoc.isWhatsAppAllow != client.isWhatsAppAllow) {
                clientDoc.isWhatsAppAllow = client.isWhatsAppAllow;
            }
            if (clientDoc.isEmailAllow != null && clientDoc.isEmailAllow != client.isEmailAllow) {
                clientDoc.isEmailAllow = client.isEmailAllow;
            }
            clientDoc.save();
        }
        return ClientDbModel.convertToDomainModel(clientDoc)
    }

    public static async create(client: Client, fromBooking: boolean): Promise<any> {
        let clientDoc = await ClientDbModel.ClientModel.findOne({ email: client.email }).exec();
        // if (client.businessId) {
        //     clientDoc = await ClientDbModel.ClientModel.findOne({ email: client.email, businessId: client.businessId }).exec();
        // }
        if (clientDoc) {
            if (fromBooking) {
                if (client.name != null && client.name != clientDoc.name) {
                    clientDoc.name = client.name
                }
                if (client.surname != null && client.surname != clientDoc.surname) {
                    clientDoc.surname = client.surname
                }
                if (client.phone != null && client.phone != clientDoc.phone) {
                    clientDoc.phone = client.phone
                }
                if (client.countryCode != null && client.countryCode != clientDoc.countryCode) {
                    clientDoc.countryCode = client.countryCode
                }
                if (client.notes != null && client.notes != clientDoc.notes) {
                    clientDoc.notes = client.notes
                }
                if (client.lastBookingDate != null) {
                    clientDoc.lastBookingDate = client.lastBookingDate;
                }
                if (client.businessId != null && !clientDoc.businessId) {
                    clientDoc.businessId = client.businessId
                }
                // if (client.isWhatsAppAllow != null && !clientDoc.isWhatsAppAllow) {
                //     clientDoc.isWhatsAppAllow = client.isWhatsAppAllow
                // }
                // else {
                //     clientDoc.isWhatsAppAllow = true
                // }
                // if (client.isEmailAllow != null && !clientDoc.isEmailAllow) {
                //     clientDoc.isEmailAllow = client.isEmailAllow
                // }
                // else {
                //     clientDoc.isEmailAllow = true
                // }                                                
                await clientDoc.save();
            } else {
                throw new BadRequestError('Client Exist')
            }
        } else {
            let newClientDoc
            try {
                if (client.isWhatsAppAllow == undefined) client.isWhatsAppAllow = true;
                if (client.isEmailAllow == undefined) client.isEmailAllow = true;
                const newClient = ClientDbModel.convertToDbModel(client);
                newClientDoc = await ClientDbModel.ClientModel.create(newClient);
            } catch (err) {
                Logger.logger.error(
                    `Failed to create client (name: '${client.name}')`,
                    err
                );
                throw new DatabaseError(`Failed to create staff (name: '${client.name}')`);
            }

            clientDoc = newClientDoc;
        }
        return ClientDbModel.convertToDomainModel(clientDoc);
    }
    public static async partialUpdate(client: Client): Promise<Client> {
        let clientDoc: IClient = await ClientDbModel.ClientModel.findOne({ businessId: client.businessId, _id: client.id }).exec();
        if (clientDoc == null) {
            Logger.logger.warn(`Client ${clientDoc.id} of business ${clientDoc.businessId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Client ${clientDoc.id} of business ${clientDoc.businessId} doesn't exist`)
        }
        if (clientDoc) {
            if (client.isWhatsAppAllow != null && client.isWhatsAppAllow != clientDoc.isWhatsAppAllow) {
                clientDoc.isWhatsAppAllow = client.isWhatsAppAllow
            }
            if (client.isEmailAllow != null && client.isEmailAllow != clientDoc.isEmailAllow) {
                clientDoc.isEmailAllow = client.isEmailAllow
            }
            await clientDoc.save();
            return ClientDbModel.convertToDomainModel(clientDoc);
        }
        else {
            throw new BadRequestError('Client Exist')
        }
    }

    public static async partialUpdateV2(client: Client): Promise<Client> {
        let clientDoc: IClient = await ClientDbModel.ClientModel.findOne({ _id: client.id }).exec();
        if (clientDoc == null) {
            Logger.logger.warn(`Client ${client.email} of business ${client.businessId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Client ${client.email} of business ${client.businessId} doesn't exist`)
        }
        if (clientDoc) {
            if (client.name != null && client.name != clientDoc.name) {
                clientDoc.name = client.name
            }
            if (client.surname != null && client.surname != clientDoc.surname) {
                clientDoc.surname = client.surname
            }
            if (client.phone != null && client.phone != clientDoc.phone) {
                clientDoc.phone = client.phone
            }
            if (client.countryCode != null && client.countryCode != clientDoc.countryCode) {
                clientDoc.countryCode = client.countryCode
            }

            if (client.isWhatsAppAllow != null && client.isWhatsAppAllow != clientDoc.isWhatsAppAllow) {
                clientDoc.isWhatsAppAllow = client.isWhatsAppAllow
            }
            if (client.isEmailAllow != null && client.isEmailAllow != clientDoc.isEmailAllow) {
                clientDoc.isEmailAllow = client.isEmailAllow
            }
            if (client.timeZone != null && client.timeZone.id != clientDoc.timeZoneId) {
                await TimeZonesService.getById(client.timeZone.id)
                clientDoc.timeZoneId = client.timeZone.id
            }
            if (client.address != null && client.address != clientDoc.address) {
                clientDoc.address = AddressDbModel.convertToDbModel(client.address)
            }
            await clientDoc.save();
            return ClientDbModel.convertToDomainModel(clientDoc);
        }
        else {
            throw new BadRequestError('Client Exist')
        }
    }

    public static async getByEmail(businessId: string, email: string): Promise<Client> {
        const client = await ClientDbModel.ClientModel.findOne({ businessId: businessId, email: email }).exec();
        if (!client) {
            return null;
        }
        return ClientDbModel.convertToDomainModel(client);
    }

    public static async createClientAccount(client: Client, fromBooking = true): Promise<Client> {
        let emailContent;
        if (await UserService.getUserByEmailAddress(client.email) != null) {
            Logger.logger.warn(`Client with email: '${client.email}' already exists`)
            throw new ResourceAlreadyExistsError(`Client with email: '${client.email}' already exists`)
        }
        let clientDoc = await ClientDbModel.ClientModel.findOne({ email: client.email }).exec();
        // Check client in user table
        const clientName = `${client.name} ${client.surname ? client.surname : ''}`;
        const activationToken = { _id: new Types.ObjectId() };
        // create business user in user table
        const userDeatils = await UserService.createV2(
            new User(
                undefined,
                client.email,
                client.password,
                clientName,
                roles.Client,
                undefined,
                undefined,
                activationToken
            )
        )
        client.userId = userDeatils.id;
        if (clientDoc) {
            if (fromBooking) {
                if (client.name != null && client.name != clientDoc.name) {
                    clientDoc.name = client.name
                }
                if (client.surname != null && client.surname != clientDoc.surname) {
                    clientDoc.surname = client.surname
                }
                if (client.phone != null && client.phone != clientDoc.phone) {
                    clientDoc.phone = client.phone
                }
                if (client.countryCode != null && client.countryCode != clientDoc.countryCode) {
                    clientDoc.countryCode = client.countryCode
                }
                if (client.notes != null && client.notes != clientDoc.notes) {
                    clientDoc.notes = client.notes
                }
                if (client.lastBookingDate != null) {
                    clientDoc.lastBookingDate = client.lastBookingDate;
                }
                // add client country and city
                if (client.address != null && (
                    client.address.address != clientDoc.address?.address ||
                    client.address.suite != clientDoc.address?.suite ||
                    client.address.district != clientDoc.address?.district ||
                    client.address.region != clientDoc.address?.region ||
                    client.address.city != clientDoc.address?.city ||
                    client.address.postcode != clientDoc.address?.postcode ||
                    client.address.country != clientDoc.address?.country ||
                    client.address.countryShortName != clientDoc.address?.countryShortName

                )) {
                    clientDoc.address = AddressDbModel.convertToDbModel(client.address)
                }

                clientDoc.userId = userDeatils.id;
                await clientDoc.save();
                emailContent = {
                    id: clientDoc.userId,
                    activationToken: activationToken,
                    name: clientName,
                    email: client.email
                }
            } else {
                throw new BadRequestError('Client Exist')
            }
        }
        else {
            let newClientDoc
            try {
                if (client.isWhatsAppAllow == undefined) client.isWhatsAppAllow = true;
                if (client.isEmailAllow == undefined) client.isEmailAllow = true;
                if (client.address) client.address = AddressDbModel.convertToDbModel(client.address);
                const newClient = ClientDbModel.convertToDbModel(client);
                newClientDoc = await ClientDbModel.ClientModel.create(newClient);
                emailContent = {
                    id: newClientDoc.userId,
                    activationToken: activationToken,
                    name: clientName,
                    email: client.email
                }

            } catch (err) {
                Logger.logger.error(
                    `Failed to create client(name: '${client.name}')`,
                    err
                );
                throw new DatabaseError(`Failed to create staff(name: '${client.name}')`);
            }
            clientDoc = newClientDoc;
        }
        await EmailService.sendAccountActivationToClient(emailContent)
        return ClientDbModel.convertToDomainModel(clientDoc);
    }

    public static async activateAccount(id: string, activationTokenId: string): Promise<void> {
        let clientDoc: IClient, userDoc: IUser;
        try {

            // clientDoc = await ClientDbModel.ClientModel.findById(id).exec();
            // // Case 1: No client found
            // if (!clientDoc) {
            //     Logger.logger.warn(`Client not found for id: '${id}'`);
            //     throw new ReferencedResourceNotFoundError(`Client not found for id: '${id}'`);
            // }

            userDoc = await UserService.getUserByTokenId(id);
            // if (userDoc.activationToken && userDoc.activationToken.id) {
            //     Logger.logger.warn(`Client with id: '${id}' is currently not verified`)
            //     throw new NotAllowedError(`Client with id: '${id}'is currently not verified`)
            // }
            if (userDoc == null || userDoc === undefined) {
                Logger.logger.warn(`Client with id: '${id}' not exists`)
                throw new ResourceAlreadyExistsError(`Client with id: '${id}' not exists`)
            }

        } catch (err) {
            Logger.logger.error(`Failed to retrieve client by id (${id})`, err)
            throw new DatabaseError(`Failed to retrieve client by id (${id})`)
        }

        if (userDoc?.activationToken?.id != activationTokenId) {
            Logger.logger.warn(`Client ${id} or its activation token ${activationTokenId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`Client ${id} or its activation token ${activationTokenId} doesn't exist`)
        }
        userDoc.activationToken = undefined;
        try {
            await userDoc.save()
        } catch (err) {
            Logger.logger.error(`Failed to update business ${userDoc.id} when activating account`, err)
            throw new DatabaseError(`Failed to update business ${userDoc.id} when activating account`)
        }
    }

    public static async getByUserId(userId: string, hydrate = true): Promise<Client> {
        if (!userId) {
            return null
        }
        const clientDoc = await ClientDbModel.ClientModel.findOne({ userId: userId, isDeleted: false }).exec();
        if (clientDoc == null) {
            Logger.logger.warn(`client ${userId} doesn't exist`);
            return null;
        }
        const client = ClientDbModel.convertToDomainModel(clientDoc);
        return client;
    }

    public static async getByEmailId(emailId: string): Promise<Client> {
        const client = await ClientDbModel.ClientModel.findOne({ email: emailId }).exec();
        return client ? ClientDbModel.convertToDomainModel(client) : null;
    }

    public static async getByIdV2(userId: string, role: number, hydrate = true): Promise<Client> {
        if (!userId) {
            return null
        }
        const userDoc = await UserService.getUserByRole(userId, role);
        const clientDoc = await this.getByUserId(userDoc.id);

        if (clientDoc == null) {
            Logger.logger.warn(`Client ${userId} doesn't exist`);
            return null;
        }
        clientDoc.timeZone = clientDoc.timeZone && clientDoc.timeZone.id ? await TimeZonesService.getById(clientDoc.timeZone.id) : null
        clientDoc['user'] = UserDbModel.convertToDomainModel(userDoc)
        clientDoc['bookingCount'] = await this.getByClientId(clientDoc.id);
        return clientDoc;
    }

    public static async getByClientId(clientId: string): Promise<IClient> {
        const client = await ClientDbModel.ClientModel.findOne({ _id: clientId }).exec();
        return client;
    }
}