import { createEvent, EventAttributes } from 'ics'
import { IBooking } from "../db-models/booking.db-model"
import { Business } from "../types/business"
import { BusinessServiceSnapshot } from "../types/business-service-snapshot"
import ical, { ICalCalendarMethod, ICalAttendeeStatus, ICalEventStatus, ICalAttendeeType } from 'ical-generator';

export class IcsService {

	public static async generateIcs(forBusiness: boolean, business: Business, bookingDoc: IBooking, snapshot: BusinessServiceSnapshot): Promise<string> {

		const event: EventAttributes = {
			uid: bookingDoc.id,
			productId: 'rezrvapp/ics',
			start: [bookingDoc.startDate.getFullYear(), bookingDoc.startDate.getMonth() + 1, bookingDoc.startDate.getDate(), bookingDoc.startDate.getHours(), bookingDoc.startDate.getMinutes()],
			startInputType: 'utc', //utc
			startOutputType: 'utc', //utc
			end: [bookingDoc.endDate.getFullYear(), bookingDoc.endDate.getMonth() + 1, bookingDoc.endDate.getDate(), bookingDoc.endDate.getHours(), bookingDoc.endDate.getMinutes()],
			endInputType: 'utc', //utc
			endOutputType: 'utc', //utc
			title: `Rezerva con ${forBusiness ? bookingDoc.customer.name + ' ' + bookingDoc.customer.surname : business.name}`,
			description: `Para servicio ${snapshot.serviceName}`,
			location: business.address == null ?
				undefined :
				business.address.address,
			geo: business.coordinates == null ?
				undefined :
				{ lat: business.coordinates.latitude, lon: business.coordinates.latitude },
			status: 'CONFIRMED',
			busyStatus: 'BUSY',
			organizer: { name: business.name, email: business.email },
			attendees: [
				{
					name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
					email: bookingDoc.customer.email,
					rsvp: true,
					partstat: 'ACCEPTED',
					role: 'REQ-PARTICIPANT'
				}
			],
			alarms: [
				{ action: 'display', trigger: { hours: 2, before: true }, repeat: 2 }
			]
		}

		return new Promise((resolve, reject) => {
			createEvent(event, (err, value) => {
				if (err) {
					reject(err)
					return
				}

				resolve(IcsService.toBase64(value))
			})
		})
	}

	public static async generateGoogleIcs(forBusiness: boolean, business: Business, bookingDoc: IBooking, snapshot: BusinessServiceSnapshot, eventDoc: any, meetLink: string): Promise<string> {
		const googleMeetLink = meetLink ? `Google Meet Link: ${meetLink}` : '';
		const event: any = {
			uid: bookingDoc.id,
			productId: 'rezrvapp/ics',
			start: [bookingDoc.startDate.getFullYear(), bookingDoc.startDate.getMonth() + 1, bookingDoc.startDate.getDate(), bookingDoc.startDate.getHours(), bookingDoc.startDate.getMinutes()],
			startInputType: 'utc', //utc
			startOutputType: 'utc', //utc
			end: [bookingDoc.endDate.getFullYear(), bookingDoc.endDate.getMonth() + 1, bookingDoc.endDate.getDate(), bookingDoc.endDate.getHours(), bookingDoc.endDate.getMinutes()],
			endInputType: 'utc',
			endOutputType: 'utc',
			title: `Rezerva con ${forBusiness ? bookingDoc.customer.name + ' ' + bookingDoc.customer.surname : business.name}`,
			description: `Para servicio ${snapshot.serviceName} ${googleMeetLink}`,
			status: 'CONFIRMED',
			organizer: { name: business.name, email: business.email },
			attendees: [
				{
					name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
					email: bookingDoc.customer.email,
					// rsvp: true,
					partstat: "ACCEPTED", //NEEDS-ACTION for yes OR no
					role: 'REQ-PARTICIPANT',
				},
			],
			alarms: [
				{ action: 'display', trigger: { hours: 2, before: true }, repeat: 2 }
			],
		}
		return new Promise((resolve, reject) => {
			createEvent(event, (err, value) => {
				if (err) {
					reject(err)
					return
				}

				resolve(IcsService.toBase64(value))
			})
		})

	}

	private static toBase64(value: string): string {
		return Buffer.from(value).toString('base64')
	}

}