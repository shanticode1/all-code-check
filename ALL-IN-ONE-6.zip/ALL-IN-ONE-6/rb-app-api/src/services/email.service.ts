const axios = require("axios");

import { IBooking } from "../db-models/booking.db-model";
import { IBusiness } from "../db-models/business.db-model";
import { EmailServiceError } from "../errors/email-service.error";
import { Logger } from "../logger";
import { Business } from "../types/business";
import { BusinessServiceSnapshot } from "../types/business-service-snapshot";
import { Message } from "../types/send-grid/message";
import { Person } from "../types/send-grid/person";
import { Personalization } from "../types/send-grid/personalizations";
import { DateUtils } from "../utils/date.utils";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { Currency } from "../types/enums/currency";
import { Booking } from "../types/booking";
import { Address } from "../types/address";
import { Attachment } from "../types/send-grid/attachment";
import { BusinessStaffSnapshot } from "../types/business-staff-snapshot";
import { PaymentType } from "../types/enums/payment-type.enum";
import { TextFormatService } from "../utils/convert-html-to-text";
import { IUser } from "../db-models/users.db-model";
import { User } from "../types/user";
import { IStaff } from "../db-models/staff.db-model";
import { IClient } from "../db-models/client.db-model";
import { MembershipServiceSnapshot } from "../types/service-membership-snapshot";
const generatePassword = require('generate-password');
export abstract class EmailService {

  private static fromEmail = "reservations@rezrva.com";
  private static fromName = "Rezrva Team";
  //Dashboard url changed to url kiura
  private static dashboardUrl = "https://app.rezrva.com/business/bookings";
  private static smtp2goKey = process.env.SMTP2GO_KEY;
  private static rezrvaSpaUrl = process.env.REZRVA_SPA_URL;

  public static async sendBookingRequestToBusiness(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot
  ): Promise<void> {
    let noStaff =
      staffSnapshot == null ||
      staffSnapshot == undefined ||
      !staffSnapshot?.name;

    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: serviceSnapshot.serviceName,
      customer_first_name: bookingDoc.customer.name,
      customer_last_name: bookingDoc.customer.surname,
      customer_email: bookingDoc.customer.email,
      customer_phone: `${bookingDoc.customer.countryCode} ${bookingDoc.customer.phoneNumber}`,
      customer_name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      service_duration: `${serviceSnapshot.serviceDuration
        } ${EmailService.getDurationNameInSpanish(
          serviceSnapshot.serviceDuration,
          serviceSnapshot.serviceDurationUnit
        )}`,
      service_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      booking_page_url: `${EmailService.rezrvaSpaUrl}/business/booking/${bookingDoc._id}`,
      dashboard_url: EmailService.dashboardUrl,
      staff_name: noStaff ? "-" : staffSnapshot?.name,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`"${business.name}" <${business.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: noStaff ? "4437691" : "7276681",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking request email to business ${business.id
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking request email to business ${business.id} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendBookingRequestToCustomer(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot
  ): Promise<void> {
    const noStaff =
      staffSnapshot == null ||
      staffSnapshot == undefined ||
      !staffSnapshot?.name;
    const hasPayment =
      business.settings.paymentTypes.includes(PaymentType.Manual) &&
      business.settings.manualPaymentInfo;

    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: serviceSnapshot.serviceName,
      customer_name: bookingDoc.customer.name,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      service_duration: `${serviceSnapshot.serviceDuration
        } ${EmailService.getDurationNameInSpanish(
          serviceSnapshot.serviceDuration,
          serviceSnapshot.serviceDurationUnit
        )}`,
      service_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      staff_name:
        staffSnapshot == null ||
          staffSnapshot == undefined ||
          !staffSnapshot?.name
          ? "-"
          : staffSnapshot?.name,
      cancellation_url: `https://app.rezrva.com/@${business.slug}/cancel/${bookingDoc._id}/${bookingDoc.customerCancellationToken._id}`,
      manual_payment_info: hasPayment
        ? business.settings.manualPaymentInfo
        : "N/A",
    };
    let templateId = "9495583";

    if (noStaff && !hasPayment) {
      templateId = "9495583";
    } else if (noStaff && hasPayment) {
      templateId = "9788407";
    } else if (!noStaff && hasPayment) {
      templateId = "2821010";
    } else if (!noStaff && !hasPayment) {
      templateId = "2898195";
    }

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${bookingDoc.customer.name}" "${bookingDoc.customer.surname}" <${bookingDoc.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: templateId,
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking request email to customer ${bookingDoc.customer.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking request email to customer ${bookingDoc.customer.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendBookingApprovedToCustomer(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot,
    icsFileString: string,
    emailPaymentLink: string,
    paidAmount: number,
    isEventService
  ): Promise<void> {
    const noStaff =
      staffSnapshot == null ||
      staffSnapshot == undefined || isEventService
    !staffSnapshot?.name;
    const businessCountryCode = business.countryCode == null ? "—" : business.countryCode;
    const serviceAddress = serviceSnapshot.serviceAddress ? serviceSnapshot.serviceAddress : business.address;

    const addressLink = business.settings.hideAddress ? ""
      : this.constructGoogleMapsUrl(serviceAddress);
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: serviceSnapshot.serviceName,
      google_meet_link: bookingDoc.googleMeetLink ? bookingDoc.googleMeetLink : '',
      business_email: business.email,
      business_address: business.settings.hideAddress
        ? "-"
        : EmailService.concatenateAddress(serviceAddress),
      business_address_link: addressLink,
      business_phone: business.phoneNumber == null ? "—" : `${businessCountryCode}${business.phoneNumber}`,
      customer_first_name: bookingDoc.customer.name,
      customer_last_name: bookingDoc.customer.surname,
      service_description:
        serviceSnapshot.serviceDescription == null
          ? "—"
          : serviceSnapshot.serviceDescription,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      service_duration: `${serviceSnapshot.serviceDuration
        } ${EmailService.getDurationNameInSpanish(
          serviceSnapshot.serviceDuration,
          serviceSnapshot.serviceDurationUnit
        )}`,
      service_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      staff_name:
        staffSnapshot == null ||
          staffSnapshot == undefined ||
          !staffSnapshot?.name
          ? "-"
          : staffSnapshot?.name,
      customer_name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      payment_instructions: business.settings.paymentTypes.includes(PaymentType.Manual) &&
        business.settings.manualPaymentInfo ? await TextFormatService.convertHtmlToString(business.settings.manualPaymentInfo) : '',
      email_info: business.settings.emailInfo ? await TextFormatService.convertHtmlToString(business.settings.emailInfo) : '',
      cancellation_url: `https://app.rezrva.com/@${business.slug}/cancel/${bookingDoc._id}/${bookingDoc.customerCancellationToken._id}`,
      cancelation_PolicyInfo: business.settings.cancelationPolicyInfo ? await TextFormatService.convertHtmlToString(business.settings.cancelationPolicyInfo) : '',
      paid_amount: `${paidAmount ? paidAmount / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      payment_link: emailPaymentLink ? emailPaymentLink : '',
      dashboard_url: EmailService.dashboardUrl,
    };
    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${bookingDoc.customer.name}" "${bookingDoc.customer.surname}" <${bookingDoc.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: noStaff ? "8636802" : "5118888",  //old id : 8722537

      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
      attachments:
        icsFileString == null
          ? []
          : [
            {
              filename: "rezrva.ics",
              fileblob: icsFileString,
              mimetype: "application/ics",
            },
          ],
    };
    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking approved email to customer ${bookingDoc.customer.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking approved email to customer ${bookingDoc.customer.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendGoogleApprovedToCustomer(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot,
    customerGoogleIcsFileString: string,
    hangoutLink: string,
    emailPaymentLink: string,
    paidAmount: number
  ): Promise<void> {
    const businessCountryCode = business.countryCode == null ? "—" : business.countryCode;
    const serviceAddress = serviceSnapshot.serviceAddress ? serviceSnapshot.serviceAddress : business.address;

    const addressLink = business.settings.hideAddress ? ""
      : this.constructGoogleMapsUrl(serviceAddress);
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: serviceSnapshot.serviceName,
      google_meet_link: hangoutLink ? hangoutLink : '',
      business_email: business.email,
      business_address: business.settings.hideAddress
        ? "-"
        : EmailService.concatenateAddress(serviceAddress),
      business_address_link: addressLink,
      business_phone: business.phoneNumber == null ? "—" : `${businessCountryCode}${business.phoneNumber}`,
      customer_first_name: bookingDoc.customer.name,
      customer_last_name: bookingDoc.customer.surname,
      service_description:
        serviceSnapshot.serviceDescription == null
          ? "—"
          : serviceSnapshot.serviceDescription,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      service_duration: `${serviceSnapshot.serviceDuration
        } ${EmailService.getDurationNameInSpanish(
          serviceSnapshot.serviceDuration,
          serviceSnapshot.serviceDurationUnit
        )}`,
      service_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      staff_name:
        staffSnapshot == null ||
          staffSnapshot == undefined ||
          !staffSnapshot?.name
          ? "-"
          : staffSnapshot?.name,
      customer_name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      payment_instructions: business.settings.paymentTypes.includes(PaymentType.Manual) &&
        business.settings.manualPaymentInfo ? await TextFormatService.convertHtmlToString(business.settings.manualPaymentInfo) : '',
      email_info: business.settings.emailInfo ? await TextFormatService.convertHtmlToString(business.settings.emailInfo) : '',
      cancellation_url: `https://app.rezrva.com/@${business.slug}/cancel/${bookingDoc._id}/${bookingDoc.customerCancellationToken._id}`,
      cancelation_PolicyInfo: business.settings.cancelationPolicyInfo ? await TextFormatService.convertHtmlToString(business.settings.cancelationPolicyInfo) : '',
      paid_amount: `${paidAmount ? paidAmount / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      payment_link: emailPaymentLink ? emailPaymentLink : ''
    };
    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${bookingDoc.customer.name}" "${bookingDoc.customer.surname}" <${bookingDoc.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "6468450",
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
      // contentType: 'text/calendar',
      attachments:
        customerGoogleIcsFileString == null
          ? []
          : [
            {
              filename: "rezrva.ics",
              fileblob: customerGoogleIcsFileString,
              // mimetype: 'text/calendar',
              mimetype: "application/ics",
            },
          ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking approved email to customer ${bookingDoc.customer.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking approved email to customer ${bookingDoc.customer.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendBookingApprovedToBusiness(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot,
    icsFileString: string,
    googleMeetLink: string
  ): Promise<void> {
    const noStaff =
      staffSnapshot == null ||
      staffSnapshot == undefined ||
      !staffSnapshot?.name;

    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: serviceSnapshot.serviceName,
      google_meet_link: googleMeetLink ? googleMeetLink : '',
      customer_first_name: bookingDoc.customer.name,
      customer_last_name: bookingDoc.customer.surname,
      customer_name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
      customer_email: bookingDoc.customer.email,
      customer_phone: `${bookingDoc.customer.countryCode} ${bookingDoc.customer.phoneNumber}`,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      service_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      payment_instructions: business.settings.paymentTypes.includes(PaymentType.Manual) &&
        business.settings.manualPaymentInfo ? await TextFormatService.convertHtmlToString(business.settings.manualPaymentInfo) : '',
      email_info: business.settings.emailInfo ? await TextFormatService.convertHtmlToString(business.settings.emailInfo) : '',
      staff_name: noStaff ? "-" : staffSnapshot?.name,
      cancelation_PolicyInfo: business.settings.cancelationPolicyInfo ? await TextFormatService.convertHtmlToString(business.settings.cancelationPolicyInfo) : '',  
      dashboard_url: EmailService.dashboardUrl
      };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`"${business.name}" <${business.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: noStaff ? "8471686" : "2114279",
      template_data: templateData,
      attachments:
        icsFileString == null
          ? []
          : [
            {
              filename: "rezrva.ics",
              fileblob: icsFileString,
              mimetype: "application/ics",
            },
          ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking approved email to business ${business.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking approved email to business ${business.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendBookingApprovedToStaff(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot,
    icsFileString: string,
    googleMeetLink: string,
  ): Promise<void> {
    const noStaff =
      staffSnapshot == null ||
      staffSnapshot == undefined ||
      !staffSnapshot?.name;

    const templateData = {
      staff_name: noStaff ? "-" : staffSnapshot?.name,
      service_name: serviceSnapshot.serviceName,
      google_meet_link: googleMeetLink ? googleMeetLink : '',
      customer_first_name: bookingDoc.customer.name,
      customer_last_name: bookingDoc.customer.surname,
      customer_name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
      customer_email: bookingDoc.customer.email,
      // customer_phone: `${bookingDoc.customer.countryCode} ${bookingDoc.customer.phoneNumber}`,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      // service_price: `${serviceSnapshot.servicePrice / 100} ${serviceSnapshot.servicePrice == 0
      //   ? ""
      //   : Currency[serviceSnapshot.serviceCurrency]
      //   }`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      // payment_instructions: business.settings.paymentTypes.includes(PaymentType.Manual) &&
      // business.settings.manualPaymentInfo ? await TextFormatService.convertHtmlToString(business.settings.manualPaymentInfo) : '',
      // email_info: business.settings.emailInfo ? await TextFormatService.convertHtmlToString(business.settings.emailInfo) : '',
      business_name: business.name == null ? "—" : business.name,
      dashboard_url: EmailService.dashboardUrl
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`${staffSnapshot.name} <${staffSnapshot?.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: '2603616',
      template_data: templateData,
      attachments:
        icsFileString == null
          ? []
          : [
            {
              filename: "rezrva.ics",
              fileblob: icsFileString,
              mimetype: "application/ics",
            },
          ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking approved email to business ${business.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking approved email to business ${business.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendBookingRejectedToCustomer(
    business: Business,
    booking: Booking
  ): Promise<void> {
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: booking.serviceSnapshot.serviceName,
      business_link: `https://app.rezrva.com/@${business.slug}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${booking.customer.name}" "${booking.customer.surname}" <${booking.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "5506208",
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking rejected email to customer ${booking.customer.email
        } for booking ${booking.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking rejected email to customer ${booking.customer.email} for booking ${booking.id}`
      );
    }
  }

  public static async sendBookingCancelledToCustomer(
    business: Business,
    booking: Booking
  ): Promise<void> {
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      business_link: `https://app.rezrva.com/@${business.slug}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${booking.customer.name}" "${booking.customer.surname}" <${booking.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "8315947",
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking cancelled email to customer ${booking.customer.email
        } for booking ${booking.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking cancelled email to customer ${booking.customer.email} for booking ${booking.id}`
      );
    }
  }

  public static async sendBookingCancelledPayentNotProceedToCustomer(
    business: IBusiness,
    booking: IBooking
  ): Promise<void> {
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      business_link: `https://app.rezrva.com/@${business.slug}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${booking.customer.name}" "${booking.customer.surname}" <${booking.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "8315947",
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking cancelled email to customer ${booking.customer.email
        } for booking ${booking.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking cancelled email to customer ${booking.customer.email} for booking ${booking.id}`
      );
    }
  }

  public static async sendBookingCancelledToBusiness(
    business: Business,
    booking: Booking
  ): Promise<void> {
    const templateData = {
      customer_first_name: booking.customer.name,
      customer_last_name: booking.customer.surname,
      customer_email: booking.customer.email,
      customer_phone: `${booking.customer.countryCode} ${booking.customer.phoneNumber}`,
      service_name: booking.serviceSnapshot.serviceName,
      reservation_date: DateUtils.toLocalDateString(
        booking.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        booking.startDate,
        business.timeZone.name
      ),
      customer_name: `${booking.customer.name} ${booking.customer.surname}`,
      reservation_number: booking.friendlyId,
      dashboard_url: EmailService.dashboardUrl,
      staff_name:
        booking.staffSnapshot == null ||
          booking.staffSnapshot == undefined ||
          !booking.staffSnapshot?.name
          ? "-"
          : booking.staffSnapshot?.name,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`"${business.name}" <${business.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "6898071",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking cancelled email to business ${business.id
        } for booking ${booking.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking cancelled email to business ${business.id} for booking ${booking.id}`
      );
    }
  }

  public static async sendBookingCancelledToStaff(
    business: Business,
    booking: Booking,
    staff: IStaff
  ): Promise<void> {
    const templateData = {
      customer_first_name: booking.customer.name,
      customer_last_name: booking.customer.surname,
      customer_email: booking.customer.email,
      // customer_phone: `${booking.customer.countryCode} ${booking.customer.phoneNumber}`,
      service_name: booking.serviceSnapshot.serviceName,
      reservation_date: DateUtils.toLocalDateString(
        booking.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        booking.startDate,
        business.timeZone.name
      ),
      customer_name: `${booking.customer.name} ${booking.customer.surname}`,
      reservation_number: booking.friendlyId,
      dashboard_url: EmailService.dashboardUrl,
      business_name:
        business.name == null ||
          business.name == undefined ||
          !business?.name
          ? "-"
          : business?.name,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`${staff.name} <${staff.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "8973510",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking cancelled email to staff of business  ${business.id
        } for booking ${booking.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking cancelled email to staff of business ${business.id} for booking ${booking.id}`
      );
    }
  }
  public static async sendBookingReminderToCustomer(
    business: Business,
    serviceSnapshot: BusinessServiceSnapshot,
    staffSnapshot: BusinessStaffSnapshot,
    bookingDoc: IBooking,
    googleMeetLink: string,
    paymentLink: string
  ): Promise<void> {
    const noStaff =
      staffSnapshot == null ||
      staffSnapshot == undefined ||
      !staffSnapshot?.name;
    const businessCountryCode = business.countryCode == null ? "—" : business.countryCode;
    const serviceAddress = serviceSnapshot.serviceAddress ? serviceSnapshot.serviceAddress : business.address;

    const addressLink = business.settings.hideAddress ? ""
      : this.constructGoogleMapsUrl(serviceAddress);
    const templateData = {
      customer_name: bookingDoc.customer.name,
      service_name: serviceSnapshot.serviceName,
      google_meet_link: googleMeetLink ? googleMeetLink : '',
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      business_name: business.name == null ? "—" : business.name,
      business_email: business.email,
      // reservation_price: `${serviceSnapshot.servicePrice / 100} ${serviceSnapshot.servicePrice == 0
      //   ? ""
      //   : Currency[serviceSnapshot.serviceCurrency]
      //   }`,
      reservation_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      // business_phone: business.phoneNumber == null ? "—" : business.phoneNumber,
      business_phone: business.phoneNumber == null ? "—" : `${businessCountryCode}${business.phoneNumber}`,
      business_address: business.settings.hideAddress
        ? "-"
        : EmailService.concatenateAddress(serviceAddress),
      staff_name: noStaff ? "-" : staffSnapshot?.name,
      business_address_link: addressLink,
      payment_instructions: business.settings.paymentTypes.includes(PaymentType.Manual) &&
        business.settings.manualPaymentInfo ? await TextFormatService.convertHtmlToString(business.settings.manualPaymentInfo) : '',
      email_info: business.settings.emailInfo ? await TextFormatService.convertHtmlToString(business.settings.emailInfo) : '',
      payment_link: paymentLink,
      cancelation_PolicyInfo: business.settings.cancelationPolicyInfo ? await TextFormatService.convertHtmlToString(business.settings.cancelationPolicyInfo) : '',
      cancellation_url: `https://app.rezrva.com/@${business.slug}/cancel/${bookingDoc._id}/${bookingDoc.customerCancellationToken._id}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${bookingDoc.customer.name}" "${bookingDoc.customer.surname}" <${bookingDoc.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: noStaff ? "8291457" : "6260114",
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking reminder email to customer ${bookingDoc.customer.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking reminder email to customer ${bookingDoc.customer.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendAccountActivationToBusiness(
    businessDoc: IBusiness
  ): Promise<void> {
    const templateData = {
      //Change url for url kiura
      activation_url: `https://app.rezrva.com/activate/${businessDoc._id}/${businessDoc.activationToken._id}`,
      contact_name: businessDoc.contactName
        ? businessDoc.contactName
        : businessDoc.name,
    };
    let postRequest = {
      //var changed
      api_key: process.env.SMTP2GO_KEY,
      to: [`"${businessDoc.name}" <${businessDoc.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "8138365",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      console.log(err.response.data);
      Logger.logger.warn(
        `Failed to send account activation email to business ${businessDoc.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send account activation email to business ${businessDoc.id}`
      );
    }
  }
  public static async sendAccountActivationToUser(
    userDoc: IUser
  ): Promise<void> {
    const templateData = {
      //Change url for url kiura
      activation_url: `https://app.rezrva.com/activate/${userDoc._id}/${userDoc.activationToken._id}`,
      contact_name: userDoc.userName
        ? userDoc.userName
        : userDoc.userName,
    };
    let postRequest = {
      //var changed
      api_key: process.env.SMTP2GO_KEY,
      to: [`${userDoc.userName} <${userDoc.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "8138365",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      console.log(err.response.data);
      Logger.logger.warn(
        `Failed to send account activation email to business ${userDoc.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send account activation email to business ${userDoc.id}`
      );
    }
  }

  public static async sendAccountActivationToStaff(
    userDoc: User,
    staffPassword: string,
    business: IBusiness,
  ): Promise<void> {
    const templateData = {
      user_password: staffPassword,
      contact_name: userDoc.userName
        ? userDoc.userName
        : userDoc.userName,
      business_name: business.name == null ? "—" : business.name,

    };
    let postRequest = {
      //var changed
      api_key: process.env.SMTP2GO_KEY,
      to: [`${JSON.stringify(userDoc.userName)} <${userDoc.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "3245104",
      template_data: templateData,
    };
    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      console.log(err.response.data);
      Logger.logger.warn(
        `Failed to send account activation email to business ${userDoc.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send account activation email to business ${userDoc.id}`
      );
    }
  }

  public static async sendAccountActivationToClient({ id, activationToken, name, email }): Promise<void> {
    const templateData = {
      //Change url for url kiura
      activation_url: `https://app.rezrva.com/activate/${id}/${activationToken._id}?isClient=true`,
      contact_name: name,
    };
    let postRequest = {
      //var changed
      api_key: process.env.SMTP2GO_KEY,
      to: [`"${name}" <${email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "9473837",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      console.log(err.response.data);
      Logger.logger.warn(
        `Failed to send account activation email to business ${id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send account activation email to business ${id}`
      );
    }
  }

  public static async sendPasswordResetToBusiness(
    businessDoc: any
  ): Promise<void> {
    const templateData = {
      reset_url: `https://app.rezrva.com/password-reset/${businessDoc.id}/${businessDoc.passwordResetToken.id}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`"${businessDoc.name}" <${businessDoc.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "7705360",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send password reset email to business ${businessDoc.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send password reset email to business ${businessDoc.id}`
      );
    }
  }

  private static creteMessage(
    recipientEmail: string,
    recipientName: string,
    templateData: object,
    templateId: string,
    bccForRezrva: boolean = false,
    attachment: Attachment = undefined
  ): Message {
    return new Message(
      [
        new Personalization(
          [new Person(recipientEmail, recipientName)],
          bccForRezrva == false
            ? undefined
            : [new Person(EmailService.fromEmail, "Rezrva")],
          templateData
        ),
      ],
      new Person(EmailService.fromEmail, EmailService.fromName),
      attachment == null ? undefined : [attachment],
      templateId
    );
  }

  private static getDurationNameInSpanish(
    duration: number,
    durationUnit: DurationUnit
  ): string {
    switch (durationUnit) {
      case DurationUnit.Minute:
        return `minuto${duration == 1 ? "" : "s"}`;
      case DurationUnit.Hour:
        return `hora${duration == 1 ? "" : "s"}`;
      default:
        return "";
    }
  }

  public static async sendStripeEmailToCustomer(
    businessDoc: IBusiness
  ): Promise<void> {
    const templateData = {
      reset_url: `https://app.rezrva.com/password-reset/${businessDoc.id}/${businessDoc.passwordResetToken.id}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`"${businessDoc.name}" <${businessDoc.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "7705360",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send password reset email to business ${businessDoc.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send password reset email to business ${businessDoc.id}`
      );
    }
  }

  public static async sendBookingPaymentFailedToCustomer(
    business: Business,
    bookingDoc: IBooking,
    serviceSnapshot: BusinessServiceSnapshot,
    emailPaymentLink: string,
  ): Promise<void> {
    const businessCountryCode = business.countryCode == null ? "—" : business.countryCode;
    const serviceAddress = serviceSnapshot.serviceAddress ? serviceSnapshot.serviceAddress : business.address;

    const addressLink = business.settings.hideAddress ? ""
      : this.constructGoogleMapsUrl(serviceAddress);
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      service_name: serviceSnapshot.serviceName,
      google_meet_link: bookingDoc.googleMeetLink ? bookingDoc.googleMeetLink : '',
      business_email: business.email,
      business_address: business.settings.hideAddress
        ? "-"
        : EmailService.concatenateAddress(serviceAddress),
      business_address_link: addressLink,
      business_phone: business.phoneNumber == null ? "—" : `${businessCountryCode}${business.phoneNumber}`,
      customer_first_name: bookingDoc.customer.name,
      customer_last_name: bookingDoc.customer.surname,
      service_description:
        serviceSnapshot.serviceDescription == null
          ? "—"
          : serviceSnapshot.serviceDescription,
      reservation_date: DateUtils.toLocalDateString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      reservation_time: DateUtils.toLocalTimeString(
        bookingDoc.startDate,
        business.timeZone.name
      ),
      service_duration: `${serviceSnapshot.serviceDuration
        } ${EmailService.getDurationNameInSpanish(
          serviceSnapshot.serviceDuration,
          serviceSnapshot.serviceDurationUnit
        )}`,
      service_price: `${serviceSnapshot.servicePrice ? serviceSnapshot.servicePrice / 100 : 0} ${Currency[serviceSnapshot.serviceCurrency]}`,
      customer_name: `${bookingDoc.customer.name} ${bookingDoc.customer.surname}`,
      reservation_notes: bookingDoc.notes == null ? "—" : bookingDoc.notes,
      cancellation_url: `https://app.rezrva.com/@${business.slug}/cancel/${bookingDoc._id}/${bookingDoc.customerCancellationToken._id}`,
      payment_link: emailPaymentLink ? emailPaymentLink : ''
    };
    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${bookingDoc.customer.name}" "${bookingDoc.customer.surname}" <${bookingDoc.customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "7118648",

      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
      attachments: [],
    };
    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send booking approved email to customer ${bookingDoc.customer.email
        } for booking ${bookingDoc._id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send booking approved email to customer ${bookingDoc.customer.email} for booking ${bookingDoc._id}`
      );
    }
  }

  public static async sendPaymentEmailToStripeCustomer(
    businessDoc: IBusiness,
    invoiceUrl: string
  ): Promise<void> {
    const templateData = {
      invoice_payment_url: `${invoiceUrl}`,
    };

    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [`${businessDoc.name} <${businessDoc.email}>`],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "5870217",
      template_data: templateData,
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send password reset email to business ${businessDoc.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send password reset email to business ${businessDoc.id}`
      );
    }
  }

  public static async sendPackagePurchaseToCustomer(
    business: IBusiness,
    customer: IClient,
    packageSnapshot: MembershipServiceSnapshot,
    bookingLimit: number
  ): Promise<void> {

    const businessCountryCode = business.countryCode == null ? "—" : business.countryCode;
    const serviceAddress = business.address;
    const addressLink = business.settings.hideAddress ? ""
      : this.constructGoogleMapsUrl(serviceAddress);
    const templateData = {
      business_name: business.name == null ? "—" : business.name,
      package_name: packageSnapshot.membershipName,
      business_email: business.email,
      business_address: business.settings.hideAddress
        ? "-"
        : EmailService.concatenateAddress(serviceAddress),
      business_address_link: addressLink,
      business_phone: business.phoneNumber == null ? "—" : `${businessCountryCode}${business.phoneNumber}`,
      customer_first_name: customer.name,
      customer_last_name: customer.surname,
      booking_count: `${bookingLimit}`,
      package_price: `${packageSnapshot.membershipPrice ? packageSnapshot.membershipPrice / 100 : 0} ${Currency[packageSnapshot.membershipCurrency]}`,
      customer_name: `${customer.name} ${customer.surname}`,
      business_url: `https://app.rezrva.com/@${business.slug}`,
    };
    let postRequest = {
      api_key: EmailService.smtp2goKey,
      to: [
        `"${customer.name}" "${customer.surname}" <${customer.email}>`,
      ],
      sender: `${EmailService.fromName} <${EmailService.fromEmail}>`,
      template_id: "1279704",
      template_data: templateData,
      custom_headers: [
        {
          header: "Reply-To",
          value: `${business.name} <${business.email}>`,
        },
      ],
    };

    try {
      await axios.post("https://api.smtp2go.com/v3/email/send", postRequest);
    } catch (err) {
      Logger.logger.warn(
        `Failed to send package approved email to customer ${customer.email
        } for package ${packageSnapshot.id}${err.message != null ? ". " + err.message : ""
        }`
      );
      throw new EmailServiceError(
        `Failed to send package approved email to customer ${customer.email} for package ${packageSnapshot.id}`
      );
    }
  }

  public static concatenateAddress(address: Address): string {
    if (address == null) {
      return "—";
    }
    return `${address.address}, ${address.city}, ${address.country}`;
  }


  public static generatePassword(): string {
    // Generate a random password
    const password = generatePassword.generate({
      length: 12, // Specify the length of the password
      numbers: true, // Include numbers
      symbols: true, // Include symbols
      uppercase: true, // Include uppercase letters
      lowercase: true, // Include lowercase letters
      excludeSimilarCharacters: true, // Exclude similar characters (like 'i' and 'l')
      strict: true // Strict mode ensures the password includes at least one character from each selected type
    });
    return password
  }

  // Function to construct the Google Maps URL
  public static constructGoogleMapsUrl(address) {
    const { address: addr = '', city = '', region = '', postcode = '', country = '' } = address;
    const parts = [addr, city, region, postcode, country].filter(part => part !== '');
    const encodedAddress = parts.join(', ');
    return `https://www.google.com/maps?q=${encodeURIComponent(encodedAddress)}`;
  }

}
