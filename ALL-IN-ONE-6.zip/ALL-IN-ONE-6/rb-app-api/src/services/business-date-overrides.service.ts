import { BusinessDateOverridesDbModel } from "../db-models/business-date-overrides.db-model";
import { DatabaseError } from "../errors/database.error";
import { Logger } from "../logger";
import { BusinessDateOverrides } from "../types/business-date-overrides";

export abstract class BusinessDateOverridesService {
    public static async get(businessId: string): Promise<any> { 
        let overrideDoc = await BusinessDateOverridesDbModel.BusinessHourOverrideModel.findOne({ businessId: businessId}).exec();
        if (overrideDoc) {
            return BusinessDateOverridesDbModel.convertToDomainModel(overrideDoc);
        } else {
            return []
        }
    }

    public static async update(override: BusinessDateOverrides): Promise<any> {
        let overrideDoc = await BusinessDateOverridesDbModel.BusinessHourOverrideModel.findOne({ businessId: override.businessId}).exec();

        if (overrideDoc) {
            overrideDoc.blockoutDates = override.blockoutDates;
            overrideDoc.save();
        } else {
            let newOverrideDoc = BusinessDateOverridesDbModel.convertToDbModel(override)
    
            try {
                await BusinessDateOverridesDbModel.BusinessHourOverrideModel.create(newOverrideDoc)
            } catch (err) {
                Logger.logger.error(`Failed to create override (business: '${override.businessId}')`, err)
                throw new DatabaseError(`Failed to create override (business: '${override.businessId}')`)
            }
        }

        return BusinessDateOverridesDbModel.convertToDomainModel(overrideDoc)
    }
}