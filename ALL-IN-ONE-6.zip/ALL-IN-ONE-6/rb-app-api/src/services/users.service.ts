import { roles } from "../data/user.roles"
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model"
import { IUser, UserDbModel } from "../db-models/users.db-model"
import { DatabaseError } from "../errors/database.error"
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error"
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error"
import { Logger } from "../logger"
import { Business } from "../types/business"
import { MembershipTier } from "../types/enums/membership-tier.enum"
import { User } from "../types/user"
import { BusinessesService } from "./businesses.service"
import { EmailService } from "./email.service"
import * as bcrypt from "bcrypt"
import { StaffService } from "./staff.service"
import { Staff } from "../types/staff"
import { IStaff, StaffDbModel } from "../db-models/staff.db-model"

export abstract class UserService {

    public static async create(user: User): Promise<User> {
        const userData = await UserService.getUserByEmail(user.email);
        if (userData != null) {
            Logger.logger.warn(`User with email: '${user.email}' already exists`)
            throw new ResourceAlreadyExistsError(`User with email: '${user.email}' already exists`)
        }
        let staffPassword = '';
        try {
            if (user.role === roles.staff) {
                // gemerate rendom password for staff
                staffPassword = await EmailService.generatePassword();
                user.password = staffPassword;
            }
            user.password = await bcrypt.hash(user.password, 11);

        } catch (err) {
            Logger.logger.error(`Failed to hash password when creating user (email: '${user.email}')`, err)
            throw Error(`Failed to hash password when creating a new user (email: '${user.email}')`)
        }
        user.isActive = true
        user.isDeleted = false

        const userDoc = UserDbModel.convertToDbModel(user)
        try {
            const userResult = await UserDbModel.UserModel.create(userDoc);
            const userId = userResult._id.toHexString();
            if (user.role === roles.Business) {
                // userDoc.activationToken = new Object() as Document
                // save data inside business table when create user
                await BusinessesService.create(
                    new Business(
                        undefined,
                        userId,
                        user.userName,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        user.email,
                        user.password,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        MembershipTier.Free,
                        new Date(),
                        new Date(),
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined
                    )
                )
                await EmailService.sendAccountActivationToUser(userDoc)
            } else if (user.role === roles.staff) {
                await StaffService.create(
                    new Staff(
                        undefined,
                        undefined,
                        undefined,
                        user.userName,
                        user.email,
                        undefined,
                        userId,
                        undefined,
                        undefined,
                        true,
                        false,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined,
                        undefined
                    )
                )
                // save staff data inside staff table with userId
                // await EmailService.sendAccountActivationToStaff(userDoc, staffPassword,businessDoc)
            }

        } catch (err) {
            Logger.logger.error(`Failed to create user (email: '${user.email}')`, err)
            throw new DatabaseError(`Failed to create user (email: '${user.email}')`)
        }

        return UserDbModel.convertToDomainModel(userDoc)
    }

    public static async createV2(user: User): Promise<User> {
        // const userData = await UserService.getUserByEmail(user.email);
        // if (userData != null) {
        //     Logger.logger.warn(`User with email: '${user.email}' already exists`)
        //     throw new ResourceAlreadyExistsError(`User with email: '${user.email}' already exists`)
        // }

        try {
            user.password = await bcrypt.hash(user.password, 11);
        } catch (err) {
            Logger.logger.error(`Failed to hash password when creating user (email: '${user.email}')`, err)
            throw Error(`Failed to hash password when creating a new user (email: '${user.email}')`)
        }
        user.isActive = true
        user.isDeleted = false
        const userDoc = UserDbModel.convertToDbModel(user)
        try {
            await UserDbModel.UserModel.create(userDoc);
        } catch (err) {
            Logger.logger.error(`Failed to create user (email: '${user.email}')`, err)
            throw new DatabaseError(`Failed to create user (email: '${user.email}')`)
        }
        return UserDbModel.convertToDomainModel(userDoc)
    }

    public static async getUserByEmail(email: string): Promise<IUser> {
        let userDoc: IUser
        try {
            // userDoc = await UserDbModel.UserModel.findOne({ email: email.toLowerCase(), activationToken: undefined, isDeleted: false }).exec()
            userDoc = await UserDbModel.UserModel.findOne({ email: email.toLowerCase(), isDeleted: false }).exec()

        } catch (err) {
            Logger.logger.error("Failed to get user by e-mail", err)
            throw new DatabaseError("Failed to get user by e-mail")
        }

        return userDoc
    }

    public static async getUserByEmailAddress(email: string): Promise<IUser> {
        try {
            return await UserDbModel.UserModel.findOne({ email: email.toLowerCase(), isDeleted: false }).exec()
        } catch (err) {
            Logger.logger.error("Failed to get user by email and role ", err)
            throw new DatabaseError("Failed to get user by email and role")
        }
    }

    public static async getUserById(userId: string): Promise<IUser> {
        try {
            return await UserDbModel.UserModel.findOne({ _id: userId, activationToken: undefined, isDeleted: false }).exec()
        } catch (err) {
            Logger.logger.error(`Failed to retrieve user by id (${userId})`, err)
            throw new DatabaseError(`Failed to retrieve user by id (${userId})`)
        }
    }

    public static async getUserByRole(userId: string, role: number): Promise<any> {
        let result = null;
        try {
            result = await UserDbModel.UserModel.findOne({ _id: userId, role: role, isDeleted: false }).exec()
        } catch (err) {
            Logger.logger.error(`Failed to retrieve user by id (${userId})`, err)
            throw new DatabaseError(`Failed to retrieve user by id (${userId})`)
        }
        return result;
    }
    public static async activateUserAccount(userId: string, activationTokenId: string): Promise<void> {
        let userDoc: IUser
        try {
            userDoc = await UserDbModel.UserModel.findById(userId).exec()
        } catch (err) {
            Logger.logger.error(`Failed to retrieve business by id (${userId})`, err)
            throw new DatabaseError(`Failed to retrieve business by id (${userId})`)
        }

        if (userDoc?.activationToken?.id != activationTokenId) {
            Logger.logger.warn(`User ${userId} or its activation token ${activationTokenId} doesn't exist`)
            throw new ReferencedResourceNotFoundError(`User ${userId} or its activation token ${activationTokenId} doesn't exist`)
        }
        const businessDoc = await BusinessDbModel.BusinessModel.findOne({ userId: userDoc.id })
        userDoc.activationToken = undefined;
        businessDoc.activationToken = undefined;
        try {
            await userDoc.save()
            await businessDoc.save();
        } catch (err) {
            Logger.logger.error(`Failed to update user ${userDoc.id} when activating account`, err)
            throw new DatabaseError(`Failed to update user ${userDoc.id} when activating account`)
        }
    }

    public static async partialUpdate(user: User): Promise<IUser> {
        try {
            // check user 
            const userData = await UserService.getUserById(user.id);
            if (userData == null) {
                Logger.logger.warn(`User with email: '${user.email}' not exists`)
                throw new ReferencedResourceNotFoundError(`User with email: '${user.email}' not exists`)
            }
            if (user.email != null && user.email != userData.email) {
                userData.email = user.email;
            }

            if (user.password != null && user.password != userData.password) {
                userData.password = await bcrypt.hash(user.password, 11);
            }

            if (user.userName != null && user.userName != userData.userName) {
                userData.userName = user.userName;
            }

            await userData.save()
            return
        } catch (error) {
            Logger.logger.error(`Failed to update user by id (${user.id})`, error)
            throw new DatabaseError(`Failed to update user by id (${user.id})`)
        }
    }

    public static async getUserDocById(id: string, role: number): Promise<any> {
        try {
            if (role === roles.Business) {
                return await BusinessDbModel.BusinessModel.findOne({ _id: id, activationToken: undefined, isDeleted: false }).exec()
            }
            if (role === roles.staff) {
                return await StaffDbModel.StaffModel.findOne({ _id: id, isDeleted: false }).exec()
            }
        } catch (err) {
            Logger.logger.error(`Failed to retrieve user by id (${id})`, err)
            throw new DatabaseError(`Failed to retrieve user by id (${id})`)
        }
    }

    public static async login(user) {
        const userDoc = await UserService.getUserByEmail(user.email)
        if (userDoc == null) {
            return null
        }
        try {
            if (await bcrypt.compare(user.password, userDoc.password) == false) {
                return null
            }
            const businessDoc = await BusinessesService.getBusinessesDocByUserId(userDoc.id);
            const businesses = await businessDoc.map(bs => BusinessDbModel.convertToDomainModel(bs))

            const staffDoc = await StaffService.getStaffsDocByUserIdV2(userDoc.id);
            const staffs = await staffDoc.map(st => StaffDbModel.convertToDomainModel(st))

            return {
                businesses: businesses,
                staffs: staffs
            }
        } catch (err) {
            Logger.logger.error("Failed to compare passwords", err)
            throw new Error("Failed to compare passwords")
        }
    }

    public static async getUserByTokenId(userId: string): Promise<IUser> {
        try {
            return await UserDbModel.UserModel.findOne({ _id: userId, isDeleted: false }).exec()
        } catch (err) {
            Logger.logger.error(`Failed to retrieve user by id (${userId})`, err)
            throw new DatabaseError(`Failed to retrieve user by id (${userId})`)
        }
    }
}