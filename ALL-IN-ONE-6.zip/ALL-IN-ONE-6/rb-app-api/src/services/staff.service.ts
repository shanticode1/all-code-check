import { BadRequestError } from "../errors/bad-request.error";
import { DatabaseError } from "../errors/database.error";
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error";
import { Logger } from "../logger";
import { IStaff, StaffDbModel } from "../db-models/staff.db-model";
import { Staff } from "../types/staff";
import {
  IStaffHoursBlock,
  StaffHoursBlockDbModel,
} from "../db-models/staff-hours-block.db-model";
import { StaffHoursBlock } from "../types/staff-hours-block";
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error";
import { UserService } from "./users.service";
import { User } from "../types/user";
import { roles } from "../data/user.roles";
import { EmailService } from "./email.service";
import * as bcrypt from "bcrypt"
import { GoogleTokenValidator } from "../utils/google-token-validator";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { BusinessServicesService } from "./business-services.service";
import { BusinessesService } from "./businesses.service";
import { NotAllowedError } from "../errors/not-allow.error";
import { BusinessTypesService } from "./business-types.service";
import { TimeZonesService } from "./time-zones.service";
import { BusinessDateOverridesService } from "./business-date-overrides.service";
import { StripeService } from "./stripe.service";
import { staffCount } from "../data/whatsappTemplateMap";
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model";
import { UploadFileService } from "./upload.file.service";
import { UserDbModel } from "../db-models/users.db-model";

export abstract class StaffService {
  public static async getById(staffId: string, businessId: string, hydrate = true): Promise<Staff> {
    if (!staffId) {
      return null
    }
    const staffDoc = await StaffService.getStaffDocById(staffId, businessId);
    if (staffDoc == null) {
      Logger.logger.warn(`Staff ${staffId} doesn't exist`);
      return null;
    }

    const staff = StaffDbModel.convertToDomainModel(staffDoc);
    return staff;

  }

  public static async getStaffById(staffId: string, businessId: string, hydrate = true): Promise<Staff> {
    if (!staffId) {
      return null
    }
    const staffDoc = await StaffService.getStaffDocByIdV4(staffId, businessId);
    if (staffDoc == null) {
      Logger.logger.warn(`Staff ${staffId} doesn't exist`);
      return null;
    }

    const staff = StaffDbModel.convertToDomainModel(staffDoc);
    return staff;
  }
  public static async getByIdV2(userId: string, role: number, hydrate = true): Promise<Staff> {
    if (!userId) {
      return null
    }
    const userDoc = await UserService.getUserByRole(userId, role);
    const staffDoc = await StaffService.getStaffDocByIdV2(userDoc.id);
    if (staffDoc == null) {
      Logger.logger.warn(`Staff ${userId} doesn't exist`);
      return null;
    }
    const businessDoc = await BusinessesService.getBusinessDocById(staffDoc.businessId)
    staffDoc.business = businessDoc;
    staffDoc.user = userDoc;
    const staff = StaffDbModel.convertToDomainModel(staffDoc);
    if (hydrate == true) {
      await this.hydrateStaff(staff)
    }
    if (staff && staff.googleToken) {
      await GoogleTokenValidator.setGlobalVariable(true)
      const isGoogleTokenValid = await GoogleTokenValidator.getGlobalVariable();
      delete staff.googleToken;
      delete staff.syncEventToken;
      delete staff.gEventWatchId;
      delete staff.gResourceId;
      staff['isGoogleTokenValid'] = isGoogleTokenValid;
    } else {
      staff['isGoogleTokenValid'] = false;
      delete staff.googleToken;
      delete staff.syncEventToken;
      delete staff.gEventWatchId;
      delete staff.gResourceId;
    }
    return staff;
  }

  private static async hydrateStaff(staff: Staff): Promise<void> {
    const services = await BusinessServicesService.getStaffServices(staff)
    staff.services = services.length == 0 ? undefined : services;
    staff.business.type = staff.business.type == null ? undefined : await BusinessTypesService.getById(staff.business.type.id)
    staff.business.timeZone = await TimeZonesService.getById(staff.business.timeZone.id)
    staff.timeZone = staff.business.timeZone;
    const overrides = await BusinessDateOverridesService.get(staff.business.id);
    staff.business.blockoutDates = overrides.blockoutDates || []
  }

  public static async getByUserId(userId: string, hydrate = true): Promise<Staff> {
    if (!userId) {
      return null
    }

    const staffDoc = await StaffDbModel.StaffModel.findOne({ userId: userId, isDeleted: false }).exec();

    if (staffDoc == null) {
      Logger.logger.warn(`Staff ${userId} doesn't exist`);
      return null;
    }

    const staff = StaffDbModel.convertToDomainModel(staffDoc);
    return staff;
  }

  public static async getStaffDoc(id: string): Promise<IStaff> {
    try {
      return await StaffDbModel.StaffModel.findOne({ _id: id, isDeleted: false, isActive: true }).exec()
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by id (${id})`, err)
      throw new DatabaseError(`Failed to retrieve staff by id (${id})`)
    }
  }
  public static async getStaffDocByObjectId(id: string): Promise<any> {
    try {
      return await StaffDbModel.StaffModel.findOne({ _id: id, isDeleted: false, isActive: true }).exec()
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by id (${id})`, err)
      throw new DatabaseError(`Failed to retrieve staff by id (${id})`)
    }
  }

  public static async getByIds(snapshotIds: string[]): Promise<Staff[]> {
    const uniqueSnapshotIds = snapshotIds.filter((sid, index, sids) => {
      if (sid !== undefined && sid !== '' && sid !== null) {
        return sids.indexOf(sid) == index
      }
    })
    let staffSnapshotDoc: IStaff[]
    try {
      staffSnapshotDoc = await StaffDbModel.StaffModel.find({ _id: { $in: uniqueSnapshotIds } }).exec()
    } catch (err) {
      Logger.logger.error(`Failed to retrieve business service snapshots by ids [${uniqueSnapshotIds.join(', ')}]`, err)
      throw new DatabaseError(`Failed to retrieve business service snapshots by ids [${uniqueSnapshotIds.join(', ')}]`)
    }

    return staffSnapshotDoc.map(ss => StaffDbModel.convertToDomainModel(ss))
  }

  public static async getAll(businessId: string | undefined, withDeleted: string): Promise<Staff[]> {
    // const businessDoc = await BusinessesService.getBusinessDocById(businessId)
    // await StaffService.updateExtraBusinessStaffToInactiveV2(businessDoc);
    let staff: Staff[] = [];
    let staffDocs: IStaff[];
    let parmsObj: any = { isDeleted: false, businessId: businessId };
    if (withDeleted == 'true') {
      parmsObj = { businessId: businessId };
    }
    try {
      staffDocs = await StaffDbModel.StaffModel.find(parmsObj).exec();
    } catch (err) {
      Logger.logger.error("Failed to get staff", err);
      throw new DatabaseError("Failed to get staff");
    }

    if (staffDocs == null) {
      return null;
    }
    for await (const b of staffDocs) {
      const staff_temp = StaffDbModel.convertToDomainModel(b);
      delete staff_temp.isDeleted;
      staff.push(staff_temp);
    }

    return staff;
  }

  public static async getStaffByService(serviceId: string): Promise<Staff[]> {
    let staff: Staff[] = [];
    let staffDocs: IStaff[];
    // get business bu serviceId
    const serviceBusinessDoc = await BusinessServicesService.getBusinessServiceById(serviceId);
    if (serviceBusinessDoc == null) {
      Logger.logger.warn(`Service ${serviceId} doesn't exist`);
      throw new ReferencedResourceNotFoundError(
        `Service ${serviceId} doesn't exist`
      );
    }
    const businessDoc = serviceBusinessDoc;
    let parmsObj: any = { servicesId: serviceId, isDeleted: false, isActive: true };
    try {
      if (businessDoc && businessDoc.isAnnualActive || businessDoc.membershipTier === MembershipTier.Pro || (businessDoc.stripePriceIds && businessDoc.stripePriceIds.staffUsagePriceId)) {
        staffDocs = await StaffDbModel.StaffModel.find(parmsObj).exec();
      } else {
        staffDocs = []
      }
    } catch (err) {
      Logger.logger.error("Failed to get staff", err);
      throw new DatabaseError("Failed to get staff");
    }

    if (staffDocs.length == 0) {
      return null;
    }

    for await (const b of staffDocs) {
      const staff_temp = StaffDbModel.convertToDomainModel(b);
      delete staff_temp.isDeleted;
      delete staff_temp.isActive;
      delete staff_temp.businessId;
      delete staff_temp.servicesId;
      staff.push(staff_temp);
    }
    return staff;
  }

  public static async getStaffByServiceV2(serviceId: string): Promise<Staff[]> {
    let staff: Staff[] = [];
    let staffDocs: IStaff[];
    // get business bu serviceId
    const serviceBusinessDoc = await BusinessServicesService.getBusinessServiceById(serviceId);
    if (serviceBusinessDoc == null) {
      Logger.logger.warn(`Service ${serviceId} doesn't exist`);
      throw new ReferencedResourceNotFoundError(
        `Service ${serviceId} doesn't exist`
      );
    }
    const businessDoc = serviceBusinessDoc;
    let parmsObj: any = { servicesId: serviceId, isDeleted: false, isActive: true };
    try {
      if (businessDoc && businessDoc.isAnnualActive || businessDoc.membershipTier === MembershipTier.Pro || (businessDoc.stripePriceIds && businessDoc.stripePriceIds.staffUsagePriceId)) {
        staffDocs = await StaffDbModel.StaffModel.find(parmsObj).exec();
      } else {
        staffDocs = []
      }
    } catch (err) {
      Logger.logger.error("Failed to get staff", err);
      throw new DatabaseError("Failed to get staff");
    }

    if (staffDocs.length == 0) {
      return null;
    }

    for await (const b of staffDocs) {
      const staff_temp = StaffDbModel.convertToDomainModel(b);
      delete staff_temp.isDeleted;
      delete staff_temp.isActive;
      delete staff_temp.businessId;
      delete staff_temp.servicesId;
      delete staff_temp.userId;
      delete staff_temp.isActiveByBusiness
      delete staff_temp.isAllow
      delete staff_temp.userId
      staff.push(staff_temp);
    }    
    return staff;
  }

  public static async create(staff: Staff): Promise<Staff> {    
    staff.isDeleted = false;
    // check existing staff with email
    // const staffData = await StaffDbModel.StaffModel.findOne({ email: staff.email });
    if (staff.email) {
      const staffData = await UserDbModel.UserModel.findOne({ email: staff.email, isDeleted: false });
      const staffUserDoc = await StaffDbModel.StaffModel.findOne({ email: staff.email, isDeleted: false });
      if (staffData != null && staffUserDoc != null) {
        // Staff with email: '${staff.email}' already exists
        Logger.logger.warn(`El personal con correo electrónico: '${staff.email}' ya existe`)
        throw new ResourceAlreadyExistsError(`El personal con correo electrónico: '${staff.email}' ya existe`)
      }
    }
    /* find business and check staff count**/
    const businessDoc = await BusinessesService.getBusinessDocById(staff.businessId)
    if (businessDoc == null) {
      Logger.logger.warn(`Business ${staff.businessId} doesn't exist`)
      throw new ReferencedResourceNotFoundError(`Business ${staff.businessId} doesn't exist`)
    }
    // get total active staffs of business 
    const businessStaffCount = await this.getStaffByBusinessId(businessDoc.id);

    // if user don't have any staff plan
    if (!businessDoc.isAnnualActive) {
      if ((MembershipTier.Plus === businessDoc.membershipTier || MembershipTier.Free === businessDoc.membershipTier) && (businessDoc.stripePriceIds && businessDoc.stripePriceIds['staffUsagePriceId'] == '' || businessDoc.stripePriceIds['staffUsagePriceId'] == undefined)) {
        Logger.logger.warn(`No tener ningún plan de personal activo de Negocios. ${staff.businessId}`)
        throw new NotAllowedError(`No tener ningún plan de personal activo de Negocios. ${staff.businessId}`);
      }
    }

    // when staff limit was reached of any account stop create staff
    // if ((businessDoc.membershipTier === MembershipTier.Pro && businessDoc.membershipStaffCount == staffCount.proCount || ((businessDoc.membershipTier === MembershipTier.Free || businessDoc.membershipTier === MembershipTier.Plus) && businessDoc && businessDoc.membershipStaffCount == staffCount.basic_count)) && businessDoc.stripePriceIds.staffUsagePriceId === '') {
    //   Logger.logger.warn(`Method not allow to create staff of Business. ${staff.businessId}`)
    //   throw new NotAllowedError(`Method not allow to create staff of Business. ${staff.businessId}`);
    // }

    // when staff limit was reached 

    // add free count with paid count for manage conditions based on user membership
    const totalBusinessStaffs = businessDoc.membershipTier === MembershipTier.Pro ? (businessDoc.membershipStaffCount + staffCount.pro_count) : businessDoc.membershipStaffCount;
    // 2>=2 true
    if (!businessDoc.isAnnualActive) {
      if (businessStaffCount !== 0 && businessStaffCount >= totalBusinessStaffs) {
        Logger.logger.warn(`Se ha alcanzado el límite de personal.`)
        throw new NotAllowedError(`Se ha alcanzado el límite de personal.`);
      }
    }

    if (staff.email) {
      // create staff password
      const staffPassword = await EmailService.generatePassword();
      // staff.password = await bcrypt.hash(staffPassword, 11);
      let staffUserDoc: User = await UserDbModel.UserModel.findOne({ email: staff.email, isDeleted: false });
      if (!staffUserDoc) {
        let staffUserDeleted = await UserDbModel.UserModel.findOne({ email: staff.email, isDeleted: true });
        if (staffUserDeleted) {
          // if user is deleted then update user
          staffUserDeleted.isDeleted = false;
          staffUserDeleted.isActive = true;
          staffUserDeleted.password = await bcrypt.hash(staffPassword, 11);
          staffUserDoc = await staffUserDeleted.save();
        } else {
          // create staff in user table
          staffUserDoc = await UserService.createV2(
            new User(
              undefined,
              staff.email,
              staffPassword,
              staff.name,
              roles.staff,
              undefined,
              undefined,
              undefined
            )
          )
        }
      }

      staff.userId = staffUserDoc.id;
      await EmailService.sendAccountActivationToStaff(staffUserDoc, staffPassword, businessDoc);
    }
    // save profile pic of staff
    if (staff.logo !== undefined && staff.logo != null && staff.logo != '') {
      // upload file to digital ocean
      const url = await UploadFileService.uploadStaffImages(staff.logo, staff, "logo-image");
      staff.logo = url;
    }
    staff.isActiveByBusiness = true;    
    const staffDoc = StaffDbModel.convertToDbModel(staff);
    try {
      await StaffDbModel.StaffModel.create(staffDoc);
      //send mail to staff with Generate Random Password 

      // update new business staff count
      // if (businessDoc.membershipTier === MembershipTier.Pro && businessDoc.membershipStaffCount <= staffCount.proCount) {
      //   // add staff on usages plan when regular plan limit reached
      //   businessDoc.membershipStaffCount = businessDoc.membershipStaffCount + 1;
      // } else if (businessDoc.membershipTier === MembershipTier.Pro && businessDoc.membershipStaffCount >= staffCount.proCount) {
      //   await StripeService.createStaffRecordUsage(businessDoc, 1, "");
      //   businessDoc.membershipStaffCount = businessDoc.membershipStaffCount + 1;
      // }
      // if (businessDoc.membershipTier === MembershipTier.Free || businessDoc.membershipTier === MembershipTier.Plus && businessDoc.membershipStaffCount <= staffCount.basic_count) {
      //   // add staff on usages plan when regular plan limit reached
      //   businessDoc.membershipStaffCount = businessDoc.membershipStaffCount + 1;
      // }
      // // update new business staff count
      // else if (businessDoc.membershipTier === MembershipTier.Free || businessDoc.membershipTier === MembershipTier.Plus && businessDoc.stripePriceIds && businessDoc.stripePriceIds.staffUsagePriceId && businessDoc.membershipStaffCount >= staffCount.basic_count) {
      //   // add staff on usages plan when regular plan limit reached
      //   await StripeService.createStaffRecordUsage(businessDoc, 1, "");
      //   businessDoc.membershipStaffCount = businessDoc.membershipStaffCount + 1;
      // }
      // await businessDoc.save()
    } catch (err) {
      Logger.logger.error(
        `Failed to create staff (name: '${staff.name}')`,
        err
      );
      throw new DatabaseError(`Failed to create staff (name: '${staff.name}')`);
    }
    return StaffDbModel.convertToDomainModel(staffDoc);
  }

  public static async partialUpdate(staff: Staff): Promise<Staff> {    
    let userDoc = null;
    const currentStaffDoc = await StaffService.getStaffDocById(staff.id, staff.businessId);
    if (currentStaffDoc == null) {
      Logger.logger.warn(`Staff ${staff.id} doesn't exist`);
      throw new ReferencedResourceNotFoundError(
        `Staff ${staff.id} doesn't exist`
      );
    }
    /* find business and check staff count**/
    const businessDoc = await BusinessesService.getBusinessDocById(staff.businessId)
    if (businessDoc == null) {
      Logger.logger.warn(`Business ${staff.businessId} doesn't exist`)
      throw new ReferencedResourceNotFoundError(`Business ${staff.businessId} doesn't exist`)
    }
    // if user don't have any staff plan
    if (!businessDoc.isAnnualActive) {
      if ((MembershipTier.Plus === businessDoc.membershipTier || MembershipTier.Free === businessDoc.membershipTier) && businessDoc.stripePriceIds && (businessDoc.stripePriceIds['staffUsagePriceId'] == '' || businessDoc.stripePriceIds['staffUsagePriceId'] == undefined)) {
        Logger.logger.warn(`No tener ningún plan de personal activo de Negocios. ${staff.businessId}`)
        throw new NotAllowedError(`No tener ningún plan de personal activo de Negocios. ${staff.businessId}`);
      }
    }
    let resourceNotModified = true;
    userDoc = staff.email ? await UserService.getUserByEmailAddress(staff.email) : null;
    // add staff in user table if not exist
    if (staff.email != null && staff.email != currentStaffDoc.email) {
      const staffUserDoc = await StaffDbModel.StaffModel.findOne({ email: staff.email, isDeleted: false });
      if (userDoc != null && staffUserDoc != null) {
        // Staff with email: '${staff.email}' already exists
        Logger.logger.warn(`El personal con correo electrónico: '${staff.email}' ya existe`)
        throw new ResourceAlreadyExistsError(`El personal con correo electrónico: '${staff.email}' ya existe`)
      } else if (staffUserDoc) {
        userDoc = staffUserDoc.email ? await UserService.getUserByEmailAddress(staffUserDoc.email) : null;
        if (userDoc) {
          userDoc.isDeleted = true;
          await userDoc.save()
        }
      }
      const staffPassword = await EmailService.generatePassword();
      if (staff.email && userDoc == null || (userDoc && (userDoc.password == undefined || userDoc.password == null))) {
        // create staff password
        // create staff in user table
        let staffUserDoc: User = await UserDbModel.UserModel.findOne({ email: staff.email, isDeleted: false });
        if (!staffUserDoc) {
          let staffUserDeleted = await UserDbModel.UserModel.findOne({ email: staff.email, isDeleted: true });
          if (staffUserDeleted) {
            // if user is deleted then update user
            staffUserDeleted.isDeleted = false;
            staffUserDeleted.isActive = true;
            staffUserDeleted.password = await bcrypt.hash(staffPassword, 11);;
            staffUserDoc = await staffUserDeleted.save();
          } else {
            staffUserDoc = await UserService.createV2(
              new User(
                undefined,
                staff.email,
                staffPassword,
                staff.name,
                roles.staff,
                undefined,
                undefined,
                undefined
              )
            )
          }
        }
        currentStaffDoc.userId = staffUserDoc.id;
        //send mail to staff with Generate Random Password 
        await EmailService.sendAccountActivationToStaff(staffUserDoc, staffPassword, businessDoc);
      }
    }
    if (
      staff.isOperatingNonStop != null &&
      staff.isOperatingNonStop != currentStaffDoc.isOperatingNonStop
    ) {
      currentStaffDoc.isOperatingNonStop = staff.isOperatingNonStop;
      resourceNotModified = false;
    }

       if (
      staff.notificationEnabled != null &&
      staff.notificationEnabled != currentStaffDoc.notificationEnabled
    ) {
      currentStaffDoc.notificationEnabled = staff.notificationEnabled;
      resourceNotModified = false;
    }

    if (staff.staffHoursBlocks != null) {
      if (staff.staffHoursBlocks.length == 0) {
        staff.staffHoursBlocks = undefined;
      }
      if (
        StaffService.areStaffHoursBlocksNotEqual(
          staff.staffHoursBlocks,
          currentStaffDoc.staffHoursBlocks
        )
      ) {
        if (staff.staffHoursBlocks == undefined) {
          currentStaffDoc.staffHoursBlocks = staff.staffHoursBlocks;
        } else {
          StaffService.checkStaffHoursBlocksAreValid(staff.staffHoursBlocks);
          currentStaffDoc.staffHoursBlocks = staff.staffHoursBlocks.map((bh) =>
            StaffHoursBlockDbModel.convertToDbModel(bh)
          );
        }
        resourceNotModified = false;
      }
    }

    if (staff.name != null && staff.name != currentStaffDoc.name) {
      currentStaffDoc.name = staff.name;
      resourceNotModified = false;
    }

    if (
      staff.servicesId != null &&
      StaffService.checkIfServiceHaveAnyChange(
        currentStaffDoc.servicesId,
        staff.servicesId
      )
    ) {
      currentStaffDoc.servicesId = staff.servicesId;
      resourceNotModified = false;
    }
    // add free count with paid count for manage conditions based on user membership
    const totalBusinessStaffs = businessDoc.membershipTier === MembershipTier.Pro ? (businessDoc.membershipStaffCount + staffCount.pro_count) : businessDoc.membershipStaffCount;
    if (staff.isActive != null && staff.isActive != currentStaffDoc.isActive) {
      const businessStaffCount = await this.getStaffByBusinessIdV4(businessDoc.id);
      // 2>=2 true
      if (!businessDoc.isAnnualActive && businessStaffCount !== 0 && businessStaffCount > totalBusinessStaffs) {
        currentStaffDoc.isActiveByBusiness = false;
        currentStaffDoc.isActive = false;
        // Logger.logger.warn(`Se ha alcanzado el límite de personal.`)
        // throw new NotAllowedError(`Se ha alcanzado el límite de personal.`);
        currentStaffDoc.isAllow = false;
      } else {
        currentStaffDoc.isActiveByBusiness = staff.isActive;
        currentStaffDoc.isActive = staff.isActive;
      }
      resourceNotModified = false;
    }

    if (staff.email != null && staff.email != currentStaffDoc.email) {
      currentStaffDoc.email = staff.email;
      if (userDoc) {
        userDoc.email = staff.email
      }
      resourceNotModified = false;
    }
    if (userDoc) {
      if (staff.password != null) {
        userDoc.password = await bcrypt.hash(staff.password, 11);
        resourceNotModified = false;
      }
    }

    // save profile pic of staff
    if (staff.logo !== undefined && staff.logo != currentStaffDoc.logo && staff.logo != null && staff.logo != '') {
      // upload file to digital ocean
      const url = await UploadFileService.uploadStaffImages(staff.logo, staff, "logo-image");
      currentStaffDoc.logo = url;
      resourceNotModified = false
    }

    /** remove staff logo  */
    if ((staff.logo === null || staff.logo == '')) {
      const url = await UploadFileService.deleteUploadBusinessImages(currentStaffDoc.logo, roles.staff);
      currentStaffDoc.logo = ''
      resourceNotModified = false
    }
    if (resourceNotModified == true) {
      return null;
    }

    try {
      await currentStaffDoc.save();
      if (userDoc) {
        await userDoc.save();
      }
    } catch (err) {
      Logger.logger.error(`Failed to partially update staff ${staff.id}`, err);
      throw new DatabaseError(`Failed to partially update staff ${staff.id}`);
    }
    currentStaffDoc.business = BusinessDbModel.convertToDomainModel(businessDoc);
    await this.hydrateStaff(currentStaffDoc)
    return StaffDbModel.convertToDomainModel(currentStaffDoc);
  }

  public static async partialUpdateV2(staff: Staff, servicesId: any): Promise<Staff> {
    let userDoc = null;
    const currentStaffDoc = await StaffService.getStaffDocById(staff.id, staff.businessId);
    if (currentStaffDoc == null) {
      Logger.logger.warn(`Staff ${staff.id} doesn't exist`);
      throw new ReferencedResourceNotFoundError(
        `Staff ${staff.id} doesn't exist`
      );
    }
    /* find business and check staff count**/
    const businessDoc = await BusinessesService.getBusinessDocById(staff.businessId)
    if (businessDoc == null) {
      Logger.logger.warn(`Business ${staff.businessId} doesn't exist`)
      throw new ReferencedResourceNotFoundError(`Business ${staff.businessId} doesn't exist`)
    }
    let resourceNotModified = true;

    if (
      staff.isOperatingNonStop != null &&
      staff.isOperatingNonStop != currentStaffDoc.isOperatingNonStop
    ) {
      currentStaffDoc.isOperatingNonStop = staff.isOperatingNonStop;
      resourceNotModified = false;
    }
    if (
      staff.notificationEnabled != null &&
      staff.notificationEnabled != currentStaffDoc.notificationEnabled
    ) {
      currentStaffDoc.notificationEnabled = staff.notificationEnabled;
      resourceNotModified = false;
    }

    if (staff.staffHoursBlocks != null) {
      if (staff.staffHoursBlocks.length == 0) {
        staff.staffHoursBlocks = undefined;
      }
      if (
        StaffService.areStaffHoursBlocksNotEqual(
          staff.staffHoursBlocks,
          currentStaffDoc.staffHoursBlocks
        )
      ) {
        if (staff.staffHoursBlocks == undefined) {
          currentStaffDoc.staffHoursBlocks = staff.staffHoursBlocks;
        } else {
          StaffService.checkStaffHoursBlocksAreValid(staff.staffHoursBlocks);
          currentStaffDoc.staffHoursBlocks = staff.staffHoursBlocks.map((bh) =>
            StaffHoursBlockDbModel.convertToDbModel(bh)
          );
        }
        resourceNotModified = false;
      }
    }
    if (
      staff.servicesId != null &&
      StaffService.checkIfServiceHaveAnyChange(
        currentStaffDoc.servicesId,
        servicesId
      )
    ) {
      currentStaffDoc.servicesId = servicesId;
      resourceNotModified = false;
    }
    if (resourceNotModified == true) {
      return null;
    }
    try {
      await currentStaffDoc.save();
      if (userDoc) {
        await userDoc.save();
      }
    } catch (err) {
      Logger.logger.error(`Failed to partially update staff ${staff.id}`, err);
      throw new DatabaseError(`Failed to partially update staff ${staff.id}`);
    }
    currentStaffDoc.business = BusinessDbModel.convertToDomainModel(businessDoc);
    await this.hydrateStaff(currentStaffDoc)
    return StaffDbModel.convertToDomainModel(currentStaffDoc);
  }

  public static async delete(staffId: string, businessId: string): Promise<StaffService> {
    const StaffDoc = await StaffService.getStaffDocById(staffId, businessId);

    if (StaffDoc == null) {
      Logger.logger.warn(`Staff ${staffId} doesn't exist`);
      throw new ReferencedResourceNotFoundError(
        `Staff ${staffId} doesn't exist`
      );
    }
    const staffUser = StaffDoc.email ? await UserService.getUserByEmailAddress(StaffDoc.email) : null;
    if (staffUser) {
      staffUser.isDeleted = true;
      await staffUser.save();
    }
    const businessDoc = await BusinessesService.getBusinessDocById(businessId)
    if (businessDoc == null) {
      Logger.logger.warn(`Business ${businessId} doesn't exist`)
      throw new ReferencedResourceNotFoundError(`Business ${businessId} doesn't exist`)
    }
    StaffDoc.isDeleted = true;
    try {
      // remove staff in stripe
      const businessStaffCount = await this.getStaffByBusinessId(businessDoc.id);
      if (businessDoc && businessDoc.stripePriceIds && businessDoc.stripePriceIds.staffUsagePriceId) {
        const subscriptionObj: any = await StripeService.getCustomerSubscriptions(businessDoc.stripeCustomerId);
        await StripeService.reduceStaff(subscriptionObj, businessDoc, 1, businessDoc.stripePriceIds.staffUsagePriceId);
      }
      // else {
      //   businessDoc.membershipStaffCount = businessDoc.membershipStaffCount - 1;
      //   await businessDoc.save();
      // }
      await StaffDoc.save();
      // update business NEW staff count
      // if (businessDoc.stripePriceIds && businessDoc.stripePriceIds.staffUsagePriceId) {
      //   // update staff extra if remove staff and manage stripe
      //   // businessDoc.buyExtraStaffCount = businessDoc.buyExtraStaffCount - 1;
      //   businessDoc.membershipStaffCount = businessDoc.membershipStaffCount - 1;
      //   // also remove staff form stripe
      //   let currencyString = 'USD';
      //   const subscriptionObj = await StripeService.getCustomerSubscriptions(businessDoc.stripeCustomerId)
      //   if (subscriptionObj && subscriptionObj.subscription && subscriptionObj.subscription.currency) {
      //     currencyString = subscriptionObj.subscription.currency.toUpperCase()
      //   }
      //   await StripeService.createstaffPlanCheckoutSession(businessDoc.stripeCustomerId, businessDoc.stripePriceIds.staffUsagePriceId, businessDoc, currencyString, 1, subscriptionObj.subscriptionList, "")
      // }
      // await businessDoc.save()
    } catch (err) {
      Logger.logger.error(
        `Failed to mark staff service ${staffId} as deleted`,
        err
      );
      throw new DatabaseError(
        `Failed to mark staff service ${staffId} as deleted`
      );
    }
    const staff = StaffDbModel.convertToDomainModel(StaffDoc);
    return staff;
  }

  public static async removeStaff(businessId: string, staffId: string,): Promise<StaffService> {
    const StaffDoc = await StaffService.getStaffDocById(staffId, businessId);

    if (StaffDoc == null) {
      Logger.logger.warn(`Staff ${staffId} doesn't exist`);
      // throw new ReferencedResourceNotFoundError(
      //   `Staff ${staffId} doesn't exist`
      // );
    }
    const businessDoc = await BusinessesService.getBusinessDocById(businessId)
    if (businessDoc == null) {
      Logger.logger.warn(`Business ${businessId} doesn't exist`)
      // throw new ReferencedResourceNotFoundError(`Business ${businessId} doesn't exist`)
    }
    StaffDoc.isDeleted = true;
    try {
      await StaffDoc.save();
    } catch (err) {
      Logger.logger.error(
        `Failed to mark staff service ${staffId} as deleted`,
        err
      );
      // throw new DatabaseError(
      //   `Failed to mark staff service ${staffId} as deleted`
      // );
    }
    const staff = StaffDbModel.convertToDomainModel(StaffDoc);
    return staff;
  }


  public static async updateBusinessStaffToFreeTier(businessId: string): Promise<void> {
    let staffDocs: IStaff[];
    let parmsObj: any = { isDeleted: false, businessId: businessId };
    try {
      staffDocs = await StaffDbModel.StaffModel.find(parmsObj).exec();
    } catch (err) {
      Logger.logger.error("Failed to get staff in updateBusinessStaffToFourActive", err);
      throw new DatabaseError("Failed to get staff in updateBusinessStaffToFourActive");
    }

    staffDocs.forEach(async (s: any) => {
      const referencedStaffDoc = staffDocs.find(sd => sd.id == s.id)

      if (referencedStaffDoc != null) {
        referencedStaffDoc.isActive = false

        try {
          await referencedStaffDoc.save()
        } catch (err) {
          Logger.logger.error(`updateBusinessStaffToFourActive - Failed to update staff ${s.id} for business ${businessId}`, err)
        }
      }
    })
  }

  public static async updateExtraBusinessStaffToInactive(business: IBusiness): Promise<void> {
    let staffDocs: IStaff[];
    let parmsObj: any = { isDeleted: false, isActiveByBusiness: false, businessId: business.id };
    try {
      staffDocs = await StaffDbModel.StaffModel.find(parmsObj).exec();
    } catch (err) {
      Logger.logger.error("Failed to get staff in updateBusinessStaffToFourActive", err);
      throw new DatabaseError("Failed to get staff in updateBusinessStaffToFourActive");
    }
    // staffDocs.splice(0, business.membershipStaffCount);
    staffDocs.forEach(async (element, index) => {
      if (index < business.membershipStaffCount) {
        element.isActive = true;
        element.isActiveByBusiness = true;
        await element.save();
      }
    })
    staffDocs.slice(business.membershipStaffCount).forEach(async (s: any) => {
      const referencedStaffDoc = staffDocs.find(sd => sd.id == s.id)
      if (referencedStaffDoc != null) {
        referencedStaffDoc.isActive = false
        try {
          await referencedStaffDoc.save()
        } catch (err) {
          Logger.logger.error(`updateBusinessStaffToFourActive - Failed to update staff ${s.id} for business ${business.id}`, err)
        }
      }
    })
  }


  public static async getStaffDocById(staffId: string, businessId: string): Promise<any> {
    let result = null;
    try {
      result = await StaffDbModel.StaffModel.findOne({
        _id: staffId,
        businessId: businessId,
        isDeleted: false
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by id (${staffId})`, err);
      throw new DatabaseError(`Failed to retrieve staff by id (${staffId})`);
    }
    return result
  }

  public static async getStaffDocByIdV4(staffId: string, businessId: string): Promise<any> {
    let result = null;
    try {
      result = await StaffDbModel.StaffModel.findOne({
        _id: staffId,
        businessId: businessId,
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by id (${staffId})`, err);
      throw new DatabaseError(`Failed to retrieve staff by id (${staffId})`);
    }
    return result
  }

  public static async getStaffByBusinessId(businessId: string): Promise<number> {
    try {
      return await StaffDbModel.StaffModel.countDocuments({
        businessId: businessId,
        isDeleted: false,
        // isActive: true,
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff of business id (${businessId})`, err);
      throw new DatabaseError(`Failed to retrieve staff of business id (${businessId})`);
    }
  }

  public static async getStaffByBusinessIdV4(businessId: string): Promise<number> {
    try {
      return await StaffDbModel.StaffModel.countDocuments({
        businessId: businessId,
        isDeleted: false,
        isActive: true,
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff of business id (${businessId})`, err);
      throw new DatabaseError(`Failed to retrieve staff of business id (${businessId})`);
    }
  }
  public static async getStaffDocByIdV3(staffId: string): Promise<IStaff> {
    try {
      return await StaffDbModel.StaffModel.findOne({
        _id: staffId,
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by id (${staffId})`, err);
      throw new DatabaseError(`Failed to retrieve staff by id (${staffId})`);
    }
  }

  public static async getStaffDocByIdV2(userId: string): Promise<IStaff> {
    try {
      return await StaffDbModel.StaffModel.findOne({
        userId: userId,
        // isActive: true,
        isDeleted: false
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by this user id (${userId})`, err);
      throw new DatabaseError(`Failed to retrieve staff by this user id (${userId})`);
    }
  }

  public static async getStaffsDocByUserIdV2(userId: string): Promise<IStaff[]> {
    try {
      return await StaffDbModel.StaffModel.find({
        userId: userId,
        // isActive: true,
        isDeleted: false
      }).exec();
    } catch (err) {
      Logger.logger.error(`Failed to retrieve staff by this user id (${userId})`, err);
      throw new DatabaseError(`Failed to retrieve staff by this user id (${userId})`);
    }
  }
  private static checkIfServiceHaveAnyChange(
    currentStaffService: [],
    staffService: []
  ) {
    let globalFlag = false;
    currentStaffService.map((item) => {
      let flag = staffService.includes(item);
      if (!flag) {
        globalFlag = true;
      }
    });

    staffService.map((item) => {
      let flag = currentStaffService.includes(item);
      if (!flag) {
        globalFlag = true;
      }
    });
    return globalFlag;
  }
  private static areStaffHoursBlocksNotEqual(
    staffHoursBlockA: StaffHoursBlock[],
    staffHoursBlockB: IStaffHoursBlock[]
  ) {
    if (staffHoursBlockA == null && staffHoursBlockB == null) {
      return false;
    }

    if (
      (staffHoursBlockA != null && staffHoursBlockB == null) ||
      (staffHoursBlockB != null && staffHoursBlockA == null) ||
      staffHoursBlockA.length != staffHoursBlockB.length
    ) {
      return true;
    }

    if (
      staffHoursBlockA.every((shba) =>
        staffHoursBlockB.some(
          (shbb) =>
            shba.startDayOfTheWeek == shbb.startDayOfTheWeek &&
            shba.startHour == shbb.startHour &&
            shba.startMinute == shbb.startMinute &&
            shba.endDayOfTheWeek == shbb.endDayOfTheWeek &&
            shba.endHour == shbb.endHour &&
            shba.endMinute == shbb.endMinute
        )
      )
    ) {
      return false;
    }

    return true;
  }

  private static checkStaffHoursBlocksAreValid(staffHoursBlocks: StaffHoursBlock[]): void {
    StaffService.checkStaffHoursBlocksAreNotOverlapping(staffHoursBlocks);
  }

  private static checkStaffHoursBlocksAreNotOverlapping(staffHoursBlocks: StaffHoursBlock[]): void {
    for (let i = 0; i < staffHoursBlocks.length; i++) {
      const staffHoursBlockA: StaffHoursBlock = staffHoursBlocks[i];
      const staffHoursBlockAStartInt = staffHoursBlockA.getStartTimeInteger();
      const staffHoursBlockAEndInt = staffHoursBlockA.getEndTimeInteger();

      for (let j = 0; j < staffHoursBlocks.length; j++) {
        if (i == j) {
          continue;
        }
        const staffHoursBlockB = staffHoursBlocks[j];
        const staffHoursBlockBStartInt = staffHoursBlockB.getStartTimeInteger();
        const staffHoursBlockBEndInt = staffHoursBlockB.getEndTimeInteger();

        if (staffHoursBlockAEndInt > staffHoursBlockAStartInt) {
          if (
            (staffHoursBlockBStartInt >= staffHoursBlockAStartInt &&
              staffHoursBlockBStartInt <= staffHoursBlockAEndInt) ||
            (staffHoursBlockBEndInt >= staffHoursBlockAStartInt &&
              staffHoursBlockBEndInt <= staffHoursBlockAEndInt)
          ) {
            Logger.logger.warn(
              `staffHoursBlocks[${i}] overlaps with staffHoursBlocks[${j}]`
            );
            throw new BadRequestError(
              `staffHoursBlocks[${i}] overlaps with staffHoursBlocks[${j}]`
            );
          }
        } else {
          if (
            (staffHoursBlockBStartInt >= staffHoursBlockAStartInt &&
              staffHoursBlockBStartInt <= 62359) ||
            (staffHoursBlockBStartInt >= 0 &&
              staffHoursBlockBStartInt <= staffHoursBlockAEndInt) ||
            (staffHoursBlockBEndInt >= staffHoursBlockAStartInt &&
              staffHoursBlockBEndInt <= 62359) ||
            (staffHoursBlockBEndInt >= 0 &&
              staffHoursBlockBEndInt <= staffHoursBlockAEndInt)
          ) {
            Logger.logger.warn(
              `staffHoursBlocks[${i}] overlaps with staffHoursBlocks[${j}]`
            );
            throw new BadRequestError(
              `staffHoursBlocks[${i}] overlaps with staffHoursBlocks[${j}]`
            );
          }
        }
      }
    }
  }
}
