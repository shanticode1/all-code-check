import { Logger } from "../logger";
import { DatabaseError } from "../errors/database.error";
import { CurrencyRate } from "../types/currencyRates";
import { CurrencyRateDbModel, ICurrencyRate } from "../db-models/currency-rate.db.modal";

export abstract class CurrencyRateService {
    public static async getAll(): Promise<CurrencyRate[]> {
        let currencyRate: CurrencyRate[] = [];
        let currencyRateDocs: ICurrencyRate[];
        try {
            currencyRateDocs = await CurrencyRateDbModel.CurrencyRateModel.find({}).sort({ '_id': -1 }).exec();
        } catch (err) {
            Logger.logger.error("Failed to get currency rates", err);
            throw new DatabaseError("Failed to get currency rates");
        }

        if (currencyRateDocs == null) {
            return null;
        }

        for await (const b of currencyRateDocs) {
            const currency_temp = CurrencyRateDbModel.convertToDomainModel(b);
            currencyRate.push(currency_temp)
        }

        return currencyRate;
    }

}