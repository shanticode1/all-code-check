import { BookingReminderDbModel, IBookingReminder } from "../db-models/booking-reminder.db-model"
import { IBooking } from "../db-models/booking.db-model"
import { Logger } from "../logger"
import { BookingReminder } from "../types/booking-reminder"
import { BookingReminderType } from "../types/enums/booking-reminder-type.enum"
import { DurationUnit } from "../types/enums/duration-unit.enum"
import { DateUtils } from "../utils/date.utils"
import { BookingsService } from "./bookings.service"
import { BusinessServiceSnapshotsService } from "./business-service-snapshots.service"
import { BusinessServicesService } from "./business-services.service"
import { BusinessesService } from "./businesses.service"
import { ClientService } from "./client.service"
import { EmailService } from "./email.service"
import { StaffService } from "./staff.service"
import { StripeService } from "./stripe.service"

export abstract class BookingRemindersService {

	public static async sendReminders(): Promise<void> {
		Logger.logger.info("Sending booking reminders...")
		let minutesInAdvance = [
			{
				minutesInAdvance: 60 * 24, // set default 24 hrs reminder before event start
				types: [BookingReminderType.Email]
			}
		];
		const unfinishedBookingDocs = await BookingsService.getUnfinishedBookingDocs()
		let sentRemindersCount = 0

		if (unfinishedBookingDocs.length == 0) {
			Logger.logger.info(`...No unfinished bookings were found. ${sentRemindersCount} reminders were sent`)
			return
		}

		const businesses = await BusinessesService.getByIds(unfinishedBookingDocs.map(b => b.businessId))
		const businessServices = await BusinessServicesService.getByIds(unfinishedBookingDocs.map(b => b.serviceId), false)
		const snapshots = await BusinessServiceSnapshotsService.getByIds(unfinishedBookingDocs.map(b => b.serviceSnapshotId))

		const now = new Date()

		for (const booking of unfinishedBookingDocs) {
			const matchingBusiness = businesses.find(b => b.id == booking.businessId)
			if (matchingBusiness == null) {
				Logger.logger.warn(`Failed to find matching business (${booking.businessId}) for booking ${booking._id}`)
				continue
			}

			const matchingService = businessServices.find(s => s.id == booking.serviceId)
			if (matchingService == null) {
				Logger.logger.warn(`Failed to find matching service (${booking.serviceId}) for booking ${booking._id}`)
				continue
			}

			var matchingSnapshot;
			if (booking.serviceSnapshotId) {
				matchingSnapshot = snapshots.find(s => s.id == booking.serviceSnapshotId)
				if (matchingSnapshot == null) {
					Logger.logger.warn(`Failed to find matching snapshot (${booking.serviceSnapshotId}) for booking ${booking._id}`)
					continue
				}
			}

			var matchingStaffSnapshot = null;
			if (booking.staffId) {
				matchingStaffSnapshot = await StaffService.getStaffDocById(booking.staffId, booking.businessId);
				if (matchingStaffSnapshot == null) {
					Logger.logger.warn(`Failed to find matching staff snapshot (${booking.staffId}) for booking ${booking._id}`)
					continue
				}
			}

			const minutesBeforeBookingStart = DateUtils.differenceInMinutes(now, booking.startDate)

			const dueReminders: BookingReminder[] = []
			if (matchingBusiness.settings && matchingBusiness.settings.emailReminderDuration && matchingBusiness.settings.emailReminderDuration.durationUnit === DurationUnit.Hour) {
				minutesInAdvance = [
					{
						minutesInAdvance: 60 * matchingBusiness.settings.emailReminderDuration.duration, // set 24 hrs reminder before event start
						types: [BookingReminderType.Email]
					}
				]
			}
			if (matchingBusiness.settings && matchingBusiness.settings.emailReminderDuration && matchingBusiness.settings.emailReminderDuration.durationUnit === DurationUnit.Minute) {
				minutesInAdvance = [
					{
						minutesInAdvance: matchingBusiness.settings.emailReminderDuration.duration, // set 24 hrs reminder before event start
						types: [BookingReminderType.Email]
					}
				]
			}
			// for (const bookingReminder of matchingService.bookingReminders) {
			for (const bookingReminder of minutesInAdvance) {
				if (bookingReminder.minutesInAdvance < minutesBeforeBookingStart ||
					booking.sentReminders.some(r => r.minutesInAdvance < bookingReminder.minutesInAdvance)) {
					continue
				}

				const matchingSentReminder = booking.sentReminders.find(sr => sr.minutesInAdvance == bookingReminder.minutesInAdvance)
				if (matchingSentReminder == null) {
					dueReminders.push(bookingReminder)
					continue
				}

				const dueReminder = new BookingReminder(bookingReminder.minutesInAdvance, [])
				dueReminder.types.push(...bookingReminder.types.filter(rt => !matchingSentReminder.types.some(st => st == rt)))
				if (dueReminder.types.length == 0) {
					continue
				}
				dueReminders.push(dueReminder)
			}

			const reminderToBeSent = BookingRemindersService.getLatestReminder(dueReminders)

			if (reminderToBeSent == null) {
				continue
			}
			for (const reminderType of reminderToBeSent.types) {
				const matchingSentReminder = booking.sentReminders.find(r => r.minutesInAdvance == reminderToBeSent.minutesInAdvance)
				switch (reminderType) {
					// booking.customer.isEmailAllow === true ? send email : not send
					case BookingReminderType.Email:
						const clientDoc = await ClientService.getByEmail(booking.businessId, booking.customer.email)
						if (matchingBusiness.settings && matchingBusiness.settings.isEmailReminder && (clientDoc && clientDoc.isEmailAllow)) {
							try {
								let googleMeetLink: string;
								let checkoutLink: any = '';
								// add meet link
								if (booking.googleMeetLink) {
									googleMeetLink = booking.googleMeetLink;
								}
								if (matchingService && matchingService.paymentSetting && matchingService.paymentSetting.isPaymentLinkSend) {
									const { sessionLink, paidPrice } = await StripeService.createConnectedAccountCheckoutSession(booking, matchingService, matchingSnapshot, matchingBusiness, false, 'reminderAmount');
									checkoutLink = sessionLink;
								}
								// 67c6f96f84b18e4c8cae01db
								await EmailService.sendBookingReminderToCustomer(matchingBusiness, matchingSnapshot, matchingStaffSnapshot, booking, googleMeetLink, checkoutLink)

							} catch { }
							sentRemindersCount++
							await BookingRemindersService.updateSentReminder(reminderToBeSent.minutesInAdvance, reminderType, matchingSentReminder, booking)
						}
						break
					// case BookingReminderType.WhatsApp:
					// 	// send msg to whatsapp  ...
					// 	Logger.logger.info("Sending booking reminders...")
					// 	await WhatsAppService.sendWhatsAppBookingReminderToCustomer(matchingBusiness, matchingSnapshot, matchingStaffSnapshot, booking)
					// 	sentRemindersCount++
					// 	await BookingRemindersService.updateSentReminder(reminderToBeSent.minutesInAdvance, reminderType, matchingSentReminder, booking)
					// 	break
					default:
						throw new Error(`Sending reminder of type ${BookingReminderType[reminderType]} is not implemented`);
				}
			}
		}

		Logger.logger.info(`...Finished sending reminders. ${sentRemindersCount} reminders were sent`)
	}

	public static async updateSentReminder(minutesInAdvance: number, reminderType: BookingReminderType, matchingSentReminder: IBookingReminder, bookingDoc: IBooking): Promise<void> {
		if (matchingSentReminder == null) {
			bookingDoc.sentReminders.push(BookingReminderDbModel.convertToDbModel(new BookingReminder(minutesInAdvance, [reminderType])))
		} else {
			matchingSentReminder.types.push(reminderType)
		}

		try {
			await bookingDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to update sentReminders for booking ${bookingDoc._id} after sending ${minutesInAdvance} minute ${BookingReminderType[reminderType]} reminder`, err)
		}
	}

	public static getLatestReminder(reminders: IBookingReminder[]): IBookingReminder {
		let latestReminder: IBookingReminder

		for (const reminder of reminders) {
			if (latestReminder == null || reminder.minutesInAdvance < latestReminder.minutesInAdvance) {
				latestReminder = reminder
			}
		}

		return latestReminder
	}

}