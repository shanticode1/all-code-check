import { Document } from "mongoose"
import { BookingDbModel, IBooking } from "../db-models/booking.db-model"
import { BadRequestError } from "../errors/bad-request.error"
import { DatabaseError } from "../errors/database.error"
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error"
import { Logger } from "../logger"
import { Booking } from "../types/booking"
import { BookingPaymentStatus, BookingStatus } from "../types/enums/booking.status"
import { DurationUnit } from "../types/enums/duration-unit.enum"
import { DateUtils } from "../utils/date.utils"
import { BusinessServiceSnapshotsService } from "./business-service-snapshots.service"
import { BusinessesService } from "./businesses.service"
import { EmailService } from "./email.service"
import { IcsService } from "./ics.service"
import { StaffService } from "./staff.service"
import { ClientService } from "./client.service"
import { Client } from "../types/clients"
import { TimeSlotService } from "./time-slot-service"
import { GoogleService } from "./google.service"
import { BookingReminderType } from "../types/enums/booking-reminder-type.enum"
import { roles } from "../data/user.roles"
import { StripeService } from "./stripe.service"
import { ServicePaymentType } from "../types/enums/payment-type.enum"
import { BusinessServicesService } from "./business-services.service"
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error"
import { TimeslotBooked } from "../types/timeslot-booked"
import { TimeZonesService } from "./time-zones.service"
import { BookingQueue } from "../utils/booking.queue"
import { ClientMembershipService } from "./client-services-membership.service "
export const reminderMinutesInAdvance = {
	minutesInAdvance: 60 * 24, // set 24 hrs reminder before event start
	types: [BookingReminderType.WhatsApp]
}


export abstract class BookingsService {

	public static async getByIdForBusiness(businessId: string, bookingId: string, hydrate = true): Promise<Booking> {
		const bookingDoc = await BookingsService.getBookingDocByIdForBusiness(bookingId, businessId)

		if (bookingDoc == null) {
			Logger.logger.warn(`Booking ${bookingId} for business ${businessId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Booking ${bookingId} for business ${businessId} doesn't exist`)
		}
		const booking = BookingDbModel.convertToDomainModel(bookingDoc)
		if (hydrate == true) {
			booking.staffSnapshot = booking.staffId == null ? undefined : await StaffService.getById(booking.staffId, businessId)
			// await BookingsService.hydrateBooking(booking) // old method for get staff
			await BookingsService.hydrateBookingV2(booking)
		}
		return booking
	}

	public static async getByIdForStaff(staffId: string, bookingId: string, hydrate = true): Promise<Booking> {
		const bookingDoc = await BookingDbModel.BookingModel.findOne({ _id: bookingId, staffId: staffId }).exec()
		if (bookingDoc == null) {
			Logger.logger.warn(`Booking ${bookingId} for business ${staffId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Booking ${bookingId} for business ${staffId} doesn't exist`)
		}

		const booking = BookingDbModel.convertToDomainModel(bookingDoc)
		if (hydrate == true) {
			booking.staffSnapshot = booking.staffId == null ? undefined : await StaffService.getStaffDocByObjectId(booking.staffId)
			await BookingsService.hydrateBooking(booking)
		}
		return booking
	}

	public static async getByIdForClient(cleintId: string, bookingId: string, hydrate = true): Promise<Booking> {
		const bookingDoc = await BookingsService.getBookingDocByIdForClient(bookingId, cleintId)

		if (bookingDoc == null) {
			Logger.logger.warn(`Booking ${bookingId} for business ${cleintId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Booking ${bookingId} for business ${cleintId} doesn't exist`)
		}
		const booking = BookingDbModel.convertToDomainModel(bookingDoc)
		if (hydrate == true) {
			booking.staffSnapshot = booking.staffId == null ? undefined : await StaffService.getById(booking.staffId, cleintId)
			// await BookingsService.hydrateBooking(booking) // old method for get staff
			await BookingsService.hydrateBookingV2(booking)
		}
		return booking
	}

	public static async getByIdForBusinessAndService(businessId: string, serviceId: string, bookingId: string, hydrate = true): Promise<Booking> {

		const bookingDoc = await BookingsService.getBookingDocByIdForBusinessAndService(bookingId, businessId, serviceId)

		if (bookingDoc == null) {
			Logger.logger.warn(`Booking ${bookingId} for business ${businessId} and service ${serviceId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Booking ${bookingId} for business ${businessId} and service ${serviceId} doesn't exist`)
		}

		const booking = BookingDbModel.convertToDomainModel(bookingDoc)
		if (hydrate == true) {
			await BookingsService.hydrateBooking(booking)
			booking.staffSnapshot = booking.staffId == null ? undefined : await StaffService.getById(booking.staffId, businessId)
		}
		return booking
	}

	public static async getForBusiness(businessId: string, status: BookingStatus, past: boolean, from: Date, to: Date, dateSortDirection = 'asc', eventType: string, hydrate = true): Promise<Booking[]> {
		let bookingDocs: IBooking[]

		const filter = { businessId: businessId }

		if (status !== undefined) {
			(filter as any).status = status == BookingStatus.Cancelled ? { $in: [BookingStatus.Rejected, BookingStatus.Cancelled] } :
				status
		}

		if (past != null && status != BookingStatus.Cancelled) {
			(filter as any).endDate = past == true ? { $lt: new Date() } : { $gte: new Date() };
		}

		if (from != null) {
			(filter as any).endDate = { $gte: from }
		}

		if (to != null) {
			(filter as any).startDate = { $lte: to }
		}

		let sortDirection = dateSortDirection === 'asc' ? { startDate: 1 } : { startDate: -1 }

		try {
			bookingDocs = await BookingDbModel.BookingModel.find(filter).sort(sortDirection).exec();
		} catch (err) {
			Logger.logger.error(`Failed to retrieve bookings for business (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve bookings for business (${businessId})`)
		}

		const bookings = bookingDocs.map(bd => BookingDbModel.convertToDomainModel(bd))
		if (hydrate == true) {
			await BookingsService.hydrateBookings(bookings)
		}
		return bookings
	}

	public static async getForBusinessV1(businessId: string, status: BookingStatus, past: boolean, from: Date, to: Date, dateSortDirection, hydrate = true): Promise<Booking[]> {
		let bookingDocs: IBooking[]
		let sortDirection;
		// const filter = { businessId: businessId }
		let filter = {} as any;
		if (status !== undefined) {
			(filter as any).status = status == BookingStatus.Cancelled ? { $in: [BookingStatus.Rejected, BookingStatus.Cancelled] } :
				status
		}

		if (past != null && status != BookingStatus.Cancelled) {
			(filter as any).endDate = past == true ? { $lt: new Date() } : { $gte: new Date() };
		}
		if (from != null) {
			(filter as any).endDate = { $gte: from }
		}

		if (to != null) {
			(filter as any).startDate = { $lte: to }
		}
		const referencedBusiness = await BusinessesService.getById(businessId);
		if (status === undefined && past === null) {
			if (referencedBusiness && (referencedBusiness.googleCalendar != undefined || referencedBusiness.googleCalendar != null)) {
				const googleData = referencedBusiness.googleCalendar ? referencedBusiness.googleCalendar.find(dt => dt.status === 'enable') : null;
				const calendarId = googleData ? googleData.calendarId : null;
				if (calendarId != null) {
					// (filter as any).$in = [{ calendarId: calendarId, businessId: businessId }];
					filter.$or = [
						{ calendarId: calendarId, businessIdForGoogle: businessId },
						{ businessId: businessId }
					]

				} else {
					(filter as any).businessId = businessId;
				}
			}
			else {
				(filter as any).businessId = businessId;
			}
		}
		else {
			(filter as any).businessId = businessId;
		}
		if (status !== undefined && (status === BookingStatus.Approved || status === BookingStatus.Pending)) {
			sortDirection = { startDate: 1 }
		} else {
			sortDirection = dateSortDirection === 'asc' ? { startDate: 1 } : { startDate: -1 }
		}
		try {
			bookingDocs = await BookingDbModel.BookingModel.find(filter).sort(sortDirection).exec();
		} catch (err) {
			Logger.logger.error(`Failed to retrieve bookings for business (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve bookings for business (${businessId})`)
		}

		const bookings = bookingDocs.map(bd => BookingDbModel.convertToDomainModel(bd))
		if (hydrate == true) {
			await BookingsService.hydrateBookings(bookings)
		}
		return bookings
	}

	public static async getForClient(businessId: string, status: BookingStatus, past: boolean, from: Date, to: Date, dateSortDirection, hydrate = true): Promise<Booking[]> {
		let bookingDocs: IBooking[]
		let sortDirection;
		// const filter = { businessId: businessId }
		let filter = {} as any;

		if (status !== undefined) {
			(filter as any).status = status == BookingStatus.Cancelled ?
				{ $in: [BookingStatus.Rejected, BookingStatus.Cancelled] } : status
		}

		if (past != null && status != BookingStatus.Cancelled) {
			(filter as any).endDate = past == true ? { $lt: new Date() } : { $gte: new Date() };
		}
		if (from != null) {
			(filter as any).endDate = { $gte: from }
		}

		if (to != null) {
			(filter as any).startDate = { $lte: to }
		}
		if (status === undefined && past === null) {


		}
		else {
			(filter as any).clientId = businessId;
		}
		if (status !== undefined && (status === BookingStatus.Approved || status === BookingStatus.Pending)) {
			sortDirection = { startDate: 1 }
		} else {
			sortDirection = dateSortDirection === 'asc' ? { startDate: 1 } : { startDate: -1 }
		}
		if (filter.status === BookingStatus.All) {
			filter = {
				clientId: businessId
			}
		}

		try {
			bookingDocs = await BookingDbModel.BookingModel.find(filter).sort(sortDirection).exec();
		} catch (err) {
			Logger.logger.error(`Failed to retrieve bookings for business (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve bookings for business (${businessId})`)
		}

		const bookings = bookingDocs.map(bd => BookingDbModel.convertToDomainModel(bd))
		if (hydrate == true) {
			await BookingsService.hydrateBookings(bookings)
		}
		return bookings
	}

	public static async getForClientUpcomingBooking(businessId: string, status: BookingStatus, past: boolean, from: Date, to: Date, dateSortDirection, hydrate = true): Promise<Booking[]> {
		let bookingDocs: IBooking[]
		let sortDirection;
		const filter = { clientId: businessId }
		sortDirection = dateSortDirection === 'asc' ? { startDate: 1 } : { startDate: -1 }
		if (status !== undefined) {
			(filter as any).status = status == BookingStatus.Cancelled ?
				{ $in: [BookingStatus.Rejected, BookingStatus.Cancelled] } : status
		}
		if (from != null) {
			(filter as any).endDate = { $gte: from }
		}
		if (to != null) {
			(filter as any).startDate = { $lte: to }
		}
		try {
			bookingDocs = await BookingDbModel.BookingModel.find(filter).sort(sortDirection).exec();
			// bookingDocs = await BookingDbModel.BookingModel.aggregate([
			// 	{ $match: filter }, // filter for bookings

			// 	// Convert IDs to ObjectId for lookup
			// 	{
			// 	  $addFields: {
			// 		businessId: { $toObjectId: "$businessId" },
			// 		serviceId: { $toObjectId: "$serviceId" }
			// 	  }
			// 	},

			// 	// Join with business collection
			// 	{
			// 	  $lookup: {
			// 		from: "businesses",
			// 		localField: "businessId",
			// 		foreignField: "_id",
			// 		as: "businessData"
			// 	  }
			// 	},
			// 	{ $unwind: { path: "$businessData", preserveNullAndEmptyArrays: true } },

			// 	// Join with service collection
			// 	{
			// 	  $lookup: {
			// 		from: "business-services",
			// 		localField: "serviceId",
			// 		foreignField: "_id",
			// 		as: "serviceData"
			// 	  }
			// 	},
			// 	{ $unwind: { path: "$serviceData", preserveNullAndEmptyArrays: true } },

			// 	// Keep only required fields
			// 	{
			// 	  $project: {
			// 		_id: 1,
			// 		bookingDate: 1,
			// 		customerId: 1,
			// 		businessId: "$businessId",
			// 		serviceId: "$serviceId",
			// 		"businessData.heroImage": 1,
			// 		"serviceData.logo": 1
			// 	  }
			// 	},

			// 	{ $sort: sortDirection }
			//   ]);

		} catch (err) {
			Logger.logger.error(`Failed to retrieve bookings for business (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve bookings for business (${businessId})`)
		}

		const bookings = bookingDocs.map(bd => BookingDbModel.convertToDomainModel(bd))

		if (hydrate == true) {
			await BookingsService.hydrateBookingsV2(bookings)
		}
		return bookings
	}

	public static async getForStaff(staffId: string, status: BookingStatus, past: boolean, from: Date, to: Date, dateSortDirection, hydrate = true): Promise<Booking[]> {
		let bookingDocs: IBooking[]
		let sortDirection;
		// const filter = { businessId: businessId }
		let filter = {} as any;
		if (status !== undefined) {
			(filter as any).status = status == BookingStatus.Cancelled ? { $in: [BookingStatus.Rejected, BookingStatus.Cancelled] } :
				status
		}

		if (past != null && status != BookingStatus.Cancelled) {
			(filter as any).endDate = past == true ? { $lt: new Date() } : { $gte: new Date() };
		}
		if (from != null) {
			(filter as any).endDate = { $gte: from }
		}

		if (to != null) {
			(filter as any).startDate = { $lte: to }
		}
		const staffBusiness: any = await StaffService.getStaffDocByIdV3(staffId);
		if (status === undefined && past === null) {
			if (staffBusiness && (staffBusiness.googleCalendar != undefined || staffBusiness.googleCalendar != null)) {
				const googleData = staffBusiness.googleCalendar ? staffBusiness.googleCalendar.find(dt => dt.status === 'enable') : null;
				const calendarId = googleData ? googleData.calendarId : null;
				if (calendarId != null) {
					// (filter as any).$in = [{ calendarId: calendarId, businessId: businessId }];
					filter.$or = [
						{ calendarId: calendarId, staffIdForGoogle: staffId },
						{ staffId: staffId }
					]

				} else {
					(filter as any).staffId = staffId;
				}
			}
			else {
				(filter as any).staffId = staffId;
			}
		}
		else {
			(filter as any).staffId = staffId;
		}
		if (status !== undefined && (status === BookingStatus.Approved || status === BookingStatus.Pending)) {
			sortDirection = { startDate: 1 }
		} else {
			sortDirection = dateSortDirection === 'asc' ? { startDate: 1 } : { startDate: -1 }
		}
		try {
			bookingDocs = await BookingDbModel.BookingModel.find(filter).sort(sortDirection).exec();
		} catch (err) {
			Logger.logger.error(`Failed to retrieve bookings for staff (${staffId})`, err)
			throw new DatabaseError(`Failed to retrieve bookings for staff (${staffId})`)
		}

		const bookings = bookingDocs.map(bd => BookingDbModel.convertToDomainModel(bd))
		if (hydrate == true) {
			await BookingsService.hydrateBookings(bookings)
		}
		return bookings
	}

	public static async getForBusinessAndService(businessId: string, serviceId: string, status: BookingStatus, past: boolean, from: Date, to: Date, hydrate = true): Promise<Booking[]> {
		let bookingDocs: IBooking[]

		const filter = { businessId: businessId, serviceId: serviceId }

		if (status !== undefined) {
			(filter as any).status = status
		}

		if (past != null) {
			(filter as any).endDate = past == true ? { $lt: new Date() } : { $gte: new Date() }
		}

		if (from != null) {
			(filter as any).endDate = { $gte: from }
		}

		if (to != null) {
			(filter as any).startDate = { $lte: to }
		}

		try {
			bookingDocs = await BookingDbModel.BookingModel.find(filter).sort({ startDate: -1 }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve bookings for business (${businessId} and service ${serviceId})`, err)
			throw new DatabaseError(`Failed to retrieve bookings for business (${businessId} and service ${serviceId})`)
		}
		const bookings = bookingDocs.map(bd => BookingDbModel.convertToDomainModel(bd))
		if (hydrate == true) {
			await BookingsService.hydrateBookings(bookings)
		}
		return bookings
	}

	public static async getUnfinishedBookingDocs(): Promise<IBooking[]> {
		try {
			return await BookingDbModel.BookingModel.find({ status: BookingStatus.Approved, endDate: { $gt: new Date() } }).exec()
		} catch (err) {
			Logger.logger.error("Failed to retrieve bookings not finished bookings", err)
			throw new DatabaseError("Failed to retrieve bookings not finished bookings")
		}
	}

	public static async getTodayUnfinishedBookingDocs(): Promise<IBooking[]> {
		try {
			const todayDate = new Date();
			const afterDayDate = new Date(todayDate);
			afterDayDate.setDate(afterDayDate.getDate() + 2);
			return await BookingDbModel.BookingModel.find({
				status: BookingStatus.Approved,
				endDate: {
					$gte: todayDate,
					$lt: afterDayDate
				}
			}).exec()
		} catch (err) {
			Logger.logger.error("Failed to retrieve bookings not finished bookings", err)
			throw new DatabaseError("Failed to retrieve bookings not finished bookings")
		}
	}

	/**
	* API entrypoint — add booking to queue and wait for full booking response
	*/
	public static async createQueued(fromBusiness: boolean, chargeImmediately: boolean, booking: Booking): Promise<any> {
		try {
			const payload = { fromBusiness, chargeImmediately, booking };
			return await BookingQueue.addBookingJobAndWait(payload);
		} catch (error) {
			// Re-throw the error so BullMQ knows it failed
			throw error;

		}
	}

	public static async create(fromBusiness, chargeImmediately: boolean, booking: Booking): Promise<Booking> {
		let googleMeetLink = '', eventDoc, staffDoc, url: any, paidAmount = 0, emailPaymentLink: any, isEventService = false, isPaidByMembership = false;
		//Booking made by Business
		let customerIcsFileString: string;
		let businessIcsFileString: string;
		const referencedBusiness = await BusinessesService.getById(booking.business.id)
		const referencedService = referencedBusiness.services?.find(s => s.id == booking.service.id)

		if (!referencedBusiness.isActive) {
			Logger.logger.warn(`Referenced business ${booking.business.id} is not active`)
			throw new BadRequestError(`Referenced business ${booking.business.id} is not active`)
		}

		if (referencedService == null) {
			Logger.logger.warn(`Referenced service ${booking.service.id} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Referenced service ${booking.service.id} doesn't exist`)
		}

		if (!referencedService.isActive) {
			Logger.logger.warn(`Referenced service ${booking.service.id} is not active`)
			throw new BadRequestError(`Referenced service ${booking.service.id} is not active`)
		}

		if (booking.staffId != null) {
			// check if staff past payment is due
			if (referencedBusiness && referencedBusiness.stripePriceIds && referencedBusiness.stripePriceIds.staffUsagePriceId != '' && !referencedBusiness.isStaffPaymentPaid) {
				Logger.logger.warn(`Past due of business ${referencedBusiness.id} of this staff : ${booking.staffId}`)
				throw new BadRequestError(`Past due of business ${referencedBusiness.id} of this staff : ${booking.staffId}`)
			}
			const staffMembers = await StaffService.getStaffByService(referencedService.id)
			if (staffMembers == null || !staffMembers.some(s => s.id == booking.staffId)) {
				Logger.logger.warn(`Referenced staff ${booking.staffId} does not exist for service ${referencedService.id} for business ${referencedBusiness.id}`)
				throw new BadRequestError(`Referenced staff ${booking.staffId} does not exist for service ${referencedService.id} for business ${referencedBusiness.id}`)
			}
		}
		//Save as UTC
		booking.startDate = TimeSlotService.getTimeZoneOffset(
			referencedBusiness.timeZone.name,
			booking.startDate,
			false
		)

		booking.endDate = TimeSlotService.getTimeZoneOffset(
			referencedBusiness.timeZone.name,
			booking.endDate,
			false
		)

		booking.startDate.setSeconds(0)
		booking.startDate.setMilliseconds(0)
		booking.endDate.setSeconds(0)
		booking.endDate.setMilliseconds(0)
		if (referencedService.type !== 'event') {
			const calculatedEndDate = BookingsService.addTimeBlock(booking.startDate, referencedService.duration, referencedService.durationUnit)
			if (calculatedEndDate.getTime() != booking.endDate.getTime()) {
				Logger.logger.warn(`Calculated booking's end date (${DateUtils.dateToShortString(calculatedEndDate)}) doesn't match with the requested one (${DateUtils.dateToShortString(booking.endDate)})`)
				throw new BadRequestError(`Calculated booking's end date (${DateUtils.dateToShortString(calculatedEndDate)}) doesn't match with the requested one ${DateUtils.dateToShortString(booking.endDate)}`)
			}
		}
		booking.status = booking.status != undefined ? booking.status : BookingStatus.Pending
		booking.serviceSnapshot = await BusinessServiceSnapshotsService.getServiceSnapshotForService(referencedService)
		booking.staffSnapshot = await StaffService.getById(booking.staffId, booking.business.id);
		const bookingDoc = BookingDbModel.convertToDbModel(booking)
		bookingDoc.customerCancellationToken = (new Object()) as Document
		do {
			bookingDoc.friendlyId = BookingsService.generateRandomFriendlyId()
		} while (await BookingsService.friendlyIdExsitsForBusiness(bookingDoc.friendlyId, bookingDoc.businessId))

		try {
			// if booking time already exist start old method
			const existingBookings = await BookingDbModel.BookingModel.find({
				startDate: { $lte: new Date(bookingDoc.endDate) },
				endDate: { $gte: new Date(bookingDoc.startDate) },
				$or: [
					{ businessId: bookingDoc.businessId },
					{ businessIdForGoogle: bookingDoc.businessId }
				],
				status: { $in: [BookingStatus.Approved, BookingStatus.Pending, BookingStatus.GoogleEvent] }
			}).exec();
			console.log(existingBookings.length, '--existingBookings');
			const bookings = existingBookings.map((bd) => {
				return new TimeslotBooked(
					bd.startDate,
					bd.endDate,
					bd.staffId,
					bd.startDate.getHours(),
					bd.endDate.getHours(),
					bd.serviceId,
					bd.eventType,
					bd.calendarId,
					bd.status,
					// bd && bd.googleTimeZone
				);
			}).filter(Boolean);
			// Logger.logger.info(JSON.stringify({ bookings, startDate: bookingDoc.startDate, endDate: bookingDoc.endDate, timezone: referencedBusiness.timeZone, staffSnapshot: booking.staffSnapshot, capacity: referencedService.capacity, id: referencedService.id }))

			let isNotOverlappingTimeslot = await TimeSlotService.checkIfTimeslotIsAvailableV2(
				bookings,
				bookingDoc.startDate,
				bookingDoc.endDate,
				referencedBusiness.timeZone,
				booking.staffSnapshot,
				referencedService.capacity, //add total capacity
				referencedService.id
			);
			Logger.logger.info(`isNotOverlappingTimeslot check: ${JSON.stringify(isNotOverlappingTimeslot)}`);
			// ===
			if (isNotOverlappingTimeslot.capacity <= 0) {
				Logger.logger.warn(`Staff member ${bookingDoc?.staffId} has reached maximum capacity for service ${bookingDoc.serviceId} during this time period`);
				throw new ResourceAlreadyExistsError(`El servicio está completamente reservado para este período de tiempo.`);
			}

			let client = await ClientService.create(
				new Client(
					"",
					bookingDoc.businessId,
					bookingDoc.customer.email,
					bookingDoc.customer.name,
					bookingDoc.customer.surname,
					bookingDoc.customer.phoneNumber,
					bookingDoc.customer.countryCode,
					new Date(),
					"",
					bookingDoc.customer.isWhatsAppAllow === undefined ? true : bookingDoc.customer.isWhatsAppAllow,
					bookingDoc.customer.isEmailAllow === undefined ? true : bookingDoc.customer.isEmailAllow,
				),
				true
			);
			bookingDoc.clientId = client.id;
			bookingDoc.eventType = ''
			bookingDoc.customer.isWhatsAppAllow = client.isWhatsAppAllow;
			bookingDoc.customer.isEmailAllow = client.isEmailAllow;
			// push event to signin user google calendar 
			const calendarEventPayload = {
				title: referencedService.name + "-" + bookingDoc.customer.name,
				location: `${referencedBusiness.address.address},${referencedBusiness.address.country}`,
				description: booking.serviceSnapshot.serviceDescription || "",
				startTime: new Date(booking.startDate).toISOString(),
				endTime: new Date(booking.endDate).toISOString(),
				timeZone: referencedBusiness.timeZone.name
			}; const existingBooking = await BookingDbModel.BookingModel.findOne({
				startDate: bookingDoc.startDate,
				endDate: bookingDoc.endDate,
				businessId: bookingDoc.businessId,
				serviceId: referencedService.id,
				status: BookingStatus.Approved
			});
			if (booking.status === BookingStatus.Approved) {
				eventDoc = await GoogleService.postGoogleCalendarEvents(calendarEventPayload, referencedBusiness.id, bookingDoc, referencedBusiness, referencedService, existingBooking);
				if (referencedService.location === 'google-meet' && eventDoc && (eventDoc.hangoutLink || existingBooking.meetLinkId)) {
					bookingDoc.meetLinkId = eventDoc.id;
					bookingDoc.googleMeetLink = eventDoc.hangoutLink || existingBooking.meetLinkId;
					googleMeetLink = eventDoc.hangoutLink || existingBooking.meetLinkId
				}
			}
			bookingDoc.googleEventId = eventDoc ? eventDoc.id : '';

			// 🧾 Get all active memberships for this client and service
			const memberShipActive: any[] = await ClientMembershipService.getMembershipActiveForClient(
				referencedBusiness.id,
				bookingDoc.serviceId,
				bookingDoc.clientId
			);
			// If memberships exist, check usage count
			if (memberShipActive?.length) {
				// Extract all membership & snapshot IDs for one-time DB query
				const membershipIds = memberShipActive.map(m => m.membershipId);
				const snapshotIds = memberShipActive.map(m => m.membershipSnapshotId);

				// 1️⃣ Fetch only relevant bookings once
				const existingBookings = await BookingDbModel.BookingModel.aggregate([
					{
						$match: {
							businessId: bookingDoc.businessId,
							clientId: bookingDoc.clientId,
							status: { $in: [BookingStatus.Approved, BookingStatus.Pending] },
							$or: [
								{ membershipId: { $in: membershipIds } },
								{ membershipSnapshotId: { $in: snapshotIds } }
							]
						}
					},
					{
						$group: {
							_id: "$membershipId",
							count: { $sum: 1 }
						}
					}
				]);

				// 2️⃣ Build a quick lookup map for used counts
				const usedCountMap = new Map(existingBookings.map(b => [b._id.toString(), b.count]));
				// 3️⃣ Find first available membership efficiently
				let availableMembership: any = null;
				for (const membership of memberShipActive) {
					const usedCount = usedCountMap.get(membership.membershipId.toString()) || 0;
					const remainingCount = membership.totalBookingQuantity - usedCount;

					if (remainingCount > 0) {
						availableMembership = membership;
						break;
					}
				}
				// 4️⃣ If available membership found, attach to booking				
				if (availableMembership) {
					isPaidByMembership = true;
					bookingDoc.isFullPaid = true;
					bookingDoc.isPaidByMembership = true;
					bookingDoc.membershipId = availableMembership.membershipId;
					bookingDoc.membershipSnapshotId = availableMembership.membershipSnapshotId;
					bookingDoc.paymentStatus = "Paid";
					bookingDoc.status = BookingStatus.Approved;
					Logger.logger.info(
						`Booking linked to membership: ${availableMembership.membershipDetails?.membershipName || "Unknown"}`
					);
				} else {
					// 5️⃣ If all memberships are used, just log (no error)
					Logger.logger.info(
						`All memberships fully used for clientId: ${bookingDoc.clientId}`
					);
				}
			}
			// ***** end of check booking cbookingDocount *****

			if (referencedService.type === 'event') {
				// ✅ Loop through all staff and create separate booking records
				if (referencedService.eventSetting.staffs.length > 0) {
					for (const staffId of referencedService.eventSetting.staffs) {
						isEventService = true;
						const staffSnapDoc = await StaffService.getById(staffId, booking.business.id);
						if (staffSnapDoc) {
							booking.staffSnapshot = staffSnapDoc;
							bookingDoc.staffId = staffId;
						}

						if (booking.staffSnapshot && booking.staffSnapshot.userId && booking.staffSnapshot.email) {
							// Generate ICS file for each staff
							businessIcsFileString = await IcsService.generateIcs(
								true,
								referencedBusiness,
								bookingDoc,
								booking.serviceSnapshot
							);
							// Send email to staff
							const staffDocExist = await BookingDbModel.BookingModel.findOne({
								startDate: bookingDoc.startDate,
								endDate: bookingDoc.endDate,
								businessId: bookingDoc.businessId,
								serviceId: referencedService.id,
								status: { $in: [BookingStatus.Approved, BookingStatus.Pending] },
								staffId: staffId
							});
							if (!staffDocExist) {
								// save google event in staff Calendar
								if (booking.status === BookingStatus.Approved) {
									await GoogleService.postStaffGoogleCalendarEvents(calendarEventPayload, referencedBusiness.id, bookingDoc, staffSnapDoc, referencedBusiness, referencedService, existingBooking);
								}
								// && staffSnapDoc.notificationEnabled
								if (staffSnapDoc.email) {
									await EmailService.sendBookingApprovedToStaff(
										referencedBusiness,
										bookingDoc,
										booking.serviceSnapshot,
										staffSnapDoc,
										businessIcsFileString,
										googleMeetLink
									);
								}

							}
						}
						// Save booking to DB
						await BookingDbModel.BookingModel.create(bookingDoc);
					}
				}
				else {
					await BookingDbModel.BookingModel.create(bookingDoc)
				}
			} else {
				// if (booking.status === BookingStatus.Approved && booking.staffSnapshot) {
				// 	await GoogleService.postStaffGoogleCalendarEvents(calendarEventPayload, referencedBusiness.id, bookingDoc, booking.staffSnapshot, referencedBusiness, referencedService, existingBooking);
				// // && staffSnapDoc.notificationEnabled
				// if (booking.staffSnapshot.email) {
				// 	await EmailService.sendBookingApprovedToStaff(
				// 		referencedBusiness,
				// 		bookingDoc,
				// 		booking.serviceSnapshot,
				// 		booking.staffSnapshot,
				// 		businessIcsFileString,
				// 		googleMeetLink
				// 	);
				// }
				// }
				
				await BookingDbModel.BookingModel.create(bookingDoc)
			}
		} catch (err) {
			if (err.httpCode === 409) {
				Logger.logger.warn(`Booking already exists for business ${booking.business.id}'`)
				throw new ResourceAlreadyExistsError(err.message)
			}
			Logger.logger.error(`Failed to create booking for business ${booking.business.id}')`, err)
			throw new DatabaseError(`Failed to create booking for business ${booking.business.id}')`)
		}

		const newBooking = BookingDbModel.convertToDomainModel(bookingDoc)
		newBooking.serviceSnapshot = booking.serviceSnapshot
		newBooking.staffSnapshot = booking.staffSnapshot
		//  todo: create payment link 
		if (referencedBusiness.stripeConnectAccountId && referencedBusiness.isPaymentMethodConnected &&
			(referencedService && referencedService.paymentSetting && referencedService.paymentSetting.paymentType &&
				!referencedService.paymentSetting.paymentType.includes(ServicePaymentType.NoPayment))
			&& isPaidByMembership == false) {
			const { sessionLink, paidPrice } = await StripeService.createConnectedAccountCheckoutSession(bookingDoc, referencedService, newBooking.serviceSnapshot, referencedBusiness, fromBusiness, '');
			url = sessionLink;
			paidAmount = paidPrice;
		}
		if (newBooking.status == BookingStatus.Approved) {
			if (chargeImmediately) {
				newBooking.paymentUrl = url
			} else {
				emailPaymentLink = url;
			}
			try {
				customerIcsFileString = await IcsService.generateIcs(false, referencedBusiness, bookingDoc, newBooking.serviceSnapshot)
				businessIcsFileString = await IcsService.generateIcs(true, referencedBusiness, bookingDoc, newBooking.serviceSnapshot);
				if (referencedService && referencedService.location === 'google-meet' && googleMeetLink) {
					customerIcsFileString = await IcsService.generateGoogleIcs(false, referencedBusiness, bookingDoc, newBooking.serviceSnapshot, eventDoc, googleMeetLink);
					businessIcsFileString = await IcsService.generateGoogleIcs(true, referencedBusiness, bookingDoc, newBooking.serviceSnapshot, eventDoc, googleMeetLink);
					await EmailService.sendGoogleApprovedToCustomer(referencedBusiness, bookingDoc, newBooking.serviceSnapshot, newBooking.staffSnapshot, customerIcsFileString, googleMeetLink, emailPaymentLink, paidAmount / 100);
				}
				else {
					await EmailService.sendBookingApprovedToCustomer(referencedBusiness, bookingDoc, newBooking.serviceSnapshot, newBooking.staffSnapshot, customerIcsFileString, emailPaymentLink, paidAmount / 100, isEventService);
				}
			} catch (err) {
				Logger.logger.warn(`Failed to generate customer .ics file for booking ${bookingDoc._id}${err.message != null ? '. ' + err.message : ''}`)
			}
			try {


				if (googleMeetLink) {
					customerIcsFileString = await IcsService.generateGoogleIcs(true, referencedBusiness, bookingDoc, newBooking.serviceSnapshot, eventDoc, googleMeetLink);
					businessIcsFileString = await IcsService.generateIcs(true, referencedBusiness, bookingDoc, newBooking.serviceSnapshot)
				} else {
					businessIcsFileString = await IcsService.generateIcs(true, referencedBusiness, bookingDoc, newBooking.serviceSnapshot)
				}
				// add meet link
				await EmailService.sendBookingApprovedToBusiness(referencedBusiness, bookingDoc, newBooking.serviceSnapshot, newBooking.staffSnapshot, businessIcsFileString, googleMeetLink)
				// send email to staff
				if (referencedService.type !== 'event' && newBooking && newBooking.staffId && newBooking.staffSnapshot && newBooking.staffSnapshot.userId) {
					// get staff with id
					//  && newBooking.staffSnapshot.notificationEnabled
					if (newBooking.staffSnapshot.email) {
						await EmailService.sendBookingApprovedToStaff(referencedBusiness, bookingDoc, newBooking.serviceSnapshot, newBooking.staffSnapshot, businessIcsFileString, googleMeetLink);
					}

				}

			} catch (err) {
				Logger.logger.warn(`Failed to generate business .ics file for booking ${bookingDoc._id}${err.message != null ? '. ' + err.message : ''}`)
			}
		}
		else if (referencedBusiness?.settings?.bookingAutoapprove && newBooking.status == BookingStatus.Pending) {
			const hasNoPaymentRequirements =
				referencedService?.paymentSetting?.paymentType?.length
					? !referencedService.paymentSetting.paymentType.some(
						(type) =>
							type === ServicePaymentType.Deposit ||
							type === ServicePaymentType.FullPayment
					)
					: true; // if paymentType is undefined or empty, consider it as no payment required

			if (hasNoPaymentRequirements) {
				newBooking.status = BookingStatus.Approved;
				await this.partialUpdate(newBooking);
			}
			else {
				emailPaymentLink = url;
				newBooking.paymentUrl = emailPaymentLink;
				try {
					await EmailService.sendBookingRequestToBusiness(referencedBusiness, bookingDoc, booking.serviceSnapshot, booking.staffSnapshot)
				} catch (err) {
					Logger.logger.error(`Failed to send booking request to Business ${booking}')`, err)
				}
				try {
					/** TODO : Email reminder */
					// if (bookingDoc.customer.isEmailAllow) 
					if (hasNoPaymentRequirements) {
						await EmailService.sendBookingRequestToCustomer(referencedBusiness, bookingDoc, booking.serviceSnapshot, booking.staffSnapshot)
					}
				} catch (err) {
					Logger.logger.error(`Failed to send booking request to Customer ${booking}')`, err)
				}
			}
		}
		else {
			try {
				await EmailService.sendBookingRequestToBusiness(referencedBusiness, bookingDoc, booking.serviceSnapshot, booking.staffSnapshot)
			} catch (err) {
				Logger.logger.error(`Failed to send booking request to Business ${booking}')`, err)
			}
			try {
				emailPaymentLink = url;
				newBooking.paymentUrl = emailPaymentLink;
				const hasNoPaymentRequirements =
					referencedService?.paymentSetting?.paymentType?.length
						? !referencedService.paymentSetting.paymentType.some(
							(type) =>
								type === ServicePaymentType.Deposit ||
								type === ServicePaymentType.FullPayment
						)
						: true; // if paymentType is undefined or empty, consider it as no payment required

				if (hasNoPaymentRequirements) {
					await EmailService.sendBookingRequestToCustomer(referencedBusiness, bookingDoc, booking.serviceSnapshot, booking.staffSnapshot)
				}
			} catch (err) {
				Logger.logger.error(`Failed to send booking request to Customer ${booking}')`, err)
			}
		}
		return newBooking
	}


	public static async partialUpdate(booking: Booking): Promise<Booking> {
		const business = await BusinessesService.getById(booking.business.id)
		const referencedBusiness = await BusinessesService.getById(booking.business.id)
		const referencedService = referencedBusiness.services?.find(s => s.id == booking.service.id)

		let eventDoc, googleMeetLink;
		const currentBookingDoc = await BookingsService.getBookingDocByIdForBusinessAndService(booking.id, booking.business.id, booking.service.id)

		if (currentBookingDoc == null) {
			Logger.logger.warn(`Booking ${booking.id} for business ${booking.business.id} for service ${booking.service.id} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Booking ${booking.id} for business ${booking.business.id} for service ${booking.service.id} doesn't exist`)
		}
		const paidValue = currentBookingDoc['paidAmount'] ? currentBookingDoc['paidAmount'] : null;

		let resourceNotModified = true
		if (booking.status != null && booking.status != currentBookingDoc.status) {
			if (currentBookingDoc.status == BookingStatus.Rejected || currentBookingDoc.status == BookingStatus.Cancelled) {
				Logger.logger.warn(`Cannot update booking ${booking.id} status becasue it was already rejected or cancelled`)
				throw new BadRequestError(`Cannot update booking ${booking.id} status becasue it was already rejected or cancelled`)
			}

			if (currentBookingDoc.status == BookingStatus.Pending && booking.status == BookingStatus.Cancelled) {
				Logger.logger.warn(`Cannot update booking ${booking.id} status to Cancelled because it has not been approved/rejected yet`)
				throw new BadRequestError(`Cannot update booking ${booking.id} status to Cancelled because it has not been approved/rejected yet`)
			}

			if (currentBookingDoc.status == BookingStatus.Approved && booking.status != BookingStatus.Cancelled) {
				Logger.logger.warn(`Cannot update booking ${booking.id} status to anything but Cancelled because it has already been approved`)
				throw new BadRequestError(`Cannot update booking ${booking.id} status to anything but Cancelled because it has already been approved`)
			}

			if (currentBookingDoc.endDate < new Date()) {
				Logger.logger.warn(`Cannot update booking ${booking.id} status because it's past its end date`)
				throw new BadRequestError(`Cannot update booking ${booking.id} status because it's past its end date`)
			}

			// if booking time already exist
			// const existingBookings = await BookingDbModel.BookingModel.find({
			// 	startDate: { $lt: currentBookingDoc.endDate },
			// 	endDate: { $gt: currentBookingDoc.startDate },
			// 	businessId: currentBookingDoc.businessId,
			// 	status: { $in: [BookingStatus.Approved, BookingStatus.Pending, BookingStatus.GoogleEvent] }
			// }).exec();
			// // google events are not allowed to book
			// const googleEvents = existingBookings.filter(b => b.status === BookingStatus.GoogleEvent);
			// if (googleEvents.length > 0) {
			// 	Logger.logger.warn(`Time slot is already booked with Google Calendar events`);
			// 	throw new ResourceAlreadyExistsError(`El horario seleccionado no está disponible.`);
			// }
			// // For bookings with staff member and service assigned
			// if (currentBookingDoc.staffId) {
			// 	const staffServiceBookings = existingBookings.filter(b =>
			// 		b.staffId === currentBookingDoc.staffId &&
			// 		b.serviceId === currentBookingDoc.serviceId
			// 	);

			// 	const maxCapacity = referencedService.capacity || 1;
			// 	if (staffServiceBookings.length >= maxCapacity) {
			// 		Logger.logger.warn(`Staff member ${currentBookingDoc.staffId} has reached maximum capacity for service ${currentBookingDoc.serviceId} during this time period`);
			// 		throw new ResourceAlreadyExistsError(`El servicio está completamente reservado para este período de tiempo.`);
			// 	}

			// 	// Check if staff has other service bookings
			// 	const otherStaffBookings = existingBookings.filter(b =>
			// 		b.staffId === currentBookingDoc.staffId &&
			// 		b.serviceId !== currentBookingDoc.serviceId
			// 	);
			// 	if (otherStaffBookings.length > 0) {
			// 		Logger.logger.warn(`Staff member ${currentBookingDoc.staffId} has other service bookings during this time period`);
			// 		throw new BadRequestError(`El miembro del personal no está disponible durante este período de tiempo.`);
			// 	}
			// }
			// // For bookings without staff (service-only)
			// else {
			// 	const serviceBookings = existingBookings.filter(b =>
			// 		b.serviceId === currentBookingDoc.serviceId &&
			// 		!b.staffId
			// 	);
			// 	const maxCapacity = referencedService.capacity || 1;

			// 	if (serviceBookings.length >= maxCapacity) {
			// 		Logger.logger.warn(`Service ${currentBookingDoc.serviceId} is at maximum capacity for this time period`);
			// 		throw new ResourceAlreadyExistsError(`El servicio está completamente reservado para este período de tiempo.`);
			// 	}
			// }
			currentBookingDoc.status = booking.status
			resourceNotModified = false
		}

		// if (resourceNotModified == true) {
		// 	return null
		// }

		try {
			// await currentBookingDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to partially update booking ${booking.id} for business ${booking.business.id}`, err)
			throw new DatabaseError(`Failed to partially update booking ${booking.id} for business ${booking.business.id}`)
		}
		const updatedBooking = BookingDbModel.convertToDomainModel(currentBookingDoc)
		await BookingsService.hydrateBooking(updatedBooking)
		let customerIcsFileString: string
		let businessIcsFileString: string
		let customerGoogleIcsFileString: string;
		let isEventService = false;
		try {

			// 🧾 Get all active memberships for this client and service
			const memberShipActive: any[] = await ClientMembershipService.getMembershipActiveForClient(
				referencedBusiness.id,
				currentBookingDoc.serviceId,
				currentBookingDoc.clientId
			);
			// If memberships exist, check usage count
			if (memberShipActive?.length) {
				// Extract all membership & snapshot IDs for one-time DB query
				const membershipIds = memberShipActive.map(m => m.membershipId);
				const snapshotIds = memberShipActive.map(m => m.membershipSnapshotId);

				// 1️⃣ Fetch only relevant bookings once
				const existingBookings = await BookingDbModel.BookingModel.aggregate([
					{
						$match: {
							businessId: currentBookingDoc.businessId,
							clientId: currentBookingDoc.clientId,
							status: { $in: [BookingStatus.Approved, BookingStatus.Pending] },
							$or: [
								{ membershipId: { $in: membershipIds } },
								{ membershipSnapshotId: { $in: snapshotIds } }
							]
						}
					},
					{
						$group: {
							_id: "$membershipId",
							count: { $sum: 1 }
						}
					}
				]);

				// 2️⃣ Build a quick lookup map for used counts
				const usedCountMap = new Map(existingBookings.map(b => [b._id.toString(), b.count]));
				// 3️⃣ Find first available membership efficiently
				let availableMembership: any = null;
				for (const membership of memberShipActive) {
					const usedCount = usedCountMap.get(membership.membershipId.toString()) || 0;
					const remainingCount = membership.totalBookingQuantity - usedCount;

					if (remainingCount > 0) {
						availableMembership = membership;
						break;
					}
				}
				// 4️⃣ If available membership found, attach to booking				
				if (availableMembership) {
					currentBookingDoc.isFullPaid = true;
					currentBookingDoc.isPaidByMembership = true;
					currentBookingDoc.membershipId = availableMembership.membershipId;
					currentBookingDoc.membershipSnapshotId = availableMembership.membershipSnapshotId;
					currentBookingDoc.paymentStatus = "Paid";
					currentBookingDoc.status = BookingStatus.Approved;
					Logger.logger.info(
						`Booking linked to membership: ${availableMembership.membershipDetails?.membershipName || "Unknown"}`
					);
				} else {
					// 5️⃣ If all memberships are used, just log (no error)
					Logger.logger.info(
						`All memberships fully used for clientId: ${currentBookingDoc.clientId}`
					);
				}
			}
			// ***** end of check booking cbookingDocount *****


			// push event to signin user google calendar 
			if (updatedBooking.status === BookingStatus.Approved) {
				const calendarEventPayload = {
					title: referencedBusiness.name + "-" + currentBookingDoc.customer.name,
					location: `${referencedBusiness.address.address},${referencedBusiness.address.country}`,
					description: updatedBooking.serviceSnapshot.serviceDescription || "",
					startTime: new Date(updatedBooking.startDate).toISOString(),
					endTime: new Date(updatedBooking.endDate).toISOString(),
					timeZone: referencedBusiness.timeZone.name
				};
				const existingBooking = await BookingDbModel.BookingModel.findOne({
					startDate: updatedBooking.startDate,
					endDate: updatedBooking.endDate,
					businessId: currentBookingDoc.businessId,
					serviceId: referencedService.id,
					status: BookingStatus.Approved
				});
				eventDoc = await GoogleService.postGoogleCalendarEvents(calendarEventPayload, referencedBusiness.id, currentBookingDoc, referencedBusiness, referencedService, existingBooking)
				if (referencedService.location === 'google-meet' && eventDoc && (eventDoc.hangoutLink || existingBooking.meetLinkId)) {
					currentBookingDoc.meetLinkId = eventDoc.id;
					currentBookingDoc.googleMeetLink = eventDoc.hangoutLink || existingBooking.googleMeetLink;
					googleMeetLink = eventDoc.hangoutLink || existingBooking.googleMeetLink
				}
			}
			currentBookingDoc.googleEventId = eventDoc ? eventDoc.id : '';
			await currentBookingDoc.save();
		} catch (err) {
			Logger.logger.warn(`Failed to generate customer .ics file for booking ${currentBookingDoc._id}${err.message != null ? '. ' + err.message : ''}`)
		}

		try {
			businessIcsFileString = await IcsService.generateIcs(true, business, currentBookingDoc, updatedBooking.serviceSnapshot);
			customerIcsFileString = await IcsService.generateIcs(false, business, currentBookingDoc, updatedBooking.serviceSnapshot);
			if (googleMeetLink) {
				businessIcsFileString = await IcsService.generateGoogleIcs(true, referencedBusiness, currentBookingDoc, updatedBooking.serviceSnapshot, eventDoc, googleMeetLink)
				customerIcsFileString = await IcsService.generateGoogleIcs(false, referencedBusiness, currentBookingDoc, updatedBooking.serviceSnapshot, eventDoc, googleMeetLink)
			}
			// customerGoogleIcsFileString = await IcsService.generateGoogleIcs(false, referencedBusiness, currentBookingDoc, updatedBooking.serviceSnapshot, eventDoc, googleMeetLink)
		} catch (err) {
			Logger.logger.warn(`Failed to generate business .ics file for booking ${currentBookingDoc._id}${err.message != null ? '. ' + err.message : ''}`)
		}
		try {
			switch (currentBookingDoc.status) {
				case BookingStatus.Approved:
					const paidValue = currentBookingDoc['paidAmount'] ? currentBookingDoc['paidAmount'] : null;
					if (referencedService.location === 'google-meet' && eventDoc) {
						businessIcsFileString = await IcsService.generateGoogleIcs(true, referencedBusiness, currentBookingDoc, updatedBooking.serviceSnapshot, eventDoc, googleMeetLink);
						await EmailService.sendGoogleApprovedToCustomer(referencedBusiness, currentBookingDoc, updatedBooking.serviceSnapshot, updatedBooking.staffSnapshot, customerIcsFileString, googleMeetLink, null, paidValue / 100);
					} else {
						await EmailService.sendBookingApprovedToCustomer(business, currentBookingDoc, updatedBooking.serviceSnapshot, updatedBooking.staffSnapshot, customerIcsFileString, null, paidValue, isEventService)
					}
					// }
					// add meet link
					await EmailService.sendBookingApprovedToBusiness(business, currentBookingDoc, updatedBooking.serviceSnapshot, updatedBooking.staffSnapshot, businessIcsFileString, googleMeetLink)
					// send email to staff
					// && updatedBooking.staffSnapshot.notificationEnabled
					if (updatedBooking && updatedBooking.staffId && updatedBooking.staffSnapshot.userId && updatedBooking.staffSnapshot?.email) {
						// get staff with id
						await EmailService.sendBookingApprovedToStaff(business, currentBookingDoc, updatedBooking.serviceSnapshot, updatedBooking.staffSnapshot, businessIcsFileString, googleMeetLink)
					}
					break
				case BookingStatus.Rejected:
					/** TODO : Email reminder */
					// if (updatedBooking.customer.isEmailAllow)

					await EmailService.sendBookingRejectedToCustomer(business, updatedBooking)

					break
				case BookingStatus.Cancelled:
					// if event is created on google so delete the event when connect booking by user
					await GoogleService.cancelEventToGoogleCalendar(business, currentBookingDoc, roles.Business);
					/** TODO : Email reminder */
					// if (updatedBooking.customer.isEmailAllow)
					await EmailService.sendBookingCancelledToCustomer(business, updatedBooking)
					// cancle event from google calender 
					await EmailService.sendBookingCancelledToBusiness(business, updatedBooking)
					// send cancel booking to staff					
					if (updatedBooking && updatedBooking.staffId) {
						// get staff with id
						// && staffDoc.notificationEnabled
						const staffDoc = await StaffService.getStaffDocByObjectId(updatedBooking.staffId);
						if (staffDoc && staffDoc.email) {
							await EmailService.sendBookingCancelledToStaff(business, updatedBooking, staffDoc)
						}
					}
					break
				default:
					break
			}
		} catch { }
		return updatedBooking
	}

	public static async cancelPendingbookingAfterTime(): Promise<string> {
		try {
			// get list of pending booking
			const pendingBookingDocs = await BookingDbModel.BookingModel.find({ status: BookingStatus.Pending }).exec()
			if (pendingBookingDocs && pendingBookingDocs.length === 0) {
				Logger.logger.warn(`Not any pending booking`)
				return "";
			}
			pendingBookingDocs.forEach(async (booking) => {
				const currentTime = new Date().getTime();
				const endTime = new Date(booking.endDate).getTime()
				if (currentTime > endTime) {
					booking.status = BookingStatus.Cancelled
					booking['isCronJobCancel'] = true //this for update booking when cancel by scheduler
					await booking.save();
				}
			});

		} catch (error) {
			Logger.logger.error('Failed while cancel pending booking:', error)
		}
	}

	public static async customerCancel(bookingId: string, customerCancelTokenId: string): Promise<void> {
		let bookingDoc: IBooking

		try {
			bookingDoc = await BookingDbModel.BookingModel.findById(bookingId).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId}`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId}`)
		}

		if (bookingDoc?.customerCancellationToken?.id != customerCancelTokenId) {
			Logger.logger.warn(`Booking ${bookingId} or its cancellation token ${customerCancelTokenId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Booking ${bookingId} or its cancellation token ${customerCancelTokenId} doesn't exist`)
		}

		const business = await BusinessesService.getById(bookingDoc.businessId)

		if (bookingDoc.status == BookingStatus.Rejected || bookingDoc.status == BookingStatus.Cancelled ||
			bookingDoc.endDate < new Date()) {
			Logger.logger.warn(`Cannot cancel booking ${bookingId} because it is past its end date or it was already rejected or cancelled`)
			throw new BadRequestError(`Cannot cancel booking ${bookingId} because it is past its end date or it was already rejected or cancelled`)
		}

		bookingDoc.status = BookingStatus.Cancelled
		bookingDoc.customerCancellationToken = undefined

		try {
			await bookingDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to update booking ${bookingId} when cancelling booking by customer`, err)
			throw new DatabaseError(`Failed to update booking ${bookingId} when cancelling booking by customer`)
		}

		const booking = BookingDbModel.convertToDomainModel(bookingDoc)
		await BookingsService.hydrateBooking(booking)
		try {
			// cancel event from google calender
			await GoogleService.cancelEventToGoogleCalendar(business, bookingDoc, roles.Business);
			await EmailService.sendBookingCancelledToBusiness(business, booking);
			// send cancel booking to staff
			if (booking && booking.staffId) {
				// get staff with id
				const staffDoc = await StaffService.getStaffDocByObjectId(booking.staffId);
				// send email to staff
				// && staffDoc.notificationEnabled 
				if (staffDoc && staffDoc.email) {
					await EmailService.sendBookingCancelledToStaff(business, booking, staffDoc)
				}
			}
		} catch { }
	}

	public static async updateBookingPaymentStatus(bookingId: string, status: number): Promise<Booking> {
		let bookingDoc: IBooking
		try {
			bookingDoc = await BookingDbModel.BookingModel.findById(bookingId).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId}`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId}`)
		}
		// BookingPaymentStatus[status]
		bookingDoc.billingStatus = status
		try {
			await bookingDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to update booking ${bookingId} when update booking by business`, err)
			throw new DatabaseError(`Failed to update booking ${bookingId} when update booking by business`)
		}
		const booking = BookingDbModel.convertToDomainModel(bookingDoc)
		await BookingsService.hydrateBooking(booking)
		return booking;
	}

	private static async getBookingDocByIdForBusiness(bookingId: string, businessId: string): Promise<IBooking> {
		try {
			return await BookingDbModel.BookingModel.findOne({ _id: bookingId, businessId: businessId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId} for business (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId} for business (${businessId})`)
		}
	}

	private static async getBookingDocByIdForClient(bookingId: string, clientId: string): Promise<IBooking> {
		try {
			return await BookingDbModel.BookingModel.findOne({ _id: bookingId, clientId: clientId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId} for client (${clientId})`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId} for client (${clientId})`)
		}
	}

	private static async getBookingDocByIdForBusinessAndService(bookingId: string, businessId: string, serviceId: string): Promise<IBooking> {
		try {
			return await BookingDbModel.BookingModel.findOne({ _id: bookingId, businessId: businessId, serviceId: serviceId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId} for business ${businessId} and service ${serviceId}`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId} for business ${businessId} and service ${serviceId}`)
		}
	}

	public static generateRandomFriendlyId(): string {
		let id = ""
		const allowedCharacters = "abcdefghijklmnopqrstuvwxyz0123456789"

		for (let i = 0; i < 5; i++) {
			id += allowedCharacters.at(Math.floor(Math.random() * allowedCharacters.length))
		}

		return id.toUpperCase()
	}

	private static async friendlyIdExsitsForBusiness(friendlyId: string, businessId: string): Promise<boolean> {
		try {
			return await BookingDbModel.BookingModel.exists({ businessId: businessId, friendlyId: friendlyId }) != null
		} catch (err) {
			Logger.logger.error(`Failed to check that friendly booking id (${friendlyId}) exists for business (${businessId})`, err)
			throw new DatabaseError(`Failed to check that friendly booking id (${friendlyId}) exists for business (${businessId})`)
		}
	}

	private static addTimeBlock(date: Date, blockLength: number, blockUnit: DurationUnit): Date {
		const result = new Date(date)

		switch (blockUnit) {
			case DurationUnit.Minute:
				result.setMinutes(date.getMinutes() + blockLength)
				return result
			case DurationUnit.Hour:
				result.setHours(date.getHours() + blockLength)
				return result
			// case DurationUnit.Day:
			// 	result.setDate(date.getDate() + blockLength)
			// 	return result
			// case DurationUnit.Week:
			// 	// what about time changes? A week from Wednesday, for example, should be next Wednesday
			// 	// regardless of time changes
			// 	result.setDate(date.getDate() + (blockLength * 7))
			// 	return result
			default:
				throw new Error(`Adding block length unit ${blockLength} is not implemented`)
		}
	}


	private static async hydrateBooking(booking: Booking): Promise<void> {
		booking.serviceSnapshot = await BusinessServiceSnapshotsService.getById(booking.serviceSnapshot.id)
		booking.staffSnapshot = booking.staffId ? await StaffService.getById(booking.staffId, booking.business.id) : null;
	}


	private static async hydrateBookingV2(booking: Booking): Promise<void> {
		booking.serviceSnapshot = await BusinessServiceSnapshotsService.getById(booking.serviceSnapshot.id);
		// const serviceDoc = await BusinessServicesService.getServiceById(booking.service.id);
		// booking.serviceSnapshot['paymentSetting'] = serviceDoc && serviceDoc.paymentSetting ? serviceDoc.paymentSetting : null;
		booking.staffSnapshot = booking.staffId ? await StaffService.getStaffById(booking.staffId, booking.business.id) : null;
	}

	private static async hydrateBookings(bookings: Booking[]): Promise<void> {
		const snapshots = await BusinessServiceSnapshotsService.getByIds(bookings.map(b => b.serviceSnapshot.id))
		for (const booking of bookings) {
			if (booking.service.id) {
				booking.serviceSnapshot = snapshots.find(s => s.id == booking.serviceSnapshot.id)
				// const serviceDoc = await BusinessServicesService.getServiceById(booking.service.id);
				// booking.serviceSnapshot.paymentSetting = serviceDoc.paymentSetting;
				// booking.serviceSnapshot['paymentSetting'] = serviceDoc && serviceDoc.paymentSetting ? serviceDoc.paymentSetting : null;
			}
		}
		const staff = await StaffService.getByIds(bookings.map(b => b.staffId));
		for (const booking of bookings) {
			booking.staffSnapshot = staff.find(s => s.id == booking.staffId && s.businessId == booking.business.id)

		}
	}

	private static async hydrateBookingsV2(bookings: any[]): Promise<void> {
		const business = await BusinessesService.getByIds(bookings.map(b => b.business.id))
		for (const booking of bookings) {
			// booking.business = business.find(s => s.id == booking.business.id)
			const b = business.find(s => s.id === booking.business.id);
			booking.business = b && { name: b.name, slug: b.slug, heroImage: b.heroImage };
		}
		const snapshots = await BusinessServiceSnapshotsService.getByIds(bookings.map(b => b.serviceSnapshot.id))
		for (const booking of bookings) {
			if (booking.service.id) {
				booking.serviceSnapshot = snapshots.find(s => s.id == booking.serviceSnapshot.id)
			}
		}
		const staff = await StaffService.getByIds(bookings.map(b => b.staffId));
		for (const booking of bookings) {
			booking.staffSnapshot = staff.find(s => s.id == booking.staffId && s.businessId == booking.business.id)

		}
	}

	public static async findEventByDates(sDate: Date, eDate: Date, businessId: string, serviceId: string): Promise<any> {
		try {
			return await await BookingDbModel.BookingModel.find({
				startDate: sDate,
				endDate: eDate,
				businessId: businessId,
				serviceId: serviceId,
				status: BookingStatus.Approved
			});
		} catch (err) {
			Logger.logger.error(`Failed to fetch event with given dates (startDate: ${sDate})and endDate: (${eDate})`, err)
			throw new DatabaseError(`Failed to fetch event with given dates (startDate: ${sDate})and endDate: (${eDate})`);
		}
	}

	public static async findBookingByMessageId(id: string): Promise<any> {
		try {
			return await await BookingDbModel.BookingModel.findOne({
				whatsappMessageId: id,
			});
		} catch (err) {
			Logger.logger.error(`Failed to fetch booking with given whatsapp Message Id ${id} `, err)
			throw new DatabaseError(`Failed to fetch booking with given whatsapp Message Id ${id} `);
		}
	}

	public static async getBookingDocById(bookingId: string): Promise<IBooking> {
		try {
			return await BookingDbModel.BookingModel.findOne({ _id: bookingId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId}`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId}`)
		}
	}

	public static async bookingMail(bookingId: string, fromBusiness): Promise<any> {
		const currentBookingDoc = await BookingsService.getBookingDocById(bookingId)
		if (currentBookingDoc) {
			try {
				const businessDoc: any = await BusinessesService.getBusinessDocById(currentBookingDoc.businessId);
				const serviceDoc: any = await BusinessServicesService.getServiceById(currentBookingDoc.serviceId);
				const serviceSnapshotIdDoc: any = await BusinessServiceSnapshotsService.getById(currentBookingDoc.serviceSnapshotId);
				const timeZoneDoc = await TimeZonesService.getById(businessDoc.timeZoneId)
				businessDoc['timeZone'] = timeZoneDoc;
				const { sessionLink, paidPrice } = await StripeService.createConnectedAccountCheckoutSession(currentBookingDoc, serviceDoc, serviceSnapshotIdDoc, businessDoc, fromBusiness, '');
				let checkoutLink = sessionLink;
				// send repayment link to customer for booking payment 
				EmailService.sendBookingPaymentFailedToCustomer(businessDoc, currentBookingDoc, serviceSnapshotIdDoc, checkoutLink)
			} catch (err) {
				Logger.logger.error(`payment_intent.payment_failed`, err)
			}
		}
	}

	public static async cancelPendingBookingPaymentAfter15Mins(): Promise<string> {
		try {
			const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000);
			// Get list of pending bookings created before 15 minutes from now
			const pendingBookingPaymentDocs = await BookingDbModel.BookingModel.find({
				paymentStatus: 'PENDING',
				status: BookingStatus.Pending,
				checkoutInitiatedAt: { $lte: fifteenMinutesAgo } // Only bookings before 15 minutes
			}).exec();
			if (!pendingBookingPaymentDocs.length) {
				Logger.logger.warn('No pending bookings found older than 15 minutes');
				return "No pending bookings";
			}

			pendingBookingPaymentDocs.forEach(async (booking) => {
				try {
					const serviceDoc = await BusinessServicesService.getServiceByObjectId(booking.serviceId);
					const hasPaymentRequirements = serviceDoc && serviceDoc.paymentSetting && serviceDoc.paymentSetting?.paymentType?.some(type =>
						type === ServicePaymentType.Deposit || type === ServicePaymentType.FullPayment
					);
					if (hasPaymentRequirements) {
						const businessDoc = await BusinessesService.getBusinessDocById(booking.businessId);
						await StripeService.expirePendingBookingCheckoutSession(booking['checkoutSessionId'])
						booking.status = BookingStatus.Cancelled;
						// Flag to update booking when cancelled by scheduler
						booking['isCheckoutCronJobCancel'] = true;
						booking['link'] = null;
						await booking.save();
						// send email to user for payment not processed
						await EmailService.sendBookingCancelledPayentNotProceedToCustomer(businessDoc, booking)
					}
					Logger.logger.info(`Booking with ID ${booking._id} has been cancelled`);
				} catch (error) {
					Logger.logger.error(`Failed to process booking ID ${booking._id}:`, error);
				}
			});

			return "Pending bookings cancellation initiated";
		} catch (error) {
			Logger.logger.error('Failed while cancelling pending bookings:', error);
			throw new Error('Error cancelling pending bookings');
		}
	}

	public static async getAddedBooking(
		businessIdParam: string,
		start: string,
		end: string,
		staffIdsParam: string,
		serviceIdParam: string
	): Promise<IBooking> {
		try {
			staffIdsParam = JSON.parse(staffIdsParam);
			const query: any = {
				startDate: { $lte: new Date(start) },
				endDate: { $gte: new Date(end) },
				$or: [{ businessId: businessIdParam }],
				status: { $in: [BookingStatus.Approved, BookingStatus.Pending] },
				staffId: { $in: staffIdsParam },
			};

			// ✅ Exclude records with the same serviceId if provided
			if (serviceIdParam) {
				query.serviceId = { $ne: serviceIdParam }; // Exclude bookings with same serviceId
			}

			const existingBookings = await BookingDbModel.BookingModel.find(query).exec();

			return existingBookings.length > 0 ? existingBookings[0] : null;
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking of date ${start}`, err)
			throw new DatabaseError(`Failed to retrieve booking if date ${start}`)
		}
	}

	public static async getBookingById(bookingId: string): Promise<Booking> {
		try {
			const bookingDoc = await this.getBookingDocById(bookingId);
			const booking = BookingDbModel.convertToDomainModel(bookingDoc)
			booking.staffSnapshot = booking.staffId == null ? undefined : await StaffService.getById(booking.staffId, bookingDoc.businessId)
			// await BookingsService.hydrateBooking(booking) // old method for get staff
			await BookingsService.hydrateBookingV2(booking)
			return booking
		} catch (err) {
			Logger.logger.error(`Failed to retrieve booking by id ${bookingId}`, err)
			throw new DatabaseError(`Failed to retrieve booking by id ${bookingId}`)
		}
	}
}
