import { IBusinessServiceDaysBlock } from "../db-models/business-service-days-block-db-model";
import { BusinessServiceEventSettingDbModel } from "../db-models/business-service-event-setting.model";
import { BusinessServicePaymentDbModel } from "../db-models/business-service-payment.model";
import {
  BusinessServiceDbModel,
  IBusinessService,
} from "../db-models/business-service.model";
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model";
import { ServiceAddressDbModel } from "../db-models/service-address.db-model";
import { MembershipServiceDbModel } from "../db-models/service-membership.db-model";
import { BadRequestError } from "../errors/bad-request.error";
import { DatabaseError } from "../errors/database.error";
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error";
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error";
import { Logger } from "../logger";
import { Business } from "../types/business";
import { BusinessService } from "../types/business-service";
import { BusinessServicePayment } from "../types/business-service-payment";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { MembershipTier } from "../types/enums/membership-tier.enum";
import { ServiceCategory } from "../types/service-category";
import { Staff } from "../types/staff";
import { TextFormatService } from "../utils/convert-html-to-text";
import { BusinessServiceSnapshotsService } from "./business-service-snapshots.service";
import { BusinessesService } from "./businesses.service";
import { ServiceCategoriesSerice } from "./service-categories.service";
import { StaffService } from "./staff.service";
import { TimeSlotService } from "./time-slot-service";
import { UploadFileService } from "./upload.file.service";
const { ObjectId } = require('mongodb');
export abstract class BusinessServicesService {
  public static async getById(
    businessId: string,
    serviceId: string,
    hydrate = true
  ): Promise<BusinessService> {
    const serviceDoc = await BusinessServicesService.getBusinessServiceDocById(
      serviceId,
      businessId
    );

    if (serviceDoc == null) {
      Logger.logger.warn(
        `Service ${serviceId} doesn't exist for business ${businessId}`
      );
      throw new ReferencedResourceNotFoundError(
        `Service ${serviceId} doesn't exist for business ${businessId}`
      );
    }
    const service = BusinessServiceDbModel.convertToDomainModel(serviceDoc);
    if (hydrate == true) {
      await BusinessServicesService.hydrateBusinessServices(businessId, [
        service,
      ]);
    };
    return service;
  }

  public static async getByIds(
    serviceIds: string[],
    excludeDeleted = true
  ): Promise<BusinessService[]> {
    return (
      await BusinessServicesService.getBusinessServiceDocsByIds(
        serviceIds,
        excludeDeleted
      )
    ).map((bs) => BusinessServiceDbModel.convertToDomainModel(bs));
  }

  public static async get(
    businessId: string,
    hydrate = true
  ): Promise<BusinessService[]> {
    const services = (
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        businessId
      )
    ).map((s) => BusinessServiceDbModel.convertToDomainModel(s));

    if (hydrate == true) {
      await BusinessServicesService.hydrateBusinessServices(
        businessId,
        services
      );
    }
    services.forEach(async (service) => {
      const tampName = await TextFormatService.removeSpecialCharacters(service.name)
      service['serviceSlug'] = tampName.replace(/\s+/g, '-');
    });

    return services;
  }

  public static async getV2(
    businessId: string,
    pageNumber: number,
    pageSize: number,
    hydrate = true
  ): Promise<any> {
    const services = (
      await BusinessServicesService.getBusinessServiceMembershipDocsForbusiness(
        businessId,
        pageNumber,
        pageSize
      )
    )
    const result = [];
    const { total, totalPages, timeline } = services
    for (const element of timeline) {
      if (element.type === 'service') {
        element.data['id'] = element.data._id.toString()
        // Convert service
        const service = BusinessServiceDbModel.convertToDomainModel(element.data);
        // Add serviceSlug
        const tampName = await TextFormatService.removeSpecialCharacters(service.name);
        service['serviceSlug'] = tampName.replace(/\s+/g, '-');

        result.push(service)
      } else if (element.type === 'membership') {
        element.data['id'] = element.data._id.toString()
        const membership = MembershipServiceDbModel.convertToDomainModel(element.data);
        // Sum of bookingQuantity
        const totalBookingQuantity = membership.packageSetting.reduce((sum, item) => sum + (item.bookingQuantity || 0), 0);
        membership['type'] = element.type;
        membership['capacity'] = totalBookingQuantity
        result.push(membership);
      }
    }

    if (hydrate == true) {
      await BusinessServicesService.hydrateBusinessServices(
        businessId,
        result
      );
    }
    return {
      data: result,
      pagination: {
        total,
        totalPages
      }
    };
  }


  public static async getStaffServices(
    staff: Staff,
    hydrate = true
  ): Promise<BusinessService[]> {
    const services = (
      await BusinessServicesService.getStaffServiceDocsForStaff(
        staff.servicesId
      )
    ).map((s) => BusinessServiceDbModel.convertToDomainModel(s));
    if (hydrate == true) {
      await BusinessServicesService.hydrateStaffServices(
        staff.businessId,
        services
      );
    }
    services.forEach(async (service) => {
      const tampName = await TextFormatService.removeSpecialCharacters(service.name)
      service['serviceSlug'] = tampName.replace(/\s+/g, '-');
    });

    return services;
  }

  public static async getStaffServicesDoc(
    staffId: string,
    hydrate = true
  ): Promise<BusinessService[]> {
    const staffDoc = await StaffService.getStaffDocByObjectId(staffId);
    return BusinessServicesService.getStaffServices(staffDoc);
  }

  private static async hydrateStaffServices(
    businessId: string,
    businessServices: BusinessService[]
  ): Promise<void> {
    const categoriesForBusiness = await ServiceCategoriesSerice.get(businessId);
    for (const businessService of businessServices) {
      businessService.category =
        businessService.category == null
          ? undefined
          : categoriesForBusiness.find(
            (c) => c.id == businessService.category.id
          );
    }
  }

  public static async getForBusinesses(
    businessIds: string[]
  ): Promise<BusinessService[]> {
    return (await this.getBusinessServiceDocsForBusinesses(businessIds)).map(
      (s) => BusinessServiceDbModel.convertToDomainModel(s)
    );
  }

  public static async create(
    businessId: string,
    businessService: BusinessService
  ): Promise<BusinessService> {
    const referencedServiceCategory =
      businessService.category == null
        ? undefined
        : await ServiceCategoriesSerice.getById(
          businessId,
          businessService.category.id
        );

    const services = await BusinessServicesService.get(businessId);
    if (
      services.some(
        (s) => s.name.toLowerCase() == businessService.name.toLowerCase()
      )
    ) {
      Logger.logger.info(
        `Referenced business ${businessId} already contains service called "${businessService.name}"`
      );
      throw new ResourceAlreadyExistsError(
        `Referenced business ${businessId} already contains service called "${businessService.name}"`
      );
    }

    if (businessService.type !== 'event' &&
      businessService.durationUnit == DurationUnit.Minute &&
      businessService.duration < 5
    ) {
      Logger.logger.warn("Service duration cannot be shorter than 5 minutes");
      throw new BadRequestError(
        "Service duration cannot be shorter than 5 minutes"
      );
    }

    if (businessService.price == null) {
      businessService.price = 0;
    }

    businessService.calculateHash();
    businessService.isDeleted = false;

    /** add service week days based on business */
    if (businessService && businessService.serviceDaysBlocks === undefined || businessService && businessService.serviceDaysBlocks.length === 0) {
      businessService.serviceDaysBlocks = await BusinessServicesService.formatBusinessHoursBlocksForService(businessId)
    }
    const businessServiceDoc = BusinessServiceDbModel.convertToDbModel(
      businessId,
      businessService
    );

    try {
      // IF EVENT SERVICE STORE STAFF WITH SERVICE 
      if (businessServiceDoc.type === 'event' && businessServiceDoc.eventSetting) {
        const referencedBusiness = await BusinessesService.getById(businessId);
        //Save as UTC
        businessServiceDoc.eventSetting.startDate = TimeSlotService.getTimeZoneOffset(
          referencedBusiness.timeZone.name,
          businessService.eventSetting.startDate,
          false
        )
        businessServiceDoc.eventSetting.endDate = TimeSlotService.getTimeZoneOffset(
          referencedBusiness.timeZone.name,
          businessService.eventSetting.endDate,
          false
        )
        businessServiceDoc.eventSetting.startDate.setSeconds(0)
        businessServiceDoc.eventSetting.startDate.setMilliseconds(0)
        businessServiceDoc.eventSetting.endDate.setSeconds(0)
        businessServiceDoc.eventSetting.endDate.setMilliseconds(0)
      }

      // add service address 
      if (businessServiceDoc.serviceAddress != null && (
        businessServiceDoc.serviceAddress.address != businessService.serviceAddress?.address ||
        businessServiceDoc.serviceAddress.suite != businessService.serviceAddress?.suite ||
        businessServiceDoc.serviceAddress.district != businessService.serviceAddress?.district ||
        businessServiceDoc.serviceAddress.region != businessService.serviceAddress?.region ||
        businessServiceDoc.serviceAddress.city != businessService.serviceAddress?.city ||
        businessServiceDoc.serviceAddress.postcode != businessService.serviceAddress?.postcode ||
        businessServiceDoc.serviceAddress.country != businessService.serviceAddress?.country ||
        businessServiceDoc.serviceAddress.countryShortName != businessService.serviceAddress?.countryShortName ||
        businessServiceDoc.serviceAddress.coordinates?.latitude != businessService.serviceAddress.coordinates?.latitude ||
        businessServiceDoc.serviceAddress.coordinates?.longitude != businessService.serviceAddress.coordinates?.longitude

      )) {
        businessServiceDoc.serviceAddress = ServiceAddressDbModel.convertToDbModel(businessServiceDoc.serviceAddress)
      }

      // service logo upload
      if (businessService.logo !== undefined && businessService.logo != null && businessService.logo != '') {
        const url = await UploadFileService.uploadMembershipImages(businessService.logo, businessService.name, "logo-image");
        businessServiceDoc.logo = url
      }

      const serviceDoc = await BusinessServiceDbModel.BusinessServiceModel.create(
        businessServiceDoc
      );
      // IF EVENT SERVICE STORE STAFF WITH SERVICE 
      if (businessServiceDoc.type === 'event' && businessServiceDoc.eventSetting) {
        businessServiceDoc.eventSetting.staffs.forEach(async (element) => {
          const staffDoc = await StaffService.getById(element, businessId);
          if (staffDoc) {
            const updatedArray = [
              ...staffDoc.servicesId,
              serviceDoc.id.toString()
            ];
            StaffService.partialUpdateV2(staffDoc, updatedArray)
          }
        });
      }
    } catch (err) {
      Logger.logger.error(
        `Failed to save business ${businessId} while creating business service (name: '${businessService.name}')`,
        err
      );
      throw new DatabaseError(
        `Failed to save business ${businessId} while creating business service (name: '${businessService.name}')`
      );
    }

    const newBusinessService =
      BusinessServiceDbModel.convertToDomainModel(businessServiceDoc);
    newBusinessService.category = referencedServiceCategory;
    return newBusinessService;
  }

  public static async update(
    businessId: string,
    businessService: BusinessService
  ): Promise<BusinessService> {
    const serviceDocs =
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        businessId
      );
    const referencedServiceDoc = serviceDocs.find(
      (s) => s.id == businessService.id
    );

    if (referencedServiceDoc == null) {
      Logger.logger.warn(
        `Service ${businessService.id} for business ${businessId} doesn't exist`
      );
      throw new ReferencedResourceNotFoundError(
        `Service ${businessService.id} for business ${businessId} doesn't exist`
      );
    }
    if (
      businessService.name == referencedServiceDoc.name &&
      businessService.description == referencedServiceDoc.description &&
      businessService.category?.id == referencedServiceDoc.categoryId &&
      businessService.duration == referencedServiceDoc.duration &&
      businessService.durationUnit == referencedServiceDoc.durationUnit &&
      businessService.price == referencedServiceDoc.price &&
      businessService.currency == referencedServiceDoc.currency &&
      businessService.type == referencedServiceDoc.type &&
      businessService.capacity == referencedServiceDoc.capacity &&
      businessService.isActive == referencedServiceDoc.isActive &&
      businessService.location == referencedServiceDoc.location &&
      businessService.serviceDaysBlocks == referencedServiceDoc.serviceDaysBlocks &&
      businessService.paymentSetting == referencedServiceDoc.paymentSetting &&
      businessService.depositAmount == referencedServiceDoc.depositAmount &&
      businessService.eventSetting == referencedServiceDoc.eventSetting &&
      // businessService.isCapacityVisible == referencedServiceDoc.isCapacityVisible &&
      businessService.serviceAddress == referencedServiceDoc.serviceAddress &&
      businessService.cutOff == referencedServiceDoc.cutOff &&
      businessService.cutOffUnit == referencedServiceDoc.cutOffUnit
    ) {
      return null;
    }

    // IF EVENT SERVICE STORE STAFF WITH SERVICE 
    if (referencedServiceDoc.type === 'event' && businessService.eventSetting) {
      const removedStaffs = referencedServiceDoc.eventSetting.staffs.filter(staff => !businessService.eventSetting.staffs.includes(staff));
      removedStaffs.forEach(async (sId) => {
        const staffDoc: any = await StaffService.getStaffDocById(sId, businessId);
        if (staffDoc) {
          staffDoc['servicesId'] = staffDoc.servicesId.filter(id => id !== referencedServiceDoc.id);
          await staffDoc.save()
        }
      });
      businessService.eventSetting.staffs.forEach(async (element) => {
        const staffDoc = await StaffService.getById(element, businessId);
        if (staffDoc) {
          const updatedArray = [
            ...staffDoc.servicesId,
            referencedServiceDoc.id.toString()
          ];
          StaffService.partialUpdateV2(staffDoc, updatedArray)
        }
      });
    }

    if (businessService.type !== 'event' &&
      businessService.durationUnit == DurationUnit.Minute &&
      businessService.duration < 5
    ) {
      Logger.logger.warn("Service duration cannot be shorter than 5 minutes");
      throw new BadRequestError(
        "Service duration cannot be shorter than 5 minutes"
      );
    }

    if (
      businessService.name.toLowerCase() !=
      referencedServiceDoc.name.toLowerCase() &&
      serviceDocs.some(
        (s) => s.name.toLowerCase() == businessService.name.toLowerCase()
      )
    ) {
      Logger.logger.info(
        `Referenced business ${businessId} already contains service called "${businessService.name}"`
      );
      throw new ResourceAlreadyExistsError(
        `Referenced business ${businessId} already contains service called "${businessService.name}"`
      );
    }

    const referencedServiceCategory =
      businessService.category == null
        ? undefined
        : await ServiceCategoriesSerice.getById(
          businessId,
          businessService.category.id
        );

    businessService.calculateHash();

    referencedServiceDoc.name = businessService.name;
    referencedServiceDoc.description = businessService.description;
    referencedServiceDoc.categoryId = businessService.category?.id;
    referencedServiceDoc.duration = businessService.duration;
    referencedServiceDoc.durationUnit = businessService.durationUnit;
    referencedServiceDoc.price = businessService.price;
    referencedServiceDoc.currency = businessService.currency;
    referencedServiceDoc.type = businessService.type;
    referencedServiceDoc.capacity = businessService.capacity;
    referencedServiceDoc.isActive = businessService.isActive;
    referencedServiceDoc.hash = businessService.hash;
    // referencedServiceDoc.isCapacityVisible = businessService.isCapacityVisible;

    if (businessService.location != null) {
      referencedServiceDoc.location = businessService.location;
    }
    if (businessService.serviceDaysBlocks) {
      referencedServiceDoc.serviceDaysBlocks = businessService.serviceDaysBlocks;
    }

    referencedServiceDoc.cutOff = businessService.cutOff
    referencedServiceDoc.cutOffUnit = businessService.cutOffUnit

    if (businessService.paymentSetting) {
      referencedServiceDoc.paymentSetting = BusinessServicePaymentDbModel.convertToDbModel(businessService.paymentSetting);
    }

    if (businessService.eventSetting) {
      const referencedBusiness = await BusinessesService.getById(businessId);
      //Save as UTC
      businessService.eventSetting.startDate = TimeSlotService.getTimeZoneOffset(
        referencedBusiness.timeZone.name,
        businessService.eventSetting.startDate,
        false
      )

      businessService.eventSetting.endDate = TimeSlotService.getTimeZoneOffset(
        referencedBusiness.timeZone.name,
        businessService.eventSetting.endDate,
        false
      )

      businessService.eventSetting.startDate.setSeconds(0)
      businessService.eventSetting.startDate.setMilliseconds(0)
      businessService.eventSetting.endDate.setSeconds(0)
      businessService.eventSetting.endDate.setMilliseconds(0)
      referencedServiceDoc.eventSetting = BusinessServiceEventSettingDbModel.convertToDbModel(businessService.eventSetting);
    }

    // referencedServiceDoc.isCapacityVisible = businessService.isCapacityVisible;
    if (businessService.depositAmount) {
      referencedServiceDoc.depositAmount = businessService.depositAmount;
    }
    // referencedServiceDoc.cutOff = businessService.cutOff
    // referencedServiceDoc.cutOffUnit = businessService.cutOffUnit;

    if (businessService.logo !== undefined &&
      businessService.logo != referencedServiceDoc.logo
      && businessService.logo != null && businessService.logo != ''
    ) {
      const url = await UploadFileService.uploadMembershipImages(businessService.logo, referencedServiceDoc.name, "logo-image");
      referencedServiceDoc.logo = url
    }

    if ((businessService.logo === null || businessService.logo == '')) {
      const url = await UploadFileService.deleteuploadMembershipImage(referencedServiceDoc.logo);
      referencedServiceDoc.logo = ''
    }
    // add service address 
    if (businessService.serviceAddress && businessService.serviceAddress.address != null && (
      businessService.serviceAddress.address != referencedServiceDoc.serviceAddress?.address ||
      businessService.serviceAddress.suite != referencedServiceDoc.serviceAddress?.suite ||
      businessService.serviceAddress.district != referencedServiceDoc.serviceAddress?.district ||
      businessService.serviceAddress.region != referencedServiceDoc.serviceAddress?.region ||
      businessService.serviceAddress.city != referencedServiceDoc.serviceAddress?.city ||
      businessService.serviceAddress.postcode != referencedServiceDoc.serviceAddress?.postcode ||
      businessService.serviceAddress.country != referencedServiceDoc.serviceAddress?.country ||
      businessService.serviceAddress.countryShortName != referencedServiceDoc.serviceAddress?.countryShortName ||
      businessService.serviceAddress.coordinates?.latitude != referencedServiceDoc.serviceAddress.coordinates?.latitude ||
      businessService.serviceAddress.coordinates?.longitude != referencedServiceDoc.serviceAddress.coordinates?.longitude

    )) {
      referencedServiceDoc.serviceAddress = ServiceAddressDbModel.convertToDbModel(businessService.serviceAddress)
    }
    try {
      await referencedServiceDoc.save();
    } catch (err) {
      Logger.logger.error(
        `Failed to update business service ${businessService.id} for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to update business service ${businessService.id} for business ${businessId}`
      );
    }

    const newBusinessService =
      BusinessServiceDbModel.convertToDomainModel(referencedServiceDoc);
    newBusinessService.category = referencedServiceCategory;
    return newBusinessService;
  }

  public static async updateMeet(
    businessId: string,
    businessService: BusinessService
  ): Promise<BusinessService> {
    const serviceDocs =
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        businessId
      );
    const referencedServiceDoc = serviceDocs.find(
      (s) => s.id == businessService.id
    );

    if (referencedServiceDoc == null) {
      Logger.logger.warn(
        `Service ${businessService.id} for business ${businessId} doesn't exist`
      );
      throw new ReferencedResourceNotFoundError(
        `Service ${businessService.id} for business ${businessId} doesn't exist`
      );
    }

    if (
      businessService.name == referencedServiceDoc.name &&
      businessService.description == referencedServiceDoc.description &&
      businessService.category?.id == referencedServiceDoc.categoryId &&
      businessService.duration == referencedServiceDoc.duration &&
      businessService.durationUnit == referencedServiceDoc.durationUnit &&
      businessService.price == referencedServiceDoc.price &&
      businessService.currency == referencedServiceDoc.currency &&
      businessService.type == referencedServiceDoc.type &&
      businessService.capacity == referencedServiceDoc.capacity &&
      businessService.isActive == referencedServiceDoc.isActive &&
      businessService.location == referencedServiceDoc.location
      // businessService.groupMeetLink == referencedServiceDoc.groupMeetLink


    ) {
      return null;
    }

    if (businessService.type !== 'event' &&
      businessService.durationUnit == DurationUnit.Minute &&
      businessService.duration < 5
    ) {
      Logger.logger.warn("Service duration cannot be shorter than 5 minutes");
      throw new BadRequestError(
        "Service duration cannot be shorter than 5 minutes"
      );
    }

    if (
      businessService.name.toLowerCase() !=
      referencedServiceDoc.name.toLowerCase() &&
      serviceDocs.some(
        (s) => s.name.toLowerCase() == businessService.name.toLowerCase()
      )
    ) {
      Logger.logger.info(
        `Referenced business ${businessId} already contains service called "${businessService.name}"`
      );
      throw new ResourceAlreadyExistsError(
        `Referenced business ${businessId} already contains service called "${businessService.name}"`
      );
    }

    const referencedServiceCategory =
      businessService.category == null
        ? undefined
        : await ServiceCategoriesSerice.getById(
          businessId,
          businessService.category.id
        );

    businessService.calculateHash();

    referencedServiceDoc.name = businessService.name;
    referencedServiceDoc.description = businessService.description;
    referencedServiceDoc.categoryId = businessService.category?.id;
    referencedServiceDoc.duration = businessService.duration;
    referencedServiceDoc.durationUnit = businessService.durationUnit;
    referencedServiceDoc.price = businessService.price;
    referencedServiceDoc.currency = businessService.currency;
    referencedServiceDoc.type = businessService.type;
    referencedServiceDoc.capacity = businessService.capacity;
    referencedServiceDoc.isActive = businessService.isActive;
    referencedServiceDoc.hash = businessService.hash;
    if (businessService.location != null) {
      referencedServiceDoc.location = businessService.location;
    }
    // referencedServiceDoc.groupMeetLink = businessService.groupMeetLink;
    // referencedServiceDoc.meetEventId = businessService.meetEventId;


    try {
      await referencedServiceDoc.save();
    } catch (err) {
      Logger.logger.error(
        `Failed to update business service ${businessService.id} for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to update business service ${businessService.id} for business ${businessId}`
      );
    }

    const newBusinessService =
      BusinessServiceDbModel.convertToDomainModel(referencedServiceDoc);
    newBusinessService.category = referencedServiceCategory;
    return newBusinessService;
  }
  public static async updateBusinessServicesToFreeTier(
    businessId: string
  ): Promise<void> {
    const serviceDocs =
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        businessId
      );

    let activeCount = 0;
    // && s.type !== 'group' 
    serviceDocs
      .filter((s) => !s.isDeleted)
      .forEach(async (s: any) => {
        if (s.isActive && activeCount < 1 && s.type !== 'group') {
          activeCount = activeCount + 1;
        } else if (s.isActive) {
          const referencedServiceDoc = serviceDocs.find((sd) => sd.id == s.id);
          if (referencedServiceDoc != null) {
            referencedServiceDoc.isActive = false;
            // in active service
            referencedServiceDoc.isInActiveByPlan = true;
            try {
              await referencedServiceDoc.save();
            } catch (err) {
              Logger.logger.error(
                `updateBusinessServicesToThreeActive - Failed to update business service ${s.id} for business ${businessId}`,
                err
              );
            }
          }
        }
      });
  }

  public static async updateBusinessServicesActivateAll(
    businessId: string
  ): Promise<void> {
    const serviceDocs =
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        businessId
      );

    serviceDocs
      .filter((s) => !s.isDeleted)
      .forEach(async (s: any) => {
        const referencedServiceDoc = serviceDocs.find((sd) => sd.id == s.id);

        if (referencedServiceDoc != null) {
          referencedServiceDoc.isActive = true;
          try {
            await referencedServiceDoc.save();
          } catch (err) {
            Logger.logger.error(
              `updateBusinessServicesActivateAll - Failed to update business service ${s.id} for business ${businessId}`,
              err
            );
          }
        }
      });
  }

  public static async updateBusinessServicesActivateAllV2(
    businessId: string
  ): Promise<void> {
    const serviceDocs =
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        businessId
      );

    serviceDocs
      .filter((s) => !s.isDeleted)
      .forEach(async (s: any) => {
        const referencedServiceDoc = serviceDocs.find((sd) => sd.id == s.id);

        if (referencedServiceDoc != null && referencedServiceDoc.isInActiveByPlan) {
          referencedServiceDoc.isActive = true;
          referencedServiceDoc.isInActiveByPlan = false
          try {
            await referencedServiceDoc.save();
          } catch (err) {
            Logger.logger.error(
              `update Business Services Activate All - Failed to update business service ${s.id} for business ${businessId}`,
              err
            );
          }
        }
      });
  }

  public static async delete(
    businessId: string,
    serviceId: string,
    hydrate = true
  ): Promise<BusinessService> {
    const serviceDoc = await BusinessServicesService.getBusinessServiceDocById(
      serviceId,
      businessId
    );

    if (serviceDoc == null) {
      Logger.logger.warn(
        `Service ${serviceId} doesn't exist for business ${businessId}`
      );
      throw new ReferencedResourceNotFoundError(
        `Service ${serviceId} doesn't exist for business ${businessId}`
      );
    }

    serviceDoc.isDeleted = true;

    try {
      await serviceDoc.save();
    } catch (err) {
      Logger.logger.error(
        `Failed to mark business service ${serviceId} for business ${businessId} as deleted`,
        err
      );
      throw new DatabaseError(
        `Failed to mark business service ${serviceId} for business ${businessId} as deleted`
      );
    }

    const service = BusinessServiceDbModel.convertToDomainModel(serviceDoc);
    if (hydrate == true) {
      await BusinessServicesService.hydrateBusinessServices(businessId, [
        service,
      ]);
    }
    return service;
  }

  public static async removeCategoryForBusinessServicesByIdForBusiness(
    businessId: string,
    businessServicesIds: string[]
  ): Promise<void> {
    try {
      await BusinessServiceDbModel.BusinessServiceModel.updateMany(
        {
          _id: { $in: businessServicesIds },
          businessId: businessId,
        },
        {
          $unset: { categoryId: false },
        }
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to remove categories for business services [${businessServicesIds.join(
          ", "
        )}] for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to remove categories for business services [${businessServicesIds.join(
          ", "
        )}] for business ${businessId}`
      );
    }
  }

  public static async getBusinessServiceDocById(
    serviceId: string,
    businessId: string
  ): Promise<IBusinessService> {
    try {
      return await BusinessServiceDbModel.BusinessServiceModel.findOne({
        _id: serviceId,
        businessId: businessId,
        isDeleted: false,
      }).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business service ${serviceId} for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business service ${serviceId} for business ${businessId}`
      );
    }
  }

  public static async getBusinessServiceById(
    serviceId: string,
  ): Promise<IBusiness> {
    try {
      const result = await BusinessServiceDbModel.BusinessServiceModel.aggregate(
        [
          {
            $match: { _id: new ObjectId(serviceId), isDeleted: false }
          },
          {
            $addFields: {
              businessId: {
                $toObjectId: "$businessId"
              }
            }
          },
          {
            $lookup: {
              from: 'businesses',
              localField: 'businessId',
              foreignField: '_id',
              as: 'businessDoc'
            }
          },
          {
            $unwind: '$businessDoc'
          },
          {
            $replaceRoot: { newRoot: '$businessDoc' }
          }
        ]
      ).exec();
      if (result.length > 0) {
        return result[0];
      } else {
        return null
      }
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business service ${serviceId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business service ${serviceId}`
      );
    }
  }
  public static async getBusinessServiceDocsForBusinesses(
    businessIds: string[],
    excludeDeleted = true
  ): Promise<IBusinessService[]> {
    const uniqueBusinessIds = businessIds.filter((bid, index, bids) => {
      return bids.indexOf(bid) == index;
    });

    const filter = { businessId: { $in: uniqueBusinessIds } };

    if (excludeDeleted == true) {
      (filter as any).isDeleted = false;
    }

    try {
      return await BusinessServiceDbModel.BusinessServiceModel.find(
        filter
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business services for businesses ${uniqueBusinessIds.join(
          ", "
        )}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business services for businesses ${uniqueBusinessIds.join(
          ", "
        )}`
      );
    }
  }

  private static async getBusinessServiceDocsByIds(
    serviceIds: string[],
    excludeDeleted = true
  ): Promise<IBusinessService[]> {
    const uniqueServiceIds = serviceIds.filter((sid, index, sids) => {
      return sids.indexOf(sid) == index;
    });

    const filter = { _id: { $in: uniqueServiceIds } };

    if (excludeDeleted == true) {
      (filter as any).isDeleted = false;
    }

    try {
      return await BusinessServiceDbModel.BusinessServiceModel.find(
        filter
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business services by ids [${uniqueServiceIds.join(
          ", "
        )}]`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business services by ids [${uniqueServiceIds.join(
          ", "
        )}]`
      );
    }
  }

  public static async getBusinessServiceDocsForbusiness(
    businessId: string,
    excludeDeleted = true
  ): Promise<IBusinessService[]> {
    const filter = { businessId: businessId };

    if (excludeDeleted == true) {
      (filter as any).isDeleted = false;
    }

    try {
      return await BusinessServiceDbModel.BusinessServiceModel.find(
        filter
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business services for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business services for business ${businessId}`
      );
    }
  }
  // public static async getBusinessServiceMembershipDocsForbusiness(
  //   businessId: string,
  //   page:number,
  //   limit:number,
  //   excludeDeleted = true
  // ): Promise<any> {
  //   const filter = { _id: new ObjectId(businessId), isDeleted: false };
  //   const skip = (page - 1) * limit;
  //   try {
  //     // const servicesDocs = await BusinessServiceDbModel.BusinessServiceModel.find(
  //     //   filter
  //     // ).exec();
  //     // const membershipDocs = await MembershipServiceDbModel.MembershipServiceModel.find(
  //     //   filter
  //     // ).exec();

  //     const businessDocs = await BusinessDbModel.BusinessModel.aggregate([
  //       { $match: filter },
  //       {
  //         $addFields: {
  //           businessId: { $toString: "$_id" }
  //         }
  //       },
  //       {
  //         $lookup: {
  //           from: "business-services",
  //           let: { businessId: "$businessId" },
  //           pipeline: [
  //             {
  //               $match: {
  //                 $expr: {
  //                   $and: [
  //                     { $eq: ["$businessId", "$$businessId"] },
  //                     { $eq: ["$isDeleted", false] }
  //                   ]
  //                 }
  //               }
  //             }
  //           ],
  //           as: "services"
  //         }
  //       },
  //       {
  //         $lookup: {
  //           from: "business-memberships",
  //           let: { businessId: "$businessId" },
  //           pipeline: [
  //             {
  //               $match: {
  //                 $expr: {
  //                   $and: [
  //                     { $eq: ["$businessId", "$$businessId"] },
  //                     { $eq: ["$isDeleted", false] }
  //                   ]
  //                 }
  //               }
  //             }
  //           ],
  //           as: "memberships"
  //         }
  //       },
  //       {
  //         $addFields: {
  //           timeline: {
  //             $concatArrays: [
  //               {
  //                 $map: {
  //                   input: "$services",
  //                   as: "service",
  //                   in: {
  //                     type: "service",
  //                     data: "$$service"
  //                   }
  //                 }
  //               },
  //               {
  //                 $map: {
  //                   input: "$memberships",
  //                   as: "membership",
  //                   in: {
  //                     type: "membership",
  //                     data: "$$membership"
  //                   }
  //                 }
  //               }
  //             ]
  //           }
  //         }
  //       },
  //       { $unwind: "$timeline" },
  //       { $sort: { "timeline.data._id": -1 } },
  //       { $skip: skip },
  // 			{ $limit: limit },
  //       {
  //         $group: {
  //           _id: "$_id",
  //           name: { $first: "$name" },
  //           businessId: { $first: "$businessId" },
  //           timeline: { $push: "$timeline" }
  //         }
  //       }
  //     ]).exec();


  //     return businessDocs?.[0]?.timeline || [];
  //   } catch (err) {
  //     Logger.logger.error(
  //       `Failed to retrieve business services for business ${businessId}`,
  //       err
  //     );
  //     throw new DatabaseError(
  //       `Failed to retrieve business services for business ${businessId}`
  //     );
  //   }
  // }

  public static async getBusinessServiceMembershipDocsForbusiness(
    businessId: string,
    page: number,
    limit: number,
    excludeDeleted = true
  ): Promise<any> {
    const filter: any = { _id: new ObjectId(businessId) };
    if (excludeDeleted) filter.isDeleted = false;

    const skip = (page - 1) * limit;

    try {
      const [result] = await BusinessDbModel.BusinessModel.aggregate([
        { $match: filter },
        {
          $addFields: {
            businessId: { $toString: "$_id" },
          },
        },
        {
          $lookup: {
            from: "business-services",
            let: { businessId: "$businessId" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ["$businessId", "$$businessId"] },
                      { $eq: ["$isDeleted", false] },
                    ],
                  },
                },
              },
            ],
            as: "services",
          },
        },
        {
          $lookup: {
            from: "business-memberships",
            let: { businessId: "$businessId" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ["$businessId", "$$businessId"] },
                      { $eq: ["$isDeleted", false] },
                    ],
                  },
                },
              },
            ],
            as: "memberships",
          },
        },
        {
          $addFields: {
            timeline: {
              $concatArrays: [
                {
                  $map: {
                    input: "$services",
                    as: "service",
                    in: {
                      type: "service",
                      data: "$$service",
                    },
                  },
                },
                {
                  $map: {
                    input: "$memberships",
                    as: "membership",
                    in: {
                      type: "membership",
                      data: "$$membership",
                    },
                  },
                },
              ],
            },
          },
        },
        { $unwind: "$timeline" },
        {
          $facet: {
            metadata: [
              { $count: "total" },
              {
                $addFields: {
                  page,
                  limit,
                },
              },
            ],
            data: [
              { $sort: { "timeline.data._id": -1 } },
              { $skip: skip },
              { $limit: limit },
              {
                $group: {
                  _id: "$_id",
                  name: { $first: "$name" },
                  businessId: { $first: "$businessId" },
                  timeline: { $push: "$timeline" },
                },
              },
            ],
          },
        },
      ]).exec();

      const total = result?.metadata?.[0]?.total || 0;
      const totalPages = Math.ceil(total / limit);
      const data = result?.data?.[0] || { timeline: [] };

      return {
        page,
        limit,
        total,
        totalPages,
        timeline: data.timeline,
        businessId: data.businessId,
        name: data.name,
      };
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business services for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business services for business ${businessId}`
      );
    }
  }


  private static async getStaffServiceDocsForStaff(
    serviceIds: string[],
    excludeDeleted = true
  ): Promise<IBusinessService[]> {
    const filter = { _id: { $in: serviceIds } };
    if (excludeDeleted == true) {
      (filter as any).isDeleted = false;
    }
    try {
      return await BusinessServiceDbModel.BusinessServiceModel.find(
        filter
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve staff services for services`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve staff services for service`
      );
    }
  }

  private static async hydrateBusinessServices(
    businessId: string,
    businessServices: BusinessService[]
  ): Promise<void> {
    const categoriesForBusiness = await ServiceCategoriesSerice.get(businessId);
    for (const businessService of businessServices) {
      businessService.category =
        businessService.category == null
          ? undefined
          : categoriesForBusiness.find(
            (c) => c.id == businessService.category.id
          );
    }
  }

  public static async formatBusinessHoursBlocksForService(
    businessId: string
  ): Promise<IBusinessServiceDaysBlock[]> {
    try {

      const currentBusinessDoc = await BusinessesService.getBusinessDocById(businessId)
      const businessBlockTime = currentBusinessDoc.businessHoursBlocks;
      const uniqueDays = new Set();
      const serviceDays = businessBlockTime
        .map(bd => ({
          dayOfTheWeek: bd.startDayOfTheWeek
        }))
        .filter(bd => {
          // Only add to the new array if it's not already in the Set
          if (!uniqueDays.has(bd.dayOfTheWeek)) {
            uniqueDays.add(bd.dayOfTheWeek);
            return true;
          }
          return false;
        });
      return serviceDays
    } catch (error) {
      Logger.logger.error(
        `Update Business Services Days - Failed to update business service ${businessId} for business ${businessId}`,
        error
      );
    }
  }

  public static async updateServiceDaysArray(serviceDocs, businessBlockTime) {
    // Find unique data based on startDayOfTheWeek
    const uniqueDaysFromArr2 = businessBlockTime.reduce((acc, item) => {
      if (!acc.some(existingItem => existingItem.startDayOfTheWeek === item.startDayOfTheWeek)) {
        acc.push(item);
      }
      return acc;
    }, []);
    // // Loop through serviceDocs to update each inner array
    serviceDocs.map(async (innerArray) => {
      // Remove day from array1 if it doesn't exist in array2
      const updatedArray1 = innerArray.serviceDaysBlocks?.filter(item1 =>
        uniqueDaysFromArr2.some(item2 => item2.startDayOfTheWeek === item1.dayOfTheWeek)
      );
      innerArray.serviceDaysBlocks = updatedArray1;
      await innerArray.save()
    });
  }

  public static async updateBusinessServicesDays(business: IBusiness): Promise<void> {
    try {
      let serviceTime = null;
      const businessBlockTime = business.businessHoursBlocks;
      const serviceDocs = await this.getBusinessServiceDocsForbusiness(business.id)
      if (business.membershipTier !== MembershipTier.Free) {
        await this.updateServiceDaysArray(serviceDocs, businessBlockTime);
      } else {
        const uniqueDays = new Set();
        const serviceDays = businessBlockTime
          .map(bd => ({
            dayOfTheWeek: bd.startDayOfTheWeek
          }))
          .filter(bd => {
            // Only add to the new array if it's not already in the Set
            if (!uniqueDays.has(bd.dayOfTheWeek)) {
              uniqueDays.add(bd.dayOfTheWeek);
              return true;
            }
            return false;
          });
        serviceTime = serviceDays;
        serviceDocs.forEach(async (sd) => {
          sd.serviceDaysBlocks = serviceTime;
          await sd.save();  //save service time
        });
      }
    } catch (error) {
      Logger.logger.error(
        `Update Business Services Days - Failed to update business service ${business.id} for business ${business.id}`,
        error
      );
    }
  }

  public static async getServiceByObjectId(id: string) {
    try {
      return await BusinessServiceDbModel.BusinessServiceModel.findOne(
        { _id: id, isDeleted: false }
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve service of id ${id}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve service of id ${id}`
      );
    }
  }

  public static async getServiceById(id: string) {
    try {
      return await BusinessServiceDbModel.BusinessServiceModel.findOne(
        { _id: id, isDeleted: false }
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve service of id ${id}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve service of id ${id}`
      );
    }
  }

  public static async getAllBusinesServices(
    businessId: string,
  ): Promise<IBusinessService[]> {
    const filter = { businessId: businessId, type: 'event', isDeleted: false, isActive: true };
    try {
      return await BusinessServiceDbModel.BusinessServiceModel.find(
        filter
      ).exec();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business services for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business services for business ${businessId}`
      );
    }
  }

  public static async updateBusinessServicesCurrency(
    business: IBusiness
  ): Promise<void> {
    const serviceDocs =
      await BusinessServicesService.getBusinessServiceDocsForbusiness(
        business.id
      );
    for (let i = 0; i < serviceDocs.length; i++) {
      const s: any = serviceDocs[i];
      // updateservice.calculateHash();
      const hashToken = await BusinessService.calculateHashV2(s);
      s.currency = business.currency;
      s.hash = hashToken;
      try {
        await s.save();
      } catch (err) {
        Logger.logger.error(
          `updateBusinessServicesToThreeActive - Failed to update business service ${s.id} for business ${business.id}`,
          err
        );
      }
    }
  }

  public static async getBusinessServiceDocsForbusinessCapacity(
    businessId: string,
  ): Promise<IBusinessService[]> {
    const filter = { businessId: businessId, isCapacityVisible: false, isDeleted: false };

    try {
      return await BusinessServiceDbModel.BusinessServiceModel.find(
        filter,
        {
          _id: 1,
          businessId: 1,
          name: 1,
          type: 1,
          isCapacityVisible: 1
        }
      ).lean();
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve business services for business ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve business services for business ${businessId}`
      );
    }
  }

}
