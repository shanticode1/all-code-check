import { BookingDbModel } from "../db-models/booking.db-model";
import { DatabaseError } from "../errors/database.error";
import { Logger } from "../logger";
import { Booking } from "../types/booking";
import { CurrenciesLookUp } from "../types/enums/currencies";
import { Currency } from "../types/enums/currency";
import { ReportsRequest, ReportsResponse } from "../types/reports";
import { BusinessServiceSnapshotsService } from "./business-service-snapshots.service";
import { StaffService } from "./staff.service";

export abstract class ReportsService {
  public static async getReports(
    businessId: string,
    params: ReportsRequest
  ): Promise<ReportsResponse> {
    try {
      /* filtters getting from UI */
      let toDate = params.toDate;
      let fromDate = params.fromDate;
      let serviceId = params.serviceId;
      let staffId = params.staffId;

      /* Output Body */
      const report: ReportsResponse = {
        total_booking: 0,
        total_revanue: '0',
        top_service: {},
        no_of_reservation_staff: {},
        chartData: [],
        currency: 0,
      };

      /* Filter Object tobe passed in query*/
      let filters: any = {
        businessId: businessId,
        status: 1,
        $expr: {
          $and: [
            {
              $gte: [
                { $convert: { input: "$_id", to: "date" } },
                new Date(fromDate),
              ],
            },
            {
              $lte: [
                { $convert: { input: "$_id", to: "date" } },
                new Date(toDate),
              ],
            },
          ],
        },
      };

      if (serviceId && serviceId != "all") {
        filters.serviceId = serviceId;
      }

      if (staffId && staffId != "all") {
        filters.staffId = staffId;
      }

      /* Chart Aggrigartion query*/
      report.chartData = await BookingDbModel.BookingModel.aggregate([
        { $set: { serviceIde: { $toObjectId: "$serviceId" } } },
        {
          $match: filters,
        },
        {
          $lookup: {
            from: "business-services",
            localField: "serviceIde",
            foreignField: "_id",
            as: "services_data",
          },
        },
        {
          $unwind: "$services_data",
        },
        {
          $group: {
            _id: { $dateToString: { format: "%Y-%m-%d", date: "$_id" } },
            reservation: { $sum: 1 },
            revenue: { $sum: "$services_data.price" },
          },
        },
        {
          $project: {
            _id: 0,
            to_date: "$_id",
            total_reservation: "$reservation",
            total_revenue: "$revenue",
          },
        },
        { $sort: { to_date: 1 } },
      ]);
      
      let _chartData = []
      report.chartData.forEach((d) => {
        _chartData.push({
          ...d,
          total_revenue: d.total_revenue
        })
      })

      report.chartData = _chartData

      /* Cards total data */
      const bookingDocs = await BookingDbModel.BookingModel.find(filters)
        .sort({ _id: -1 })
        .exec();

      const bookings = bookingDocs.map((bd) =>
        BookingDbModel.convertToDomainModel(bd)
      );

      await ReportsService.hydrateBookings(bookings);

      report.total_booking = bookingDocs.length;
      let totalRev = 0;
      bookings.map((eachBooking) => {
        if (eachBooking?.serviceSnapshot?.servicePrice) {
          totalRev = totalRev + eachBooking.serviceSnapshot.servicePrice;

          report.top_service[eachBooking.serviceSnapshot.serviceName] =
            (report.top_service[eachBooking.serviceSnapshot.serviceName]
              ? report.top_service[eachBooking.serviceSnapshot.serviceName]
              : 0) + 1;
        }
        if (eachBooking?.staffSnapshot?.name) {
          report.no_of_reservation_staff[eachBooking.staffSnapshot.name] =
            (report.no_of_reservation_staff[eachBooking.staffSnapshot.name]
              ? report.no_of_reservation_staff[eachBooking.staffSnapshot.name]
              : 0) + 1;
        }
        report.currency = eachBooking.serviceSnapshot.serviceCurrency;
      });
      var currencyInfo = CurrenciesLookUp.find(
        (z) => z.code == Currency[report.currency]
      );
      report.total_revanue = currencyInfo && (currencyInfo.locale || currencyInfo.locule) ? (totalRev / 100).toLocaleString(currencyInfo.locale) : '';
      report.top_service = Object.keys(report.top_service)
        .sort()
        .reduce((obj, key) => {
          obj[key] = report.top_service[key];
          return obj;
        }, {});
      
      report.no_of_reservation_staff = Object.keys(
        report.no_of_reservation_staff
      )
        .sort()
        .reduce((obj, key) => {
          obj[key] = report.no_of_reservation_staff[key];
          return obj;
        }, {});

      return report;
    } catch (err) {
      Logger.logger.error(
        `Failed to retrieve reports by businessId ${businessId}`,
        err
      );
      throw new DatabaseError(
        `Failed to retrieve reports by businessId ${businessId}`
      );
    }
  }

  private static async hydrateBookings(bookings: Booking[]): Promise<void> {
    try {
      const snapshots = await BusinessServiceSnapshotsService.getByIds(
        bookings.map((b) => b.serviceSnapshot.id)
      );
      for (const booking of bookings) {
        booking.serviceSnapshot = snapshots.find(
          (s) => s.id == booking.serviceSnapshot.id
        );
      }
      const staff = await StaffService.getByIds(bookings.map((b) => b.staffId));
      for (const booking of bookings) {
        booking.staffSnapshot = staff.find((s) => s.id == booking.staffId && s.businessId == booking.business.id);
      }
    } catch (err) {
      Logger.logger.error(`Failed to retrieve reports by hydrateBookings`, err);
      throw new DatabaseError(`Failed to retrieve reports by hydrateBookings`);
    }
  }
}
