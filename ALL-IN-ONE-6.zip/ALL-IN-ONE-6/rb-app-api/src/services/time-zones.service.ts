import { ITimeZone, TimeZoneDbModel } from "../db-models/time-zone.db-model"
import { DatabaseError } from "../errors/database.error"
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error"
import { Logger } from "../logger"
import { TimeZone } from "../types/time-zone"
const axios = require("axios");

export class TimeZonesService {

	public static async getById(timeZoneId: string): Promise<TimeZone> {
		const timeZoneDoc = await TimeZonesService.getTimeZoneDocById(timeZoneId)

		if (timeZoneDoc == null) {
			Logger.logger.warn(`Time zone ${timeZoneId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Time zone ${timeZoneId} doesn't exist`)
		}

		return TimeZoneDbModel.convertToDomainModel(timeZoneDoc)
	}

	public static async getByIds(timeZoneIds: string[]): Promise<TimeZone[]> {
		return (await this.getTimeZoneDocsByIds(timeZoneIds)).map(tz => TimeZoneDbModel.convertToDomainModel(tz))
	}

	public static async getBusinessDefault(): Promise<TimeZone> {
		let timeZoneDoc: ITimeZone

		try {
			timeZoneDoc = await TimeZoneDbModel.TimeZoneModel.findOne({ isBusinessDefault: true }).exec()
		} catch (err) {
			Logger.logger.error("Failed to retrieve business default time zone", err)
			throw new DatabaseError("Failed to retrieve business default time zone")
		}

		if (timeZoneDoc == null) {
			Logger.logger.warn("Business default time zone doesn't exist")
			throw new ReferencedResourceNotFoundError("Business default time zone doesn't exist")
		}

		return TimeZoneDbModel.convertToDomainModel(timeZoneDoc)
	}

	public static async get(): Promise<TimeZone[]> {
		let timeZoneDocs: ITimeZone[]

		try {
			timeZoneDocs = await TimeZoneDbModel.TimeZoneModel.find().exec()
		} catch (err) {
			Logger.logger.error("Failed to get time zones", err)
			throw new DatabaseError("Failed to get time zones")
		}

		return timeZoneDocs.map(tz => TimeZoneDbModel.convertToDomainModel(tz))
	}

	public static async getTimeZoneDocById(timeZoneId: string): Promise<ITimeZone> {
		try {
			return await TimeZoneDbModel.TimeZoneModel.findById(timeZoneId).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve time zone by id (${timeZoneId})`, err)
			throw new DatabaseError(`Failed to retrieve time zone by id (${timeZoneId})`)
		}
	}

	private static async getTimeZoneDocsByIds(timeZoneIds: string[]): Promise<ITimeZone[]> {
		const uniqueTimeZoneIds = timeZoneIds.filter((tid, index, tids) => {
			return tids.indexOf(tid) == index
		})

		let timeZoneDocs: ITimeZone[]

		try {
			timeZoneDocs = await TimeZoneDbModel.TimeZoneModel.find({ _id: { $in: uniqueTimeZoneIds } }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve time zones by ids [${uniqueTimeZoneIds.join(', ')}]`, err)
			throw new DatabaseError(`Failed to retrieve time zones by ids [${uniqueTimeZoneIds.join(', ')}]`)
		}

		return timeZoneDocs
	}

	public static async getGoogleTimeZone(lat: string, lng: string): Promise<any> {
		try {
			const timestamp = Math.floor(Date.now() / 1000);
			const url = `https://maps.googleapis.com/maps/api/timezone/json?location=${lat},${lng}&timestamp=${timestamp}&key=${process.env.GOOGLE_API_KEY}`;
			try {
				const response = await axios.get(url);
				if (response.data && response.data.timeZoneId) {
					return { timeZoneId: response.data.timeZoneId };
				} else {
					console.log('Failed to retrieve time zone, defaulting to US time zone');
					return { timeZoneId: 'America/New_York' }; // Default US time zone
				}
			} catch (error) {
				console.error('Error getting time zone:', error);
				return { timeZoneId: 'America/New_York' }; // Default US time zone in case of error
			}
		} catch (error) {
			Logger.logger.error('error while get google time zone', error)
		}
	}

}