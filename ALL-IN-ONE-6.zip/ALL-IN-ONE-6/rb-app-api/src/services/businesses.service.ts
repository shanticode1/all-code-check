import * as bcrypt from "bcrypt"
import { Document } from "mongoose"

import { AddressDbModel } from "../db-models/address.db-model"
import { BusinessHoursBlockDbModel, IBusinessHoursBlock } from "../db-models/business-hours-block.db-model"
import { BusinessServiceDbModel } from "../db-models/business-service.model"
import { BusinessDbModel, IBusiness } from "../db-models/business.db-model"
import { CoordinatesDbModel } from "../db-models/coordinates.db-model"
import { BadRequestError } from "../errors/bad-request.error"
import { DatabaseError } from "../errors/database.error"
import { ReferencedResourceNotFoundError } from "../errors/referenced-resource-not-found.error"
import { ResourceAlreadyExistsError } from "../errors/resource-already-exists.error"
import { Logger } from "../logger"
import { Business, BusinessPagination } from "../types/business"
import { BusinessHoursBlock } from "../types/business-hours-block"
import { Currency } from "../types/enums/currency"
import { BusinessServicesService } from "./business-services.service"
import { BusinessTypesService } from "./business-types.service"
import { EmailService } from "./email.service"
import { BusinessSettings } from "./../types/business-settings";
import { TimeZonesService } from "./time-zones.service"
import { BusinessSocialMediasDbModel } from "../db-models/business-social-medias.db-model"
import { MembershipTier } from "../types/enums/membership-tier.enum"
import { StaffService } from "./staff.service"
import { BusinessDateOverridesService } from "./business-date-overrides.service"
import { StripeService } from "./stripe.service"
import { ModalTypeEnum, trialEnum } from "../types/enums/ModalType.enum"
import { Address } from "../types/address"
import { GoogleTokenValidator } from "../utils/google-token-validator"
import { UploadFileService } from "./upload.file.service"
import { TextFormatService } from "../utils/convert-html-to-text"
import { UserService } from "./users.service"
import { User } from "../types/user"
import { roles } from "../data/user.roles"
import { DurationUnit } from "../types/enums/duration-unit.enum"
import { PaymentType } from "../types/enums/payment-type.enum"
import { DateUtils } from "../utils/date.utils"
import { PaymentStatus } from "../types/enums/payment.status"
import { ClientMembershipService } from "./client-services-membership.service "
import { BusinessMembershipService } from "./business-services-membership.service "
const { v4: uuidv4 } = require('uuid');

export abstract class BusinessesService {
	public static async exists(businessId: string): Promise<boolean> {
		try {
			return await BusinessDbModel.BusinessModel.exists({ _id: businessId, activationToken: undefined, isDeleted: false }).exec() != null
		} catch (err) {
			Logger.logger.error(`Failed to find business ${businessId}`, err)
			throw new DatabaseError(`Failed to find business ${businessId}`)
		}
	}

	public static async getById(businessId: string, hydrate = true): Promise<Business> {
		const businessDoc = await BusinessesService.getBusinessDocById(businessId)

		if (businessDoc == null) {
			// Logger.logger.warn(`Business ${businessId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Business ${businessId} doesn't exist`)
		}
		//Create customer on Stripe if no record
		// try {
		// 	if (!businessDoc.stripeCustomerId) {
		// 		await StripeService.createCustomer(businessDoc.id, businessDoc.contactName, businessDoc.email) 
		// 	}
		// } catch (err) {
		// 	Logger.logger.error("Stripe Create Customer", err)
		// }
		// Membership Tier Logic
		let dateTimeNowUtc = new Date(new Date().toUTCString());
		let membershipExpirationUTC = new Date(businessDoc.membershipExpirationDate);

		const isTrialExpired = businessDoc.membershipTier !== MembershipTier.Free && businessDoc.stripeOnTrial && membershipExpirationUTC <= dateTimeNowUtc

		if (isTrialExpired) {
			businessDoc.stripeOnTrial = false;
		} else if (businessDoc.membershipTier != MembershipTier.Free && !businessDoc.stripeOnTrial && membershipExpirationUTC <= dateTimeNowUtc) {
			//Set to FREE tier
			try {
				businessDoc.membershipTier = MembershipTier.Free
				businessDoc.stripeOnTrial = false;
				businessDoc.settings.bookingAutoapprove = false;
				// stripe payment setting
				businessDoc.settings.paymentTypes = []
				await businessDoc.save();
				//Set 1 service to Active
				await BusinessServicesService.updateBusinessServicesToFreeTier(businessDoc.id);
				if (!businessDoc.isAnnualActive) {
					if (businessDoc.stripePriceIds && (businessDoc.stripePriceIds.staffUsagePriceId === '' || businessDoc.stripePriceIds.staffUsagePriceId == undefined)) {
						//Set all Staff to inactive
						await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
					}
				}

			} catch (error) {

			}
		} else if (businessDoc.membershipTier == MembershipTier.Free) {
			//ensure Free tier limitations are set
			try {
				businessDoc.settings.bookingAutoapprove = false;
				businessDoc.settings.paymentTypes = [];
				await businessDoc.save();
				//Set 1 service to Active
				await BusinessServicesService.updateBusinessServicesToFreeTier(businessDoc.id);
				if (!businessDoc.isAnnualActive) {
					if (businessDoc.stripePriceIds && (businessDoc.stripePriceIds.staffUsagePriceId === '' || businessDoc.stripePriceIds.staffUsagePriceId == undefined)) {
						//Set all Staff to inactive
						await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
					}
				}
			} catch (error) {
			}
		} else if (businessDoc.membershipTier == MembershipTier.Plus) {
			if (!businessDoc.isAnnualActive) {
				if (businessDoc.stripePriceIds && (businessDoc.stripePriceIds.staffUsagePriceId === '' || businessDoc.stripePriceIds.staffUsagePriceId == undefined)) {
					//Set all Staff to inactive
					await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
				}
			}
		}

		// Copy last login date before update
		const PrevLogin = businessDoc.lastLoginDate;
		//check when trial end
		const today = new Date();
		const expirationDate = new Date(businessDoc.membershipExpirationDate);
		const expirationDateCopy = new Date(businessDoc.membershipExpirationDate);
		if (businessDoc.stripeOnTrial) {
			// Subtract 3 days from the expirationDate
			expirationDate.setDate(expirationDate.getDate() - 3);
			if (today >= expirationDate && today <= expirationDateCopy) {
				businessDoc.modalType = ModalTypeEnum.TrialEnding;
			} else if (PrevLogin < expirationDateCopy && today > expirationDateCopy) {
				businessDoc.modalType = ModalTypeEnum.TrialEnded;
			} else {
				businessDoc.modalType = null;
			}
		} else {
			businessDoc.modalType = null;
		}
		//Update last login date
		businessDoc.lastLoginDate = dateTimeNowUtc;
		const business = BusinessDbModel.convertToDomainModel(businessDoc);

		// check stripe connect account is connected or not and deactivate packages if not connected
		if (!businessDoc.isPaymentMethodConnected || !businessDoc.stripeConnectAccountId) {
			await BusinessMembershipService.updateBusinessPackagesToInactive(businessDoc.id);
		}

		// check connected account submmited or not 
		if (businessDoc.stripeConnectAccountId) {
			const accountDoc = await StripeService.getConnectedAccountStatus(businessDoc);
			if (accountDoc.connectedAccDetails && accountDoc.connectedAccDetails.requirements.currently_due.length === 0) {
				businessDoc.isConnectedAccDetailSubmitted = true
				business['dashBoardUrl'] = accountDoc.dashBoardLink && accountDoc.dashBoardLink.url !== null ? accountDoc.dashBoardLink.url : '';
				business['actionRequiredDue'] = accountDoc.connectedAccDetails.requirements.currently_due;
			} else if (businessDoc.isPaymentMethodConnected && businessDoc.settings.paymentTypes.includes(PaymentType.Stripe)) {
				businessDoc.isConnectedAccDetailSubmitted = false;
				business['dashBoardUrl'] = await StripeService.createAccountOnboardingLink(businessDoc.id)
			}
			//  FOR THE TIME 
			if (accountDoc.connectedAccDetails.requirements.currently_due.length !== 0) {
				business['actionRequiredDue'] = accountDoc.connectedAccDetails.requirements.currently_due;
			}
			if (accountDoc.connectedAccDetails.future_requirements?.currently_due.length !== 0) {
				business['actionRequiredDue'] = accountDoc.connectedAccDetails.future_requirements?.currently_due;
			}
			if (accountDoc.connectedAccDetails.requirements.eventually_due.length !== 0) {
				business['actionRequiredDue'] = accountDoc.connectedAccDetails.requirements.eventually_due;
			}
		}
		await businessDoc.save();
		if (hydrate == true) {
			await BusinessesService.hydrateBusiness(business)
		}
		const businessStaffCount = await StaffService.getStaffByBusinessId(businessDoc.id);
		// businessDoc.membershipStaffCount = businessStaffCount;
		if (!businessDoc.isAnnualActive) {
			if (businessStaffCount >= businessDoc.membershipStaffCount) {
				//Set extra Staff to inactive if not paid
				// await StaffService.updateExtraBusinessStaffToInactive(businessDoc);
			}
		}
		if (businessDoc && businessDoc.isTrialActivatedOnce === null || businessDoc.isTrialActivatedOnce === undefined) {
			business.isTrialActivatedOnce = null
		}
		if (business && businessDoc.membershipTier != MembershipTier.Free) {
			if (business.googleToken) {
				await GoogleTokenValidator.setGlobalVariable(true)
				const isGoogleTokenValid = await GoogleTokenValidator.getGlobalVariable();
				delete business.googleToken;
				delete business.syncEventToken;
				business['isGoogleTokenValid'] = isGoogleTokenValid;
			}
		} else {
			business['isGoogleTokenValid'] = false;
			delete business.googleToken;
			delete business.syncEventToken;
		}

		if (businessDoc.membershipTier === MembershipTier.Free) {
			delete business.bannerImage;
			delete business.heroImage;
		}
		if (businessDoc.membershipTier === MembershipTier.Free || businessDoc.membershipTier === MembershipTier.Plus) {
			business['businessTotalStaff'] = businessDoc.stripePriceIds && (businessDoc.stripePriceIds.staffUsagePriceId) ? await StaffService.getStaffByBusinessId(businessDoc.id) : 0;
		} else if (businessDoc.membershipTier === MembershipTier.Pro) {
			business['businessTotalStaff'] = await StaffService.getStaffByBusinessId(businessDoc.id);
		}
		business['isConnectedAccDetailSubmitted'] = businessDoc.isConnectedAccDetailSubmitted;
		return business
	}


	public static async getByUserId(userId: string, hydrate = true): Promise<Business> {
		const userDoc = await UserService.getUserById(userId)
		const businessDoc = await BusinessesService.getBusinessDocByUserId(userId)
		if (businessDoc == null) {
			// Logger.logger.warn(`Business ${businessId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Business of use Id: ${userId} doesn't exist`)
		}
		//Create customer on Stripe if no record
		// try {
		// 	if (!businessDoc.stripeCustomerId) {
		// 		await StripeService.createCustomer(businessDoc.id, businessDoc.contactName, businessDoc.email) 
		// 	}
		// } catch (err) {
		// 	Logger.logger.error("Stripe Create Customer", err)
		// }

		// Membership Tier Logic
		let dateTimeNowUtc = new Date(new Date().toUTCString());
		let membershipExpirationUTC = new Date(businessDoc.membershipExpirationDate);

		const isTrialExpired = businessDoc.membershipTier !== MembershipTier.Free && businessDoc.stripeOnTrial && membershipExpirationUTC <= dateTimeNowUtc
		if (isTrialExpired) {
			businessDoc.stripeOnTrial = false;
		} else if (businessDoc.membershipTier != MembershipTier.Free && !businessDoc.stripeOnTrial && membershipExpirationUTC <= dateTimeNowUtc) {
			//Set to FREE tier
			try {
				businessDoc.membershipTier = MembershipTier.Free
				businessDoc.stripeOnTrial = false;
				businessDoc.settings.bookingAutoapprove = false;
				// stripe payment setting
				businessDoc.settings.paymentTypes = []
				await businessDoc.save();
				//Set 1 service to Active
				await BusinessServicesService.updateBusinessServicesToFreeTier(businessDoc.id);

				//Set all Staff to inactive
				await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
			} catch (error) {

			}
		} else if (businessDoc.membershipTier == MembershipTier.Free) {
			//ensure Free tier limitations are set
			try {
				businessDoc.settings.bookingAutoapprove = false;
				businessDoc.settings.paymentTypes = [];
				await businessDoc.save();

				//Set 1 service to Active
				await BusinessServicesService.updateBusinessServicesToFreeTier(businessDoc.id);

				//Set all Staff to inactive
				await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
			} catch (error) {
			}
		} else if (businessDoc.membershipTier == MembershipTier.Plus) {
			//Set all Staff to inactive
			//await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
			if (!businessDoc.isAnnualActive) {
				if (businessDoc.stripePriceIds && (businessDoc.stripePriceIds.staffUsagePriceId === '' || businessDoc.stripePriceIds.staffUsagePriceId == undefined)) {
					//Set all Staff to inactive
					await StaffService.updateBusinessStaffToFreeTier(businessDoc.id);
				}
			}
		}
		// Copy last login date before update
		const PrevLogin = businessDoc.lastLoginDate;

		//check when trial end
		const today = new Date();
		const expirationDate = new Date(businessDoc.membershipExpirationDate);
		const expirationDateCopy = new Date(businessDoc.membershipExpirationDate);
		if (businessDoc.stripeOnTrial) {
			// Subtract 3 days from the expirationDate
			expirationDate.setDate(expirationDate.getDate() - 3);
			if (today >= expirationDate && today <= expirationDateCopy) {
				businessDoc.modalType = ModalTypeEnum.TrialEnding;
			} else if (PrevLogin < expirationDateCopy && today > expirationDateCopy) {
				businessDoc.modalType = ModalTypeEnum.TrialEnded;
			} else {
				businessDoc.modalType = null;
			}
		} else {
			businessDoc.modalType = null;
		}

		//Update last login date
		businessDoc.lastLoginDate = dateTimeNowUtc;
		await businessDoc.save();
		businessDoc.user = userDoc;
		const business = BusinessDbModel.convertToDomainModel(businessDoc)
		if (hydrate == true) {
			await BusinessesService.hydrateBusiness(business)
		}
		if (businessDoc && businessDoc.isTrialActivatedOnce === null || businessDoc.isTrialActivatedOnce === undefined) {
			business.isTrialActivatedOnce = null
		}
		if (business && business.googleToken && businessDoc.membershipTier != MembershipTier.Free) {
			await GoogleTokenValidator.setGlobalVariable(true)
			const isGoogleTokenValid = await GoogleTokenValidator.getGlobalVariable();
			delete business.googleToken;
			delete business.syncEventToken;
			business['isGoogleTokenValid'] = isGoogleTokenValid;
		} else {
			business['isGoogleTokenValid'] = false;
			delete business.bannerImage;
			delete business.heroImage;
			delete business.googleToken;
			delete business.syncEventToken;
		}
		return business
	}

	public static async getByIds(businessIds: string[], excludeDeleted = true, hydrate = true): Promise<Business[]> {
		const businesses = (await BusinessesService.getBusinessDocsByIds(businessIds, excludeDeleted)).map(bd => BusinessDbModel.convertToDomainModel(bd))

		if (hydrate == true) {
			await this.hydrateBusinesses(businesses)
		}

		return businesses
	}

	// this method does not delete operator's password as it is used by auth service!
	public static async getByEmail(email: string): Promise<IBusiness> {
		let businessDoc: IBusiness

		try {
			businessDoc = await BusinessDbModel.BusinessModel.findOne({ email: email.toLowerCase(), activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error("Failed to get business by e-mail", err)
			throw new DatabaseError("Failed to get business by e-mail")
		}

		return businessDoc
	}

	public static async getBusinessByEmail(email: string): Promise<IBusiness> {
		let businessDoc: IBusiness

		try {
			businessDoc = await BusinessDbModel.BusinessModel.findOne({ email: email.toLowerCase(), isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error("Failed to get business by e-mail", err)
			throw new DatabaseError("Failed to get business by e-mail")
		}

		return businessDoc
	}
	public static async getBySlug(slug: string, clientId?: string, hydrate = true): Promise<Business> {
		let businessDoc: IBusiness

		try {
			businessDoc = await BusinessDbModel.BusinessModel.findOne({ slug: slug.toLowerCase(), activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error("Failed to get business by slug", err)
			throw new DatabaseError("Failed to get business by slug")
		}

		if (businessDoc == null) {
			return null
		}

		if (businessDoc.membershipTier === MembershipTier.Free) {
			return null;
		}
		// Pause access if payment failed and not on Free plan
		// if (
		// 	businessDoc.membershipTier !== MembershipTier.Free &&
		// 	businessDoc?.planBillingStatus === PaymentStatus.Failed &&
		// 	businessDoc.isAccessPaused) {
		// 	return null;

		// }

		const business = BusinessDbModel.convertToDomainModel(businessDoc)
		delete business.email
		business.type
		delete business.isActive
		delete business.isDeleted
		if (hydrate == true) {
			await BusinessesService.hydrateBusiness(business)
		}
		if (business.services && business.services.length > 0) {
			business.services.forEach(async (service) => {
				const tampName = await TextFormatService.removeSpecialCharacters(service.name)
				service['serviceSlug'] = tampName.replace(/\s+/g, '-');
			});
		}
		if (business.googleToken) {
			delete business.googleToken;
			delete business.syncEventToken;
			delete business.gmail
		}
		if (businessDoc.membershipTier == MembershipTier.Free) {
			delete business.bannerImage;
			delete business.heroImage;
		}
		// add client package check
		business.services = await ClientMembershipService.checkClientPackageValidity(business.services, clientId);

		return business
	}

	public static async getBySlugV2(slug: string, hydrate = true): Promise<Business> {
		let businessDoc: IBusiness

		try {
			businessDoc = await BusinessDbModel.BusinessModel.findOne({ slug: slug.toLowerCase(), activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error("Failed to get business by slug", err)
			throw new DatabaseError("Failed to get business by slug")
		}

		if (businessDoc == null) {
			return null
		}
		const business = BusinessDbModel.convertToDomainModel(businessDoc)
		delete business.email
		delete business.type
		delete business.isActive
		delete business.isDeleted
		delete business.isConnectedAccDetailSubmitted
		delete business.isPaymentMethodConnected
		delete business.isStaffPaymentPaid
		delete business.membershipStaffCount
		delete business.stripePriceIds
		delete business.usageCount
		delete business.whatsAppBagsCredits
		delete business.whatsAppCredits
		delete business.whatsAppPayAsYouGoCredits
		delete business.whatsAppPayAsYouGoMembershipTier
		delete business.whatsappBagsQuantity
		delete business.buyExtraStaffCount
		delete business.isPaymentDue
		delete business.isAnnualActive
		delete business.modalType
		// delete business.stripeConnectAccountId
		delete business.lastLoginDate
		delete business.createdAt
		delete business.isOperatingNonStop
		delete business.isTrialActivatedOnce
		delete business.isTrialOnce
		delete business.membershipTier
		// delete business.settings
		delete business.watchEventExpiry
		delete business.userId

		if (hydrate == true) {
			await BusinessesService.hydrateBusiness(business)
		}
		if (business.services && business.services.length > 0) {
			business.services.forEach(async (service) => {
				const tampName = await TextFormatService.removeSpecialCharacters(service.name)
				service['serviceSlug'] = tampName.replace(/\s+/g, '-');
			});
		}
		if (business.googleToken) {
			delete business.googleToken;
			delete business.syncEventToken;
			delete business.gmail
			delete business.googleCalendar;
		}
		if (businessDoc.membershipTier == MembershipTier.Free) {
			delete business.bannerImage;
			delete business.heroImage;
		}
		return business
	}

	public static async getByCountry(country: string, page, limit, searchParam, findByCategory, hydrate = true): Promise<any> {
		let businessDoc: IBusiness[];
		try {
			let filters: any = {
				// isPublishedOnMarketplace: true,  // temporarily hide all business from marketplace
				isActive: true,
				// "address.country": country,
				"address.city": country,
				activationToken: undefined,
				isDeleted: false,
				membershipTier: { $ne: MembershipTier.Free }
			}
			const skip = (page - 1) * limit;
			if (searchParam != undefined && searchParam != null && searchParam != "") {
				filters.name = { $regex: searchParam, $options: "i" }
			}
			if (findByCategory != undefined && findByCategory != null && findByCategory != "") {
				filters.businessTypeId = findByCategory
			}

			businessDoc = await BusinessDbModel.BusinessModel.aggregate([
				// 1️⃣ Match businesses based on filters
				{
					$match: filters
				},
				// 2️⃣ Sort, skip, limit for pagination
				{ $sort: { _id: -1 } },
				{ $skip: skip },
				{ $limit: limit },

				// 3️⃣ Convert _id to string for lookup
				{
					$addFields: {
						stringId: { $toString: "$_id" }
					}
				},

				// 4️⃣ Lookup services
				{
					$lookup: {
						from: "business-services",
						let: { businessId: "$stringId" },
						pipeline: [
							{
								$match: {
									$expr: { $eq: ["$businessId", "$$businessId"] },
									isActive: true,
									isDeleted: false
								}
							}
						],
						as: "services"
					}
				},

				// 5️⃣ Remove temporary stringId field
				{
					$project: {
						stringId: 0
					}
				}
			]).exec();

		} catch (err) {
			Logger.logger.error("Failed to get business by slug", err)
			throw new DatabaseError("Failed to get business by slug")
		}

		if (businessDoc == null) {
			return null
		}
		const formattedRecords = await this.formatBusinessAndServices(businessDoc)

		return formattedRecords
	}

	public static async formatBusinessAndServices(businesses) {
		const formattedBusinesses = businesses.map(business => ({
			serviceId: business._id,
			image: business.heroImage || null,
			title: business.name,
			rating: 4.5, // placeholder, use actual data if available
			price: null,
			unit: "Hours",
			currency: business.currency,
			serviceSlug: business.name.replace(/\s+/g, "-"),
			businessSlug: business.slug,
			name: business.name,
			address: business.address
		}));

		const formattedServices = businesses.flatMap(business =>
			business.services.map(service => ({
				serviceId: service._id,
				image: null, // placeholder
				title: service.name,
				rating: 4.5, // placeholder
				price: service.price ? service.price / 100 : 0,
				duration: service.type === 'event'
					? DateUtils.getTimeDifferenceInMinutes(service.eventSetting?.startDate, service.eventSetting?.endDate)
					: service.duration,
				unit: service.durationUnit === DurationUnit.Minute ? 'Minutes' : 'Hours',
				currency: service.currency,
				businessName: business.name,
				serviceSlug: TextFormatService.removeSpecialCharacters(service.name || '').replace(/\s+/g, '-'),
				businessSlug: business.slug,
				name: service.name,
				address: (service.serviceAddress && service.serviceAddress.country) ? service.serviceAddress : business.address
			}))
		);
		return {
			businesses: formattedBusinesses,
			services: formattedServices
		};
	}

	public static async getAll(city: string, country: string, businessType: string = '', hydrate = true): Promise<Business[]> {
		let businesses: Business[] = []
		let businessDocs: IBusiness[]

		try {
			if (businessType) {
				businessDocs = await BusinessDbModel.BusinessModel.find({ 'businessTypeId': businessType, 'address.city': city, 'address.country': country, activationToken: undefined, isDeleted: false, isActive: true }).exec()
			} else {
				businessDocs = await BusinessDbModel.BusinessModel.find({ 'address.city': city, 'address.country': country, activationToken: undefined, isDeleted: false, isActive: true }).exec()
			}
		} catch (err) {
			Logger.logger.error("Failed to get businesses", err)
			throw new DatabaseError("Failed to get businesses")
		}

		if (businessDocs == null) {
			return null
		}

		for await (const b of businessDocs) {
			const business = BusinessDbModel.convertToDomainModel(b)
			delete business.email
			delete business.type
			delete business.isActive
			delete business.isDeleted
			delete business.isConnectedAccDetailSubmitted

			await BusinessesService.hydrateBusiness(business)
			businesses.push(business);
		}

		return businesses
	}

	public static async getAllForAdmin(pageNumber: number, pageSize: number, searchParam: string): Promise<BusinessPagination> {
		let businesses: Business[] = []
		let businessDocs: IBusiness[]
		const skip = (pageNumber - 1) * pageSize;
		let totalCount: any = 0;
		try {
			let queryObject: any = { isActive: true, isDeleted: false }
			if (searchParam) {
				queryObject.email = { $regex: new RegExp(searchParam, 'i') }
			}
			// businessDocs = await BusinessDbModel.BusinessModel.find({ isActive: true, isDeleted: false }).sort({ '_id': -1 }).exec()

			// get to total count
			totalCount = await BusinessDbModel.BusinessModel.countDocuments(queryObject);


			// find data with pagination for admin
			businessDocs = await BusinessDbModel.BusinessModel
				.find(queryObject)
				.sort({ '_id': -1 })
				.skip(skip)
				.limit(pageSize)
				.exec();
		} catch (err) {
			Logger.logger.error("Failed to get businesses", err)
			throw new DatabaseError("Failed to get businesses")
		}

		if (businessDocs == null) {
			return null
		}
		let index = skip + 1;
		for await (const b of businessDocs) {
			const business = BusinessDbModel.convertToDomainModel(b)
			await BusinessesService.hydrateBusiness(business)
			business['index'] = index++;
			businesses.push(business);
		}
		// await Promise.all(businessDocs.map(async (b) => {
		// 	const business = BusinessDbModel.convertToDomainModel(b);
		// 	await BusinessesService.hydrateBusiness(business);
		// 	business['index'] = index++;
		// 	businesses.push(business);
		// }));
		return {
			totalCount: totalCount,
			businesses: businesses
		}
	}

	public static async create(business: Business): Promise<Business> {

		const businessDefaultTimeZone = await TimeZonesService.getBusinessDefault()

		if (await BusinessesService.getByEmail(business.email) != null) {
			Logger.logger.warn(`Business with email: '${business.email}' already exists`)
			throw new ResourceAlreadyExistsError(`Business with email: '${business.email}' already exists`)
		}
		if (await UserService.getUserByEmailAddress(business.email) != null) {
			Logger.logger.warn(`Business with email: '${business.email}' already exists`)
			throw new ResourceAlreadyExistsError(`Business with email: '${business.email}' already exists`)
		}
		business.name = null
		business.slug = null
		business.phoneNumber = null
		business.countryCode = null
		business.address = null
		business.type = null
		business.timeZone = businessDefaultTimeZone
		business.currency = Currency.CLP
		business.isOperatingNonStop = true
		business.businessHoursBlocks = null
		business.about = null
		business.services = null
		business.serviceCategories = null
		business.settings = new BusinessSettings(false, false, [], null, false, false, null, null, null, null, null, null)
		business.isActive = true
		business.isDeleted = false
		business.googleToken = null
		business.googleCalendar = null
		business.gmail = null
		business.stripePriceIds = null
		business.isTrialOnce = trialEnum.signUp
		// create business user in user table
		const userDeatils = await UserService.createV2(
			new User(
				undefined,
				business.email,
				business.password,
				business.contactName,
				roles.Business,
				undefined,
				undefined,
				undefined
			)
		)
		business.userId = userDeatils.id;
		try {
			business.password = await bcrypt.hash(business.password, 11)
		} catch (err) {
			Logger.logger.error(`Failed to hash password when creating business (email: '${business.email}')`, err)
			throw Error(`Failed to hash password when creating a new business (email: '${business.email}')`)
		}
		const businessDoc = BusinessDbModel.convertToDbModel(business)
		businessDoc.activationToken = new Object() as Document
		try {
			await BusinessDbModel.BusinessModel.create(businessDoc)
		} catch (err) {
			Logger.logger.error(`Failed to create business (email: '${business.email}')`, err)
			throw new DatabaseError(`Failed to create business (email: '${business.email}')`)
		}

		try {
			await EmailService.sendAccountActivationToBusiness(businessDoc)
		} catch { }

		return BusinessDbModel.convertToDomainModel(businessDoc)
	}

	public static async partialUpdate(business: Business): Promise<Business> {
		let isStripeUpdate = false;
		let uploadedUrls: any = [];
		const currentBusinessDoc = await BusinessesService.getBusinessDocById(business.id)
		if (currentBusinessDoc == null) {
			Logger.logger.warn(`Business ${business.id} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Business ${business.id} doesn't exist`)
		}
		const userDoc = await UserService.getUserByEmailAddress(currentBusinessDoc.email)
		if (currentBusinessDoc.email && userDoc == null) {
			Logger.logger.warn(`User ${business.email} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`User ${business.email} doesn't exist`)
		}
		let resourceNotModified = true

		if (business.contactName != null && business.contactName != currentBusinessDoc.contactName) {
			currentBusinessDoc.contactName = business.contactName
			resourceNotModified = false
			isStripeUpdate = true;

		}

		if (business.email != null && business.email.toLowerCase() != currentBusinessDoc.email) {
			if (await BusinessesService.getByEmail(business.email) != null) {
				Logger.logger.warn(`Business with email: '${business.email}' already exists`)
				throw new ResourceAlreadyExistsError(`Business with email: '${business.email}' already exists`)
			}
			// update customer email on stripe

			isStripeUpdate = true;

			// update business user email 
			userDoc.email = business.email

			currentBusinessDoc.email = business.email
			resourceNotModified = false
		}

		if (isStripeUpdate) {
			if (currentBusinessDoc && currentBusinessDoc.stripeCustomerId) {
				await StripeService.updateCustomerDetails(currentBusinessDoc.stripeCustomerId, business)
			}
		}

		if (business.referral != null) {
			currentBusinessDoc.referral = business.referral
			resourceNotModified = false
		}

		if (business.lastCompletedOnboardingStep != null) {
			currentBusinessDoc.lastCompletedOnboardingStep = business.lastCompletedOnboardingStep
			resourceNotModified = false
		}
		// if (business.isTrialActivatedOnce != null) {
		// 	currentBusinessDoc.isTrialActivatedOnce = business.isTrialActivatedOnce
		// 	resourceNotModified = false
		// }

		if (business.slug != null && business.slug.toLowerCase() != currentBusinessDoc.slug) {
			if (await BusinessesService.getBySlug(business.slug) != null) {
				Logger.logger.warn(`Business with slug: '${business.slug}' already exists`)
				throw new ResourceAlreadyExistsError(`Business with slug: '${business.slug}' already exists`)
			}
			currentBusinessDoc.slug = business.slug
			resourceNotModified = false
		}

		if (business.type != null && business.type.id != currentBusinessDoc.businessTypeId) {
			await BusinessTypesService.getById(business.type.id)
			currentBusinessDoc.businessTypeId = business.type.id
			resourceNotModified = false
		}

		if (business.phoneNumber != null && business.phoneNumber != currentBusinessDoc.phoneNumber) {
			currentBusinessDoc.phoneNumber = business.phoneNumber
			resourceNotModified = false
		}
		if (business.countryCode != null && business.countryCode != currentBusinessDoc.countryCode) {
			currentBusinessDoc.countryCode = business.countryCode
			resourceNotModified = false
		}

		if (business.address != null && (
			business.address.address != currentBusinessDoc.address?.address ||
			business.address.suite != currentBusinessDoc.address?.suite ||
			business.address.district != currentBusinessDoc.address?.district ||
			business.address.region != currentBusinessDoc.address?.region ||
			business.address.city != currentBusinessDoc.address?.city ||
			business.address.postcode != currentBusinessDoc.address?.postcode ||
			business.address.country != currentBusinessDoc.address?.country ||
			business.address.countryShortName != currentBusinessDoc.address?.countryShortName

		)) {
			currentBusinessDoc.address = AddressDbModel.convertToDbModel(business.address)
			resourceNotModified = false
		}

		if (business.coordinates != null) {
			if (business.coordinates.latitude == 0 && business.coordinates.longitude == 0) {
				business.coordinates = undefined
			}
			if (business.coordinates?.latitude != currentBusinessDoc.coordinates?.latitude ||
				business.coordinates?.longitude != currentBusinessDoc.coordinates?.longitude) {
				if (business.coordinates == undefined) {
					currentBusinessDoc.coordinates = business.coordinates
				} else {
					currentBusinessDoc.coordinates = CoordinatesDbModel.convertToDomainModel(business.coordinates)
				}
				resourceNotModified = false
			}
		}
		if (business.password != null) {
			try {
				const bcryptPassword = await bcrypt.hash(business.password, 11);
				currentBusinessDoc.password = bcryptPassword
				// update business user password 
				userDoc.password = bcryptPassword
			} catch (err) {
				Logger.logger.error(`Failed to hash password when partially updating business ${business.id}`, err)
				throw Error(`Failed to hash password when partially updating a new business ${business.id}`)
			}
			resourceNotModified = false
		}
		if (business.isOperatingNonStop != null && business.isOperatingNonStop != currentBusinessDoc.isOperatingNonStop) {
			currentBusinessDoc.isOperatingNonStop = business.isOperatingNonStop
			resourceNotModified = false
		}
		if (business.businessHoursBlocks != null) {
			if (business.businessHoursBlocks.length == 0) {
				business.businessHoursBlocks = undefined
			}
			if (BusinessesService.areBusinessHoursBlocksNotEqual(business.businessHoursBlocks, currentBusinessDoc.businessHoursBlocks)) {
				if (business.businessHoursBlocks == undefined) {
					currentBusinessDoc.businessHoursBlocks = business.businessHoursBlocks
					/** reset service days block if business block hours array is empty */
					await BusinessServicesService.updateBusinessServicesDays(currentBusinessDoc)
				} else {
					BusinessesService.checkBusinessHoursBlocksAreValid(business.businessHoursBlocks)
					currentBusinessDoc.businessHoursBlocks = business.businessHoursBlocks.map(bh => BusinessHoursBlockDbModel.convertToDbModel(bh))
					await BusinessServicesService.updateBusinessServicesDays(currentBusinessDoc)
				}
				resourceNotModified = false
			}
		}

		if (business.timeZone != null && business.timeZone.id != currentBusinessDoc.timeZoneId) {
			await TimeZonesService.getById(business.timeZone.id)
			currentBusinessDoc.timeZoneId = business.timeZone.id
			resourceNotModified = false
		}

		if (currentBusinessDoc.membershipTier !== MembershipTier.Free && (business.heroImage != 'undefined' && business.heroImage !== undefined && business.heroImage != null && business.heroImage != '')) {
			// upload file to digital ocean
			const url = await UploadFileService.uploadBusinessImages(business.heroImage, currentBusinessDoc, "logo-image");
			currentBusinessDoc.heroImage = url
			resourceNotModified = false
		}

		if (currentBusinessDoc.membershipTier !== MembershipTier.Free && (business.bannerImage != 'undefined' && business.bannerImage !== undefined && business.bannerImage != null && business.bannerImage != '')) {
			// upload file to digital ocean
			const url = await UploadFileService.uploadBusinessImages(business.bannerImage, currentBusinessDoc, 'hero-image');
			currentBusinessDoc.bannerImage = url
			resourceNotModified = false
		}
		if ((business.bannerImage === null || business.bannerImage == '')) {
			const url = await UploadFileService.deleteUploadBusinessImages(currentBusinessDoc.bannerImage, roles.Business);
			currentBusinessDoc.bannerImage = ''
			resourceNotModified = false
		}

		if ((business.heroImage === null || business.heroImage == '')) {
			const url = await UploadFileService.deleteUploadBusinessImages(currentBusinessDoc.heroImage, roles.Business);
			currentBusinessDoc.heroImage = ''
			resourceNotModified = false
		}
		// delete uploaded marketPlace image
		// Only process if there are IDs
		if (business.fileIds && business.fileIds.length > 0 && currentBusinessDoc.marketPlaceImages?.length) {
			const filledUrls = currentBusinessDoc.marketPlaceImages
				.filter(dbItem => business.fileIds.includes(dbItem.id)) // match by ID
				.map(dbItem => ({ id: dbItem.id, url: dbItem.url }))
				.filter(item => item.url && item.url.trim() !== ''); // only URLs that exist

			// Delete all matched URLs in parallel safely
			await Promise.allSettled(
				filledUrls.map(item =>
					UploadFileService.deleteuploadMarketPlaceImages(item.url)
						.then(result => Logger.logger.info(`Deleted URL: ${item.url}`))
						.catch(err => console.error(`Failed to delete URL: ${item.url}`, err))
				)
			);
			// Remove deleted images from DB array
			currentBusinessDoc.marketPlaceImages = currentBusinessDoc.marketPlaceImages.filter(
				dbItem => !business.fileIds.includes(dbItem.id)
			);
			resourceNotModified = false;
		}

		// upload market place images 
		if (currentBusinessDoc.membershipTier !== MembershipTier.Free && (business.marketPlaceImages.length > 0)) {
			// upload file to digital ocean
			for (let i = 0; i < business.marketPlaceImages.length; i++) {
				const image = business.marketPlaceImages[i];
				const url = await UploadFileService.uploadMarketPlaceImages(image, currentBusinessDoc.name, 'market-place-images');
				uploadedUrls.push({ url: url })
			}
			currentBusinessDoc.marketPlaceImages = uploadedUrls
			resourceNotModified = false
		}

		if (business.currency != null && business.currency != currentBusinessDoc.currency) {
			// update service currency while update business currency
			currentBusinessDoc.currency = business.currency;
			await BusinessServicesService.updateBusinessServicesCurrency(currentBusinessDoc)
			resourceNotModified = false
		}

		if (business.name != null && business.name != currentBusinessDoc.name) {
			currentBusinessDoc.name = business.name
			resourceNotModified = false
		}
		if (business.isPublishedOnMarketplace != null && business.isPublishedOnMarketplace != currentBusinessDoc.isPublishedOnMarketplace) {
			currentBusinessDoc.isPublishedOnMarketplace = business.isPublishedOnMarketplace
			resourceNotModified = false
		}

		if (business.about != null) {
			if (business.about == '') {
				business.about = undefined
			}
			if (business.about != currentBusinessDoc.about) {
				currentBusinessDoc.about = business.about
				resourceNotModified = false
			}
		}
		if (business.settings != null && (business.settings.bookingAutoapprove != currentBusinessDoc.settings?.bookingAutoapprove || business.settings.hideAddress != currentBusinessDoc.settings?.hideAddress || business.settings.paymentTypes != currentBusinessDoc.settings?.paymentTypes || business.settings.manualPaymentInfo != currentBusinessDoc.settings?.manualPaymentInfo || business.settings.isWhatsAppReminder != currentBusinessDoc.settings?.isEmailReminder || business.settings.isEmailReminder != currentBusinessDoc.settings?.isWhatsAppReminder || business.settings.whatsAppReminderInfo != currentBusinessDoc.settings?.whatsAppReminderInfo || business.settings.emailInfo != currentBusinessDoc.settings?.emailInfo || business.settings.emailReminderDuration != currentBusinessDoc.settings?.emailReminderDuration || business.settings.whatsappReminderDuration != currentBusinessDoc.settings?.whatsappReminderDuration || business.settings.cancelationPolicyInfo != currentBusinessDoc.settings?.cancelationPolicyInfo || business.settings.serviceCapacityVisibility != currentBusinessDoc.settings?.serviceCapacityVisibility)
		) {
			currentBusinessDoc.settings = business.settings
			resourceNotModified = false
		}

		//allow whatsapp reminder 
		// if (business.settings != null && (business.settings.isWhatsAppReminder != currentBusinessDoc.settings?.isWhatsAppReminder)) {
		// 	currentBusinessDoc.settings = business.settings
		// 	resourceNotModified = false
		// }

		if (business.socialMedia != null) {
			if (business.socialMedia.ig == undefined && business.socialMedia.fb == undefined && business.socialMedia.wa == undefined && business.socialMedia.countryCode == undefined) {
				business.socialMedia = undefined
			}

			if (business.socialMedia == undefined) {
				currentBusinessDoc.socialMedia = business.socialMedia
			} else {
				currentBusinessDoc.socialMedia = BusinessSocialMediasDbModel.convertToDbModel(business.socialMedia)
			}
			resourceNotModified = false
		}

		if (resourceNotModified == true) {
			return null
		}

		try {
			await currentBusinessDoc.save();
			if (business.email) await userDoc.save();
		} catch (err) {
			Logger.logger.error(`Failed to partially update business ${business.id}`, err)
			throw new DatabaseError(`Failed to partially update business ${business.id}`)
		}

		return BusinessDbModel.convertToDomainModel(currentBusinessDoc)
	}

	public static async createPasswordResetToken(email: string): Promise<void> {

		const businessDoc = await BusinessesService.getByEmail(email)

		if (businessDoc == null) {
			return
		}

		businessDoc.passwordResetToken = new Object() as Document

		try {
			await businessDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to save password reset token for business ${businessDoc.id}`, err)
			throw new DatabaseError(`Failed to save password reset token for business ${businessDoc.id}`)
		}

		try {
			await EmailService.sendPasswordResetToBusiness(businessDoc)
		} catch { }
	}

	public static async createPasswordResetTokenV2(email: string): Promise<void> {
		const businessDoc = await UserService.getUserByEmailAddress(email)

		if (businessDoc == null) {
			return
		}

		businessDoc.passwordResetToken = new Object() as Document

		try {
			await businessDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to save password reset token for business ${businessDoc.id}`, err)
			throw new DatabaseError(`Failed to save password reset token for business ${businessDoc.id}`)
		}

		try {
			await EmailService.sendPasswordResetToBusiness(businessDoc)
		} catch { }
	}

	public static async resetPassword(newPassword: string, businessId: string, passwordResetTokenId: string): Promise<void> {

		const businessDoc = await BusinessesService.getBusinessDocById(businessId)

		if (businessDoc?.passwordResetToken?.id != passwordResetTokenId) {
			Logger.logger.warn(`Business ${businessId} or its password reset token ${passwordResetTokenId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Business ${businessId} or its password reset token ${passwordResetTokenId} doesn't exist`)
		}

		const tokenExpiryDate = new Date(businessDoc.passwordResetToken._id.getTimestamp())
		tokenExpiryDate.setHours(tokenExpiryDate.getHours() + 1)

		if (tokenExpiryDate < new Date()) {

			businessDoc.passwordResetToken = undefined

			try {
				await businessDoc.save()
			} catch (err) {
				Logger.logger.error(`Failed to save password reset token for business ${businessDoc.id}`, err)
				throw new DatabaseError(`Failed to save password reset token for business ${businessDoc.id}`)
			}

			Logger.logger.warn(`Password reset token ${passwordResetTokenId} for business ${businessId} is expired`)
			throw new ReferencedResourceNotFoundError(`Password reset token ${passwordResetTokenId} for business ${businessId} is expired`)
		}

		try {
			businessDoc.password = await bcrypt.hash(newPassword, 11)
			const userData = await UserService.getUserById(businessDoc.userId);
			if (userData != null) {
				userData.password = businessDoc.password;
				await userData.save()
			}
		} catch (err) {
			Logger.logger.error(`Failed to hash new password when resetting password for business ${businessId}`, err)
			throw Error(`Failed to hash new password when resetting password for business ${businessId}`)
		}

		businessDoc.passwordResetToken = undefined

		try {
			await businessDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to save new password for business ${businessDoc.id}`, err)
			throw new DatabaseError(`Failed to save new password for business ${businessDoc.id}`)
		}
	}

	public static async resetPasswordV2(newPassword: string, businessId: string, passwordResetTokenId: string): Promise<void> {

		const userDoc = await UserService.getUserById(businessId);		
		if (userDoc?.passwordResetToken?.id != passwordResetTokenId) {
			Logger.logger.warn(`Business ${businessId} or its password reset token ${passwordResetTokenId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`user ${businessId} or its password reset token ${passwordResetTokenId} doesn't exist`)
		}
		const tokenExpiryDate = new Date(userDoc.passwordResetToken._id.getTimestamp())
		tokenExpiryDate.setHours(tokenExpiryDate.getHours() + 1)
		const bcryptedPassword = await bcrypt.hash(newPassword, 11);
		if (tokenExpiryDate > new Date()) {
			userDoc.passwordResetToken = undefined
			try {
				userDoc.password = bcryptedPassword;
				await userDoc.save();
			} catch (err) {
				Logger.logger.error(`Failed to save password reset token for user ${userDoc.id}`, err)
				throw new DatabaseError(`Failed to save password reset token for user ${userDoc.id}`)
			}
		} else {
			Logger.logger.warn(`Password reset token ${passwordResetTokenId} for user ${businessId} is expired`)
			throw new ReferencedResourceNotFoundError(`Password reset token ${passwordResetTokenId} for user ${businessId} is expired`)
		}

		try {
			// update business document if applicable
			if (userDoc.role == roles.Business) {
				const businessDoc = await BusinessesService.getBusinessDocByUserId(userDoc.id);
				businessDoc.password = bcryptedPassword;
				businessDoc.passwordResetToken = undefined
				await businessDoc.save()
			}
		} catch (err) {
			Logger.logger.error(`Failed to hash new password when resetting password for business ${businessId}`, err)
			throw Error(`Failed to hash new password when resetting password for business ${businessId}`)
		}

	}

	public static async activateAccount(businessId: string, activationTokenId: string): Promise<void> {
		let businessDoc: IBusiness
		try {
			businessDoc = await BusinessDbModel.BusinessModel.findById(businessId).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${businessId})`)
		}

		if (businessDoc?.activationToken?.id != activationTokenId) {
			Logger.logger.warn(`Business ${businessId} or its activation token ${activationTokenId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`Business ${businessId} or its activation token ${activationTokenId} doesn't exist`)
		}
		businessDoc.activationToken = undefined;
		try {
			await businessDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to update business ${businessDoc.id} when activating account`, err)
			throw new DatabaseError(`Failed to update business ${businessDoc.id} when activating account`)
		}
	}

	public static async getNewBusinessDocById(businessId: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ _id: businessId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${businessId})`)
		}
	}

	public static async getBusinessDocById(businessId: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ _id: businessId, activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${businessId})`)
		}
	}

	public static async getBusinessDocByUserId(id: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ userId: id, activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by user id (${id})`, err)
			throw new DatabaseError(`Failed to retrieve business by user id (${id})`)
		}
	}
	public static async getBusinessesDocByUserId(id: string): Promise<IBusiness[]> {
		try {
			return await BusinessDbModel.BusinessModel.find({ userId: id, activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by user id (${id})`, err)
			throw new DatabaseError(`Failed to retrieve business by user id (${id})`)
		}
	}

	public static async getBusinessDocByIdV2(businessId: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ _id: businessId, isDeleted: false, activationToken: undefined }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${businessId})`)
		}
	}

	public static async getBusinessByCalendarId(gResourceId: string, eventWatchId: string): Promise<IBusiness[]> {
		try {
			return await BusinessDbModel.BusinessModel.find({ gResourceId: gResourceId, gEventWatchId: eventWatchId, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by eventWatchId (${gResourceId})`, err)
			throw new DatabaseError(`Failed to retrieve business by eventWatchId (${gResourceId})`)
		}
	}

	private static async getBusinessDocsByIds(businessIds: string[], excludeDeleted = true): Promise<IBusiness[]> {
		const uniqueBusinessIds = businessIds.filter((bid, index, bids) => {
			return bids.indexOf(bid) == index
		})
		// activationToken: undefined
		const filter = {
			_id: { $in: uniqueBusinessIds },
			activationToken: { $exists: false }, // or change based on your need
		}

		if (excludeDeleted == true) {
			(filter as any).isDeleted = false
		}

		try {
			return await BusinessDbModel.BusinessModel.find(filter).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by ids [${uniqueBusinessIds.join(', ')}`, err)
			throw new DatabaseError(`Failed to retrieve business by ids [${uniqueBusinessIds.join(', ')}`)
		}
	}

	public static async getBusinessDocByStripeSubscriptionId(subId: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ stripeSubscriptionId: subId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by stripeSubscriptionId (${subId})`, err)
			throw new DatabaseError(`Failed to retrieve business by stripeSubscriptionId (${subId})`)
		}
	}

	public static async getBusinessDocByStripeCustomerId(stripeCustomerId: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ stripeCustomerId: stripeCustomerId }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by stripeCustomerId (${stripeCustomerId})`, err)
			throw new DatabaseError(`Failed to retrieve business by stripeCustomerId (${stripeCustomerId})`)
		}
	}

	private static async hydrateBusiness(business: Business): Promise<void> {
		const services = await BusinessServicesService.get(business.id)
		business.services = services.length == 0 ? undefined : services
		business.type = business.type == null ? undefined : await BusinessTypesService.getById(business.type.id)
		business.timeZone = await TimeZonesService.getById(business.timeZone.id)
		const overrides = await BusinessDateOverridesService.get(business.id);
		business.blockoutDates = overrides.blockoutDates || [];
		const packages = await BusinessMembershipService.getAllPackagesByBusinessId(business.id)
		business.packages = packages.length == 0 ? undefined : packages
	}

	private static async hydrateBusinesses(businesses: Business[]): Promise<void> {
		const serviceDocs = await BusinessServicesService.getBusinessServiceDocsForBusinesses(businesses.map(b => b.id))
		const types = await BusinessTypesService.getByIds(businesses.map(b => b.type?.id).filter(t => t != null))
		const timeZones = await TimeZonesService.getByIds(businesses.map(b => b.timeZone.id))

		for (const business of businesses) {
			business.services = serviceDocs.filter(s => s.businessId == business.id).map(s => BusinessServiceDbModel.convertToDomainModel(s))
			if (business.type != null) {
				business.type = types.find(t => t.id == business.type.id)
			}
			business.timeZone = timeZones.find(tz => tz.id == business.timeZone.id)
		}
	}

	private static areBusinessHoursBlocksNotEqual(businessHoursBlockA: BusinessHoursBlock[], businessHoursBlockB: IBusinessHoursBlock[]) {
		if (businessHoursBlockA == null && businessHoursBlockB == null) {
			return false
		}

		if (businessHoursBlockA != null && businessHoursBlockB == null ||
			businessHoursBlockB != null && businessHoursBlockA == null ||
			businessHoursBlockA.length != businessHoursBlockB.length) {
			return true
		}

		if (businessHoursBlockA.every(bhba => businessHoursBlockB.some(bhbb =>
			bhba.startDayOfTheWeek == bhbb.startDayOfTheWeek &&
			bhba.startHour == bhbb.startHour &&
			bhba.startMinute == bhbb.startMinute &&
			bhba.endDayOfTheWeek == bhbb.endDayOfTheWeek &&
			bhba.endHour == bhbb.endHour &&
			bhba.endMinute == bhbb.endMinute))) {
			return false
		}

		return true
	}

	private static checkBusinessHoursBlocksAreValid(businessHoursBlocks: BusinessHoursBlock[]): void {
		BusinessesService.checkBusinessHoursBlocksAreNotOverlapping(businessHoursBlocks)
	}

	private static checkBusinessHoursBlocksAreNotOverlapping(businessHoursBlocks: BusinessHoursBlock[]): void {
		for (let i = 0; i < businessHoursBlocks.length; i++) {
			const businessHoursBlockA = businessHoursBlocks[i]
			const businessHoursBlockAStartInt = businessHoursBlockA.getStartTimeInteger()
			const businessHoursBlockAEndInt = businessHoursBlockA.getEndTimeInteger()

			for (let j = 0; j < businessHoursBlocks.length; j++) {
				if (i == j) {
					continue
				}
				const businessHoursBlockB = businessHoursBlocks[j]
				const businessHoursBlockBStartInt = businessHoursBlockB.getStartTimeInteger()
				const businessHoursBlockBEndInt = businessHoursBlockB.getEndTimeInteger()

				if (businessHoursBlockAEndInt > businessHoursBlockAStartInt) {
					if ((businessHoursBlockBStartInt >= businessHoursBlockAStartInt && businessHoursBlockBStartInt <= businessHoursBlockAEndInt) ||
						(businessHoursBlockBEndInt >= businessHoursBlockAStartInt && businessHoursBlockBEndInt <= businessHoursBlockAEndInt)) {
						Logger.logger.warn(`businessHoursBlocks[${i}] overlaps with businessHoursBlocks[${j}]`)
						throw new BadRequestError(`businessHoursBlocks[${i}] overlaps with businessHoursBlocks[${j}]`)
					}
				} else {
					if ((businessHoursBlockBStartInt >= businessHoursBlockAStartInt && businessHoursBlockBStartInt <= 62359) ||
						(businessHoursBlockBStartInt >= 0 && businessHoursBlockBStartInt <= businessHoursBlockAEndInt) ||
						(businessHoursBlockBEndInt >= businessHoursBlockAStartInt && businessHoursBlockBEndInt <= 62359) ||
						(businessHoursBlockBEndInt >= 0 && businessHoursBlockBEndInt <= businessHoursBlockAEndInt)) {
						Logger.logger.warn(`businessHoursBlocks[${i}] overlaps with businessHoursBlocks[${j}]`)
						throw new BadRequestError(`businessHoursBlocks[${i}] overlaps with businessHoursBlocks[${j}]`)
					}
				}
			}
		}
	}

	public static async getBusinessDocByGmailId(id: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ gmail: id, activationToken: undefined, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${id})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${id})`)
		}
	}

	public static async getBusinessDocByEmailId(id: string): Promise<IBusiness> {
		try {
			return await BusinessDbModel.BusinessModel.findOne({ email: id, isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${id})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${id})`)
		}
	}
	public static async updateTrialOnce(stripeCustomerId: string): Promise<Business> {
		const currentBusinessDoc = await BusinessDbModel.BusinessModel.findOne({ stripeCustomerId: stripeCustomerId }).exec()
		if (currentBusinessDoc == null) {
			Logger.logger.warn(`StripeCustomerId ${stripeCustomerId} doesn't exist`)
			throw new ReferencedResourceNotFoundError(`StripeCustomerId ${stripeCustomerId} doesn't exist`)
		}
		currentBusinessDoc.isTrialActivatedOnce = true
		try {
			await currentBusinessDoc.save()
		} catch (err) {
			Logger.logger.error(`Failed to partially update StripeCustomerId ${stripeCustomerId}`, err)
			throw new DatabaseError(`Failed to partially update StripeCustomerId ${stripeCustomerId}`)
		}

		return BusinessDbModel.convertToDomainModel(currentBusinessDoc)
	}

	public static async updateBusinessWhatsappCredits(businessId: string): Promise<IBusiness> {
		try {
			const businessDoc = await BusinessDbModel.BusinessModel.findOne({ _id: businessId }).exec();
			if (businessDoc == null) {
				Logger.logger.warn(`Business ${businessId} doesn't exist`)
				throw new ReferencedResourceNotFoundError(`Business ${businessId} doesn't exist`)
			}
			// check credits based on plan (I=regular plan, II=bags plan, then use III=usages plan ) 
			if (businessDoc.whatsAppCredits === 0 && businessDoc.whatsAppBagsCredits !== 0) {
				// if whats regular plan balance is zero
				businessDoc['whatsAppBagsCredits'] = businessDoc['whatsAppBagsCredits'] - 1;
			} else if (businessDoc.whatsAppBagsCredits === 0 && businessDoc['whatsAppCredits'] === 0 && businessDoc.stripePriceIds && businessDoc.stripePriceIds.usagePriceId) {
				// update usage record to stripe for track current usages
				// businessDoc['whatsAppPayAsYouGoCredits'] = businessDoc['whatsAppPayAsYouGoCredits'] - 1;
				const usageData = await StripeService.createRecordUsage(businessDoc);
				if (usageData) {
					businessDoc.usageCount = businessDoc.usageCount ? Number(businessDoc.usageCount) + 1 : 1;
				}
			}
			else if (businessDoc['whatsAppCredits'] !== 0) {
				businessDoc['whatsAppCredits'] = businessDoc['whatsAppCredits'] - 1;
			}
			businessDoc.save();
			return businessDoc;
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business by id (${businessId})`, err)
			throw new DatabaseError(`Failed to retrieve business by id (${businessId})`)
		}
	}

	public static async getAllBusinessDocs(): Promise<IBusiness[]> {
		try {
			return await BusinessDbModel.BusinessModel.find({ isDeleted: false }).exec()
		} catch (err) {
			Logger.logger.error(`Failed to retrieve business list when renew calendar webhook`, err)
			// throw new DatabaseError(`Failed to retrieve business list when renew calendar webhook`)
		}
	}

	public static async saveUploadedFile(businessId: string, file: any): Promise<String> {
		try {
			const businessDoc = await BusinessDbModel.BusinessModel.findOne({ _id: businessId, isDeleted: false }).exec();
			if (businessDoc == null) {
				Logger.logger.warn(`Business ${businessId} doesn't exist`)
				throw new ReferencedResourceNotFoundError(`Business ${businessId} doesn't exist`)
			}
			// get uploaded file url and save into db
			const url = await UploadFileService.uploadBusinessImages(file, businessDoc, "");
			if (file.fieldname === 'heroImage') {
				businessDoc.heroImage = url;
			}
			if (file.fieldname === 'bannerImage') {
				businessDoc.bannerImage = url;
			}
			await businessDoc.save();
			return 'Uploaded'
		} catch (err) {
			Logger.logger.error(`Failed to save uploaded file for business id ${businessId}`, err)
			throw new DatabaseError(`Failed to upload file ${err}`)
		}
	}

	public static async resendConformationEmail(email: string): Promise<String> {
		try {
			let userDoc = null;
			const businessDoc = await BusinessesService.getBusinessByEmail(email);
			userDoc = businessDoc
			if (businessDoc == null) {
				userDoc = await UserService.getUserByEmailAddress(email)
			}

			if (userDoc && userDoc.email != null && userDoc.activationToken === undefined) {
				Logger.logger.warn(`confirmación error: Negocio con correo electrónico: '${email}' ya existe`)
				throw new ResourceAlreadyExistsError(`confirmación error: Negocio con correo electrónico: '${email}' ya existe`)
			}
			// else if (businessDoc === null) {
			// 	Logger.logger.warn(`Something went wrong please try again`)
			// 	throw new ResourceAlreadyExistsError(`Something went wrong please try again`)
			// }
			if (userDoc && userDoc.activationToken) {
				const currentTime = new Date();
				const resendInterval = 1 * 60 * 1000; // 1 minute in milliseconds
				if (userDoc && userDoc.emailResendTime && currentTime.getTime() - new Date(userDoc.emailResendTime).getTime() < resendInterval) {
					Logger.logger.warn(`confirmación error: Espere al menos 1 minuto antes de reenviar el correo electrónico de confirmación.`);
					throw new Error(`confirmación error: Espere al menos 1 minuto antes de reenviar el correo electrónico de confirmación.`);
				}
				// resend confirmation to user

				if (userDoc.role === roles.Client) {
					await EmailService.sendAccountActivationToClient(userDoc);
				}
				else {
					await EmailService.sendAccountActivationToBusiness(userDoc);
				}
				userDoc.emailResendTime = new Date()
				await userDoc.save()
				return 'Resend email';
			} else {
				Logger.logger.error(`confirmación error: Negocio con correo electrónico: '${email}' no registrado`);
				throw new DatabaseError(`confirmación error: Negocio con correo electrónico: '${email}' no registrado`)
			}
		} catch (error) {
			Logger.logger.error(`Failed to resend confirmation email : ${email}`, error);
			if (error.message.includes('confirmación error:')) {
				throw new DatabaseError(error.message)
			} else {
				throw new DatabaseError(`No se pudo reenviar el correo electrónico de confirmación`)
			}
		}
	}

	public static async getAllBusinesses(): Promise<IBusiness[]> {
		try {
			return await BusinessDbModel.BusinessModel.find({ isActive: true, isDeleted: false }).exec();
		} catch (err) {
			Logger.logger.error(`Failed to retrieve businesses`, err)
			throw new DatabaseError(`Failed to retrieve businesses`)
		}
	}

	public static async getAllServices(pageNumber: number, size: number, findBy: string, sortBy: string, searchParam: string, clientId: string, findByCategory: string, findByCountry: string): Promise<any> {
		try {
			let county = '';
			const page = pageNumber;
			const limit = size;
			const skip = (page - 1) * limit;
			const sortDirection: Record<string, 1 | -1> = sortBy === 'asc' ? { _id: 1 } : { _id: -1 };
			let filters: any = { isDeleted: false, isActive: true };

			let result: any[] = [];
			let totalCount = 0;
			if (searchParam != undefined && searchParam != null && searchParam != "") {
				// filters.name = new RegExp(searchParam, "i");
				filters.name = { $regex: searchParam.trim(), $options: "i" }
			} else {
				filters.name = { $exists: true, $ne: "" } // ✅ ensure service has a name
			}
			if (findByCountry != undefined && findByCountry != null && findByCountry != "") {
				county = findByCountry
			}

			if (findBy === 'service') {
				const servicePipeline = [
					{ $match: filters },
					{ $addFields: { businessId: { $toObjectId: "$businessId" } } },
					{
						$lookup: {
							from: "businesses",
							let: { businessId: "$businessId" },
							pipeline: [
								{
									$match: {
										$expr: { $eq: ["$_id", "$$businessId"] },
										...(findByCategory ? { businessTypeId: findByCategory } : {}),
										...(county ? { "address.country": county } : {})
									}
								},
								// ✅ Convert string IDs to ObjectId for lookups
								{
									$addFields: {
										businessTypeObjId: {
											$cond: [
												{ $ne: [{ $type: "$businessTypeId" }, "objectId"] },
												{ $toObjectId: "$businessTypeId" },
												"$businessTypeId"
											]
										},

									}
								},
								// ✅ Lookup Business Type details
								{
									$lookup: {
										from: "business-types",
										localField: "businessTypeObjId",
										foreignField: "_id",
										as: "businessTypeDetails"
									}
								},
								{ $unwind: { path: "$businessTypeDetails", preserveNullAndEmptyArrays: true } },
							],
							as: "businessDoc"
						}
					},
					{ $unwind: { path: "$businessDoc", preserveNullAndEmptyArrays: false } },
					{
						$addFields: {
							businessName: "$businessDoc.name",
							businessId: "$businessDoc._id",
							businessSlug: "$businessDoc.slug",
							address: "$businessDoc.address",
							businessType: "$businessDoc.businessTypeDetails", // ✅ Business type name
							serviceCategories: "$businessDoc.serviceCategories",
						}
					},
					{ $project: { businessDoc: 0 } },
					{
						$facet: {
							metadata: [{ $count: "total" }],
							data: [
								{ $sort: sortDirection },
								{ $skip: skip },
								{ $limit: limit }
							]
						}
					}
				];

				const aggResult = await BusinessServiceDbModel.BusinessServiceModel.aggregate(servicePipeline).exec();

				totalCount = aggResult[0]?.metadata[0]?.total || 0;
				result = aggResult[0]?.data || [];
			}
			else {
				if (findByCategory) {
					filters.businessTypeId = findByCategory
				}
				if (county) {
					filters["address.country"] = county
				}
				filters = {
					...filters,
					membershipTier: { $ne: MembershipTier.Free }
				};
				const businessDocs = await BusinessDbModel.BusinessModel.aggregate([
					{ $match: filters },
					{ $sort: sortDirection },
					{ $skip: skip },
					{ $limit: limit }
				]);
				totalCount = await BusinessDbModel.BusinessModel.countDocuments(filters);
				result = businessDocs || [];
			}
			// 🔹 Map data consistently
			const mappedData = result.map(service => ({
				serviceId: service._id,
				image: service.heroImage || null,
				title: service.name,
				rating: 4.5,
				price: service.price ? service.price / 100 : null,
				duration: service.type === 'event'
					? DateUtils.getTimeDifferenceInMinutes(service.eventSetting?.startDate, service.eventSetting?.endDate)
					: service.duration,
				unit: service.durationUnit === DurationUnit.Minute ? 'Minutes' : 'Hours',
				currency: service.currency,
				businessName: service.businessName,
				serviceSlug: TextFormatService.removeSpecialCharacters(service.name || '').replace(/\s+/g, '-'),
				businessSlug: service.businessSlug ?? service.slug,
				name: service.name,
				address: (service.serviceAddress && service.serviceAddress.country) ? service.serviceAddress : service.address,
				categoryName: service.categoryId ? service.serviceCategories.find(cat => cat._id?.$oid === service.categoryId)?.name : service.businessType?.name || '',
			}));

			return {
				data: mappedData,
				pagination: {
					total: totalCount,
					page,
					limit,
					totalPages: Math.ceil(totalCount / limit)
				}
			};
		} catch (err) {
			Logger.logger.error("Failed to get services/businesses", err);
			throw new DatabaseError("Failed to get services/businesses");
		}
	}

	public static async getNewBusiness(country: string, pageNumber: number, size: number): Promise<any> {
		try {
			const page = pageNumber;
			const limit = size;
			const skip = (page - 1) * limit;
			let filters: any = { isDeleted: false, isActive: true, "address.country": country, };

			let result: any[] = [];
			let totalCount = 0;
			filters = {
				...filters,
				membershipTier: { $ne: MembershipTier.Free } // get only paid users
			}
			// find data with pagination for admin
			const businessDocs = await BusinessDbModel.BusinessModel.aggregate([
				{ $match: filters }, // apply filters
				{ $sort: { _id: -1 } }, // sort
				{ $skip: skip }, // pagination skip
				{ $limit: limit } // pagination limit
			]);

			// get to total count
			totalCount = await BusinessDbModel.BusinessModel.countDocuments(filters);
			// totalCount = aggResult[0]?.metadata[0]?.total || 0;
			result = businessDocs || [];
			// 🔹 Map data consistently
			const mappedData = result.map(service => ({
				serviceId: service._id,
				image: service.heroImage || null,
				title: service.name,
				rating: 4.5,
				price: service.price ? service.price / 100 : null,
				duration: service.type === 'event'
					? DateUtils.getTimeDifferenceInMinutes(service.eventSetting?.startDate, service.eventSetting?.endDate)
					: service.duration,
				unit: service.durationUnit === DurationUnit.Minute ? 'Minutes' : 'Hours',
				currency: service.currency,
				businessName: service.businessName,
				serviceSlug: TextFormatService.removeSpecialCharacters(service.name || '').replace(/\s+/g, '-'),
				businessSlug: service.businessSlug ?? service.slug,
				name: service.name,
				address: service.address,
				description: service.about ?? service.description,
				settings: service.settings
			}));

			return {
				data: mappedData,
				pagination: {
					total: totalCount,
					page,
					limit,
					totalPages: Math.ceil(totalCount / limit)
				}
			};
		} catch (err) {
			Logger.logger.error("Failed to get services/businesses", err);
			throw new DatabaseError("Failed to get services/businesses");
		}
	}

	public static async getLocations(filter: { country?: string; city?: string } = {}): Promise<any> {
		try {
			const matchStage: any = {
				"address.city": { $nin: [null, ""] },  // ensure city exists
				"address.country": { $nin: [null, ""] } // ensure country exists
			};

			// apply filter if passed
			if (filter.country) {
				matchStage["address.country"] = filter.country;
			}
			if (filter.city) {
				matchStage["address.city"] = filter.city;
			}

			const result = await BusinessDbModel.BusinessModel.aggregate([
				{ $match: matchStage },
				{
					$addFields: {
						normalizedCity: { $toLower: { $trim: { input: "$address.city" } } },
						normalizedCountry: { $toLower: { $trim: { input: "$address.country" } } }
					}
				},
				{
					$group: {
						_id: { country: "$normalizedCountry", city: "$normalizedCity" }, // composite key
						cityOriginal: { $first: "$address.city" },
						countryOriginal: { $first: "$address.country" },
						businessCount: { $sum: 1 }
					}
				},
				{
					$match: {
						businessCount: { $gt: 10 } // only locations with 10+ businesses
					}
				},
				{ $sort: { businessCount: -1 } },
				{
					$project: {
						_id: 0,
						city: "$cityOriginal",
						country: "$countryOriginal",
						businessCount: 1
					}
				}
			]);

			return result;
		} catch (err) {
			Logger.logger.error("Failed to get services/businesses", err);
			throw new DatabaseError("Failed to get services/businesses");
		}
	}


}
