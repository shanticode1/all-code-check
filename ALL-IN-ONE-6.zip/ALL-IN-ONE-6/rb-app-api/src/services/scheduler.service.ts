import { roles } from "../data/user.roles";
import { IBusiness } from "../db-models/business.db-model";
import { Logger } from "../logger";
import { BusinessesService } from "./businesses.service";
import { GoogleService } from "./google.service";

export abstract class RenewWebHookService {
    public static async renewCalendarWebhook(): Promise<void> {
        try {
            // fetch all Businesses and check webhook expried or not 
            const businessList = await BusinessesService.getAllBusinessDocs();
            for (const business of businessList) {
                const webhookExpiryTime = business.watchEventExpiry;
                const currentTime = Date.now();
                // const currentTime = new Date('2024-05-18T06:48:11.000Z').getTime(); //may 20
                if (webhookExpiryTime) {
                    const expirationTimestamp = new Date(webhookExpiryTime).getTime(); //may 22
                    const dayBeforeExpiration = expirationTimestamp - (3 * 24 * 60 * 60 * 1000); //may 19 // Subtract 3 day in milliseconds
                    // if (currentTime >= dayBeforeExpiration && currentTime < expirationTimestamp)
                    if (currentTime >= dayBeforeExpiration && currentTime < expirationTimestamp) {
                        console.log('The webhook expiration time is within 3 days from now.');
                        // renew Webhook defor day expiry 
                        await GoogleService.renewCalendarWebhhok(business, roles.Business);
                    }
                    //  else {
                    //     Logger.logger.info('The webhook expiration time is not within 3 day from now.');
                    // }
                }
            }
        } catch (error) {
            Logger.logger.error(`Failed to renew webhook for business id`, error)
        }
    }

    public static async getNextCalendarEvents(): Promise<void> {
        // fetch all Businesses and check webhook expried ot not 
        const businessList = await BusinessesService.getAllBusinessDocs();
        for (const business of businessList) {
            if (business) {
                await GoogleService.getnextUpcomingEvents(business, roles.Business)
            }
        }
    }
}