import { parsePhoneNumber } from "awesome-phonenumber";
import { ClientDbModel } from "./db-models/client.db-model";
import { Logger } from "./logger";
import { BusinessDbModel } from "./db-models/business.db-model";
import { MembershipTier } from "./types/enums/membership-tier.enum";
export abstract class ClientReminderScriptService {
    public static async clientReminderUpdate() {
        try {
            //get client and check phone is valid or not
            const businessDoc = await BusinessDbModel.BusinessModel
                .find({ isActive: true, isDeleted: false, membershipTier: { $in: [MembershipTier.Plus, MembershipTier.Pro] } })
                .exec();
            businessDoc.forEach(async (businessElement) => {
                console.log('stripeCustomerId:', businessElement && businessElement.stripeCustomerId);
                if (businessElement && businessElement.stripeCustomerId) {
                    const clients = await ClientDbModel.ClientModel.find({ businessId: businessElement.id });
                    console.log('clients client count:', clients.length);
                    // clients.forEach(async (clientDoc) => {
                    for (let clientDoc of clients) {
                        // businessId
                        if (clientDoc.phone) {
                            console.log('client phone:', clientDoc.phone);
                            let number = clientDoc.phone.trim();
                            if (number.startsWith("+")) {
                                console.log(number, '---numbe');
                                number = number.split('+')[1];  //remove + if exist for format the number
                                const pn: any = parsePhoneNumber(`+${number}`);
                                console.log('number is valid or not :', pn.valid);
                                if (pn.valid) {
                                    //update phone number and country code in client table
                                    clientDoc.oldPhone = clientDoc.phone;
                                    clientDoc.phone = pn.number.significant;
                                    clientDoc.countryCode = pn.countryCode;
                                } else {
                                    // set country code empty of client for next update
                                    clientDoc.countryCode = "";
                                }
                            }
                            else {
                                // set country code empty of client for next update
                                clientDoc.countryCode = "";
                            }
                            clientDoc.isWhatsAppAllow = true;  //Set reminder of existing users
                            // update client with new values
                            await clientDoc.save();
                        }
                    }
                    Logger.logger.info('All Client updated successfully...')
                }
            });
        } catch (error) {
            console.log(error, '----error');
        }
        // })
    }
}