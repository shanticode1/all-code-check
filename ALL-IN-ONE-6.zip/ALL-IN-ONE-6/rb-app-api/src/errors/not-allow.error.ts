import { BaseError } from "./base.error"

export class NotAllowedError extends BaseError {

    public static httpCode = 405

    constructor(
        public message: string,
        public sendErrMsgToCaller: boolean = false) {
        super(message, NotAllowedError.httpCode, sendErrMsgToCaller)
    }
}