import moment = require("moment");
import { ProductToPriceMap } from "./data/productToPriceMap";
import { whatsAppCreditsMap } from "./data/whatsappTemplateMap";
import { BusinessDbModel } from "./db-models/business.db-model";
import { Logger } from "./logger";
import { MembershipTier } from "./types/enums/membership-tier.enum";
import { Business } from "./types/business";
import { planType } from "./data/whatsAppProductAndCurrency";
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const fs = require('fs');
const BATCH_SIZE = 10;
export abstract class CreditsScriptService {
    public static async runOnTimeScript() {
        try {
            Logger.logger.info('************ Script start ****************')
            let tampArr = [];
            const isProd = process.env.NODE_ENV.toLowerCase() == "production";
            let subscriptions: any;
            const businesses = await BusinessDbModel.BusinessModel
                .find({ isActive: true, isDeleted: false, membershipTier: { $in: [MembershipTier.Plus, MembershipTier.Pro] } })
                .exec();
            console.log('script businesses.length', businesses.length);
            businesses.forEach(async currentBusinessDetail => {
                if (currentBusinessDetail && currentBusinessDetail.stripeCustomerId) {
                    console.log('stripeCustomerId:', currentBusinessDetail.stripeCustomerId);
                    // const customer = await stripe.customers.retrieve(currentBusinessDetail.stripeCustomerId);
                    // console.log('customer:--', customer);
                    try {
                        subscriptions = await stripe.subscriptions.list({
                            customer: currentBusinessDetail.stripeCustomerId,
                            // limit: 1 //optional
                        });
                    } catch (error) {
                        console.error('script error subscriptions list', error.message);
                    }
                    console.log(`customer:${currentBusinessDetail.stripeCustomerId}`);
                    if (subscriptions && subscriptions.data.length > 0) {
                        console.log(`subscriptions:${subscriptions.data.length}`);
                        for (let subscription of subscriptions.data) {
                            console.log('subscription.status-------', subscription.status);
                            if (subscription.plan && subscription.plan.id) {
                                const stripePlanId = subscription.plan.id;
                                if (subscription.status === 'active') {
                                    console.log('stripePlanId-', stripePlanId);
                                    console.log('subscription.plan.metadata---', subscription.plan.metadata);
                                    if (isProd) {
                                        // based on old user
                                        if (ProductToPriceMap.prod.PLUS.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PLUS
                                        }
                                        if (ProductToPriceMap.prod.PRO.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PRO
                                        }
                                    } else {
                                        if (ProductToPriceMap.test.PLUS.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PLUS
                                        }
                                        if (ProductToPriceMap.test.PRO.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PRO
                                        }
                                        // if (ProductToPriceMap.test.PRO_DAILY.includes(stripePlanId)) {
                                        //     currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PRO
                                        // }
                                    }
                                    // this is based on new user with whatsapp 
                                    if (subscription.plan.usage_type == 'licensed' && subscription.plan.metadata && subscription.plan.metadata['whatsapp_credits']) {
                                        currentBusinessDetail.whatsAppCredits = Number(subscription.plan.metadata['whatsapp_credits'])
                                        // currentBusinessDetail.settings.isWhatsAppReminder = true;
                                        // currentBusinessDetail.settings.isEmailReminder = true;
                                    }
                                }
                                else if (subscription.status === 'trialing') {
                                    // trialing for new user first time credits
                                    // const stripePlanId = subscription.plan.id;
                                    console.log('stripePlanId-', stripePlanId);
                                    if (isProd) {
                                        if (ProductToPriceMap.prod.PRO_MONTHLY.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.TRIAL_PRO
                                        }
                                        if (ProductToPriceMap.prod.PLUS_MONTHLY.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.TRIAL_PLUS
                                        }
                                    } else {
                                        if (ProductToPriceMap.test.PRO_MONTHLY.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.TRIAL_PRO
                                        }
                                        if (ProductToPriceMap.test.PLUS_MONTHLY.includes(stripePlanId)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.TRIAL_PLUS
                                        }
                                        // if (ProductToPriceMap.test.PRO_DAILY.includes(stripePlanId)) {
                                        //     currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PRO
                                        // }

                                        // this is based on new user with whatsapp 
                                        if (subscription.plan.usage_type == 'licensed' && subscription.plan.metadata && subscription.plan.metadata['trial_whatsapp_credits']) {
                                            currentBusinessDetail.whatsAppCredits = Number(subscription.plan.metadata['trial_whatsapp_credits'])
                                            currentBusinessDetail.settings.isWhatsAppReminder = true;
                                        }
                                    }

                                }
                                console.log('whatsAppCredits', currentBusinessDetail.whatsAppCredits, 'membershipTier:-', currentBusinessDetail.membershipTier);
                                console.log('update credits for existing users....');
                                // write file for update credits business file 
                                tampArr.push({
                                    id: currentBusinessDetail.id,
                                    stripeId: currentBusinessDetail.stripeCustomerId,
                                });
                                const jsonData = JSON.stringify(tampArr);
                                fs.writeFileSync('credits.json', jsonData, 'utf8');
                                currentBusinessDetail.settings.isWhatsAppReminder = true;
                                currentBusinessDetail.settings.isEmailReminder = true;
                                await currentBusinessDetail.save();
                                // return subscription;
                            }
                        }
                        Logger.logger.info('Credits Added Successfully....')
                    }
                    Logger.logger.info(`There is not any subscriptions for customer ${currentBusinessDetail.stripeCustomerId}`)
                }
            })
            return 'Done'
        } catch (error) {
            Logger.logger.error(`Error when run credits script:${error}`)
        }
    }

    private static async findStripePlanId(customerSubscription, customerPlanId) {
        let isMatched: boolean = false;
        // const matchPlan = customerSubscription.find(it =>
        //     it.plan &&
        //     it.plan.usage_type === planType.LICENSED &&
        //     it.plan.id === customerPlanId
        // );
        const matchPlan = customerSubscription.items.data.find(item => item.plan &&
            item.plan.usage_type === planType.LICENSED
            && item.plan.id === customerPlanId);
            
        if (matchPlan) {
            isMatched = true;
        }
        return isMatched;
    }


    private static async getAllCustomerInfo(businesses: any) {
        const isProd = process.env.NODE_ENV.toLowerCase() == "production";
        let subscriptions;
        businesses.forEach(async currentBusinessDetail => {
            if (currentBusinessDetail.stripeCustomerId) {
                // this is end date of annual end
                let endDateString = new Date(currentBusinessDetail.membershipExpirationDate);
                // endDateString.setUTCSeconds(currentBusinessDetail.membershipExpirationDate);
                const endDate = moment(endDateString).format("DD/MM/YYYY");
                const endDateValue = moment(endDateString).format("DD");
                let currentDate = moment().format("DD/MM/YYYY");
                let currentDateValue = moment().format("DD");
                // console.log('currentDate', currentDate);
                if (new Date(currentDate).getTime() <= new Date(endDate).getTime()) {  //2 apr<= 2 apr 2024  true
                    if (endDateValue == currentDateValue) {  // 2 may >= 2 apr                        
                        try {
                            subscriptions = await stripe.subscriptions.list({
                                customer: currentBusinessDetail.stripeCustomerId,
                                // limit: 1 //optional
                            });
                        } catch (error) {
                            console.error('error subscriptions list:-', error.message);
                        }
                        if (subscriptions && subscriptions.data && subscriptions.data.length > 0) {
                            for (let subscription of subscriptions.data) {
                                console.log(subscription.status);
                                if (subscription.status === 'active') {
                                    if (isProd) {
                                        if (this.findStripePlanId(subscription, ProductToPriceMap.prod.PLUS_ANNUAL)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PLUS
                                        }

                                        if (this.findStripePlanId(subscription, ProductToPriceMap.prod.PRO_ANNUAL)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PRO
                                        }
                                    } else {

                                        if (this.findStripePlanId(subscription, ProductToPriceMap.test.PLUS_ANNUAL)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PLUS
                                        }

                                        if (this.findStripePlanId(subscription, ProductToPriceMap.test.PRO_ANNUAL)) {
                                            currentBusinessDetail.whatsAppCredits = whatsAppCreditsMap.PRO
                                        }
                                    }
                                    // this is based on new user with whatsapp 

                                    // if (subscription.plan.usage_type == 'licensed' && subscription.plan.metadata && subscription.plan.metadata['whatsapp_credits']) {
                                    //     currentBusinessDetail.whatsAppCredits = Number(subscription.plan.metadata['whatsapp_credits'])
                                    // }

                                    const matchItem = subscription.items.data.find(item => item.plan && item.plan.usage_type === planType.LICENSED && item.plan.id === (currentBusinessDetail.stripePriceIds && currentBusinessDetail.stripePriceIds.recurringPriceId));
                                    if (matchItem) {
                                        currentBusinessDetail.whatsAppCredits = Number(matchItem.plan.metadata['whatsapp_credits'])
                                    }
                                    currentBusinessDetail.settings.isWhatsAppReminder = true;  //enable existing users whatsapp reminder setting 
                                    currentBusinessDetail.settings.isEmailReminder = true;  //enable existing users email reminder setting
                                }
                            }
                            await currentBusinessDetail.save();
                        }
                    }
                }
            }
        });
    }

    public static async annualUsersCreditsScript() {
        try {
            const businesses = await BusinessDbModel.BusinessModel
                .find({ isActive: true, isDeleted: false, stripeCustomerId: { $exists: true }, membershipTier: { $in: [MembershipTier.Plus, MembershipTier.Pro] } })
                .exec();
            console.log('script businesses.length', businesses.length);
            // const customerIds = businesses.map(business => business.stripeCustomerId && business.stripeCustomerId);
            const validBusinesses = businesses.filter(business => business.stripeCustomerId);
            const customerIds = validBusinesses.map(business => business.stripeCustomerId);
            for (let i = 0; i < customerIds.length; i += BATCH_SIZE) {
                const batchCustomerIds = customerIds.slice(i, i + BATCH_SIZE);
                const batchBusinesses = businesses.slice(i, i + BATCH_SIZE);
                await this.getAllCustomerInfo(batchBusinesses);
            }
            Logger.logger.info('Annual PRO Users Added Successfully....')
            // return
        } catch (error) {
            Logger.logger.error(`Error when run credits script:${error}`)
        }
    }
}
