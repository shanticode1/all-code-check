import { Schema } from "mongoose";
import { BusinessNotes } from "../types/business-notes";

export abstract class BusinessNotesDbModel {
  public static businessNotesSchema = new Schema(
    {
      email: String,
      notes: String,
    },
    { _id: false }
  );

  public static convertToDbModel(businessNotes: BusinessNotes): IBusinessNotes {
    return {
      email: businessNotes.email,
      notes: businessNotes.notes,
    };
  }

  public static convertToDomainModel(
    businessNotes: IBusinessNotes
  ): BusinessNotes {
    return new BusinessNotes(businessNotes.email, businessNotes.notes);
  }
}

export interface IBusinessNotes {
  email: String;
  notes: String;
}
