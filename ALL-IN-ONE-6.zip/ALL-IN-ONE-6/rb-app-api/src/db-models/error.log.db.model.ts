import { Schema, Document, model } from "mongoose";
import { User } from "../types/user";

export abstract class LogDbModel {
    private static ErrorSchema = new Schema({
        type: {
            type: String,
            default: null
        },
        message: {
            type: String,
            default: null
        },
        createdAt: {
            type: Date,
            default: Date.now,
            expires: '2d'  //TTL index to remove documents older than 2 days
        }
    }, { timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' } });

    public static ErrorModel = model("error-log", LogDbModel.ErrorSchema);
}


