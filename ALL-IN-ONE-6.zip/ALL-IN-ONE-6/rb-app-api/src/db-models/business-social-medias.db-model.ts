import { Schema } from "mongoose"

import { BusinessSocialMedias } from "../types/business-social-medias"

export abstract class BusinessSocialMediasDbModel {
	public static BusinessSocialMediasSchema = new Schema(
		{
			ig: String,
			fb: String,
			wa: String,
			countryCode:String
		},
		{ _id: false }
	)

	public static convertToDbModel(socialMedias: BusinessSocialMedias): IBusinessSocialMedias {
		return {
			ig: socialMedias.ig == null ?
				undefined :
				socialMedias.ig,
			fb: socialMedias.fb == null ?
				undefined :
				socialMedias.fb,
			wa: socialMedias.wa == null ?
				undefined :
				socialMedias.wa,
			countryCode: socialMedias.countryCode == null ?
				'' :
				socialMedias.countryCode,
		}
	}

	public static convertToDomainModel(socialMedias: IBusinessSocialMedias): BusinessSocialMedias {
		return new BusinessSocialMedias(
			socialMedias.ig == null ?
				undefined :
				socialMedias.ig,
			socialMedias.fb == null ?
				undefined :
				socialMedias.fb,
			socialMedias.wa == null ?
				undefined :
				socialMedias.wa,
				socialMedias.countryCode == null ?
				'' :
				socialMedias.countryCode,
			)
	}
}

export interface IBusinessSocialMedias {
	ig: string
	fb: string
	wa: string
	countryCode:string
}
