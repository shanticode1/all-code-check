import { Schema } from "mongoose"

import { Customer } from "../types/customer"

export abstract class CustomerDbModel {

	public static customerSchema = new Schema({
		name: String,
		surname: String,
		email: String,
		phoneNumber: String,
		countryCode: String,
		isWhatsAppAllow: {
			default: true,
			type: Boolean,
		},
		isEmailAllow: {
			default: true,
			type: Boolean,
		},
	},
		{ _id: false }
	)

	public static convertToDbModel(customer: Customer): ICustomer {
		return {
			name: customer.name === null ? undefined : customer.name,
			surname: customer.surname === null ? undefined : customer.surname,
			email: customer.email === null ? undefined : customer.email,
			phoneNumber: customer.phoneNumber == null ?
				undefined :
				customer.phoneNumber,
			countryCode: customer.countryCode == null ?
				'' :
				customer.countryCode,
			isWhatsAppAllow: customer.isWhatsAppAllow == null ?
				undefined :
				customer.isWhatsAppAllow,
			isEmailAllow: customer.isEmailAllow == null ?
				undefined : customer.isEmailAllow,
		}
	}

	public static convertToDomainModel(customerDoc: ICustomer): Customer {
		return new Customer(
			customerDoc?.name,
			customerDoc?.surname,
			customerDoc?.email,
			customerDoc?.phoneNumber == null ?
				undefined :
				customerDoc.phoneNumber,
			customerDoc?.countryCode == null ?
				'' :
				customerDoc.countryCode,
			customerDoc?.isWhatsAppAllow == null ?
				undefined :
				customerDoc.isWhatsAppAllow,
			customerDoc?.isEmailAllow == null ?
				undefined :
				customerDoc.isEmailAllow,
		)
	}

}

export interface ICustomer {
	name: string
	surname: string
	email: string
	phoneNumber: string
	countryCode: string,
	isWhatsAppAllow: boolean,
	isEmailAllow: boolean
}