import { Schema, Document, model } from "mongoose";

import { Booking } from "../types/booking";
import { Business } from "../types/business";
import { BusinessService } from "../types/business-service";
import { BusinessServiceSnapshot } from "../types/business-service-snapshot";
import { BookingPaymentStatus, BookingStatus } from "../types/enums/booking.status";
import { Staff } from "../types/staff";
import {
  BookingReminderDbModel,
  IBookingReminder,
} from "./booking-reminder.db-model";
import { CustomerDbModel, ICustomer } from "./customer.db-model";

export abstract class BookingDbModel {
  private static bookingSchema = new Schema({
    businessId: String,
    serviceId: String,
    friendlyId: {
      type: String,
      lowercase: true,
    },
    startDate: Date,
    endDate: Date,
    clientId: String,
    customer: CustomerDbModel.customerSchema,
    notes: String,
    staffId: String,
    status: {
      type: Number,
      enum: Object.values(BookingStatus).filter((v) => Number.isInteger(v)),
    },
    serviceSnapshotId: String,
    sentReminders: [BookingReminderDbModel.ReminderSchema],
    customerCancellationToken: new Schema({}),
    eventType: String,
    googleEventId: String,
    calendarId: String,
    title: String,
    googleMeetLink: String,
    meetLinkId: String,
    creator: String,
    organizer: String,
    attendees: Array,
    businessIdForGoogle: String,
    isReminderSent: Boolean,
    whatsappMessageId: String,
    isMessageDelivered: {
      type: Boolean,
      default: false
    },
    isCronJobCancel: {
      type: Boolean,
      default: false
    },
    staffIdForGoogle: String,
    googleTimeZone: {
      type: String,
      default: null
    },
    isDayLightUpdated: {
      type: Boolean,
      default: false
    },
    paymentStatus: String,
    checkoutInitiatedAt: Date,
    isCheckoutCronJobCancel: {
      type: Boolean,
      default: false
    },
    isDepositPaid: {
      type: Boolean,
      default: false
    },
    isRemainingPaid: {
      type: Boolean,
      default: false
    },
    isNoRequired: {
      type: Boolean,
      default: true
    },
    isFullPaid: {
      type: Boolean,
      default: false
    },
    paidAmount: Number,
    link: {
      type: String,
      default: null
    },
    checkoutSessionId: String,
    billingStatus: {
      type: Number,
      enum: Object.values(BookingPaymentStatus).filter((v) => Number.isInteger(v)),
    },
    promoCode: String,
    isPaidByMembership: {
      type: Boolean,
      default: false
    },
    membershipId:String,
    membershipSnapshotId: String

  },
    {
      timestamps: true, // adds createdAt and updatedAt automatically
    }).index({ businessId: 1, friendlyId: 1 }, { unique: true });

  public static BookingModel = model<IBooking>(
    "booking",
    BookingDbModel.bookingSchema
  );

  public static convertToDbModel(booking: Booking): IBooking {
    return new BookingDbModel.BookingModel({
      businessId: booking.business.id,
      serviceId: booking.service.id,
      friendlyId: booking.friendlyId,
      startDate: booking.startDate,
      endDate: booking.endDate,
      clientId: booking.clientId,
      customer: CustomerDbModel.convertToDbModel(booking.customer),
      notes: booking.notes == null ? undefined : booking.notes,
      staffId: booking.staffId == null ? undefined : booking.staffId,
      status: booking.status,
      serviceSnapshotId: booking.serviceSnapshot.id,
      eventType: booking.eventType,
      googleEventId: booking.googleEventId,
      calendarId: booking.calendarId,
      businessIdForGoogle: booking.businessIdForGoogle == null ? undefined : booking.businessIdForGoogle,
      staffIdForGoogle: booking.staffIdForGoogle == null ? undefined : booking.staffIdForGoogle,
      billingStatus: booking.billingStatus === null ? undefined : booking.billingStatus,
      promoCode:booking.promoCode === null ? '' : booking.promoCode,
      isPaidByMembership: booking.isPaidByMembership === null ? false : booking.isPaidByMembership,
      membershipId: booking.membershipId,
      membershipSnapshotId: booking.membershipSnapshotId,

    });
  }

  public static convertToDomainModel(bookingDoc: IBooking): Booking {
    return new Booking(
      bookingDoc.id,
      new Business(
        bookingDoc.businessId,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined
      ),
      new BusinessService(
        bookingDoc.serviceId,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        // undefined,
        // undefined
      ),
      bookingDoc.friendlyId,
      bookingDoc.startDate,
      bookingDoc.endDate,
      bookingDoc.clientId,
      CustomerDbModel.convertToDomainModel(bookingDoc.customer),
      bookingDoc.notes == null ? undefined : bookingDoc.notes,
      bookingDoc.staffId == null ? undefined : bookingDoc.staffId,
      bookingDoc.status,
      new BusinessServiceSnapshot(
        bookingDoc.serviceSnapshotId,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        // undefined
        undefined,
        undefined
      ),
      new Staff(
        bookingDoc.staffId,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined,
        undefined
      ),
      bookingDoc.eventType == null ? undefined : bookingDoc.eventType,
      bookingDoc.googleEventId == null ? undefined : bookingDoc.googleEventId,
      bookingDoc.calendarId == null ? undefined : bookingDoc.calendarId,
      bookingDoc.title == null ? undefined : bookingDoc.title,
      bookingDoc.creator == null ? undefined : bookingDoc.creator,
      bookingDoc.googleMeetLink == null ? undefined : bookingDoc.googleMeetLink,
      bookingDoc.businessIdForGoogle == null ? undefined : bookingDoc.businessIdForGoogle,
      bookingDoc.staffIdForGoogle == null ? undefined : bookingDoc.staffIdForGoogle,
      bookingDoc.paymentUrl === null ? undefined : bookingDoc.paymentUrl,
      undefined,
      bookingDoc.paymentStatus === null ? undefined : bookingDoc.paymentStatus,
      bookingDoc.isDepositPaid === null ? undefined : bookingDoc.isDepositPaid,
      bookingDoc.isRemainingPaid === null ? undefined : bookingDoc.isRemainingPaid,
      bookingDoc.isFullPaid === null ? undefined : bookingDoc.isFullPaid,
      bookingDoc.link === null ? undefined : bookingDoc.link,
      bookingDoc.isNoRequired === null ? true : bookingDoc.isNoRequired,
      bookingDoc.billingStatus === null ? undefined : bookingDoc.billingStatus,
      bookingDoc.promoCode === null ? '' : bookingDoc.promoCode,
      bookingDoc.isPaidByMembership === null ? false : bookingDoc.isPaidByMembership,
      bookingDoc.membershipId,
      bookingDoc.membershipSnapshotId
    );    
  }
}

export interface IBooking extends Document {
  businessId: string;
  serviceId: string;
  friendlyId: string;
  startDate: Date;
  endDate: Date;
  clientId: string;
  customer: ICustomer;
  notes: string;
  staffId: string;
  status: BookingStatus;
  serviceSnapshotId: string;
  sentReminders: IBookingReminder[];
  customerCancellationToken: Document;
  eventType: string,
  googleEventId: string,
  calendarId: string
  title: string,
  creator: string,
  googleMeetLink: string,
  meetLinkId: string,
  businessIdForGoogle: string;
  staffIdForGoogle?: string,
  googleTimeZone?: string,
  paymentUrl?: string,
  chargeImmediately?: boolean,
  paymentStatus?: string,
  checkoutInitiatedAt?: Date
  isDepositPaid?: boolean,
  isRemainingPaid?: boolean,
  isFullPaid?: boolean,
  link?: string,
  checkoutSessionId?: string
  isNoRequired?: boolean
  billingStatus?: BookingPaymentStatus,
  promoCode?:string,
  isPaidByMembership?:boolean,
  membershipId?: string;
  membershipSnapshotId?:string

}
