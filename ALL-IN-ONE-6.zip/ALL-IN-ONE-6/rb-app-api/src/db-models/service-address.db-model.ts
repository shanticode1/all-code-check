import { Schema } from "mongoose"

import { Address } from "../types/address"

export abstract class ServiceAddressDbModel {
	public static serviceAddressSchema = new Schema(
		{
			address: String,
			suite: String,
			district: String,
			region: String,
			postcode: String,
			city: String,
			country: String,
			countryShortName: String,
			coordinates: {
				latitude: Number,
				longitude: Number,
			}
		},
		{ _id: false }
	)

	public static convertToDbModel(address: Address): IServiceAddress {
		return {
			address: address.address,
			suite: address.suite == null ? undefined : address.suite,
			district: address.district == null ? undefined : address.district,
			city: address.city == null ? undefined : address.city,
			region: address.region == null ? undefined : address.region,
			postcode: address.postcode == null ? undefined : address.postcode,
			country: address.country == null ? undefined : address.country,
			countryShortName: address.countryShortName == null ? '' : address.countryShortName,
			coordinates: address.coordinates == null ? undefined : {
				latitude: address.coordinates.latitude,
				longitude: address.coordinates.longitude
			}
		}
	}

	public static convertToDomainModel(addressDoc: IServiceAddress): Address {
		return new Address(
			addressDoc.address,
			addressDoc.suite == null ? undefined : addressDoc.suite,
			addressDoc.district == null ? undefined : addressDoc.district,
			addressDoc.city == null ? undefined : addressDoc.city,
			addressDoc.region == null ? undefined : addressDoc.region,
			addressDoc.postcode == null ? undefined : addressDoc.postcode,
			addressDoc.country == null ? undefined : addressDoc.country,
			addressDoc.countryShortName == null ? '' : addressDoc.countryShortName,
			addressDoc.coordinates == null ? undefined : {
				latitude: addressDoc.coordinates.latitude,
				longitude: addressDoc.coordinates.longitude
			}
		)
	}
}

export interface IServiceAddress {
	address: string
	suite: string
	district: string
	city: string
	region: string
	postcode: string
	country: string
	countryShortName: string,
	coordinates?: {
		latitude: number
		longitude: number
	}
}
