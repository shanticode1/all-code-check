import { Schema, Document, model } from "mongoose"
import { EventType, RecurrenceType } from "../types/enums/event-type.enum"
import { BusinessServiceEventSetting } from "../types/business-service-event-setting"


export class BusinessServiceEventSettingDbModel {

    public static businessServiceEventSettingSchema = new Schema({
        eventType: [{
            type: String,
            enum: Object.values(EventType).filter(v => typeof v === 'string')
        }],
        startDate: Date,
        startTime: {
            type: String,
            default: null
        },
        endDate: Date,
        endTime: {
            type: String,
            default: null
        },
        staffs: Array,
        isStaffConflict: Boolean,
        isBusinessConflict: Boolean,
        isNoConflict: Boolean,
        recurrenceType: [{
            type: String,
            enum: Object.values(RecurrenceType).filter(v => typeof v === 'string')
        }],
        customSetting: {
            type: Schema.Types.Mixed,
            default: {}
        }
    }, { _id: false })

    public static BusinessServiceEventSettingModel = model<IBusinessServiceEventSetting>('event-setting', BusinessServiceEventSettingDbModel.businessServiceEventSettingSchema)

    public static convertToDbModel(businessServiceEventSetting: BusinessServiceEventSetting): IBusinessServiceEventSetting {
        return new BusinessServiceEventSettingDbModel.BusinessServiceEventSettingModel({
            eventType: businessServiceEventSetting.eventType == null ? undefined : businessServiceEventSetting.eventType,
            startDate: businessServiceEventSetting.startDate == null ? undefined : businessServiceEventSetting.startDate,
            startTime: businessServiceEventSetting.startTime == null ? undefined : businessServiceEventSetting.startTime,
            endDate: businessServiceEventSetting.endDate == null ? undefined : businessServiceEventSetting.endDate,
            endTime: businessServiceEventSetting.endTime == null ? undefined : businessServiceEventSetting.endTime,
            staffs: businessServiceEventSetting.staffs == null ? undefined : businessServiceEventSetting.staffs,
            isStaffConflict: businessServiceEventSetting.isStaffConflict == null ? undefined : businessServiceEventSetting.isStaffConflict,
            isBusinessConflict: businessServiceEventSetting.isBusinessConflict == null ? undefined : businessServiceEventSetting.isBusinessConflict,
            recurrenceType: businessServiceEventSetting.recurrenceType == null ? undefined : businessServiceEventSetting.recurrenceType,
            isNoConflict: businessServiceEventSetting.isNoConflict == null ? undefined : businessServiceEventSetting.isNoConflict,
            customSetting: businessServiceEventSetting.customSetting == null ? undefined : businessServiceEventSetting.customSetting,
        })
    }

    public static convertToDomainModel(businessServiceEventSettingDoc: IBusinessServiceEventSetting): BusinessServiceEventSetting {
        return new BusinessServiceEventSetting(
            businessServiceEventSettingDoc.eventType == null ? undefined : businessServiceEventSettingDoc.eventType,
            businessServiceEventSettingDoc.startDate == null ? undefined : businessServiceEventSettingDoc.startDate,
            businessServiceEventSettingDoc.startTime == null ? undefined : businessServiceEventSettingDoc.startTime,
            businessServiceEventSettingDoc.endDate == null ? undefined : businessServiceEventSettingDoc.endDate,
            businessServiceEventSettingDoc.endTime == null ? undefined : businessServiceEventSettingDoc.endTime,
            businessServiceEventSettingDoc.staffs == null ? undefined : businessServiceEventSettingDoc.staffs,
            businessServiceEventSettingDoc.isStaffConflict == null ? undefined : businessServiceEventSettingDoc.isStaffConflict,
            businessServiceEventSettingDoc.isBusinessConflict == null ? undefined : businessServiceEventSettingDoc.isBusinessConflict,
            businessServiceEventSettingDoc.recurrenceType == null ? undefined : businessServiceEventSettingDoc.recurrenceType,
            businessServiceEventSettingDoc.isNoConflict == null ? undefined : businessServiceEventSettingDoc.isNoConflict,
            businessServiceEventSettingDoc.customSetting == null ? undefined : businessServiceEventSettingDoc.customSetting
        )
    }
}

export interface IBusinessServiceEventSetting extends Document {
    eventType: EventType;
    startDate: Date;
    startTime: string;
    endDate: Date;
    endTime: string;
    staffs: string[];
    isStaffConflict?: boolean;
    isBusinessConflict?: boolean;
    recurrenceType?: RecurrenceType;
    isNoConflict?: boolean;
    customSetting?: any;
}
