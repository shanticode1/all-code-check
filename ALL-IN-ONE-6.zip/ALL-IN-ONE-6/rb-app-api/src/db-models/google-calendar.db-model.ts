import { Schema, Document, model } from "mongoose"

import { GoogleCalendar } from "../types/google-calendar"

export abstract class GoogleCalendarDbModel {

    public static googleCalendarSchema = new Schema({
        calendarId: String,
        status: String,
        name: String,
        isProcessing: {
            type: Boolean,
            default: false
        },
        lastLoggedInTime: Date
    }, { _id: false }
    )

    public static GoogleCalendarModel = model<IGoogleCalendarType>('google-calendar', GoogleCalendarDbModel.googleCalendarSchema)

    public static convertToDbModel(googleCalendar: GoogleCalendar): IGoogleCalendarType {
        return new GoogleCalendarDbModel.GoogleCalendarModel({
            calendarId: googleCalendar.calendarId,
            status: googleCalendar.status,
            name: googleCalendar.name == null ?
                undefined :
                googleCalendar.name,
            isProcessing: googleCalendar.isProcessing == null ?
                undefined :
                googleCalendar.isProcessing,
            lastLoggedInTime: googleCalendar.lastLoggedInTime == null ?
                undefined :
                googleCalendar.lastLoggedInTime,
        })
    }

    public static convertToDomainModel(googleCalendarDoc: IGoogleCalendarType): GoogleCalendar {
        return new GoogleCalendar(
            googleCalendarDoc.calendarId,
            googleCalendarDoc.status,
            googleCalendarDoc.name == null ?
                undefined :
                googleCalendarDoc.name,
            googleCalendarDoc.isProcessing == null ?
                undefined :
                googleCalendarDoc.isProcessing,
            googleCalendarDoc.lastLoggedInTime == null ?
                undefined :
                googleCalendarDoc.lastLoggedInTime,
        )
    }
}

export interface IGoogleCalendarType {
    calendarId: string
    status: string
    name: string
    isProcessing: boolean
    lastLoggedInTime: Date
}