import { Schema, Document, model } from "mongoose"

import { TimeZone } from "../types/time-zone"


export class TimeZoneDbModel {

	private static timeZoneSchema = new Schema({
		name: String,
		displayName: String,
		isBusinessDefault: Boolean
	})

	public static TimeZoneModel = model<ITimeZone>('time-zone', TimeZoneDbModel.timeZoneSchema)

	public static convertToDbModel(timeZone: TimeZone): ITimeZone {
		return new TimeZoneDbModel.TimeZoneModel({
			name: timeZone.name,
			displayName: timeZone.displayName,
			isBusinessDefault: timeZone.isBusinessDefault
		})
	}

	public static convertToDomainModel(timeZoneDoc: ITimeZone): TimeZone {
		return new TimeZone(
			timeZoneDoc.id,
			timeZoneDoc.name,
			timeZoneDoc.displayName,
			timeZoneDoc.isBusinessDefault
		)
	}
}

export interface ITimeZone extends Document {
	name: string
	displayName: string
	isBusinessDefault: boolean
}