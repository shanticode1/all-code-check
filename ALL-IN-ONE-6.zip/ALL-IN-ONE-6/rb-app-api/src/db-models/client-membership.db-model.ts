import { Schema, Document, model } from "mongoose";
import { ClientMembership } from "../types/clientMembership";
import { MembershipServiceSnapshot } from "../types/service-membership-snapshot";

export abstract class ClientMembershipDbModel {

    private static ClientMembershipSchema = new Schema({
        businessId: String,
        clientId: String,
        userId: String,
        membershipId: String,
        membershipUnits: Number,
        paymentStatus: String,
        checkoutInitiatedAt: Date,
        isActive: Boolean,
        isDeleted: Boolean,
        purchaseDate: Date,
        membershipSnapshotId: String,
        bookingCapacity: Number
    }, { timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' } });

    public static ClientMembershipModel = model<IClientMembership>("client-membership", ClientMembershipDbModel.ClientMembershipSchema);

    public static convertToDbModel(clientMembership: ClientMembership): IClientMembership {
        return new ClientMembershipDbModel.ClientMembershipModel({
            businessId: clientMembership.businessId,
            clientId: clientMembership.clientId,
            membershipId: clientMembership.membershipId,
            membershipUnits: clientMembership.membershipUnits,
            paymentStatus: clientMembership.paymentStatus,
            checkoutInitiatedAt: clientMembership.checkoutInitiatedAt == null ? undefined : clientMembership.checkoutInitiatedAt,
            isActive: clientMembership.isActive == null ? undefined : clientMembership.isActive,
            isDeleted: clientMembership.isDeleted == null ? undefined : clientMembership.isDeleted,
            membershipSnapshotId: clientMembership.membershipSnapshot.id,
            purchaseDate: clientMembership.purchaseDate == null ? undefined : clientMembership.purchaseDate,
            bookingCapacity: clientMembership.bookingCapacity == null ? undefined : clientMembership.bookingCapacity,
            userId: clientMembership.userId === undefined ? undefined : clientMembership.userId,
        });
    }

    public static convertToDomainModel(clientMembershipDoc: IClientMembership): ClientMembership {
        const user = new ClientMembership(
            clientMembershipDoc.id.toString(),
            clientMembershipDoc.businessId,
            clientMembershipDoc.clientId,
            clientMembershipDoc.membershipId,
            clientMembershipDoc.membershipUnits,
            clientMembershipDoc.paymentStatus,
            clientMembershipDoc.checkoutInitiatedAt,
            clientMembershipDoc.isActive,
            clientMembershipDoc.isDeleted,
            new MembershipServiceSnapshot(
                clientMembershipDoc.membershipSnapshotId,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                undefined,
                // undefined
                undefined,
                undefined
            ),
            undefined,
            undefined,
            clientMembershipDoc.purchaseDate,
            clientMembershipDoc.bookingCapacity,
            clientMembershipDoc.userId == null ? undefined : clientMembershipDoc.userId,
        );
        return user;
    }
}

export interface IClientMembership extends Document {
    id: string,
    businessId: string,
    clientId: string,
    membershipId: string,
    membershipUnits: number,
    paymentStatus: string,
    checkoutInitiatedAt: Date,
    isActive: boolean,
    isDeleted: boolean,
    membershipSnapshot?: MembershipServiceSnapshot
    membershipSnapshotId: string,
    createdAt?: Date,
    updatedAt?: Date,
    purchaseDate?: Date,
    bookingCapacity?: number,
    userId?: string,
}
