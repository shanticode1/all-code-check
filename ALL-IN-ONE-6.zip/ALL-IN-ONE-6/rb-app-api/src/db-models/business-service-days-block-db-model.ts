import { Schema } from "mongoose"

import { ServiceDaysBlock } from "../types/business-hours-block"
import { DayOfTheWeek } from "../types/enums/day-of-the-week.enum"


export abstract class ServiceDaysBlockDbModel {

    public static serviceDaysBlockSchema = new Schema({
        dayOfTheWeek: {
            type: Number,
            enum: Object.values(DayOfTheWeek).filter(v => Number.isInteger(v))
        },
    },
        { _id: false }
    )

    public static convertToDbModel(serviceDaysBlocks: ServiceDaysBlock): IBusinessServiceDaysBlock {
        return {
            dayOfTheWeek: serviceDaysBlocks.dayOfTheWeek,
        }
    }

    public static convertToDomainModel(serviceDaysBlockDoc: IBusinessServiceDaysBlock): ServiceDaysBlock {
        return new ServiceDaysBlock(
            serviceDaysBlockDoc.dayOfTheWeek,
        )
    }
}

export interface IBusinessServiceDaysBlock {
    dayOfTheWeek: number
}