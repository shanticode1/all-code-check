import { Schema, Document, model } from "mongoose"
import { IMembershipPackage, MembershipPackageDbModel } from "./membership-setting.db-model"
import { MembershipService } from "../types/membership-package"
import { Currency } from "../types/enums/currency"

export abstract class MembershipServiceDbModel {
	public static membershipServiceModal = new Schema(
		{
			businessId: String,
			name: String,
			description: String,
			membershipHash: String,
			packageSetting: [MembershipPackageDbModel.membershipPackageSchema],
			price: Number,
			isDeleted: Boolean,
			isActive: Boolean,
			logo: String,
			currency: {
				type: Number,
				enum: Object.values(Currency).filter((v) => Number.isInteger(v)),
			},
			type: {
				type: String,
				default: 'membership',
			},
		},
		{
			timestamps: true, // adds createdAt and updatedAt automatically
		}
	)

	public static MembershipServiceModel = model<IMembershipService>('business-membership', MembershipServiceDbModel.membershipServiceModal)
	// from SPA to DB
	public static convertToDbModel(serviceMembership: MembershipService): IMembershipService {
		return new MembershipServiceDbModel.MembershipServiceModel({
			businessId: serviceMembership.businessId,
			name: serviceMembership.name,
			description: serviceMembership.description,
			membershipHash:serviceMembership.membershipHash,
			packageSetting: serviceMembership.packageSetting === null ? undefined : serviceMembership.packageSetting.map(setting =>
				MembershipPackageDbModel.convertToDbModel(setting)),
			price: serviceMembership.price === null ? undefined : serviceMembership.price,
			isDeleted: serviceMembership.isDeleted === null ? undefined : serviceMembership.isDeleted,
			isActive: serviceMembership.isActive === null ? undefined : serviceMembership.isActive,
			logo: serviceMembership.logo == null ? undefined : serviceMembership.logo,
			currency: serviceMembership.currency == null ? undefined : serviceMembership.currency,
			type: serviceMembership.type == null ? undefined : serviceMembership.type,
		})
	}
	// from DB to SPA
	public static convertToDomainModel(membershipDoc: IMembershipService): MembershipService {
		return new MembershipService(
			membershipDoc.id,
			membershipDoc.businessId,
			membershipDoc.name,
			membershipDoc.description == null ? undefined : membershipDoc.description,
			membershipDoc.membershipHash == null ? undefined : membershipDoc.membershipHash,
			membershipDoc.packageSetting == null ? undefined : membershipDoc.packageSetting.map(setting => MembershipPackageDbModel.convertToDomainModel(setting)),
			membershipDoc.price === null ? 0 : membershipDoc.price,
			membershipDoc.isDeleted === null ? undefined : membershipDoc.isDeleted,
			membershipDoc.isActive === null ? undefined : membershipDoc.isActive,
			membershipDoc.logo == null ? undefined : membershipDoc.logo,
			membershipDoc.currency == null ? undefined : membershipDoc.currency,
			membershipDoc.type == null ? undefined : membershipDoc.type,

		);
	}
}

export interface IMembershipService extends Document {
	businessId: string,
	name: string,
	description: string,
	membershipHash: string,
	packageSetting: IMembershipPackage[],
	price: number,
	isDeleted?: boolean,
	isActive?: boolean,
	logo?: string,
	currency: number;
	type?: string
}
