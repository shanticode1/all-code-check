import { Schema, Document, model } from "mongoose"
import { Client } from "../types/clients"
import { TimeZone } from "../types/time-zone"
import { AddressDbModel, IAddress } from "./address.db-model"

export abstract class ClientDbModel {
	public static clientSchema = new Schema(
		{
			businessId: String,
			userId: String,
			email: {
				type: String,
				lowercase: true
			},
			name: String,
			surname: String,
			phone: String,
			countryCode: String,
			lastBookingDate: Date,
			notes: String,
			isWhatsAppAllow: {
				type: Boolean,
				default: true
			},
			oldPhone: String,
			isEmailAllow: {
				type: Boolean,
				default: true
			},
			timeZoneId: String,
			address: AddressDbModel.addressSchema,

		}
	)

	public static ClientModel = model<IClient>('client', ClientDbModel.clientSchema)
	// from SPA to DB
	public static convertToDbModel(client: Client): IClient {
		return new ClientDbModel.ClientModel({
			businessId: client.businessId,
			email: client.email,
			name: client.name == null ? undefined : client.name,
			surname: client.surname == null ? undefined : client.surname,
			phone: client.phone == null ? undefined : client.phone,
			countryCode: client.countryCode == null ? '' : client.countryCode,
			lastBookingDate: client.lastBookingDate == null ? undefined : client.lastBookingDate,
			notes: client.notes == null ? undefined : client.notes,
			isWhatsAppAllow: client.isWhatsAppAllow == null ? false : client.isWhatsAppAllow,
			isEmailAllow: client.isEmailAllow == null ? false : client.isEmailAllow,
			password: client.password == null ? false : client.password,
			userId: client.userId == null ? false : client.userId,
			timeZoneId: client.timeZone == null ? undefined : client.timeZone.id,
			address: client.address == null ?
				undefined :
				AddressDbModel.convertToDbModel(client.address),
		})
	}
	// from DB to SPA
	public static convertToDomainModel(clientDoc: IClient): Client {
		return new Client(
			clientDoc?.id == null ? undefined : clientDoc?.id,
			clientDoc.businessId,
			clientDoc.email,
			clientDoc.name,
			clientDoc.surname,
			clientDoc.phone == null ? undefined : clientDoc.phone,
			clientDoc.countryCode == null ? '' : clientDoc.countryCode,
			clientDoc.lastBookingDate == null ? undefined : clientDoc.lastBookingDate,
			clientDoc.notes == null ? undefined : clientDoc.notes,
			clientDoc.isWhatsAppAllow == null ? false : clientDoc.isWhatsAppAllow,
			clientDoc.isEmailAllow == null ? false : clientDoc.isEmailAllow,
			clientDoc.bookings == null ? undefined : clientDoc.bookings,
			clientDoc.password == null ? undefined : clientDoc.password,
			clientDoc.userId == null ? undefined : clientDoc.userId,
			new TimeZone(clientDoc.timeZoneId, undefined, undefined, undefined),
			clientDoc.address == null ?
				undefined :
				AddressDbModel.convertToDomainModel(clientDoc.address),
		);
	}
}

export interface IClient extends Document {
	businessId: string,
	email: string
	name: string,
	surname: string,
	phone: string,
	countryCode: string,
	lastBookingDate: Date,
	notes: string,
	bookings: any,
	isWhatsAppAllow: boolean,
	isEmailAllow: boolean,
	oldPhone: string,
	password?: string,
	userId?: string,
	timeZoneId?: string,
	address: IAddress

}
