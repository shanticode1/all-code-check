import { Schema, Document, model } from "mongoose"
import { CurrencyRate } from "../types/currencyRates"


export abstract class CurrencyRateDbModel {
    public static currencyRateSchema = new Schema(
        {
            country: String,
            currencyCode: String,
            appMinCurrency: Number,
            isActive: {
                type: Boolean,
                default: true
            },
            isDeleted: {
                type: Boolean,
                default: false
            }
        }
    )

    public static CurrencyRateModel = model<ICurrencyRate>('currencyRate', CurrencyRateDbModel.currencyRateSchema)
    // from SPA to DB
    public static convertToDbModel(currencyRate: CurrencyRate): ICurrencyRate {
        return new CurrencyRateDbModel.CurrencyRateModel({
            id: currencyRate.id,
            country: currencyRate.country,
            currencyCode: currencyRate.currencyCode,
            appMinCurrency: currencyRate.appMinCurrency,
            isActive: currencyRate.isActive == null ? undefined : currencyRate.isActive,
            isDeleted: currencyRate.isDeleted == null ? undefined : currencyRate.isDeleted,
        })
    }
    // from DB to SPA
    public static convertToDomainModel(currencyRateDoc: ICurrencyRate): CurrencyRate {
        return new CurrencyRate(
            currencyRateDoc.id,
            currencyRateDoc.country,
            currencyRateDoc.currencyCode,
            currencyRateDoc.appMinCurrency,
            currencyRateDoc.isActive,
            currencyRateDoc.isDeleted,
        )
    }
}

export interface ICurrencyRate extends Document {
    id: string,
    country: string,
    currencyCode: string,
    appMinCurrency: number
    isActive: boolean,
    isDeleted: boolean
}
