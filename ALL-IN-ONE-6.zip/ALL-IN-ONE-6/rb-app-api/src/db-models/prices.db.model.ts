import { Schema } from "mongoose"

import { Prices } from "../types/prices"

export abstract class PricesDbModel {
    public static priceSchema = new Schema(
        {
            oneTimePriceId: {
                type: String,
                default: ''
            },
            recurringPriceId: {
                type: String,
                default: ''
            },
            usagePriceId: {
                type: String,
                default: ''
            },
            staffUsagePriceId: {
                type: String,
                default: ''
            }
        },
        { _id: false }
    )

    public static convertToDbModel(prices: Prices): IPrices {
        return {
            oneTimePriceId: prices.oneTimePriceId == null ? '' : prices.oneTimePriceId,
            recurringPriceId: prices.recurringPriceId == null ? '' : prices.recurringPriceId,
            usagePriceId: prices.usagePriceId == null ? '' : prices.usagePriceId,
            staffUsagePriceId: prices.staffUsagePriceId == null ? '' : prices.staffUsagePriceId,

        }
    }

    public static convertToDomainModel(priceDoc: IPrices): Prices {
        return new Prices(
            priceDoc.oneTimePriceId == null ? '' : '',
            priceDoc.recurringPriceId == null ? '' : priceDoc.recurringPriceId,
            priceDoc.usagePriceId == null ? '' : priceDoc.usagePriceId,
            priceDoc.staffUsagePriceId == null ? '' : priceDoc.staffUsagePriceId,
        )
    }
}

export interface IPrices {
    oneTimePriceId: string
    recurringPriceId: string
    usagePriceId: string
    staffUsagePriceId: string
}
