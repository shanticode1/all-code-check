import { Schema, Document, model } from "mongoose";
import { Staff } from "../types/staff";
import {
  StaffHoursBlockDbModel,
  IStaffHoursBlock,
} from "./staff-hours-block.db-model";
import { GoogleTokenDbModel, IGoogleToken } from "./google-token.db-model";
import { GoogleCalendarDbModel, IGoogleCalendarType } from "./google-calendar.db-model";
import { BusinessService } from "../types/business-service";
import { Business } from "../types/business";
import { User } from "../types/user";
import { IBusinessService } from "./business-service.model";
import { BusinessDbModel, IBusiness } from "./business.db-model";
import { IUser, UserDbModel } from "./users.db-model";

export abstract class StaffDbModel {
  private static staffSchema = new Schema({
    businessId: String,
    servicesId: Array,
    name: String,
    email: {
      type: String,
      // unique: true,
      lowercase: true,
      default: null
    },
    userId: {
      type: String,
      default: null
    },
    isOperatingNonStop: Boolean,
    staffHoursBlocks: [StaffHoursBlockDbModel.staffHoursBlockSchema],
    isActive: Boolean,
    isDeleted: Boolean,
    logo: String,
    googleToken: GoogleTokenDbModel.googleTokenSchema,
    googleCalendar: [GoogleCalendarDbModel.googleCalendarSchema],
    gmail: String,
    isConflict: Boolean,
    gPicture: String,
    gName: String,
    gEventWatchId: String,
    gResourceId: String,
    syncEventToken: String,
    watchEventExpiry: String,
    isActiveByBusiness: { type: Boolean, default: false },
    notificationEnabled: { type: Boolean, default: false },
  },
  {
    timestamps: true, // adds createdAt and updatedAt automatically
  });

  public static StaffModel = model<IStaff>("staff", StaffDbModel.staffSchema);

  public static convertToDbModel(staff: Staff): IStaff {
    return new StaffDbModel.StaffModel({
      businessId: staff.businessId,
      servicesId: staff.servicesId,
      name: staff.name == null ? undefined : staff.name,
      email: staff.email == null ? undefined : staff.email,
      password: staff.password == null ? undefined : staff.password,
      userId: staff.userId == null ? undefined : staff.userId,
      isOperatingNonStop:
        staff.isOperatingNonStop == null ? undefined : staff.isOperatingNonStop,
      staffHoursBlocks:
        staff.staffHoursBlocks == null
          ? undefined
          : staff.staffHoursBlocks.map((bh) =>
            StaffHoursBlockDbModel.convertToDbModel(bh)
          ),
      isActive: staff.isActive == null ? undefined : staff.isActive,
      isDeleted: staff.isDeleted == null ? undefined : staff.isDeleted,
      logo: staff.logo == null ? undefined : staff.logo,
      googleToken: staff.googleToken == null ?
        undefined :
        GoogleTokenDbModel.convertToDbModel(staff.googleToken),
      googleCalendar: staff.googleCalendar == null || staff.googleCalendar.length == 0 ?
        undefined :
        staff.googleCalendar.map(sc => GoogleCalendarDbModel.convertToDbModel(sc)),
      gmail: staff.gmail == null ? undefined : staff.gmail,
      gPicture: staff.gPicture == null ? undefined : staff.gPicture,
      gName: staff.gName == null ? undefined : staff.gName,
      gEventWatchId: staff.gEventWatchId == null ? undefined : staff.gEventWatchId,
      gResourceId: staff.gResourceId == null ? undefined : staff.gResourceId,
      syncEventToken: staff.syncEventToken == null ? undefined : staff.syncEventToken,
      watchEventExpiry: staff.watchEventExpiry == null ? undefined : staff.watchEventExpiry,
      isActiveByBusiness: staff.isActiveByBusiness == null ? undefined : staff.isActiveByBusiness,
      notificationEnabled: staff.notificationEnabled == null ? undefined : staff.notificationEnabled,
    });
  }

  public static convertToDomainModel(staffDoc: IStaff): Staff {
    const staff = new Staff(
      staffDoc.id.toString(),
      staffDoc.businessId == null ? undefined : staffDoc.businessId,
      staffDoc.servicesId == null ? [] : staffDoc.servicesId,
      staffDoc.name == null ? undefined : staffDoc.name,
      staffDoc.email == null ? undefined : staffDoc.email,
      staffDoc.password == null ? undefined : staffDoc.password,
      staffDoc.userId == null ? undefined : staffDoc.userId,
      staffDoc.isOperatingNonStop == null
        ? undefined
        : staffDoc.isOperatingNonStop,
      staffDoc.staffHoursBlocks == null || staffDoc.staffHoursBlocks.length == 0
        ? undefined
        : staffDoc.staffHoursBlocks.map((bh) =>
          StaffHoursBlockDbModel.convertToDomainModel(bh)
        ),
      staffDoc.isActive,
      staffDoc.isDeleted,
      staffDoc.logo == null ? undefined : staffDoc.logo,
      staffDoc.googleToken == null ?
        undefined :
        GoogleTokenDbModel.convertToDomainModel(staffDoc.googleToken),
      staffDoc.googleCalendar == null || staffDoc.googleCalendar.length == 0 ?
        undefined :
        staffDoc.googleCalendar.map(sc => GoogleCalendarDbModel.convertToDomainModel(sc)),
      staffDoc.gmail == null ? undefined : staffDoc.gmail,
      staffDoc.isConflict == null ? undefined : staffDoc.isConflict,
      staffDoc.gPicture == null ? undefined : staffDoc.gPicture,
      staffDoc.gName == null ? undefined : staffDoc.gName,
      staffDoc.gEventWatchId == null ? undefined : staffDoc.gEventWatchId,
      staffDoc.gResourceId == null ? undefined : staffDoc.gResourceId,
      staffDoc.syncEventToken == null ? undefined : staffDoc.syncEventToken,
      staffDoc.watchEventExpiry == null ? undefined : staffDoc.watchEventExpiry,
      staffDoc.isActiveByBusiness == null ? undefined : staffDoc.isActiveByBusiness,
      undefined,
      staffDoc.business == null ?
        undefined :
        BusinessDbModel.convertToDomainModel(staffDoc.business),
      staffDoc.isAllow == null ? true : staffDoc.isAllow,
      staffDoc.user == null ?
        undefined :
        UserDbModel.convertToDomainModel(staffDoc.user
        ),
      undefined,
      staffDoc.notificationEnabled == null ? undefined : staffDoc.notificationEnabled,
    );
    staff.orderStaffHoursBlocks();
    return staff;
  }
}

export interface IStaff extends Document {
  businessId: string;
  servicesId: [];
  name: string;
  email: string,
  password: string,
  userId: string,
  isOperatingNonStop: boolean;
  staffHoursBlocks: IStaffHoursBlock[];
  isActive: boolean;
  isDeleted: boolean;
  logo: any,
  googleToken: IGoogleToken,
  googleCalendar: IGoogleCalendarType[],
  gmail: string,
  isConflict: boolean,
  gPicture: string,
  gName: string
  gEventWatchId: string,
  gResourceId: string,
  syncEventToken: string,
  watchEventExpiry: string,
  isActiveByBusiness: boolean,
  services?: IBusinessService[],
  business?: IBusiness,
  isAllow?: boolean,
  user?: IUser,
  notificationEnabled?: boolean,
}
