import { Schema, Document, model } from "mongoose";

import { BusinessService } from "../types/business-service";
import { Currency } from "../types/enums/currency";
import { DurationUnit } from "../types/enums/duration-unit.enum";
import { ServiceCategory } from "../types/service-category";
import {
  BookingReminderDbModel,
  IBookingReminder,
} from "./booking-reminder.db-model";
import { IBusinessServiceDaysBlock, ServiceDaysBlockDbModel } from "./business-service-days-block-db-model";
import { BusinessServicePaymentDbModel, IBusinessServicePayment } from "./business-service-payment.model";
import { BusinessServiceEventSettingDbModel, IBusinessServiceEventSetting } from "./business-service-event-setting.model";
import { IServiceAddress, ServiceAddressDbModel } from "./service-address.db-model";

export abstract class BusinessServiceDbModel {
  public static businessServiceSchema = new Schema({
    businessId: String,
    name: String,
    description: String,
    categoryId: String,
    duration: Number,
    durationUnit: {
      type: Number,
      enum: Object.values(DurationUnit).filter((v) => Number.isInteger(v)),
    },
    price: Number,
    currency: {
      type: Number,
      enum: Object.values(Currency).filter((v) => Number.isInteger(v)),
    },
    type: String,
    capacity: Number,
    hash: String,
    bookingReminders: [BookingReminderDbModel.ReminderSchema],
    isActive: Boolean,
    isDeleted: Boolean,
    location: {
      type: String,
      default: 'none'
    },
    groupMeetLink: String,
    meetEventId: String,
    serviceDaysBlocks: [ServiceDaysBlockDbModel.serviceDaysBlockSchema],
    paymentSetting: BusinessServicePaymentDbModel.businessServicePaymentSchema,
    depositAmount: Number,
    eventSetting: BusinessServiceEventSettingDbModel.businessServiceEventSettingSchema,
    // isCapacityVisible: {
    //   type: Boolean,
    //   default: true
    // },
    serviceAddress: ServiceAddressDbModel.serviceAddressSchema,
    cutOff: Number,
    cutOffUnit: {
      type: Number,
      enum: Object.values(DurationUnit).filter((v) => Number.isInteger(v)),
    },
    logo: {
      type: String,
      default: ''
    },
    isInActiveByPlan: Boolean,

  },
  {
    timestamps: true, // adds createdAt and updatedAt automatically
  }
);

  public static BusinessServiceModel = model<IBusinessService>(
    "business-service",
    BusinessServiceDbModel.businessServiceSchema
  );

  public static convertToDbModel(
    businessId: string,
    businessService: BusinessService
  ): IBusinessService {    
    return new BusinessServiceDbModel.BusinessServiceModel({
      businessId: businessId,
      name: businessService.name,
      description:
        businessService.description == null
          ? undefined
          : businessService.description,
      categoryId:
        businessService.category == null
          ? undefined
          : businessService.category.id,
      duration: businessService.duration,
      durationUnit: businessService.durationUnit,
      price: businessService.price,
      currency:
        businessService.currency == null ? undefined : businessService.currency,
      type: businessService.type,
      capacity: businessService.capacity,
      hash: businessService.hash,
      bookingReminders:
        businessService.bookingReminders == null
          ? undefined
          : businessService.bookingReminders.map((r) =>
            BookingReminderDbModel.convertToDbModel(r)
          ),
      isActive: businessService.isActive,
      isDeleted: businessService.isDeleted,
      location: businessService.location,
      // groupMeetLink: businessService.groupMeetLink == null
      //   ? undefined : businessService.groupMeetLink,
      //   meetEventId: businessService.meetEventId == null
      //   ? undefined : businessService.meetEventId,
      serviceDaysBlocks: businessService.serviceDaysBlocks == null ? undefined : businessService.serviceDaysBlocks,
      paymentSetting: businessService.paymentSetting == null ? undefined : BusinessServicePaymentDbModel.convertToDbModel(businessService.paymentSetting),
      depositAmount: businessService.depositAmount == null ? undefined : businessService.depositAmount,
      eventSetting: businessService.eventSetting == null ? undefined : BusinessServiceEventSettingDbModel.convertToDbModel(businessService.eventSetting),
      // isCapacityVisible: businessService.isCapacityVisible == null ? true : businessService.isCapacityVisible,
      serviceAddress: businessService.serviceAddress == null
        ? undefined
        : ServiceAddressDbModel.convertToDbModel(businessService.serviceAddress),
      cutOff: businessService.cutOff == null ? undefined : businessService.cutOff,
      cutOffUnit: businessService.cutOffUnit == null ? undefined : businessService.cutOffUnit,
      logo: businessService.logo == null ? undefined : businessService.logo,
      isInActiveByPlan: businessService.isInActiveByPlan == null ? undefined : businessService.isInActiveByPlan,
    });
  }


  public static convertToDomainModel(
    businessServiceDoc: IBusinessService
  ): BusinessService {
    return new BusinessService(
      businessServiceDoc.id,
      businessServiceDoc.name,
      businessServiceDoc.description == null
        ? undefined
        : businessServiceDoc.description,
      businessServiceDoc.categoryId == null
        ? undefined
        : new ServiceCategory(
          businessServiceDoc.categoryId,
          undefined,
          undefined
        ),
      businessServiceDoc.duration,
      businessServiceDoc.durationUnit,
      businessServiceDoc.price,
      businessServiceDoc.currency == null
        ? undefined
        : businessServiceDoc.currency,
      businessServiceDoc.type,
      businessServiceDoc.capacity,
      businessServiceDoc.hash,
      businessServiceDoc.bookingReminders == null
        ? undefined
        : businessServiceDoc.bookingReminders.map((r) =>
          BookingReminderDbModel.convertToDomainModel(r)
        ),
      businessServiceDoc.isActive,
      businessServiceDoc.isDeleted,
      businessServiceDoc.location == null ? undefined : businessServiceDoc.location,
      // businessServiceDoc.groupMeetLink == null ? undefined : businessServiceDoc.groupMeetLink,
      // businessServiceDoc.meetEventId == null ? undefined : businessServiceDoc.meetEventId,
      businessServiceDoc.serviceDaysBlocks == null ? undefined : businessServiceDoc.serviceDaysBlocks,
      businessServiceDoc.paymentSetting == null ? undefined : BusinessServicePaymentDbModel.convertToDomainModel(businessServiceDoc.paymentSetting),
      businessServiceDoc.depositAmount == null ? undefined : businessServiceDoc.depositAmount,
      businessServiceDoc.eventSetting == null ? undefined : BusinessServiceEventSettingDbModel.convertToDomainModel(businessServiceDoc.eventSetting),
      // businessServiceDoc.isCapacityVisible == null ? true : businessServiceDoc.isCapacityVisible,
      businessServiceDoc.serviceAddress == null
        ? undefined
        : ServiceAddressDbModel.convertToDomainModel(businessServiceDoc.serviceAddress),
      businessServiceDoc.cutOff == null ? undefined : businessServiceDoc.cutOff,
      businessServiceDoc.cutOffUnit == null ? undefined : businessServiceDoc.cutOffUnit,
      businessServiceDoc.logo == null ? undefined : businessServiceDoc.logo,
      businessServiceDoc.isInActiveByPlan == null ? undefined : businessServiceDoc.isInActiveByPlan,

    );
  }
}

export interface IBusinessService extends Document {
  businessId: string;
  name: string;
  description: string;
  categoryId: string;
  duration: number;
  durationUnit: number;
  price: number;
  currency: number;
  type: string;
  capacity: number;
  hash: string;
  bookingReminders: IBookingReminder[];
  isActive: boolean;
  isDeleted: boolean;
  location: string;
  // groupMeetLink: string;
  // meetEventId:string
  serviceDaysBlocks: IBusinessServiceDaysBlock[];
  paymentSetting?: IBusinessServicePayment;
  depositAmount?: number;
  eventSetting?: IBusinessServiceEventSetting;
  isCapacityVisible?: boolean;
  serviceAddress?: IServiceAddress;
  cutOff?: number,
  cutOffUnit?: number,
  logo?: string
  isInActiveByPlan?: boolean
}
