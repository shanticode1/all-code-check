import { Schema } from "mongoose"
import { MembershipPackage } from "../types/membership-package";

export abstract class MembershipPackageDbModel {
  public static membershipPackageSchema = new Schema(
    {
      serviceId: String,
      bookingQuantity: Number,
    },
    { _id: false }
  );

  public static convertToDbModel(
    businessSettings: MembershipPackage
  ): IMembershipPackage {
    return {
      serviceId: businessSettings.serviceId,
      bookingQuantity: businessSettings.bookingQuantity,
    };
  }

  public static convertToDomainModel(
    businessSettings: IMembershipPackage
  ): MembershipPackage {
    return new MembershipPackage(
      businessSettings.serviceId,
      businessSettings.bookingQuantity,

    )
  }
}

export interface IMembershipPackage {
  serviceId: string,
  bookingQuantity: number
}


