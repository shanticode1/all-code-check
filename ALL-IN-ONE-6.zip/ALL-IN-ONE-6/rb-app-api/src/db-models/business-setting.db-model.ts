import { Schema } from "mongoose"
import { BusinessSettings, ReminderSetting } from "../types/business-settings"
import { PaymentType } from "../types/enums/payment-type.enum";
import { ReminderSettingDbModel } from "./reminder-setting.db-model";
import { ServiceType } from "../types/enums/service.type";

export abstract class BusinessSettingDbModel {
  public static businessSettingSchema = new Schema(
    {
      bookingAutoapprove: Boolean,
      hideAddress: Boolean,
      paymentTypes: [{
        type: Number,
        enum: Object.values(PaymentType).filter(v => Number.isInteger(v))
      }],
      manualPaymentInfo: String,
      isWhatsAppReminder: Boolean,
      isEmailReminder: Boolean,
      whatsAppReminderInfo: String,
      emailInfo: String,
      emailReminderDuration: ReminderSettingDbModel.reminderSettingSchema,
      whatsappReminderDuration: ReminderSettingDbModel.reminderSettingSchema,
      cancelationPolicyInfo: String,
      serviceCapacityVisibility: {
        types: [{
          type: Number,
          enum: Object.values(ServiceType).filter(v => Number.isInteger(v))
        }],
      }
    },
    { _id: false }
  );

  public static convertToDbModel(
    businessSettings: BusinessSettings
  ): IBusinessSettings {
    return {
      bookingAutoapprove: businessSettings.bookingAutoapprove,
      hideAddress: businessSettings.hideAddress,
      paymentTypes: businessSettings.paymentTypes == null ? [] : businessSettings.paymentTypes,
      manualPaymentInfo: businessSettings.manualPaymentInfo == null ? "" : businessSettings.manualPaymentInfo,
      isWhatsAppReminder: businessSettings.isWhatsAppReminder == null ? false : businessSettings.isWhatsAppReminder,
      isEmailReminder: businessSettings.isEmailReminder == null ? false : businessSettings.isEmailReminder,
      whatsAppReminderInfo: businessSettings.whatsAppReminderInfo == null ? "" : businessSettings.whatsAppReminderInfo,
      emailInfo: businessSettings.emailInfo == null ? "" : businessSettings.emailInfo,
      emailReminderDuration: businessSettings.emailReminderDuration == null ? undefined : ReminderSettingDbModel.convertToDbModel(businessSettings.emailReminderDuration),
      whatsappReminderDuration: businessSettings.whatsappReminderDuration == null ? undefined : ReminderSettingDbModel.convertToDbModel(businessSettings.whatsappReminderDuration),
      cancelationPolicyInfo: businessSettings.cancelationPolicyInfo == null ? "" : businessSettings.cancelationPolicyInfo,
      serviceCapacityVisibility: businessSettings.serviceCapacityVisibility == null ? undefined : businessSettings.serviceCapacityVisibility,

    };
  }

  public static convertToDomainModel(
    businessSettings: IBusinessSettings
  ): BusinessSettings {
    return new BusinessSettings(
      businessSettings.bookingAutoapprove,
      businessSettings.hideAddress,
      businessSettings.paymentTypes == null ? [] : businessSettings.paymentTypes,
      businessSettings.manualPaymentInfo == null ? "" : businessSettings.manualPaymentInfo,
      businessSettings.isWhatsAppReminder == null ? false : businessSettings.isWhatsAppReminder,
      businessSettings.isEmailReminder == null ? false : businessSettings.isEmailReminder,
      businessSettings.whatsAppReminderInfo == null ? "" : businessSettings.whatsAppReminderInfo,
      businessSettings.emailInfo == null ? "" : businessSettings.emailInfo,
      businessSettings.emailReminderDuration == null ? undefined : ReminderSettingDbModel.convertToDomainModel(businessSettings.emailReminderDuration),
      businessSettings.whatsappReminderDuration == null ? undefined : ReminderSettingDbModel.convertToDomainModel(businessSettings.whatsappReminderDuration),
      businessSettings.cancelationPolicyInfo == null ? "" : businessSettings.cancelationPolicyInfo,
      businessSettings.serviceCapacityVisibility == null ? undefined : businessSettings.serviceCapacityVisibility,

    )
  }
}

export interface IReminderSetting {
  duration: number,
  durationUnit: number
}
export interface ICapactiySetting {
  types: { type: ServiceType[] }[];
}

export interface IBusinessSettings {
  bookingAutoapprove: boolean,
  hideAddress: boolean,
  paymentTypes: number[],
  manualPaymentInfo: string,
  isWhatsAppReminder: boolean,
  isEmailReminder: boolean,
  whatsAppReminderInfo: string,
  emailInfo: string,
  emailReminderDuration: IReminderSetting,
  whatsappReminderDuration: IReminderSetting,
  cancelationPolicyInfo: string,
  serviceCapacityVisibility: ICapactiySetting
}
