import { Schema, Document, model } from "mongoose"

import { BusinessServiceSnapshot } from "../types/business-service-snapshot"
import { Currency } from "../types/enums/currency"
import { DurationUnit } from "../types/enums/duration-unit.enum"
import { BusinessServicePaymentDbModel, IBusinessServicePayment } from "./business-service-payment.model"
import { BusinessServiceEventSettingDbModel, IBusinessServiceEventSetting } from "./business-service-event-setting.model"
import { IServiceAddress, ServiceAddressDbModel } from "./service-address.db-model"
import { Address } from "../types/address"

export abstract class BusinessServiceSnapshotDbModel {

	public static businessServiceSnapshotSchema = new Schema({
		serviceHash: {
			type: String,
			index: true
		},
		serviceName: String,
		serviceDescription: String,
		serviceDuration: Number,
		serviceDurationUnit: {
			type: Number,
			enum: Object.values(DurationUnit).filter(v => Number.isInteger(v))
		},
		servicePrice: Number,
		serviceCurrency: {
			type: Number,
			enum: Object.values(Currency).filter(v => Number.isInteger(v))
		},
		paymentSetting: BusinessServicePaymentDbModel.businessServicePaymentSchema,
		depositAmount: Number,
		eventSetting: BusinessServiceEventSettingDbModel.businessServiceEventSettingSchema,
		// isCapacityVisible: {
		// 	type: Boolean,
		// 	default: true
		// },
		serviceAddress: ServiceAddressDbModel.serviceAddressSchema,
		type: {
			type: String,
			default: null
		},
		cutOff: Number,
		cutOffUnit: {
			type: Number,
			enum: Object.values(DurationUnit).filter((v) => Number.isInteger(v)),
		},

	},
	{
		timestamps: true, // adds createdAt and updatedAt automatically
	})

	public static BusinessServiceSnapshotModel = model<IBusinessServiceSnapshot>('business-service-snapshot', BusinessServiceSnapshotDbModel.businessServiceSnapshotSchema)

	public static convertToDbModel(businessServiceSnapshot: BusinessServiceSnapshot): IBusinessServiceSnapshot {
		return new BusinessServiceSnapshotDbModel.BusinessServiceSnapshotModel({
			serviceHash: businessServiceSnapshot.serviceHash,
			serviceName: businessServiceSnapshot.serviceName,
			serviceDescription: businessServiceSnapshot.serviceDescription == null ?
				undefined :
				businessServiceSnapshot.serviceDescription,
			serviceDuration: businessServiceSnapshot.serviceDuration,
			serviceDurationUnit: businessServiceSnapshot.serviceDurationUnit,
			servicePrice: businessServiceSnapshot.servicePrice,
			serviceCurrency: businessServiceSnapshot.serviceCurrency == null ?
				undefined :
				businessServiceSnapshot.serviceCurrency,
			paymentSetting: businessServiceSnapshot.paymentSetting == null ?
				undefined :
				businessServiceSnapshot.paymentSetting,
			depositAmount: businessServiceSnapshot.depositAmount == null ? undefined : businessServiceSnapshot.depositAmount,
			eventSetting: businessServiceSnapshot.eventSetting == null ?
				undefined :
				businessServiceSnapshot.eventSetting,
			// isCapacityVisible: businessServiceSnapshot.isCapacityVisible == null ? true : businessServiceSnapshot.isCapacityVisible,
			serviceAddress: businessServiceSnapshot.serviceAddress == null ?
				undefined :
				ServiceAddressDbModel.convertToDbModel(businessServiceSnapshot.serviceAddress),
			type: businessServiceSnapshot.type == null ? null : businessServiceSnapshot.type,
			cutOff: businessServiceSnapshot.cutOff == null ? undefined : businessServiceSnapshot.cutOff,
			cutOffUnit: businessServiceSnapshot.cutOffUnit == null ? undefined : businessServiceSnapshot.cutOffUnit
		})
	}

	public static convertToDomainModel(businessServiceSnapshotDoc: IBusinessServiceSnapshot): BusinessServiceSnapshot {
		return new BusinessServiceSnapshot(
			businessServiceSnapshotDoc.id,
			businessServiceSnapshotDoc.serviceHash,
			businessServiceSnapshotDoc.serviceName,
			businessServiceSnapshotDoc.serviceDescription == null ?
				undefined :
				businessServiceSnapshotDoc.serviceDescription,
			businessServiceSnapshotDoc.serviceDuration,
			businessServiceSnapshotDoc.serviceDurationUnit,
			businessServiceSnapshotDoc.servicePrice,
			businessServiceSnapshotDoc.serviceCurrency == null ?
				undefined :
				businessServiceSnapshotDoc.serviceCurrency,
			// businessServiceSnapshotDoc.groupMeetLink == null ?
			// undefined :
			// businessServiceSnapshotDoc.groupMeetLink,
			businessServiceSnapshotDoc.paymentSetting == null ?
				undefined :
				businessServiceSnapshotDoc.paymentSetting,
			businessServiceSnapshotDoc.depositAmount == null ?
				undefined :
				businessServiceSnapshotDoc.depositAmount,
			businessServiceSnapshotDoc.eventSetting == null ?
				undefined :
				businessServiceSnapshotDoc.eventSetting,
			// businessServiceSnapshotDoc.isCapacityVisible == null ? true : businessServiceSnapshotDoc.isCapacityVisible,
			businessServiceSnapshotDoc.serviceAddress == null ?
				undefined :
				ServiceAddressDbModel.convertToDomainModel(businessServiceSnapshotDoc.serviceAddress),
			businessServiceSnapshotDoc.type == null ? null : businessServiceSnapshotDoc.type,
			businessServiceSnapshotDoc.cutOff == null ? undefined : businessServiceSnapshotDoc.cutOff,
			businessServiceSnapshotDoc.cutOffUnit == null ? undefined : businessServiceSnapshotDoc.cutOffUnit,
		)
	}
}

export interface IBusinessServiceSnapshot extends Document {
	serviceHash: string
	serviceName: string,
	serviceDescription: string
	serviceDuration: number
	serviceDurationUnit: number
	servicePrice: number
	serviceCurrency: number
	// groupMeetLink:string
	paymentSetting: IBusinessServicePayment;
	depositAmount: number,
	eventSetting?: IBusinessServiceEventSetting;
	// isCapacityVisible?: boolean,
	serviceAddress?: IServiceAddress,
	type?: string,
	cutOff?: number,
	cutOffUnit?: number
}