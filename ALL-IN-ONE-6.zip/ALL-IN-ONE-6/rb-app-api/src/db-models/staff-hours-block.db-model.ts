import { Schema } from "mongoose";

import { StaffHoursBlock } from "../types/staff-hours-block";
import { DayOfTheWeek } from "../types/enums/day-of-the-week.enum";

export abstract class StaffHoursBlockDbModel {
  public static staffHoursBlockSchema = new Schema(
    {
      startDayOfTheWeek: {
        type: Number,
        enum: Object.values(DayOfTheWeek).filter((v) => Number.isInteger(v)),
      },
      startHour: Number,
      startMinute: Number,
      endDayOfTheWeek: {
        type: Number,
        enum: Object.values(DayOfTheWeek).filter((v) => Number.isInteger(v)),
      },
      endHour: Number,
      endMinute: Number,
    },
    { _id: false }
  );

  public static convertToDbModel(
    staffHoursBlock: StaffHoursBlock
  ): IStaffHoursBlock {
    return {
      startDayOfTheWeek: staffHoursBlock.startDayOfTheWeek,
      startHour: staffHoursBlock.startHour,
      startMinute: staffHoursBlock.startMinute,
      endDayOfTheWeek: staffHoursBlock.endDayOfTheWeek,
      endHour: staffHoursBlock.endHour,
      endMinute: staffHoursBlock.endMinute,
    };
  }

  public static convertToDomainModel(
    staffHoursBlockDoc: IStaffHoursBlock
  ): StaffHoursBlock {
    return new StaffHoursBlock(
      staffHoursBlockDoc.startDayOfTheWeek,
      staffHoursBlockDoc.startHour,
      staffHoursBlockDoc.startMinute,
      staffHoursBlockDoc.endDayOfTheWeek,
      staffHoursBlockDoc.endHour,
      staffHoursBlockDoc.endMinute
    );
  }
}

export interface IStaffHoursBlock {
  startDayOfTheWeek: number;
  startHour: number;
  startMinute: number;
  endDayOfTheWeek: number;
  endHour: number;
  endMinute: number;
}
