import { Schema, Document, model } from "mongoose"
import { BusinessDateOverrides } from "../types/business-date-overrides"

export abstract class BusinessDateOverridesDbModel {
	public static businessDateOverrideSchema = new Schema(
		{
			businessId: String,
			blockoutDates: [String],
		}
	)

	public static BusinessHourOverrideModel = model<IBusinessDateOverrides>('business-override', BusinessDateOverridesDbModel.businessDateOverrideSchema)
	// from SPA to DB
	public static convertToDbModel(overrideDoc: BusinessDateOverrides): IBusinessDateOverrides {
		return new BusinessDateOverridesDbModel.BusinessHourOverrideModel({
			businessId: overrideDoc.businessId == null ? undefined : overrideDoc.businessId,
			blockoutDates: overrideDoc.blockoutDates == null ? undefined : overrideDoc.blockoutDates
		})
	}
	// from DB to SPA
	public static convertToDomainModel(overrideDoc: IBusinessDateOverrides): BusinessDateOverrides {
		return new BusinessDateOverrides(
			overrideDoc.businessId == null ? undefined : overrideDoc.businessId,
			overrideDoc.blockoutDates == null ? undefined : overrideDoc.blockoutDates
		);
	}
}

export interface IBusinessDateOverrides extends Document {
	businessId: string,
	blockoutDates: string[]
}
