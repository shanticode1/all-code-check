import { Schema, Document, model } from "mongoose";
import { User } from "../types/user";

export abstract class UserDbModel {

    private static UserSchema = new Schema({
        email: {
            type: String,
            // unique: true,
            lowercase: true
        },
        password: String,
        userName: String,
        role: Number,
        isActive: Boolean,
        isDeleted: Boolean,
        activationToken: new Schema({}, { _id: true }),
		passwordResetToken: new Schema({}),
		emailResendTime: Date,

    }, { timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' } });

    public static UserModel = model<IUser>("user", UserDbModel.UserSchema);

    public static convertToDbModel(user: User): IUser {
        return new UserDbModel.UserModel({
            email: user.email,
            password: user.password == null ? undefined : user.password,
            userName: user.userName == null ? undefined : user.userName,
            role: user.role == null ? undefined : user.role,
            isActive: user.isActive == null ? undefined : user.isActive,
            isDeleted: user.isDeleted == null ? undefined : user.isDeleted,
            activationToken: user.activationToken == null ? undefined : user.activationToken,
        });
    }

    public static convertToDomainModel(userDoc: IUser): User {
        const user = new User(
            userDoc.id.toString(),
            userDoc.email == null ? undefined : userDoc.email,
            userDoc.password == null ? undefined : userDoc.password,
            userDoc.userName == null ? undefined : userDoc.userName,
            userDoc.role == null
                ? undefined
                : userDoc.role,
            userDoc.isActive,
            userDoc.isDeleted,
            userDoc.activationToken ? false : true,
        );
        delete user.password
        return user;
    }
}

export interface IUser extends Document {
    id: string,
    email: string,
    password: string,
    userName: string,
    role: number,
    isActive: boolean,
    isDeleted: boolean,
    activationToken: Document,
    createdAt?: Date
    updatedAt?: Date
    passwordResetToken?: Document,
	emailResendTime?: Date,
}
