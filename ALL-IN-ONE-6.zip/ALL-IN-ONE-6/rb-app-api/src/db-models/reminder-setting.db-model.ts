import { Schema } from "mongoose"

import { ReminderSetting } from "../types/business-settings"

export abstract class ReminderSettingDbModel {
	public static reminderSettingSchema = new Schema(
		{
			duration: { type: Number, default: 24 },
			durationUnit: { type: Number, default: 1 },
		},
		{ _id: false }
	)

	public static convertToDbModel(reminderSetting: ReminderSetting): IReminderSetting {
		return {
			duration: reminderSetting.duration == null ? undefined : reminderSetting.duration,
			durationUnit: reminderSetting.durationUnit == null ? undefined : reminderSetting.durationUnit,
		}
	}

	public static convertToDomainModel(reminderSettingDoc: IReminderSetting): ReminderSetting {
		return new ReminderSetting(
			reminderSettingDoc.duration == null ? undefined : reminderSettingDoc.duration,
			reminderSettingDoc.durationUnit == null ? undefined : reminderSettingDoc.durationUnit,
		)
	}
}

export interface IReminderSetting {
	duration: number
	durationUnit: number
}
