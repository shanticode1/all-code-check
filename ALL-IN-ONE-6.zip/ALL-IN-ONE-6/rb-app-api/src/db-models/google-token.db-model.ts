import { Schema } from "mongoose"

import { GoogleToken } from "../types/googleToken"

export abstract class GoogleTokenDbModel {
    public static googleTokenSchema = new Schema(
        {
            access_token: String,
            refresh_token: String,
            scope: String,
            token_type: String,
            id_token: String,
            expiry_date: Number,
            // syncEventToken:String
        },
        { _id: false }
    )

    public static convertToDbModel(googleToken: GoogleToken): IGoogleToken {
        return {
            access_token: googleToken.access_token,
            refresh_token: googleToken.refresh_token == null ? undefined : googleToken.refresh_token,
            scope: googleToken.scope == null ? undefined : googleToken.scope,
            token_type: googleToken.token_type == null ? undefined : googleToken.token_type,
            id_token: googleToken.id_token == null ? undefined : googleToken.id_token,
            expiry_date: googleToken.expiry_date == null ? undefined : googleToken.expiry_date,
            // syncEventToken:googleToken.syncEventToken==null ?undefined :googleToken.syncEventToken
        }
    }

    public static convertToDomainModel(googleTokenDoc: IGoogleToken): GoogleToken {
        return new GoogleToken(
            googleTokenDoc.access_token,
            googleTokenDoc.refresh_token == null ? undefined : googleTokenDoc.refresh_token,
            googleTokenDoc.scope == null ? undefined : googleTokenDoc.scope,
            googleTokenDoc.token_type == null ? undefined : googleTokenDoc.token_type,
            googleTokenDoc.id_token == null ? undefined : googleTokenDoc.id_token,
            googleTokenDoc.expiry_date == null ? undefined : googleTokenDoc.expiry_date,
            // googleTokenDoc.syncEventToken==null ? undefined:googleTokenDoc.syncEventToken
        )
    }
}

export interface IGoogleToken {
    access_token: string
    refresh_token: string
    scope: string
    token_type: string
    id_token: string
    expiry_date: number
    // syncEventToken:string
}
