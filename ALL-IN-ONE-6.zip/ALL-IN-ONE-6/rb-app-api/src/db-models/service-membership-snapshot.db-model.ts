import { Schema, Document, model } from "mongoose"
import { IMembershipPackage, MembershipPackageDbModel } from "./membership-setting.db-model"
import { Currency } from "../types/enums/currency"
import { MembershipServiceSnapshot } from "../types/service-membership-snapshot"

export abstract class MembershipServiceSnapshotDbModel {
	public static membershipServiceSnapshotModal = new Schema(
		{
			membershipName: String,
			membershipDescription: String,
			membershipHash: {
				type: String,
				index: true
			},
			membershipPackageSetting: [MembershipPackageDbModel.membershipPackageSchema],
			membershipPrice: Number,
			isDeleted: Boolean,
			isActive: Boolean,
			membershipLogo: String,
			membershipCurrency: {
				type: Number,
				enum: Object.values(Currency).filter((v) => Number.isInteger(v)),
			},
			membershipType: {
				type: String,
				default: 'membership',
			},
		},
		{
			timestamps: true, // adds createdAt and updatedAt automatically
		}
	)

	public static MembershipServiceSnapshotModel = model<IMembershipServiceSnapshot>('business-membership-snapshot', MembershipServiceSnapshotDbModel.membershipServiceSnapshotModal)
	// from SPA to DB
	public static convertToDbModel(serviceMembership: MembershipServiceSnapshot): IMembershipServiceSnapshot {
		return new MembershipServiceSnapshotDbModel.MembershipServiceSnapshotModel({
			membershipName: serviceMembership.membershipName,
			membershipDescription: serviceMembership.membershipDescription,
			membershipHash: serviceMembership.membershipHash,
			membershipPackageSetting: serviceMembership.membershipPackageSetting === null ? undefined : serviceMembership.membershipPackageSetting.map(setting =>
				MembershipPackageDbModel.convertToDbModel(setting)),
			membershipPrice: serviceMembership.membershipPrice === null ? undefined : serviceMembership.membershipPrice,
			membershipCurrency: serviceMembership.membershipCurrency == null ? undefined : serviceMembership.membershipCurrency,
			isDeleted: serviceMembership.isDeleted === null ? undefined : serviceMembership.isDeleted,
			isActive: serviceMembership.isActive === null ? undefined : serviceMembership.isActive,
			membershipLogo: serviceMembership.membershipLogo == null ? undefined : serviceMembership.membershipLogo,
			membershipType: serviceMembership.membershipType == null ? undefined : serviceMembership.membershipType,
		})
	}
	// from DB to SPA
	public static convertToDomainModel(membershipDoc: IMembershipServiceSnapshot): MembershipServiceSnapshot {
		return new MembershipServiceSnapshot(
			membershipDoc.id,
			membershipDoc.membershipName,
			membershipDoc.membershipDescription == null ? undefined : membershipDoc.membershipDescription,
			membershipDoc.membershipHash == null ? undefined : membershipDoc.membershipHash,
			membershipDoc.membershipPackageSetting == null ? undefined : membershipDoc.membershipPackageSetting.map(setting => MembershipPackageDbModel.convertToDomainModel(setting)),
			membershipDoc.membershipPrice === null ? 0 : membershipDoc.membershipPrice,
			membershipDoc.membershipCurrency == null ? undefined : membershipDoc.membershipCurrency,
			membershipDoc.isDeleted === null ? undefined : membershipDoc.isDeleted,
			membershipDoc.isActive === null ? undefined : membershipDoc.isActive,
			membershipDoc.membershipLogo == null ? undefined : membershipDoc.membershipLogo,
			membershipDoc.membershipType == null ? undefined : membershipDoc.membershipType,
		);
	}
}

export interface IMembershipServiceSnapshot extends Document {
	membershipName: string,
	membershipDescription: string,
	membershipHash: string,
	membershipPackageSetting: IMembershipPackage[],
	membershipPrice: number,
	membershipCurrency: number;
	isDeleted?: boolean,
	isActive?: boolean,
	membershipLogo?: string,
	membershipType?: string
}
