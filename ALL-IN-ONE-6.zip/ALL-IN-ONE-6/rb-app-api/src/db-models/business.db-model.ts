import { Schema, Document, model } from "mongoose"

import { BusinessType } from "../types/business-type"
import { Business } from "../types/business"
import { AddressDbModel, IAddress } from "./address.db-model"
import { BusinessHoursBlockDbModel, IBusinessHoursBlock } from "./business-hours-block.db-model"
import { Currency } from "../types/enums/currency"
import { CoordinatesDbModel, ICoordinates } from "./coordinates.db-model"
import { IServiceCategoryType, ServiceCategoryDbModel } from "./service-category.db-model"
import { BusinessSettingDbModel, IBusinessSettings } from "./business-setting.db-model"
import { BusinessNotesDbModel, IBusinessNotes } from "./business-notes.db-model"
import { TimeZone } from "../types/time-zone"
import { BusinessSocialMediasDbModel, IBusinessSocialMedias } from "./business-social-medias.db-model"
import { MembershipTier, WhatsAppMembershipTier } from "../types/enums/membership-tier.enum"
import { ModalTypeEnum, trialEnum } from "../types/enums/ModalType.enum"
import { GoogleTokenDbModel, IGoogleToken } from "./google-token.db-model"
import { GoogleCalendarDbModel, IGoogleCalendarType } from "./google-calendar.db-model"
import { IPrices, PricesDbModel } from "./prices.db.model"
import { IUser, UserDbModel } from "./users.db-model"
import { User } from "../types/user"
import { PaymentStatus } from "../types/enums/payment.status"

export abstract class BusinessDbModel {

	private static businessSchema = new Schema({
		userId: String,
		contactName: String,
		name: String,
		slug: {
			type: String,
			lowercase: true,
			index: {
				unique: true,
				partialFilterExpression: { slug: { $type: 'string' } }
			}
		},
		phoneNumber: String,
		countryCode: String,
		address: AddressDbModel.addressSchema,
		coordinates: CoordinatesDbModel.coordinatesSchema,
		email: {
			type: String,
			unique: true,
			lowercase: true
		},
		password: String,
		businessTypeId: String,
		timeZoneId: String,
		currency: {
			type: Number,
			enum: Object.values(Currency).filter(v => Number.isInteger(v))
		},
		isOperatingNonStop: Boolean,
		businessHoursBlocks: [BusinessHoursBlockDbModel.businessHoursBlockSchema],
		about: String,
		serviceCategories: [ServiceCategoryDbModel.serviceCategorySchema],
		settings: BusinessSettingDbModel.businessSettingSchema,
		notes: [BusinessNotesDbModel.businessNotesSchema],
		socialMedia: BusinessSocialMediasDbModel.BusinessSocialMediasSchema,
		isActive: Boolean,
		isDeleted: Boolean,
		passwordResetToken: new Schema({}),
		activationToken: new Schema({}),
		membershipTier: {
			type: Number,
			enum: Object.values(MembershipTier).filter(v => Number.isInteger(v))
		},
		membershipExpirationDate: Date,
		staffMembershipExpirationDate: Date,
		modalType: {
			type: Number,
			enum: Object.values(ModalTypeEnum).filter(v => Number.isInteger(v))
		},
		lastLoginDate: Date,
		stripeCustomerId: String,
		stripeOnTrial: Boolean,
		frillToken: String,
		referral: String,
		lastCompletedOnboardingStep: Number,
		googleToken: GoogleTokenDbModel.googleTokenSchema,
		googleCalendar: [GoogleCalendarDbModel.googleCalendarSchema],
		gmail: String,
		isConflict: Boolean,
		gPicture: String,
		gName: String,
		isTrialActivatedOnce: { default: false, type: Boolean },
		isTrialOnce: {
			type: Number,
			enum: Object.values(trialEnum).filter(v => Number.isInteger(v))
		},
		gEventWatchId: String,
		gResourceId: String,
		syncEventToken: String,
		whatsAppCredits: {
			type: Number,
			default: 0
		},
		watchEventExpiry: Number,
		heroImage: String,
		bannerImage: String,
		whatsAppMembershipTier: {
			type: Number,
			enum: Object.values(WhatsAppMembershipTier).filter(v => Number.isInteger(v))
		},
		whatsAppBagsMembershipTier: {
			type: Number,
			enum: Object.values(MembershipTier).filter(v => Number.isInteger(v))
		},
		whatsAppPayAsYouGoMembershipTier: {
			type: Number,
			enum: Object.values(MembershipTier).filter(v => Number.isInteger(v))
		},
		whatsAppBagsCredits: {
			type: Number,
			default: 0
		},
		whatsAppPayAsYouGoCredits: {
			type: Number,
			default: 0
		},
		whatsAppBagsExpirationdate: Date,
		whatsAppPayAsYouGoExpirationdate: Date,
		whatsappMembershipExpirationDate: Date,
		stripePayAsYouGoOnTrial: Boolean,
		stripePriceIds: PricesDbModel.priceSchema,
		usageCount: Number,
		emailResendTime: Date,
		isPaymentDue: { type: Boolean, default: false },
		createdAt: { type: Date },
		whatsappBagsQuantity: {
			type: Number,
		},
		trialMonthDate: Date,
		stripePlanStatus: String,
		membershipStaffCount: {
			type: Number,
			default: 0
		},
		buyExtraStaffCount: {
			type: Number,
			default: 0
		},
		subscriptionId: String,
		isStaffPaymentPaid: {
			type: Boolean,
			default: true
		},
		isAnnualActive: {
			type: Boolean,
			default: false
		},
		stripeConnectAccountId: {
			type: String,
			default: null
		},
		isPaymentMethodConnected: Boolean,
		isConnectedAccDetailSubmitted: Boolean,
		planBillingStatus: {
			type: Number,
			enum: Object.values(PaymentStatus).filter(v => Number.isInteger(v))
		},
		paymentRetryCount: Number,
		paymentFailedAt: Date,
		isAccessPaused: Boolean,
		marketPlaceImages: [
			{
				url: { type: String },
			}
		],
		isPublishedOnMarketplace: Boolean,
	})

	public static BusinessModel = model<IBusiness>('business', BusinessDbModel.businessSchema)

	public static convertToDbModel(business: Business): IBusiness {
		return new BusinessDbModel.BusinessModel({
			userId: business.userId == null ? undefined : business.userId,
			contactName: business.contactName == null ? undefined : business.contactName,
			name: business.name == null ?
				undefined :
				business.name,
			slug: business.slug == null ?
				undefined :
				business.slug,
			phoneNumber: business.phoneNumber == null ?
				undefined :
				business.phoneNumber,
			countryCode: business.countryCode == null ?
				'' :
				business.countryCode,
			address: business.address == null ?
				undefined :
				AddressDbModel.convertToDbModel(business.address),
			coordinates: business.coordinates == null ?
				undefined :
				CoordinatesDbModel.convertToDbModel(business.coordinates),
			email: business.email,
			password: business.password,
			businessTypeId: business.type == null ?
				undefined :
				business.type.id,
			timeZoneId: business.timeZone.id,
			currency: business.currency,
			isOperatingNonStop: business.isOperatingNonStop == null ?
				undefined :
				business.isOperatingNonStop,
			businessHoursBlocks: business.businessHoursBlocks == null ?
				undefined :
				business.businessHoursBlocks.map(bh => BusinessHoursBlockDbModel.convertToDbModel(bh)),
			about: business.about == null ?
				undefined :
				business.about,
			serviceCategories: business.serviceCategories == null || business.serviceCategories.length == 0 ?
				undefined :
				business.serviceCategories.map(sc => ServiceCategoryDbModel.convertToDbModel(sc)),

			settings: business.settings == null ?
				undefined :
				BusinessSettingDbModel.convertToDbModel(business.settings),
			socialMedia: business.socialMedia == null ?
				undefined :
				BusinessSocialMediasDbModel.convertToDbModel(business.socialMedia),
			isActive: business.isActive == null ?
				undefined :
				business.isActive,
			isDeleted: business.isDeleted == null ?
				undefined :
				business.isDeleted,
			membershipTier: business.membershipTier,
			createdAt: business.createdAt,
			membershipExpirationdate: business.membershipExpirationDate,
			staffMembershipExpirationDate: business.staffMembershipExpirationDate,
			modalType: business.modalType,
			lastLoginDate: business.lastLoginDate,
			stripeCustomerId: business.stripeCustomerId,
			stripeOnTrial: business.stripeOnTrial,
			frillToken: business.frillToken,
			referral: business.referral,
			heroImage: business.heroImage,
			bannerImage: business.bannerImage,
			lastCompletedOnboardingStep: business.lastCompletedOnboardingStep,
			googleToken: business.googleToken == null ?
				undefined :
				GoogleTokenDbModel.convertToDbModel(business.googleToken),
			googleCalendar: business.googleCalendar == null || business.googleCalendar.length == 0 ?
				undefined :
				business.googleCalendar.map(sc => GoogleCalendarDbModel.convertToDbModel(sc)),
			gmail: business.gmail == null ? undefined : business.gmail,
			gPicture: business.gPicture == null ? undefined : business.gPicture,
			gName: business.gName == null ? undefined : business.gName,
			isTrialActivatedOnce: business.isTrialActivatedOnce == null ? undefined : business.isAccountActivated,
			isTrialOnce: business.isTrialOnce == null ? trialEnum.oldUser : business.isTrialOnce,
			gEventWatchId: business.gEventWatchId == null ? undefined : business.gEventWatchId,
			gResourceId: business.gResourceId == null ? undefined : business.gResourceId,
			syncEventToken: business.syncEventToken == null ? undefined : business.syncEventToken,
			whatsAppCredits: business.whatsAppCredits == null ? undefined : business.whatsAppCredits,
			watchEventExpiry: business.watchEventExpiry == null ? undefined : business.watchEventExpiry,
			whatsAppMembershipTier: business.whatsAppMembershipTier,
			stripePayAsYouGoOnTrial: business.stripePayAsYouGoOnTrial == null ? undefined : business.stripePayAsYouGoOnTrial,
			stripePriceIds: business.stripePriceIds == null ?
				undefined :
				PricesDbModel.convertToDbModel(business.stripePriceIds),
			membershipStaffCount: business.membershipStaffCount == null ? undefined : business.membershipStaffCount,
			buyExtraStaffCount: business.buyExtraStaffCount == null ? undefined : business.buyExtraStaffCount,
			isStaffPaymentPaid: business.isStaffPaymentPaid == null ? undefined : business.buyExtraStaffCount,
			isAnnualActive: business.isAnnualActive == null ? false : business.isAnnualActive,
			stripeConnectAccountId: business.stripeConnectAccountId == null ? undefined : business.stripeConnectAccountId,
			isConnectedAccDetailSubmitted: business.isConnectedAccDetailSubmitted == null ? undefined : business.isConnectedAccDetailSubmitted,
			isPaymentMethodConnected: business.isPaymentMethodConnected == null ? undefined : business.isPaymentMethodConnected,
			planBillingStatus: business.planBillingStatus == null ? undefined : business.planBillingStatus,
			paymentRetryCount: business.paymentRetryCount == null ? undefined : business.paymentRetryCount,
			isAccessPaused: business.isAccessPaused == null ? false : business.isAccessPaused,
			marketPlaceImages: Array.isArray(business.marketPlaceImages)
				? business.marketPlaceImages.map(img => ({
					url: img.url
				}))
				: [],
			isPublishedOnMarketplace: business.isPublishedOnMarketplace == null ? false : business.isPublishedOnMarketplace,
		})
	}

	public static convertToDomainModel(businessDoc: IBusiness): Business {
		const business = new Business(
			businessDoc.id,
			businessDoc.userId,
			businessDoc.contactName,
			businessDoc.name == null ?
				undefined :
				businessDoc.name,
			businessDoc.slug == null ?
				undefined :
				businessDoc.slug,
			businessDoc.phoneNumber == null ?
				undefined :
				businessDoc.phoneNumber,
			businessDoc.countryCode == null ?
				'' :
				businessDoc.countryCode,
			businessDoc.address == null ?
				undefined :
				AddressDbModel.convertToDomainModel(businessDoc.address),
			businessDoc.coordinates == null ?
				undefined :
				CoordinatesDbModel.convertToDomainModel(businessDoc.coordinates),
			businessDoc.email,
			businessDoc.password,
			businessDoc.businessTypeId == null ?
				undefined :
				new BusinessType(businessDoc.businessTypeId, undefined),
			new TimeZone(businessDoc.timeZoneId, undefined, undefined, undefined),
			businessDoc.currency as Currency,
			businessDoc.isOperatingNonStop == null ?
				undefined :
				businessDoc.isOperatingNonStop,
			businessDoc.businessHoursBlocks == null || businessDoc.businessHoursBlocks.length == 0 ?
				undefined :
				businessDoc.businessHoursBlocks.map(bh => BusinessHoursBlockDbModel.convertToDomainModel(bh)),
			undefined, //blockout dates
			businessDoc.about == null ?
				undefined :
				businessDoc.about,
			undefined,
			businessDoc.serviceCategories == null || businessDoc.serviceCategories.length == 0 ?
				undefined :
				businessDoc.serviceCategories.map(sc => ServiceCategoryDbModel.convertToDomainModel(sc)),

			businessDoc.settings == null ?
				undefined :
				BusinessSettingDbModel.convertToDomainModel(businessDoc.settings),
			businessDoc.socialMedia == null ?
				undefined :
				BusinessSocialMediasDbModel.convertToDomainModel(businessDoc.socialMedia),
			businessDoc.isActive,
			businessDoc.isDeleted,
			businessDoc.membershipTier,
			businessDoc.createdAt == null ? undefined : businessDoc.createdAt,
			businessDoc.membershipExpirationDate == null ? undefined : businessDoc.membershipExpirationDate,
			businessDoc.staffMembershipExpirationDate == null ? undefined : businessDoc.staffMembershipExpirationDate,
			businessDoc.modalType,
			businessDoc.lastLoginDate,
			businessDoc.activationToken ? false : true,
			businessDoc.stripeCustomerId == null ? undefined : businessDoc.stripeCustomerId,
			businessDoc.stripeOnTrial == null ? undefined : businessDoc.stripeOnTrial,
			businessDoc.frillToken == null ? undefined : businessDoc.frillToken,
			businessDoc.referral == null ? undefined : businessDoc.referral,
			businessDoc.heroImage == null ? undefined : businessDoc.heroImage,
			businessDoc.bannerImage == null ? undefined : businessDoc.bannerImage,
			businessDoc.lastCompletedOnboardingStep == null ? undefined : businessDoc.lastCompletedOnboardingStep,
			businessDoc.googleToken == null ?
				undefined :
				GoogleTokenDbModel.convertToDomainModel(businessDoc.googleToken),
			businessDoc.googleCalendar == null || businessDoc.googleCalendar.length == 0 ?
				undefined :
				businessDoc.googleCalendar.map(sc => GoogleCalendarDbModel.convertToDomainModel(sc)),
			businessDoc.gmail == null ? undefined : businessDoc.gmail,
			businessDoc.isConflict == null ? undefined : businessDoc.isConflict,
			businessDoc.gPicture == null ? undefined : businessDoc.gPicture,
			businessDoc.gName == null ? undefined : businessDoc.gName,
			businessDoc.isTrialActivatedOnce == null ? undefined : businessDoc.isTrialActivatedOnce,
			businessDoc.isTrialOnce == null ? trialEnum.oldUser : businessDoc.isTrialOnce,
			businessDoc.gEventWatchId == null ? undefined : businessDoc.gEventWatchId,
			businessDoc.gResourceId == null ? undefined : businessDoc.gResourceId,
			businessDoc.syncEventToken == null ? undefined : businessDoc.syncEventToken,
			businessDoc.whatsAppCredits == null ? undefined : businessDoc.whatsAppCredits,
			businessDoc.watchEventExpiry == null ? undefined : businessDoc.watchEventExpiry,
			businessDoc.whatsAppMembershipTier == null ? undefined : businessDoc.whatsAppMembershipTier,
			businessDoc.stripePayAsYouGoOnTrial == null ? undefined : businessDoc.stripePayAsYouGoOnTrial,
			businessDoc.stripePriceIds == null ?
				undefined :
				PricesDbModel.convertToDomainModel(businessDoc.stripePriceIds),
			businessDoc.whatsAppBagsCredits == null ? undefined : businessDoc.whatsAppBagsCredits,
			businessDoc.whatsAppPayAsYouGoCredits == null ? undefined : businessDoc.whatsAppPayAsYouGoCredits,
			businessDoc.usageCount == null ? 0 : businessDoc.usageCount,
			businessDoc.whatsappBagsQuantity == null ? 0 : businessDoc.whatsappBagsQuantity,
			businessDoc.isPaymentDue == null ? false : businessDoc.isPaymentDue,
			businessDoc.whatsAppPayAsYouGoMembershipTier == null ? 0 : businessDoc.whatsAppPayAsYouGoMembershipTier,
			businessDoc.user == null ?
				undefined :
				UserDbModel.convertToDomainModel(businessDoc.user),
			businessDoc.membershipStaffCount == null ? undefined : businessDoc.membershipStaffCount,
			businessDoc.buyExtraStaffCount == null ? undefined : businessDoc.buyExtraStaffCount,
			businessDoc.isStaffPaymentPaid == null ? undefined : businessDoc.isStaffPaymentPaid,
			businessDoc.isAnnualActive == null ? undefined : businessDoc.isAnnualActive,
			businessDoc.stripeConnectAccountId == null ? undefined : businessDoc.stripeConnectAccountId,
			businessDoc.isConnectedAccDetailSubmitted == null ? undefined : businessDoc.isConnectedAccDetailSubmitted,
			businessDoc.isPaymentMethodConnected == null ? false : businessDoc.isPaymentMethodConnected,
			businessDoc.planBillingStatus == null ? undefined : businessDoc.planBillingStatus,
			businessDoc.paymentRetryCount == null ? undefined : businessDoc.paymentRetryCount,
			businessDoc.isAccessPaused == null ? false : businessDoc.isAccessPaused,
			businessDoc.marketPlaceImages == null
				? undefined
				: businessDoc.marketPlaceImages.map(img => ({
					id: img.id,
					url: img.url
				} as IMarketPlaceImanges)),
			businessDoc.isPublishedOnMarketplace == null ? false : businessDoc.isPublishedOnMarketplace,
		)
		delete business.password
		business.orderBusinessHoursBlocks()
		return business
	}
}

export interface IMarketPlaceImanges extends Document {
	id: string,
	url: string
}

export interface IBusiness extends Document {
	userId: string,
	contactName: string
	name: string
	slug: string
	phoneNumber: string
	countryCode: string
	address: IAddress
	coordinates: ICoordinates
	email: string
	password: string
	timeZoneId: string
	currency: number
	isOperatingNonStop: boolean
	businessHoursBlocks: IBusinessHoursBlock[]
	blockoutDates: string[],
	businessTypeId: string
	about: string
	serviceCategories: IServiceCategoryType[]
	settings: IBusinessSettings
	socialMedia: IBusinessSocialMedias
	isActive: boolean
	isDeleted: boolean
	passwordResetToken: Document
	activationToken: Document,
	membershipTier: number,
	createdAt: Date,
	membershipExpirationDate: Date,
	staffMembershipExpirationDate: Date,
	modalType: number,
	lastLoginDate: Date,
	stripeCustomerId: string,
	stripeOnTrial: boolean,
	frillToken: string,
	referral: string,
	heroImage: string,
	bannerImage: string,
	lastCompletedOnboardingStep: number,
	googleToken: IGoogleToken,
	googleCalendar: IGoogleCalendarType[],
	gmail: string,
	isConflict: boolean,
	gPicture: string,
	gName: string
	isTrialActivatedOnce: boolean,
	isTrialOnce: number,
	gEventWatchId: string,
	gResourceId: string,
	syncEventToken: string,
	whatsAppCredits: number,
	watchEventExpiry: number,
	whatsAppMembershipTier: number,
	stripePayAsYouGoOnTrial: boolean,
	stripePriceIds: IPrices,
	// isFileDeleted:boolean
	whatsAppBagsCredits?: number
	whatsAppPayAsYouGoCredits?: number,
	usageCount?: number,
	emailResendTime?: Date,
	// isPaymentDue?: boolean,
	whatsAppPayAsYouGoExpirationdate?: Date,
	whatsappBagsQuantity?: number,
	isPaymentDue?: boolean,
	whatsAppPayAsYouGoMembershipTier?: number
	user?: IUser,
	membershipStaffCount?: number,
	buyExtraStaffCount?: number,
	isStaffPaymentPaid?: boolean,
	isAnnualActive?: boolean,
	stripeConnectAccountId?: string,
	isConnectedAccDetailSubmitted?: boolean,
	isPaymentMethodConnected?: boolean,
	planBillingStatus?: number,
	paymentRetryCount?: number,
	isAccessPaused?: boolean,
	marketPlaceImages?: IMarketPlaceImanges[],
	isPublishedOnMarketplace?: boolean,
}