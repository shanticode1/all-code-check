import { Schema, Document, model } from "mongoose"

import { BusinessServicePayment } from "../types/business-service-payment"
import { ServicePaymentType } from "../types/enums/payment-type.enum"


export class BusinessServicePaymentDbModel {

    public static businessServicePaymentSchema = new Schema({
        isPaymentAllow: {
            type: Boolean,
            default: false
        },
        paymentType: [{
            type: Number,
            enum: Object.values(ServicePaymentType).filter(v => Number.isInteger(v))
        }],
        isCurrency:Boolean,
        isPercentage:Boolean,

        isPaymentLinkSend: {
            type: Boolean,
            default: false
        },
    }, { _id: false })

    public static BusinessServicePaymentModel = model<IBusinessServicePayment>('payment-setting', BusinessServicePaymentDbModel.businessServicePaymentSchema)

    public static convertToDbModel(businessServicePayment: BusinessServicePayment): IBusinessServicePayment {
        return new BusinessServicePaymentDbModel.BusinessServicePaymentModel({
            isPaymentAllow: businessServicePayment.isPaymentAllow == null ? undefined : businessServicePayment.isPaymentAllow,
            paymentType: businessServicePayment.paymentType == null ? undefined : businessServicePayment.paymentType,
            isPaymentLinkSend: businessServicePayment.isPaymentLinkSend == null ? undefined : businessServicePayment.isPaymentLinkSend,
            isCurrency:businessServicePayment.isCurrency == null ? undefined : businessServicePayment.isCurrency,
            isPercentage:businessServicePayment.isPercentage == null ? undefined : businessServicePayment.isPercentage,
        })
    }

    public static convertToDomainModel(businessServicePaymentDoc: IBusinessServicePayment): BusinessServicePayment {
        return new BusinessServicePayment(
            businessServicePaymentDoc.isPaymentAllow == null ? undefined : businessServicePaymentDoc.isPaymentAllow,
            businessServicePaymentDoc.paymentType == null ? undefined : businessServicePaymentDoc.paymentType,
            businessServicePaymentDoc.isPaymentLinkSend == null ? undefined : businessServicePaymentDoc.isPaymentLinkSend,
            businessServicePaymentDoc.isCurrency == null ? undefined : businessServicePaymentDoc.isCurrency,
            businessServicePaymentDoc.isPercentage == null ? undefined : businessServicePaymentDoc.isPercentage,
        )
    }
}

export interface IBusinessServicePayment extends Document {
    isPaymentAllow: boolean;
    paymentType: number[];
    isPaymentLinkSend: boolean;
    isCurrency?:boolean,
    isPercentage?:boolean,
}