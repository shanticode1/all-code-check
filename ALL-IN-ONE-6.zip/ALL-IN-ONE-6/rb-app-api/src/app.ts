import * as express from "express";
import * as cors from "cors";
import helmet from "helmet";

import { HttpErrorCodeResolver } from "./errors/http-error-code-resolver";
import { BaseRoutes } from "./routes/base.routes";
import { ErrorMessage } from "./types/error-message";
import { BaseError } from "./errors/base.error";
import { CreditsScriptService } from "./credits.script";
import { ClientReminderScriptService } from "./client-reminder-script";
import { ScriptService } from "./scripts/migrate-user-script";
import { roles } from "./data/user.roles";
import { StepperCountScriptService } from "./scripts/business-on-boarding-step";
import { BusinessServiceDaysBlock } from "./scripts/business-service-days-block";
// import { BookingTimeZoneScriptService } from "./scripts/chile-booking-time-migrate";
import { ClientEmailReminderOnService } from "./scripts/clients-email-reminder-add";
import { Logger } from "./logger";
const cookieParser = require('cookie-parser');
// require("dotenv").config();
export abstract class App {
  public static createApp() {
    const app = express();

    app.use(cookieParser());
    app.use(helmet());
    app.use(
      express.json({
        limit: "5mb",
        verify: (req: any, res, buf) => {
          req.rawBody = buf.toString();
        },
      })
    );

    app.use(
      cors({
        origin: process.env.CORS_ORIGIN.split(","),
        methods: "GET,POST,PUT,PATCH,DELETE",
      })
    );

    app.get('/api/whatsapp-credits', async (req, res) => {
      const code = (req.query as any).code as string;
      if (code === '7923823') {
        await CreditsScriptService.runOnTimeScript();
        res.status(200).send('Data updated successfully...')
      }
      else {
        res.status(401).send('unauthorized')
      }
    });

    app.get('/api/reminder', async (req, res) => {
      const code = (req.query as any).code as string;
      if (code === '7923823') {
        await ClientReminderScriptService.clientReminderUpdate();
        res.status(200).send('Data updated successfully...')
      }
      else {
        res.status(401).send('unauthorized')
      }
    });

    app.post('/api/user-migrate', async (req, res) => {
      const code = (req.query as any).code as string;
      const role = (req.query as any).role as number;
      if (code === '7923823' && role) {
        if (role == roles.Business) {
        }
        // if (role == roles.staff) {
        //   await ScriptService.migrateStaffToUser();
        // }
        res.status(200).send('User migrate successfully...')
      }
      else {
        res.status(401).send('unauthorized: Please pass params code and role')
      }
    });

    app.post('/api/insert-currency-rate', async (req, res) => {
      const code = (req.query as any).code as string;
      const role = (req.query as any).role as number;
      Logger.logger.info(" insert process strat--")
      if (code === '7923823' && role) {
        await ScriptService.insertCurrencyRates();
        res.status(200).send('Currency migrate successfully...')
      }
      else {
        res.status(401).send('unauthorized: Please pass params code and role')
      }
    });



    app.patch('/api/business-step-migrate', async (req, res) => {
      const code = (req.query as any).code as string;
      if (code === '7923823') {
        await StepperCountScriptService.updateBusinessStepCount();
        res.status(200).send('User migrate successfully...')
      }
      else {
        res.status(401).send('unauthorized: Please pass params code')
      }
    });

    // app.patch('/api/booking-time-back', async (req, res) => {
    //   const code = (req.query as any).code as string;
    //   console.log('booking time back calling');
    //   if (code === '7923823') {
    //     await BookingTimeZoneScriptService.updateBackWardBookingTime();
    //     res.status(200).send('Back ward Booking migrate successfully...')
    //   }
    //   else {
    //     res.status(401).send('unauthorized: Please pass params code')
    //   }
    // });

    // app.patch('/api/booking-time-revert', async (req, res) => {
    //   const code = (req.query as any).code as string;
    //   console.log('booking time revert calling');
    //   if (code === '7923823') {
    //     await BookingTimeZoneScriptService.revertBackWardBookingTime();
    //     res.status(200).send('Back ward Booking migrate successfully...')
    //   }
    //   else {
    //     res.status(401).send('unauthorized: Please pass params code')
    //   }
    // });

    // app.patch('/api/booking-time-back-bybusiness', async (req: any, res) => {
    //   const code = (req.query as any).code as string;
    //   console.log('booking time back by business id calling:',req.query.businessId);
    //   if (req.query.businessId == undefined) {
    //     res.status(400).send('Business id is required');
    //     return
    //   }
    //   if (code === '7923823') {
    //     await BookingTimeZoneScriptService.backWardBookingTimeByBusinessId(req.query.businessId);
    //     res.status(200).send('booking time back by business id migrate successfully...')
    //   }
    //   else {
    //     res.status(401).send('unauthorized: Please pass params code')
    //   }
    // });

    // app.patch('/api/booking-time-add', async (req, res) => {
    //   const code = (req.query as any).code as string;
    //   console.log('booking time add calling');
    //   if (code === '7923823') {
    //     // await BookingTimeZoneScriptService.updateForwardBookingTime();
    //     res.status(200).send('backward 1 hrs successfully...')
    //   }
    //   else {
    //     res.status(401).send('unauthorized: Please pass params code')
    //   }
    // });

    app.patch('/api/service-days-block', async (req, res) => {
      const code = (req.query as any).code as string;
      console.log('***************** Service days block calling ****************');
      if (code === '7923823') {
        await BusinessServiceDaysBlock.updateServicesDays();
        res.status(200).send('Service days block migrate successfully...')
      } else {
        res.status(401).send('unauthorized: Please pass params code')
      }
    })


    app.patch('/api/client-email-reminder', async (req, res) => {
      const code = (req.query as any).code as string;
      console.log('Client reminder service calling......');
      if (code === '7923823') {
        await ClientEmailReminderOnService.clientEmailReminderAdd();
        res.status(200).send('Client migrate successfully...')
      }
      else {
        res.status(401).send('unauthorized: Please pass params code')
      }
    });

    app.use(BaseRoutes.basePath, BaseRoutes.addChildRoutes());

    app.use((err: BaseError, req, res, next) => {
      const httpErrorCode = HttpErrorCodeResolver.resolveError(err);
      const response = res.status(httpErrorCode);
      if (
        err.sendErrMsgToCaller == true &&
        err.message != null &&
        err.message != ""
      ) {
        console.log('errr app 40', err);
        response.json(new ErrorMessage(err.message));
        return;
      }
      response.send();
    });

    return app;
  }
}
