#!/usr/bin/env bash

docker-compose exec rezrvapp-db_dev sh -c "mongo -u admin -p RGDFjEdoDTFY5V7b7bEKZm5LcLQoXC --eval \"db.getSiblingDB('rezrvapp').createUser({user:'rezrvapp-api',pwd:'PT1CDOhK986pjp9Mzf47dOvttWZag5',roles:[{role:'readWrite',db:'rezrvapp'}]})\""