function testte(){
    setTimeout(() => {
        console.log("Timeout executed 0seconds");
        
    }, 0);

    console.log("Hello, World!");
  
    setTimeout(() => {
        console.log("Timeout executed 2seconds");
        
    }, 2000);
const str='shantichouhan';
const countWithChar={};
for(let i=0;i<str.length;i++){
    console.log(str[i]);
    if(countWithChar[str[i]]){
        countWithChar[str[i]]+=1;
    }else{
        countWithChar[str[i]]=1;
    }
}
const countWithChar1 = new Map();
console.log(countWithChar);
for(const char of str){
    countWithChar1.set(char,(countWithChar1.get(char) || 0)+1);
}
let rev='';
console.log(countWithChar1);
for(let i = str.length - 1; i >= 0; i--){
    rev+=str[i]
}
console.log(rev);

}

testte();