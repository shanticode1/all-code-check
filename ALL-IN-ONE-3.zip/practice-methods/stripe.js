const data = {
    "id": "in_1SG0LAB070pPqlXTHWLrrjVS",
    "object": "invoice",
    "account_country": "US",
    "account_name": "Rezrva",
    "account_tax_ids": null,
    "amount_due": 2500000,
    "amount_overpaid": 0,
    "amount_paid": 0,
    "amount_remaining": 2500000,
    "amount_shipping": 0,
    "application": null,
    "application_fee_amount": null,
    "attempt_count": 2,
    "attempted": true,
    "auto_advance": true,
    "automatic_tax": {
        "disabled_reason": null,
        "enabled": false,
        "liability": null,
        "provider": null,
        "status": null
    },
    "automatically_finalizes_at": null,
    "billing_reason": "subscription_cycle",
    "charge": "ch_3SG1HRB070pPqlXT07ELsfWJ",
    "collection_method": "charge_automatically",
    "created": 1759941348,
    "currency": "ars",
    "custom_fields": null,
    "customer": "cus_T79yZAV3euvnVL",
    "customer_address": null,
    "customer_email": "cerbananasol@gmail.com",
    "customer_name": "Cielo Nails",
    "customer_phone": null,
    "customer_shipping": null,
    "customer_tax_exempt": "none",
    "customer_tax_ids": [
    ],
    "default_payment_method": null,
    "default_source": null,
    "default_tax_rates": [
    ],
    "description": null,
    "discount": null,
    "discounts": [
    ],
    "due_date": null,
    "effective_at": 1759944960,
    "ending_balance": 0,
    "footer": null,
    "from_invoice": null,
    "hosted_invoice_url": "https://invoice.stripe.com/i/acct_1M6wbbB070pPqlXT/live_YWNjdF8xTTZ3YmJCMDcwcFBxbFhULF9UQ1A5Zlg3OWFhYmljRnEzZ2pvTklVMk5OeFRXOWw5LDE1MDUyODk3MA020058dTOm3M?s=ap",
    "invoice_pdf": "https://pay.stripe.com/invoice/acct_1M6wbbB070pPqlXT/live_YWNjdF8xTTZ3YmJCMDcwcFBxbFhULF9UQ1A5Zlg3OWFhYmljRnEzZ2pvTklVMk5OeFRXOWw5LDE1MDUyODk3MA020058dTOm3M/pdf?s=ap",
    "issuer": {
        "type": "self"
    },
    "last_finalization_error": null,
    "latest_revision": null,
    "lines": {
        "object": "list",
        "data": [
            {
                "id": "il_1SG0LAB070pPqlXTulBRO70h",
                "object": "line_item",
                "amount": 2500000,
                "amount_excluding_tax": 2500000,
                "currency": "ars",
                "description": "1 Plan × Pro (at $25,000.00 / month)",
                "discount_amounts": [
                ],
                "discountable": true,
                "discounts": [
                ],
                "invoice": "in_1SG0LAB070pPqlXTHWLrrjVS",
                "livemode": true,
                "metadata": {
                    "priceId": "price_1PXqujB070pPqlXTqkU8rw3t",
                    "usage_type": "licensed"
                },
                "parent": {
                    "invoice_item_details": null,
                    "subscription_item_details": {
                        "invoice_item": null,
                        "proration": false,
                        "proration_details": {
                            "credited_items": null
                        },
                        "subscription": "sub_1SAveeB070pPqlXTq833gnzw",
                        "subscription_item": "si_T79yC0SrJ83c3B"
                    },
                    "type": "subscription_item_details"
                },
                "period": {
                    "end": 1762619696,
                    "start": 1759941296
                },
                "plan": {
                    "id": "price_1PXqujB070pPqlXTqkU8rw3t",
                    "object": "plan",
                    "active": true,
                    "aggregate_usage": null,
                    "amount": 2500,
                    "amount_decimal": "2500",
                    "billing_scheme": "per_unit",
                    "created": 1719866009,
                    "currency": "usd",
                    "interval": "month",
                    "interval_count": 1,
                    "livemode": true,
                    "metadata": {
                        "category": "regular-plan",
                        "first_month_whatsapp_credits": "95",
                        "trial_whatsapp_credits": "5",
                        "type": "2",
                        "whatsapp_credits": "100"
                    },
                    "meter": null,
                    "nickname": "Month Pro Multi-currency",
                    "product": "prod_QOeDquMtwp1oR4",
                    "tiers_mode": null,
                    "transform_usage": null,
                    "trial_period_days": null,
                    "usage_type": "licensed"
                },
                "pretax_credit_amounts": [
                ],
                "price": {
                    "id": "price_1PXqujB070pPqlXTqkU8rw3t",
                    "object": "price",
                    "active": true,
                    "billing_scheme": "per_unit",
                    "created": 1719866009,
                    "currency": "usd",
                    "custom_unit_amount": null,
                    "livemode": true,
                    "lookup_key": null,
                    "metadata": {
                        "category": "regular-plan",
                        "first_month_whatsapp_credits": "95",
                        "trial_whatsapp_credits": "5",
                        "type": "2",
                        "whatsapp_credits": "100"
                    },
                    "nickname": "Month Pro Multi-currency",
                    "product": "prod_QOeDquMtwp1oR4",
                    "recurring": {
                        "aggregate_usage": null,
                        "interval": "month",
                        "interval_count": 1,
                        "meter": null,
                        "trial_period_days": null,
                        "usage_type": "licensed"
                    },
                    "tax_behavior": "exclusive",
                    "tiers_mode": null,
                    "transform_quantity": null,
                    "type": "recurring",
                    "unit_amount": 2500,
                    "unit_amount_decimal": "2500"
                },
                "pricing": {
                    "price_details": {
                        "price": "price_1PXqujB070pPqlXTqkU8rw3t",
                        "product": "prod_QOeDquMtwp1oR4"
                    },
                    "type": "price_details",
                    "unit_amount_decimal": "2500000"
                },
                "proration": false,
                "proration_details": {
                    "credited_items": null
                },
                "quantity": 1,
                "subscription": "sub_1SAveeB070pPqlXTq833gnzw",
                "subscription_item": "si_T79yC0SrJ83c3B",
                "tax_amounts": [
                ],
                "tax_rates": [
                ],
                "taxes": [
                ],
                "type": "subscription",
                "unit_amount_excluding_tax": "2500000"
            }
        ],
        "has_more": false,
        "total_count": 1,
        "url": "/v1/invoices/in_1SG0LAB070pPqlXTHWLrrjVS/lines"
    },
    "livemode": true,
    "metadata": {
    },
    "next_payment_attempt": null,
    "number": "TYZHZZR6-0002",
    "on_behalf_of": null,
    "paid": false,
    "paid_out_of_band": false,
    "parent": {
        "quote_details": null,
        "subscription_details": {
            "metadata": {
                "priceId": "price_1PXqujB070pPqlXTqkU8rw3t",
                "usage_type": "licensed"
            },
            "subscription": "sub_1SAveeB070pPqlXTq833gnzw"
        },
        "type": "subscription_details"
    },
    "payment_intent": "pi_3SG1HRB070pPqlXT01gJhGbd",
    "payment_settings": {
        "default_mandate": null,
        "payment_method_options": null,
        "payment_method_types": null
    },
    "period_end": 1759941296,
    "period_start": 1758731696,
    "post_payment_credit_notes_amount": 0,
    "pre_payment_credit_notes_amount": 0,
    "quote": null,
    "receipt_number": null,
    "rendering": null,
    "rendering_options": null,
    "shipping_cost": null,
    "shipping_details": null,
    "starting_balance": 0,
    "statement_descriptor": null,
    "status": "open",
    "status_transitions": {
        "finalized_at": 1759944960,
        "marked_uncollectible_at": null,
        "paid_at": null,
        "voided_at": null
    },
    "subscription": "sub_1SAveeB070pPqlXTq833gnzw",
    "subscription_details": {
        "metadata": {
            "priceId": "price_1PXqujB070pPqlXTqkU8rw3t",
            "usage_type": "licensed"
        }
    },
    "subtotal": 2500000,
    "subtotal_excluding_tax": 2500000,
    "tax": null,
    "test_clock": null,
    "total": 2500000,
    "total_discount_amounts": [
    ],
    "total_excluding_tax": 2500000,
    "total_pretax_credit_amounts": [
    ],
    "total_tax_amounts": [
    ],
    "total_taxes": [
    ],
    "transfer_data": null,
    "webhooks_delivered_at": 1759941350
}

const isRegularPlan = data.lines.data.find(item => item.plan.id && item.plan.metadata['category'] == 'regular-plan1')
console.log(isRegularPlan);
