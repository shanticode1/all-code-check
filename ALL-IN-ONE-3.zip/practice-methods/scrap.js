const puppeteer=require('puppeteer');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
async function scrape99Acres(maxPages = 3) {
    // puppeteer.use(StealthPlugin());
  const browser = await puppeteer.launch({ headless: false,args: [ '--disable-http2', '--disable-features=NetworkService' ] });
  const page = await browser.newPage();

  const baseUrl = "https://www.99acres.com/new-launch-projects-in-india-ffid";
  let currentPage = 1;
  let allProperties = [];

  await page.goto(baseUrl, { waitUntil: "networkidle2" });

  while (currentPage <= maxPages) {
    console.log(`Scraping page ${currentPage}...`);

    // Run DOM queries inside the browser context
    const properties = await page.evaluate(() => {
      const cards = document.querySelectorAll('.NPSRP__npsrpTuplesContainer')[0].childNodes;
      console.log(cards.length,'-----------');
      
      return Array.from(cards).map(card => {
        const title = card.querySelector(".NpsrpTuple__npsrpHead")?.textContent.trim() || "";
        const location = card.querySelector(".NpsrpTuple__npsrpHead")?.textContent.trim() || "";
        const price = card.querySelector(".NpsrpTuple__dispPrice")?.textContent.trim() || "";
        const builder = card.querySelector(".srpTuple__propertyDeveloper")?.textContent.trim() || "";
        const bhk = card.querySelector(".NpsrpTuple__subHead")?.textContent.trim() || "";
        const images = Array.from(card.querySelectorAll("img")).map(img => img.src);

        return { title, location, price, builder, bhk, images };
      });
    });
console.log(properties);

    allProperties.push(...properties);

    // Try clicking the "Next" button
    const nextButton = await page.$(".component__pgselActive");
    console.log(nextButton,'nextbutton');
    
    if (nextButton) {
      await Promise.all([
        page.waitForNavigation({ waitUntil: "networkidle2" }),
        nextButton.click(),
      ]);
      currentPage++;
    } else {
      console.log("No more pages found.");
      break;
    }
  }

  await browser.close();
  return allProperties;
}

// Run scraper
scrape99Acres(2).then(data => {
  console.log(`Scraped ${data.length} properties`);
  console.log(data.slice(0, 5)); // Preview first 5
});
