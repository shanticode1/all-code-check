const mArr = [1, 1, 2, 1, 3, 5, 1]
function majorityElement(arr) {
    console.log(arr.length);

    for (let i = 0; i < arr.length; i++) {
        let count = 0;
        for (let j = 0; j < arr.length; j++) {
            if (arr[i] === arr[j]) {
                count++;
            }
            console.log(arr[i], arr[j], count, 'floor', Math.floor(arr.length / 2));

            if (count > Math.floor(arr.length / 2)) {
                console.log(arr[i], 'majority element');

                return arr[i];
            }
        }
    }
    return null;
}

console.log(majorityElement(mArr));

function majorityElementV1(arr) {
    const freq = {};

    for (let num of arr) {
        console.log(freq, 'frequency', num);

        freq[num] = (freq[num] || 0) + 1;

        if (freq[num] > Math.floor(arr.length / 2)) {
            return num;
        }
    }
    return null;
}

const x=[1,2,3];
const y=x.fill(1);
console.log(x,'filled array',y);

console.log('majorityElementV1', majorityElementV1(mArr));


