const crypto = require("crypto");

// Use a fixed 32-byte key (for AES-256)
// In real apps, store in environment variable
const SECRET_KEY = crypto.createHash("sha256").update("my-secret-passphrase").digest(); // 32 bytes

// Encrypt
 function encrypt(text) {
  const iv = crypto.randomBytes(16); // generate a new IV
  const cipher = crypto.createCipheriv("aes-256-cbc", SECRET_KEY, iv);
  let encrypted = cipher.update(text, "utf8", "hex");
  encrypted += cipher.final("hex");

  // Prepend IV to encrypted text
  return iv.toString("hex") + ":" + encrypted;
}

// Decrypt
function decrypt(encryptedText) {
  console.log("Encrypted Text:", encryptedText);
  
  const [ivHex, encrypted] = encryptedText.split(":");
  const iv = Buffer.from(ivHex, "hex");

  const decipher = crypto.createDecipheriv("aes-256-cbc", SECRET_KEY, iv);
  let decrypted = decipher.update(encrypted, "hex", "utf8");
  decrypted += decipher.final("utf8");
  console.log("Decrypted Text:", decrypted);
  
  return decrypted;
}

// Example
const token = "b31276fc9b54d904adedaaa2efab2baf3bd6160f053ae1115bf1c6645e33269ab5673063";

const encrypted = encrypt(token);
console.log("Encrypted:", encrypted);

const decrypted = decrypt('44fc6b22dcc3d683ab85f49404d8a636:ab09f2605e7e60aa59b9cfea985afe6ecb0e8618bf91342d087a3c9a9f984563542f433b80cab2c5563227db2941ebc2872a8f1e56851965e5843698ea15ac4927f040e4d116de445481b6a34ecf8554');
console.log("Decrypted:", decrypted);
