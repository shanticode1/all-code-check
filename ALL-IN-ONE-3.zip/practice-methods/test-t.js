const { convert } = require('html-to-text');

function convertHtmlToString(text) {
  const options = {
    wordwrap: false,
    ignoreHref: false,
    ignoreImage: true,
  };

  const textWithLinks = convert(text, options);
  return removeDuplicateLines(textWithLinks);
}

function removeDuplicateLines(text) {
    // 1. Remove mailto references completely
    text = text.replace(/\s*\[mailto:[^\]]+\]/gi, '');
  
    // 2. Remove duplicate URLs like:
    //    https://abc.com [https://abc.com]
    text = text.replace(
      /(https?:\/\/[^\s\]]+)\s*\[\1\]/gi,
      '$1'
    );
  
    // 3. Remove [email@example.com] if any
    text = text.replace(
      /\s*\[[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\]/g,
      ''
    );
  
    // 4. Normalize spaces
    return text.replace(/\s+/g, ' ').trim();
  }
// Example
const te = `
<p>
Para confirmar la reserva se debe realizar el pago (dentro de las 48hs)
mediante transferencia a la siguiente cuenta bancaria.
</p>
<p>
BBVA<br>
DARIO RAFAEL CAMPAYO<br>
CBU: 0170133940000001991521<br>
ALIAS: DRCAMPAYO
</p>
<p>
Una vez efectuado el mismo enviar el comprobante al correo electrónico
<a href="mailto:drcampayo@gmail.com">drcampayo@gmail.com</a>
o vía whatsapp al 1166772325, donde se confirmará su
<a href="https://test.app.rezrva.com/">https://test.app.rezrva.com/</a>
</p>
`;

console.log(convertHtmlToString(te));
