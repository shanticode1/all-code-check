const { ObjectId } = require('mongodb');


//682886b8f94326db7c6c982a:2025-05-17T12:53:12.000Z    68288875f94326db7c6cb92e :2025-05-17T13:00:37.000Z
const id = new ObjectId("686c23b39a92fecf93df0e3d");
console.log(id.getTimestamp()); // Outputs the creation date


// 683dd3864e4a9577712f84d6 : 2025-06-02T16:38:30.000Z   2025-06-02 13:38:30 
// 683dc2744e4a9577712d9bc2 : 2025-06-02T15:25:40.000Z   2025-06-02 12:25:40

// booking time :             2025-06-02T19: 00: 00      2025-06-02 16:00:00



