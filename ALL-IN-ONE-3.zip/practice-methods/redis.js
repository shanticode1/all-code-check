import Redis from "ioredis";

const redis = new Redis({
  host: "redis-12073.c16.us-east-1-2.ec2.cloud.redislabs.com",
  port: 12073,
  username: "default",
  password: "FOiFkMcEy1ZQou4MpPgGePnNGwmHWnpb"
});

redis.on("connect", () => console.log("Connected to Redis Cloud"));
redis.on("error", (err) => console.error("Redis error:", err));
