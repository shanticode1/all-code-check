const Fraction = require('fraction.js');
const studentNumerator = 0, studentDenominator = 0;
function name() {
    if (
        studentNumerator !== undefined &&
        studentDenominator !== undefined
    ) {
        const studentNumStr =
            String(studentNumerator).replace(/^0+/, '') || '0';
        const studentDenStr =
            String(studentDenominator).replace(/^0+/, '') || '0';
    
        const adminNumeratorEntry = 0
    
    
        const adminDenominatorEntry = 0
       
    console.log(adminNumeratorEntry);
    
            console.log(adminNumeratorEntry);
            
            const adminNumStr =
                String(adminNumeratorEntry.option_text).replace(/^0+/, '') || '0';
            const adminDenStr =
                String(adminDenominatorEntry.option_text).replace(/^0+/, '') || '0';
    
            const studentNum = Number(studentNumStr);
            const studentDen = Number(studentDenStr);
            const adminNum = Number(adminNumStr);
            const adminDen = Number(adminDenStr);
    
            let isCorrect = false;
    
            const isStudentInvalid = studentDen === 0;
            const isAdminInvalid = adminDen === 0;
    
            if (isStudentInvalid && isAdminInvalid) {
                // Compare invalid fractions as strings
                isCorrect =
                    studentNumStr === adminNumStr && studentDenStr === adminDenStr;
            } else if (!isStudentInvalid && !isAdminInvalid) {
                try {
                    const studentFraction = new Fraction(studentNum, studentDen);
                    const adminFraction = new Fraction(adminNum, adminDen);
                    isCorrect = studentFraction.equals(adminFraction);
                } catch (err) {
                    console.error('Fraction parsing error:', err.message);
                }
            
    
            updateStudentQuestionPromises.push(
                prismaService.updateRecord(
                    'studentQuestion',
                    {
                        is_correct: isCorrect,
                        is_attended: true,
                    },
                    {
                        student_question_id: item.student_question_id,
                    }
                )
            );
    console.log(isCorrect);
    
            if (isCorrect) {
                correctQuestionCount++;
            }
        }
    }
}

name()