const express = require("express");
const geoip = require("geoip-lite");

const app = express();

app.get("/", (req, res) => {
  // Simulate request IP when testing locally
//   const testIP = "8.8.8.8"; // Google US IP
//   const testIP = "49.36.57.123"; // India IP
  // const testIP = "81.2.69.142"; // UK IP

  const testIP = "190.103.177.162"; // AR IP


  const geo = geoip.lookup(testIP);
console.log(geo);

  if (geo && geo.country === "AR") {
    return res.status(403).send("Access blocked in your country");
  }

  res.send(`Hello, your country is ${geo ? geo.country : "Unknown"}`);
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
