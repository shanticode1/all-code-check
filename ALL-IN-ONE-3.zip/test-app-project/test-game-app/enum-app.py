from enum import Enum
class Role(Enum):
    ADMIN='ADMIN'
    USER='USER'  
print(Role.ADMIN.value,Role.USER.value)
    
    