import random

print("🎯 Welcome to the Guess the Number Game!")
print("I'm thinking of a number between 1 and 100...")

# Computer chooses a random number
secret_number = random.randint(1, 100)
attempts = 0

while True:
    guess = input("Enter your guess: ")

    # Check if input is a number
    if not guess.isdigit():
        print("❌ Please enter a valid number!")
        continue
    print(secret_number)
    guess = int(guess)
    print("Thanks for playing! 👋"+str(guess))
    attempts += 1
    print("Thanks for playing! 👋"+str(attempts))
    if guess < secret_number:
        print("📉 Too low! Try again.")
    elif guess > secret_number:
        print("📈 Too high! Try again.")
    else:
        print(f"🎉 Congratulations! You guessed it in {attempts} tries!")
        break
