from slack_sdk import WebClient
from datetime import datetime
from docx import Document
import pandas as pd
import time

# --- Slack Bot Token ---
client = WebClient(token="xoxp-10058778380118-10060816083490-10064709661988-e5c71a7ca1cbf2fceb20bec98a5d4a37")

# --- Your REAL Slack user ID ---
YOUR_USER_ID = "U0A1SQ02FEE"

# --- Convert date/time to UNIX timestamp ---
def to_unix(date_string):
    return time.mktime(datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S").timetuple())

# --- Date range ---
start_time = to_unix("2025-12-01 00:00:00")
end_time   = to_unix("2025-12-13 23:59:59")

# --- Create docx ---
doc = Document()
doc.add_heading("Slack Chat Export", level=1)

# --- Store rows for CSV ---
all_rows = []

# --- Get bot user ID ---
auth_info = client.auth_test()
bot_user_id = auth_info["user_id"]

# --- Find existing DM (you ↔ bot) ---
self_dm_channel = None
ims = client.conversations_list(types="im")

for im in ims["channels"]:
    if im.get("user") == YOUR_USER_ID:
        self_dm_channel = im["id"]
        break

if not self_dm_channel:
    print("❌ No DM found between you & bot. Send bot a message first!")
    exit()

print("Self DM channel:", self_dm_channel)


# --- Function: fetch messages and write docx + CSV ---
def fetch_and_write(channel_id, title):
    doc.add_heading(title, level=2)

    history = client.conversations_history(
        channel=channel_id,
        oldest=start_time,
        latest=end_time
    )

    messages = history.get("messages", [])
    if not messages:
        doc.add_paragraph("No messages found.")
        return

    for msg in messages:
        ts = float(msg["ts"])
        readable = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
        user = msg.get("user", "BOT")
        text = msg.get("text", "")

        # Write to docx
        doc.add_paragraph(f"[{readable}] {user}: {text}")

        # Add to CSV rows
        all_rows.append({
            "datetime": readable,
            "user": user,
            "text": text,
            "channel_id": channel_id,
            "channel_title": title
        })


# --- 1. Export DM between YOU & BOT ---
fetch_and_write(self_dm_channel, "Self DM Chat (You ↔ Bot)")

# --- 2. Export other IMs ---
for im in ims["channels"]:
    ch_id = im["id"]
    user = im.get("user")
    
    if ch_id == self_dm_channel:
        continue

    fetch_and_write(ch_id, f"DM with User: {user}")

# --- Save DOCX ---
doc.save("slack_chat_export.docx")
print("✔ DOCX exported to: slack_chat_export.docx")

# --- Save CSV ---
df = pd.DataFrame(all_rows)
df.to_csv("slack_chat_export.csv", index=False)
print("✔ CSV exported to: slack_chat_export.csv")
