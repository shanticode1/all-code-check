from slack_sdk import WebClient
from datetime import datetime
from docx import Document
import time

# --- Slack Bot Token ---
client = WebClient(token="xoxp-10058778380118-10060816083490-10064709661988-e5c71a7ca1cbf2fceb20bec98a5d4a37")

# --- Your REAL Slack user ID (NOT bot id) ---
YOUR_USER_ID = "U0A1SQ02FEE"   # <-- Replace with your Slack user ID

# --- Convert date/time to UNIX timestamp ---
def to_unix(date_string):
    return time.mktime(datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S").timetuple())

# --- Set date range ---
start_time = to_unix("2025-12-01 00:00:00")
end_time   = to_unix("2025-12-13 23:59:59")

# --- Create docx ---
doc = Document()
doc.add_heading("Slack Chat Export", level=1)

# --- Get bot user ID ---
auth_info = client.auth_test()
bot_user_id = auth_info["user_id"]
print("Bot ID:", bot_user_id)

# --- Find existing bot ↔ you DM channel (Slack auto-created) ---
self_dm_channel = None

ims = client.conversations_list(types="im")

for im in ims["channels"]:
    if im.get("user") == YOUR_USER_ID:
        self_dm_channel = im["id"]
        break
if not self_dm_channel:
    print("❌ No DM found between you & bot. Send a message to the bot first!")
    exit()

print("Self DM channel:", self_dm_channel)


# --- Function: fetch messages and write to docx ---
def fetch_and_write(channel_id, title):
    doc.add_heading(title, level=2)

    history = client.conversations_history(
        channel=channel_id,
        oldest=start_time,
        latest=end_time,
        # inclusive=True
    )
    print(history,"pric hist")

    messages = history.get("messages", [])
    if not messages:
        doc.add_paragraph("No messages found.")
        return

    for msg in messages:
        ts = float(msg["ts"])
        readable = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
        user = msg.get("user", "BOT")
        text = msg.get("text", "")

        doc.add_paragraph(f"[{readable}] {user}: {text}")


# --- 1. Export DM between YOU & BOT ---
fetch_and_write(self_dm_channel, "Self DM Chat (You ↔ Bot)")


# --- 2. Export other IM channels ---
for im in ims["channels"]:
    ch_id = im["id"]
    user = im.get("user")

    # Skip your own DM
    if ch_id == self_dm_channel:
        continue

    fetch_and_write(ch_id, f"DM with User: {user}")


# --- Save file ---
output_file = "slack_chat_export.docx"
doc.save(output_file)

print("✔ Chat exported to:", output_file)
