import tkinter as tk
import random

# --- GAME SETUP ---
secret_number = random.randint(1, 100)
attempts = 0

# --- GUI SETUP ---
root = tk.Tk()
root.title("🎯 Guess the Number Game")
root.geometry("350x250")
root.config(bg="#282C34")

# --- FUNCTIONS ---
def check_guess():
    global attempts
    guess = entry.get()

    if not guess.isdigit():
        result_label.config(text="❌ Please enter a number!", fg="orange")
        return

    guess = int(guess)
    attempts += 1

    if guess < secret_number:
        result_label.config(text="📉 Too low!", fg="yellow")
    elif guess > secret_number:
        result_label.config(text="📈 Too high!", fg="lightblue")
    else:
        result_label.config(text=f"🎉 Correct! You guessed in {attempts} tries!", fg="lightgreen")
        check_button.config(state="disabled")

# --- UI ELEMENTS ---
title_label = tk.Label(root, text="I'm thinking of a number between 1 and 100", 
                       bg="#282C34", fg="white", font=("Helvetica", 12))
title_label.pack(pady=10)

entry = tk.Entry(root, font=("Helvetica", 12))
entry.pack(pady=5)

check_button = tk.Button(root, text="Check Guess", command=check_guess, 
                         bg="#61AFEF", fg="white", font=("Helvetica", 11, "bold"))
check_button.pack(pady=10)

result_label = tk.Label(root, text="", bg="#282C34", fg="white", font=("Helvetica", 12))
result_label.pack(pady=10)

reset_button = tk.Button(root, text="🔄 New Game", command=lambda: reset_game(),
                         bg="#98C379", fg="white", font=("Helvetica", 11, "bold"))
reset_button.pack(pady=5)

# --- RESET FUNCTION ---
def reset_game():
    global secret_number, attempts
    secret_number = random.randint(1, 100)
    attempts = 0
    entry.delete(0, tk.END)
    result_label.config(text="", fg="white")
    check_button.config(state="normal")

# --- RUN LOOP ---
root.mainloop()
