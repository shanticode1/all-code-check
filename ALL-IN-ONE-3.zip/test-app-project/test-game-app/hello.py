# name=input("Enter your Name: ")
print('Hello 👋',"shanti chouhan".title())

# if 2>0:
#     print("This wo print")

# print('This line was added later.'); print('Another line added.')
# print('This line was added later.'); print('Another line-2 added.')

for i in range(10):
    print(i*1)

for r in [0,1,2,3,4]:
    print("R: ", r+2)

print("\nPrint 2 to 10 table")

#  print 2 to 10 table
# for a in range(2, 11):
#     print(f"\nTable for {a}:")  
#     for b in range(1,11):
#         print(f"{a} x {b} = {a*b}")    

print("\nPrint a pattern of stars")
# rows = 5
# for i in range(1, rows+1):
#     print('*' * i)
    
# print("\n")

# for p in range (rows,0,-1):
#       print('*' * p)


# palindrome Number

# Take input from user
text = input("Enter a word or phrase: ").lower().replace(" ", "")

# Check if palindrome
if text == text[::-1]:
    print(f"'{text}' is a palindrome!")
else:
    print(f"'{text}' is not a palindrome.")
    
num = int(input("Enter a number: "))
original = num
reverse = 0

while num > 0:
    digit = num % 10
    reverse = reverse * 10 + digit
    num = num // 10

if original == reverse:
    print(f"{original} is a palindrome number!")
else:
    print(f"{original} is not a palindrome number.")

