# Colors
RED = "\033[91m"
GREEN = "\033[92m"
BLUE = "\033[94m"
YELLOW = "\033[93m"
RESET = "\033[0m"
YELLOW = "\033[93m"
RESET = "\033[0m"
print(GREEN + "🧮 Welcome to Python Calculator!" + RESET)
print(GREEN + "Select operation: +  -  *  /" + RESET)
print(YELLOW + "⚠ Type 'exit' to quit.\n" + RESET)
while True:

    op = input("Enter operator: ")

    if op.lower() == "exit":
        print(BLUE + "Exiting calculator... 👋" + RESET)
        break

    if op not in ['+', '-', '*', '/']:
        print(RED + "Invalid operator! Try again." + RESET)
        continue

    try:
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))
    except ValueError:
        print(RED + "Invalid number! Try again." + RESET)
        continue

    if op == '+':
        print(GREEN + f"{num1} + {num2} = {num1 + num2}" + RESET)
    elif op == '-':
        print(GREEN + f"{num1} - {num2} = {num1 - num2}" + RESET)
    elif op == '*':
        print(GREEN + f"{num1} * {num2} = {num1 * num2}" + RESET)
    elif op == '/':
        if num2 != 0:
            print(GREEN + f"{num1} / {num2} = {num1 / num2}" + RESET)
        else:
            print(RED + "Error: Division by zero is not allowed." + RESET)
