X=5;
Y=6;
print(X); print(Y);
print(X+Y)
print(True+X)
X += 1
print(X)
name=input("Enter your name: ")
name=name.capitalize()
print("Hello 👋, "+name+"!")
name=name.title()
print("Hello 👋, "+name+"!")

x=str(8)
y=int("7")
z=float(x)
print(x)
print(y)
print(z)
a, b, c= 1,2,3
print(a); print(b); print(c)
F='Apple','cat','Tom'
d,e,f=F
print(d); print(e); print(f)


# multiple value
# p, q, r='Hello World'
p= q= r='Hello World'
# x|y|z='Hello World'
print('Tom','Jerry')
print(p,q,r)
