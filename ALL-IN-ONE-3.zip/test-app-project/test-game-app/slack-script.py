from slack_sdk import WebClient

client = WebClient(token="xoxb-10058778380118-10057666859877-OJ1ypMoQE5k7VHorOOjoc1lK")

response = client.conversations_list()

for channel in response["channels"]:
    print(channel["name"], "->", channel["id"])

response = client.conversations_list(types="im")

for im in response["channels"]:
    print(im["id"], im["user"])