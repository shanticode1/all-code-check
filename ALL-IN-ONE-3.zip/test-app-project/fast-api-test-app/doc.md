Read this doc for follow how to setup fastapi
1. create project 
2. install this : pip install fastapi uvicorn
---> geting issue with above command try with this : sudo pip install fastapi uvicorn

3. create file --> main.py
4. use this command for app--> uvicorn main:app --reload
5. open this swagger url : http://127.0.0.1:8000/docs
