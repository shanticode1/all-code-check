import { withSentryConfig } from "@sentry/nextjs";
import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

const withNextIntl = createNextIntlPlugin();
const nextConfig: NextConfig & {
  eslint?: {
    ignoreDuringBuilds: boolean;
  };
}  = {
  reactStrictMode: true,
  // sentry: {
  //   hideSourceMaps: true, // Hide source maps in production builds
  // },
  // /**
  //  * Currently ingores eslint errors during build
  //  */
  eslint: {
    ignoreDuringBuilds: true,
  },
  webpack: (config, { dev }) => {
    if (dev) {
      config.cache = {
        type: "memory",
      };
    }
    return config;
  },
  async headers() {
    return [
      {
        source: "/tinymce/:all*",
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=31536000, immutable",
          },
        ],
      },
    ];
  },
};
const configWithIntl = withNextIntl(nextConfig);
export default withSentryConfig(configWithIntl, {
  silent: true,
  org: process.env.SENTRY_ORG,
  project: process.env.SENTRY_PROJECT,
});
