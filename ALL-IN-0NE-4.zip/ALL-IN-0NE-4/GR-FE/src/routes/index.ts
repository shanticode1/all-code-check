import { CommonTableProps } from "@/types/CommonTable";

export const paths = {
  ROOT_DASHBOARD: "/dashboard",
  ROOT_LOGIN: "/login",
  ROOT_PROFILE: "/profile",
  ROOT_EXAMS: "/exams",
  ROOT_ADMIN_EXAM: "/admin/exams",
  ROOT_ADD_QUESTIONS: "/add-questions",
  ROOT_STUDENT: "/admin/student",
  ROOT_STUDENT_EXAM: "/student/exams",
  ROOT_ADMIN_PREVIEW_SECTION: "/admin/preview/section/",
  ROOT_EXAMS_HISTORY: "/score-reports",
  ROOT_EXPORT_EXAM_HISTORY: "/admin/export-exam-history",
  ROOT_STUDENT_PREVIEW_SECTION: "/exams/section",
  ROOT_ANALYTICAL_WRITING: "/admin/analytical-evaluation",
  ROOT_STUDENT_QUESTION_REVIEW: "/section",
  SWAH_TERM_OF_SERVICE: "https://www.smartwithaheart.org/terms-of-service",
  SHERPA_PREP_TERM_OF_SERVICE: "https://sherpaprep.com/terms_of_use",
  ROOT_SETTING: "/admin/setting/retention-days",
  ROOT_SECTION_REVIEW_QUESTIONS: (sectionId: string) =>
    `/exams/section/${sectionId}/review-questions`,
  ROOT_STUDENT_LOGIN: "/student-login",
  ROOT_SECTION_EXIT: (sectionId: string) => `/exams/section/${sectionId}/exit-section`,
  ROOT_SECTION_HELP: (sectionId: string) => `/exams/section/${sectionId}/help-section`,
  ROOT_END_EXAM: (sectionId: string) => `/exams/section/${sectionId}/end-exam`,
  ROOT_NOT_FOUND:"/not-found",
  ROOT_FORGOT_PASSWORD: "/forgot-password",
};

function path(root: string, sublink: string) {
  return `${root}${sublink}`;
}

const ROOTS_DASHBOARD = "/dashboard";
const ROOT_APPS = "/apps";
const ROOTS_PAGES = "/pages";
const ROOTS_PROJECTS = "/projects";
const ROOTS_ORDERS = "/orders";
const ROOTS_INVOICES = "/invoices";
const ROOTS_TASKS = "/tasks";
const ROOTS_CALENDAR = "/calendar";
const ROOTS_AUTH = "/authentication";
const ROOTS_CHANGELOG = "/changelog";
const ROOTS_ABOUT = "/pages/about";

export const PATH_DASHBOARD = {
  root: ROOTS_DASHBOARD,
  default: path(ROOTS_DASHBOARD, "/default"),
  analytics: path(ROOTS_DASHBOARD, "/analytics"),
  saas: path(ROOTS_DASHBOARD, "/saas"),
};

export const PATH_APPS = {
  root: ROOT_APPS,
  calendar: path(ROOT_APPS, "/calendar"),
  chat: path(ROOT_APPS, "/chat"),
  invoices: {
    all: path(ROOT_APPS, ROOTS_INVOICES + "/list"),
    sample: path(ROOT_APPS, ROOTS_INVOICES + `/details/`),
    invoice_details: (id: string): string => path(ROOT_APPS, ROOTS_INVOICES + `/details/${id}`),
  },
  orders: path(ROOT_APPS, "/orders"),
  profile: path(ROOT_APPS, "/profile"),
  projects: path(ROOT_APPS, "/projects"),
  settings: path(ROOT_APPS, "/settings"),
  tasks: path(ROOT_APPS, "/tasks"),
  fileManager: {
    root: path(ROOT_APPS, "/file-manager"),
  },
};

export const PATH_PAGES = {
  root: ROOTS_PAGES,
  pricing: path(ROOTS_PAGES, "/pricing"),
  blank: path(ROOTS_PAGES, "/blank"),
};

export const PATH_PROJECTS = {
  root: ROOTS_PROJECTS,
};

export const PATH_ORDERS = {
  root: ROOTS_ORDERS,
};

export const PATH_INVOICES = {
  root: ROOTS_INVOICES,
  invoices: {
    all: path(ROOTS_INVOICES, "/list"),
    sample: path(ROOTS_INVOICES, `/details/`),
    invoice_details: (id: string): string => path(ROOTS_INVOICES, `/details/${id}`),
  },
};

export const PATH_TASKS = {
  root: ROOTS_TASKS,
};

export const PATH_CALENDAR = {
  root: ROOTS_CALENDAR,
};

export const PATH_AUTH = {
  root: ROOTS_AUTH,
  signin: path(ROOTS_AUTH, "/signin"),
  signup: path(ROOTS_AUTH, "/signup"),
  passwordReset: path(ROOTS_AUTH, "/password-reset"),
};

export const PATH_CHANGELOG = {
  root: ROOTS_CHANGELOG,
};

export const PATH_ABOUT = {
  root: ROOTS_ABOUT,
};

export const STUDENT_QUESTION_LINK = ({
  examId,
  student_question_id,
  student_exam_section_id,
}: Pick<CommonTableProps, "examId"> & {
  student_question_id: string | number;
  student_exam_section_id: string | number;
}): string =>
  `/exam/${examId}/question/${student_question_id}?student_exam_section_id=${student_exam_section_id}`;

export const ADMIN_QUESTION_LINK = ({
  examId,
  studentId,
  student_question_id,
  student_exam_section_id,
}: Pick<CommonTableProps, "examId"> & {
  student_question_id: string | number;
  student_exam_section_id: string | number;
  studentId: string;
}): string =>
  `/admin/student/exams/${examId}/detail/${studentId}/question/${student_question_id}?student_exam_section_id=${student_exam_section_id}`;
