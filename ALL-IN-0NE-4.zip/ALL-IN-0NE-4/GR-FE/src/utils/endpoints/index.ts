export const API_ENDPOINTS = {
  // auth
  LOGIN: "/auth/login",
  LOGOUT: "/logout",
  ME: "/auth/me",
  REFRESH: "/auth/refresh",
  CHANGE_PASSWORD: "/auth/change-password",
  UPDATE_PROFILE: "/auth/update-profile",
  SEND_OTP: "/auth/send-otp",
  VERIFY_OTP: "/auth/verify-otp",
  FORGOT_PASSWORD: "/auth/forgot-password",
  RESET_PASSWORD: "/auth/reset-password",

  // Exam
  EXAM: "/exams",
  EXAM_DETAIL: "/exams/:examId",
  EXAM_START: "/exams/start",
  EXAM_SECTION_UPDATE: "/exam-sections/update-timer",
  EXAM_SECTION_COMPLETE: "/exam-sections/complete",
  EXAM_ANSWER_CHOICE_SUBMIT: "/exam-questions/answer-choice-submit",
  EXAM_STATUS: "/exams/status",
  EXAM_FILE_DOWNLOAD: "/exams/download/csv",
  EXAM_EXIT: "/exams/:student_exam_id",
  EXAM_SCHEDULE_EXIT: "/exams/schedule-exit",
  EXAM_CANCEL_EXIT: "/exams/cancel-exit",
  EXAM_EXIT_UPDATE_TIMER: "exams/update-screen-time/:student_exam_id",
  COPY_EXAM: "/exams/copy",

  // Exam Section
  EXAM_SECTION: "/exam-sections",
  EXAM_SECTION_ORDER: "/exam-sections/change_order",
  EXAM_SECTION_VIDEO: "/exam-sections/videos",

  // Question
  EXAM_QUESTION: "/exam-questions",
  EXAM_QUESTIONS_STUDENT_QUESTION: "/exam-questions/student-question",
  EXAM_QUESTION_TIME_TAKEN: "exam-questions/:student_question_id/time-taken",
  // question
  QUESTIONS: "/exam-questions",
  EXAM_QUESTION_MARKED_UPDATE: "exam-questions/:student_question_id/marked",

  // Category
  CATEGORY: "/categories",

  //Student
  STUDENT: "/student",
  STUDENT_ALL_EXAM: "/exams/history",
  STUDENTS: "/students",
  STUDETN_DETAIL: "/students/:studentId",
  UPLOAD: "/students/upload",

  //User
  USER: "/user",
  USERS: "/users",
  USER_DETAIL: "/user/:userId",

  // Analytical-section
  EXAM_SECTION_ANALYTICAL_WRITING: "/exam-sections/analytical-writing/pending",
  STUDENT_UPDATE_TOTAL_SCORE: "students/update-total-score",

  // Dashboard
  DASHBOARD_SUMMARY: "/dashboard/summary",

  // setting
  RETENTION: "/setting/retention",

  // Dashboard Reports
  DASHBOARD_REPORTS: "/dashboard/report",

  // File Upload

  FILE_UPLOAD:"exam-questions/assets/upload-url",
};
