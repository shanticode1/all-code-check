import { ISelectedSentenceObj } from "@/types";

export const highlightBySentence = (
  html: string,
  selectedSentences: ISelectedSentenceObj[],
  hoverColor = "rgba(0, 0, 0, 0.4)",
  selectedColor = "rgba(0, 0, 0, 0.8)",
): string => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  let sentenceCounter = 0;

  const ACRONYM_MASK = "§";
  const acronymPattern = /\b(?:[A-Z]\.){2,}/g;

  const sentenceRegex =
    /([\s\S]+?[.!?])(?:["'”’)]*)(?=(?:\s|<\/?[^>]+>)*(?:["'“‘]*[A-Z]|<br\s*\/?>|<\/p>|$))/gi;

  doc.body.querySelectorAll("p").forEach((p) => {
    const rawHTML = p.innerHTML;
    const maskedHTML = rawHTML.replace(acronymPattern, (m) => m.replace(/\./g, ACRONYM_MASK));

    const parts = maskedHTML.match(sentenceRegex) || [];

    const consumed = parts.join("");
    const remainder = maskedHTML.slice(consumed.length);

    const frag = document.createDocumentFragment();

    parts.forEach((part) => {
      const textWithHTML = part.replace(new RegExp(ACRONYM_MASK, "g"), ".");

      const span = document.createElement("span");
      span.innerHTML = textWithHTML;
      span.dataset.sentIndex = String(sentenceCounter);
      span.dataset.sentText = span.textContent ?? "";

      const isSel = selectedSentences.some((s) => s.paragraph_answer_key === sentenceCounter);
      if (isSel) {
        span.setAttribute("data-selected", "true");
        span.style.backgroundColor = selectedColor;
        span.style.cursor = "pointer";
      } else {
        span.style.cursor = "pointer";
        span.setAttribute(
          "onmouseover",
          `if(!this.dataset.selected)this.style.backgroundColor='${hoverColor}'`,
        );
        span.setAttribute("onmouseout", `if(!this.dataset.selected)this.style.backgroundColor=''`);
      }

      frag.appendChild(span);
      sentenceCounter++;
    });

    if (remainder) {
      const unmaskedRem = remainder.replace(new RegExp(ACRONYM_MASK, "g"), ".");
      const tmp = document.createElement("template");
      tmp.innerHTML = unmaskedRem;
      frag.appendChild(tmp.content);
    }

    p.innerHTML = "";
    p.appendChild(frag);
  });

  return doc.body.innerHTML;
};
