import dayjs from 'dayjs';
import Papa from "papaparse";
import * as XLSX from 'xlsx';

import { SubscriptionRow } from '@/types';
const customParseFormat = require('dayjs/plugin/customParseFormat');

dayjs.extend(customParseFormat);

interface ExportCSVOptions<T> {
    data: T[];
    fileName: string;
    formatFn: (item: T) => Record<string, string | number>;
}

export const exportCSV = <T>({ data, fileName, formatFn }: ExportCSVOptions<T>) => {
    const formattedData = data.map(formatFn);
    const csv = Papa.unparse(formattedData);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${fileName}.csv`;
    link.click();
};

export const getCurrentProgress = (chunkNo: number, chunkSize: number, data: unknown[]) => {
    const totalItems = data.length;
    const processedItems = Math.min(chunkNo * chunkSize, totalItems);
    const progress = (processedItems / totalItems) * 100;
    return Math.min(progress, 100); // Ensure it doesn't exceed 100%
};

// Convert Excel serial number to JS Date
export const excelDateToJSDate = (input: string | number): string => {
    // Case 1: if input is already a valid date string in YYYY-MM-DD format
    if (typeof input === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(input)) {
        return input;
    }
    // Case 2: if input is a numeric Excel serial number
    const serial = Number(input);
    // Check if input is a valid number
    if (isNaN(serial) || serial < 0 || serial > 60000) {
        throw new Error('Invalid Excel serial number or unsupported format');
    }
    const utc_days = Math.floor(serial - 25569);
    const utc_value = utc_days * 86400; // seconds in a day
    const date = new Date(utc_value * 1000); // convert to milliseconds
    // Format as YYYY-MM-DD
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const dateWithFormat = `${year}-${month}-${day}`;
    return dateWithFormat;
};

const formatDates = (input: string) => {
    const formats = [
        'DD-MM-YYYY',
        'YYYY-MM-DD',
        'MMMM D YYYY',
        'MMM D YYYY',
        'D MMMM YYYY',
        'D MMM YYYY'
    ];

    let parsedDate = null;

    for (const format of formats) {
        const tryParse = dayjs(input, format, true); // strict parsing
        if (tryParse.isValid()) {
            parsedDate = tryParse;
            break;
        }
    }

    // Fallback to native parser if no format matched
    if (!parsedDate) {
        parsedDate = dayjs(input);
    }

    if (!parsedDate.isValid()) {
        return 'Invalid date';
    }

    return parsedDate.format('YYYY-MM-DD');
};

// Parse csv file
export const parseCSVFile = (file: File): Promise<unknown[]> => {
    return new Promise((resolve, reject) => {
        Papa.parse(file, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
                if (results.errors.length) {
                    reject(results.errors);
                } else {
                    const parsedData = (results.data as SubscriptionRow[]).map((row: SubscriptionRow) => {
                        const trimmedRow: Record<string, any> = {};

                        for (const key in row) {
                            if (Object.prototype.hasOwnProperty.call(row, key)) {
                                const value = row[key as keyof SubscriptionRow];

                                // Trim strings, leave other types as-is
                                if (typeof value === 'string') {
                                    trimmedRow[key] = value.trim();
                                } else {
                                    trimmedRow[key] = value;
                                }
                            }
                        }
                        // Format subscription dates if present
                        if (trimmedRow['Subscription Start Date']) {
                            trimmedRow['Subscription Start Date'] = formatDates(
                                trimmedRow['Subscription Start Date']
                            );
                        }
                        if (trimmedRow['Subscription End Date']) {
                            trimmedRow['Subscription End Date'] = formatDates(
                                trimmedRow['Subscription End Date']
                            );
                        }
                        if (trimmedRow['Subscription Status']) {
                            const formatted = trimmedRow['Subscription Status'].charAt(0).toUpperCase() + trimmedRow['Subscription Status'].slice(1);
                            trimmedRow['Subscription Status'] = formatted;
                        }
                        return trimmedRow;
                    });
                    resolve(parsedData);
                }
            },
            error: (error) => {
                reject(error);
            },
        });
    });
};
// Parse Excel file
export const parseExcelFile = (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = (e) => {
            try {
                const data = e.target?.result;
                if (!data) return reject('No file data');

                const workbook = XLSX.read(data, { type: 'binary' });
                const worksheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: '' });

                const formattedData = (jsonData as SubscriptionRow[]).map((row: SubscriptionRow) => {
                    const formattedRow: Record<string, any> = {};

                    for (const key in row) {
                        if (Object.prototype.hasOwnProperty.call(row, key)) {
                            const value = row[key as keyof SubscriptionRow];

                            // Trim string values
                            if (typeof value === 'string') {
                                formattedRow[key] = value.trim();
                            } else {
                                formattedRow[key] = value;
                            }
                        }
                    }

                    // Format subscription dates if present
                    if (formattedRow['Subscription Start Date']) {
                        formattedRow['Subscription Start Date'] = excelDateToJSDate(
                            formattedRow['Subscription Start Date']
                        );
                    }

                    if (formattedRow['Subscription End Date']) {
                        formattedRow['Subscription End Date'] = excelDateToJSDate(
                            formattedRow['Subscription End Date']
                        );
                    }
                    if (formattedRow['Subscription Status']) {
                        const formatted = formattedRow['Subscription Status'].charAt(0).toUpperCase() + formattedRow['Subscription Status'].slice(1);
                        formattedRow['Subscription Status'] = formatted;
                    }

                    return formattedRow;
                });

                resolve(formattedData);
            } catch (error) {
                reject(error);
            }
        };

        reader.onerror = () => reject('File reading error');
        reader.readAsBinaryString(file);
    });
};

