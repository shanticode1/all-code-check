import sanitizeHtml from "sanitize-html";
import truncate from "truncate-html";

import { BYTES_PER_KILOBYTE } from "@/constants";
import { QUESTION_TYPE_OPTIONS_BY_SECTION } from "@/constants/exam";
import { IStudentExamDetail, TranslateFunction } from "@/types/Exam/ExamHistory";
import { IExamRecord } from "@/types/Exam/ExamList";

const allOptions = Object.values(QUESTION_TYPE_OPTIONS_BY_SECTION).flat();
export const htmlToText = (html: string) => {
  if (!html) return "";
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  return doc.body.textContent ?? "";
};

export const formatHtmlToText = (html: string) => {
  const text = htmlToText(html).trim();
  if (!text) return "Click Here To Add";
  const words = text.split(/\s+/);
  return words.slice(0, 10).join(" ") + (words.length > 5 ? "..." : "");
};

export const convertSecondsToHoursAndMinutes = (seconds: number) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours} hour${hours !== 1 ? "s" : ""} ${minutes} minute${minutes !== 1 ? "s" : ""}`;
};
export const formatTime = (seconds: number) => {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
};

export function truncateHtml(html: string, maxChars: number, ellipsis: string = "…"): string {
  const clean = sanitizeHtml(html, {
    allowedTags: sanitizeHtml.defaults.allowedTags.concat("img"),
    allowedAttributes: {
      ...sanitizeHtml.defaults.allowedAttributes,
      img: ["src", "alt", "title"],
    },
  });

  return truncate(clean, maxChars, {
    ellipsis,
    reserveLastWord: true,
  });
}

export const formatDateToUTCISOString = (date: Date | null) => {
  if (!date) return null;

  const year = date.getFullYear();
  const month = date.getMonth(); // 0-based
  const day = date.getDate();

  // Create a new date in UTC
  const utcDate = new Date(Date.UTC(year, month, day, 0, 0, 0));
  return utcDate.toISOString(); // e.g., '2025-05-05T00:00:00.000Z'
};

export const getQuestionTypeLabel = (questionType: string | null): string => {
  if (!questionType) return "-";

  const match = allOptions.find((opt) => opt.value === questionType);

  return match?.label ?? questionType;
};
export const extractDateFromISO = (isoDate: string) => {
  return new Date(isoDate).toISOString().split("T")[0];
};

export const getScoreSections = (studentExamDetail: IStudentExamDetail, t: TranslateFunction) => {
  const analytical = studentExamDetail?.data?.analyticalWritingScore ?? 0;
  const verbal = studentExamDetail?.data?.verbalReasoningScore ?? 0;
  const quantitative = studentExamDetail?.data?.quantitativeReasoningScore ?? 0;

  return [
    {
      label: t("score.cards.sections.analyticalWriting.label"),
      value: analytical,
      min: 0,
      max: 6,
    },
    {
      label: t("score.cards.sections.verbalReasoning.label"),
      value: verbal,
      min: 130,
      max: 170,
    },
    {
      label: t("score.cards.sections.quantitativeReasoning.label"),
      value: quantitative,
      min: 130,
      max: 170,
    },
    {
      label: t("score.cards.sections.totalScore.label"),
      value: verbal + quantitative,
      min: 260,
      max: 340,
    },
  ];
};

// upload methods
export const getFileSizeInMB = (file: File | Blob | null | undefined) =>
  ((file?.size ?? 0) / BYTES_PER_KILOBYTE / BYTES_PER_KILOBYTE).toFixed(2);

export const formatDate = (dateStr: string) =>
  new Intl.DateTimeFormat("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(new Date(dateStr));

export const extractEmbedUrl = (url: string) => {
  try {
    const videoUrlRegex =
      /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/;
    const match = url.match(videoUrlRegex);
    return match ? `https://www.youtube.com/embed/${match[1]}` : null;
  } catch {
    return null;
  }
};

export function truncateName(name: string, length: number) {
  return name.length <= length ? name : name.slice(0, length) + "...";
}

export const sanitizeHtmlToText = (html: string): boolean => {
  const tmp = document.createElement("div");
  tmp.innerHTML = html;

  const hasText = tmp.textContent?.trim();
  const hasMeaningfulElements = tmp.querySelector("img, svg, math");

  return !hasText && !hasMeaningfulElements;
};

export const extractPlainTextFromHtml = (html: string): string => {
  const div = document.createElement("div");
  div.innerHTML = html;

  const textParts: string[] = [];

  // Get all plain text
  const text = div.textContent?.trim().toLowerCase() ?? "";
  if (text) textParts.push(`text:${text}`);

  // Get all <img src="..."> values
  const images = div.querySelectorAll("img[src]");
  images.forEach((img) => {
    const src = img.getAttribute("src")?.trim();
    if (src) textParts.push(`img:${src}`);
  });

  return textParts.join("|"); // normalized combined string
};

export const roundToDecimal = (number: number, decimals: number) => {
  const multiplier = Math.pow(10, decimals);
  return Math.round(number * multiplier) / multiplier;
};

export const cleanBrokenImagesFromHTML = (html: string) => {
  if (!html) return "No question available";

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const imgs = doc.querySelectorAll("img");

  imgs.forEach((img) => {
    const src = img.getAttribute("src") ?? "";
    // Customize this condition for your broken images
    if (src.includes("oaiusercontent.com") || !src) {
      const fallbackText = doc.createElement("p");
      fallbackText.innerHTML = "<em>Image not found.</em>";
      img.replaceWith(fallbackText);
    }
  });

  return doc.body.innerHTML;
};

export const capitalize = (str: string = "") =>
  str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();

export const formatName = (name: string = "") =>
  name
    .trim()
    .split(/\s+/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join("_");

export const getNextCopyName = (examName: string, examNames: IExamRecord[]): string => {
  const match = examName.match(/^(.*?)(?:\s*\(Copy\s*(\d+)\))?$/);
  if (!match) {
    return `${examName} (Copy 1)`;
  }

  const base = match[1].trim();
  const regex = new RegExp(`^${base}\\s*\\(Copy\\s*(\\d+)\\)$`, "i");

  let maxCopy = 0;

  for (const exam of examNames) {
    const copyMatch = exam.examName.match(regex);
    if (copyMatch) {
      const copyNum = parseInt(copyMatch[1], 10);
      if (!isNaN(copyNum)) {
        maxCopy = Math.max(maxCopy, copyNum);
      }
    }
  }

  const nextNum = maxCopy + 1;
  return `${base} (Copy ${nextNum})`;
};

export function validatePrefixOrSuffix(value: string, field: "Prefix" | "Suffix") {
  if (!value) return null;

  // Check for leading spaces
  if (value.startsWith(" ")) {
    return `${field} cannot start with a space.`;
  }
  return null;
}

export const getSectionKey = (slug?: string | null) => {
  if (!slug) return "";
  if (slug.includes("analytical-writing")) return "analytical-writing";
  if (slug.includes("verbal-reasoning")) return "verbal-reasoning";
  if (slug.includes("quantitative-reasoning")) return "quantitative-reasoning";
  return "";
};
/**
 * check is value contains HTML tags or not
 * @param value
 * @returns
 */
export const containsHTML = (value: string) => {
  if (!value) return false;
  return /<\/?[a-z][\s\S]*>/i.test(value);
};
