export interface AnswerChoicesProps {
    type: string; // The selected type from the dropdown
}