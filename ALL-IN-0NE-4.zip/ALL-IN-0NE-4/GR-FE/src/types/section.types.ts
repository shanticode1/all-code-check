import React, { ReactNode } from "react";

export interface IQuestion {
  question_id: number;
  exam_id: number;
  section_id: number;
  category_id: number | null;
  question_type: string | null;
  question_text: string | null;
  video_url: string | null;
  difficulty_level: "Easy" | "Medium" | "Hard";
  score_weightage: number;
  explanation: string | null;
  display_order: number;
  is_active: boolean;
  student_question_id?: number;
}

export interface ISection {
  section_id: number;
  exam_id: number;
  section_name: string;
  question_counts: number;
  calculator_permitted: boolean;
  base_score: number;
  time_limit: number;
  adaptive_learning: boolean;
  display_order: number;
  questions: IQuestion[];
  instructions?: string;
  section_slug: string |undefined;
}

export interface SectionHeaderProps extends React.PropsWithChildren {
  title: string;
}

export type Column<T> = {
  title: string;
  render: (item: T, index: number) => ReactNode;
};

export interface CommonTableProps<T> {
  title?: string;
  data?: T[];
  columns: Column<T>[];
  section: string | undefined;
}