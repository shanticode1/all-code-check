export interface IUpdateProfileFormValues {
  first_name: string;
  last_name: string;
  email: string;
  token: string;
}

export interface IChangePasswordFormValues {
  currentPassword: string;
  newPassword: string;
  confirmNewPassword: string;
}

export interface IUpdateProfilePayload {
  first_name: string;
  last_name: string | null; 
  email: string;
  token: string;
}

export interface IUpdatePassword {
  currentPassword: string;
  newPassword: string;
}
export interface IUpdateProfileResponse {
  success: boolean;
  message: string;
  data: {
    first_name: string;
    last_name: string;
    email: string;
    token: string;
  };
}

export interface IOTPResponse {
  success: boolean;
  message: string;
  data: null;
}

export interface UserSubscription {
  first_name: string;
  email: string;
  subscription_status: "Paid" | "Free"; // adjust as needed
  subscription_start_date: string; // consider using Date if you're parsing dates
  subscription_end_date: string; // consider using Date if you're parsing dates
}
export interface FailedDetail {
  // Define the structure of failedDetails if known, here's a placeholder
  // Example: field: string; message: string;
  [key: string]: string;
}

export interface AlreadyExistsEntry {
  email: string;
}

export interface IImportSummary {
  created: number;
  failed: number;
  failedDetails: FailedDetail[];
  alreadyExists: AlreadyExistsEntry[];
}

export interface ImportSummaryProps {
  summary: IImportSummary;
}