import { Control, FieldErrors } from "react-hook-form";

import { IExamResponse } from "@/types/Exam/index";

export * from "./exam";
/**
 * @description: type for the admin login object
 */
export type LoginFormValues = {
  email: string;
  password: string;
};
/**
 * @description: type for the admin update profile object
 */
export type UpdateProfileFormValues = {
  first_name: string;
  last_name: string;
  email: string;
  token: string;
};
export type ChangePasswordFormValues = {
  currentPassword: string;
  newPassword: string;
  confirmNewPassword: string;
};
export interface LoginPayload {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  refreshToken: string;
  role: string;
  email: string;
  name: string;
  data: {
    token: string;
    first_name: string;
    last_name: string;
    email: string;
    role: string;
    name: string;
  };
}

export interface RefreshTokenPayload {
  refreshToken: string;
}

export interface RefreshTokenResponse {
  token: string;
  refreshToken: string;
}

export interface AddEram {
  exam_id?: number;
  exam_type?: string;
  exam_name?: string;
  guidelines?: string;
  is_free?: boolean;
  status?: string | undefined | null;
  adaptive_learning?: boolean;
  exam_duration?: number;
  scoring_method?: string;
  display_order?: number;
}

export interface ExamResponse {
  success: boolean;
  message: string;
  data: IExamResponse;
}

export interface Section {
  display_order?: number;
  time_limit?: number;
}

export interface SectionQuestions {
  exam_id: number;
  section_id: number;
  category_id: number;
  question_type: string;
  question_text: string;
  video_url: string;
  difficulty_level: string;
}
export type AddQuestionsFormValues = {
  type: string;
  category: string;
  difficultyLevel: string;
  video: string;
  question: string;
};
export interface AddExamFormValues {
  examName: string;
  accessType: string;
  status: string;
  guidelines: string;
}
export interface AddExam {
  handleClose: () => void;
}

export interface ExamList {
  id: string;
  examName: string;
  examType: string;
  paidAndRegisteredStudent: number;
  attemptedStudent: number;
  createdDate: string;
  accessType: string;
  status: string;
  guidelines: string;
  sections: string;
}

export interface CommonEditorProps {
  placeholder?: string; // Add a placeholder prop
  onContentChange?: (content: string) => void;
  guidelines?: string; // Add a guidelines prop
  height?: number;
}
export interface AddExam {
  handleClose: () => void;
  exam: IExamResponse; // You can define a more specific type for the exam object
}

export interface ExamList {
  id: string;
  examName: string;
  examType: string;
  paidAndRegisteredStudent: number;
  attemptedStudent: number;
  createdDate: string;
  accessType: string;
  status: string;
  guidelines: string;
}

export interface CommonEditorProps {
  placeholder?: string; // Add a placeholder prop
  onContentChange?: (content: string) => void;
  guidelines?: string; // Add a guidelines prop
}

export interface IExamQueryParams {
  page: number;
  limit: number;
  search?: string;
  sortBy?: string;
  orderBy?: string;
  filter?: object;
}

export interface UpdateProfilePayload {
  first_name: string;
  last_name: string;
  email: string;
  token: string;
}

export interface UpdatePassword {
  currentPassword: string;
  newPassword: string;
}
export interface UpdateProfileResponse {
  success: boolean;
  message: string;
  data: {
    first_name: string;
    last_name: string;
    email: string;
    token: string;
  };
}

export interface ISearchProps {
  placeholder?: string;
  defaultValue?: string;
  className?: string;
  value?: string;
  handleChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  handleClear?: () => void;
}

export type WindowWithNextNav = Window & {
  __allowNextNavigation__?: () => void;
};

export interface CalculatorProps {
  readonly showTransfer?: boolean;
  readonly onTransfer?: (value: string) => void;
}

export interface FormDatePickerProps<> {
  name: string;
  control: Control<any>;
  placeholderKey: string;
  errors?: FieldErrors;
  disabled?: boolean,
  minDate?: Date,
  isRequired?: boolean,
  label?: string,
  isClearable?: boolean
  maxDate?: Date
}

export interface ConfirmationModalProps {
  opened: boolean;
  title: string;
  description: string | React.ReactNode;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  buttonCancelText?: string;
  disabled?: boolean;
  buttonText?: string;
  examNames?: {
    original: string | null;
    copy: string | null;
  };
  copyConfirmText?: string;
}

export interface IWarningAlertProps {
  isShow: boolean;
  onClose: () => void;
  isLoading?: boolean;
  handleSubmit?: () => void;
  description: string;
  showButtons?: boolean;
}

export interface IRoundBadgeProp {
  bgColor?: string;
  minWidth?: string;
  maxWidth?: string;
  title?: string;
  color?: string;
}

export interface SubscriptionRow {
  "First Name": string;
  "Last Name": string;
  "Email": string;
  "Subscription Status": "Paid" | "Free";
  "Subscription Start Date": string; 
  "Subscription End Date": string;  
}
export interface TimerDisplayProps {
  secondsRemaining?: number;
  selectedSectionId?: string;
  initialTimeLimit?: number | null;
  handleSubmitSection?: () => void;
}

export interface ExplanationVideoProps {
  opened: boolean;
  onClose: () => void;
  onVideoSelect: (url: string) => void;
  sectionSlug: string;
  selectedVideoUrl?: string;
  t: (key: string) => string;
}

export interface TinyBlobInfo {
  base64: () => string;
  blob: () => Blob;
  filename?: () => string;
  blobUri?: () => string;
}
export interface PastePostProcessEvent {
  node: HTMLElement;
}
