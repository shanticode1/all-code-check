export interface IUserList {
  user_id: number;
  first_name: string;
  last_name: string | null | undefined;
  email: string;
  role: string;
  id: number;
  is_active: boolean;
  message: string;
}

export interface IUserListResponse {
  data: {
    users: IUserList[];
    total: number;
  };
}

export interface IGetUserListPagination {
  page: number;
  limit: number;
  search?: string;
}

export interface IGetUserDetail {
  id: string;
  role: string;
  data?: {
    first_name: string;
    last_name: string;
    email: string;
    user_id: number;
    role: string;
  };
}

export interface UserFormValues {
  first_name: string;
  last_name: string | null;
  email: string;
  role: string;
}
export interface AddUserFormProps {
  handleClose: () => void;
  userDetail?: IUserList | null;
}