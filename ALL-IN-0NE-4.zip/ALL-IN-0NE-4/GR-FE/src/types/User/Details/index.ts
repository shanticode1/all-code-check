export interface IAddUser {
  user_id: number;
  first_name: string;
  last_name: string;
  email: string;
  role: string;
  message: string;
  is_active: boolean;
}

export interface IUpdateUserPayload {
  user_id: number;
  first_name: string;
  last_name: string;
  email: string;
  role: string;
  message: string | undefined | null;
  is_active: boolean;
}
