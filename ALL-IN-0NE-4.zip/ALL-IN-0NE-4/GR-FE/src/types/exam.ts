import { StaticImageData } from "next/image";

import { IAnswerChoices, IQuestionResponse } from "./Exam/index";

export type HeaderNavProps = {
  mobileOpened?: boolean;
  toggleMobile?: () => void;
  onSidebarStateChange: () => void;
};

export interface CalculatorProps {
  opened: boolean;
  setOpened: (value: boolean) => void;
  draggableRef: any;
  currentQ: IQuestionResponse | null;
  role: string;
  handleAnserChoices: (value: string, index: number, type: string) => void;
}
export interface DualLogoProps {
  logo: StaticImageData;
  sherpaPreplogo: StaticImageData;
}

interface Section {
  section_id: number;
  section_name: string;
}

export interface ExamSectionButtonControlsProps {
  role: string;
  selectedSectionId: string | string[];
  allSections?: Section[];
  handleSectionChange: (value: string) => void;
  handleHelpSection: () => void;
  handleExitSection: () => void;
  handleNavigateToSectionQuestions?: () => void;
  handleExit: () => void;
  handlePrevious: () => void;
  handleNext: () => void;
  handleNavigateToSection: () => void;
  handleUpdatemark: (checked: boolean) => void;
  isSaving: boolean;
  isExamDataLoading?: boolean;
  isQuestionFetching?: boolean;
  questionIds: IQuestionResponse[];
  currentIndex: number;
  isQuestionMarked?: boolean;
  calculatorPermitted?: boolean;
  opened: boolean;
  setOpened: (open: boolean) => void;
  analyticalWriting: boolean;
  sectionSlug?: string;
  t: (key: string) => string;
  icons: {
    HelpIcon: StaticImageData;
    ExitIcon: StaticImageData;
    CalculatorIcon: StaticImageData;
    BookmarkIcon: StaticImageData;
    PrevIcon: StaticImageData;
    NextIcon: StaticImageData;
  };
}

export interface SectionProps {
  role: string;
  sectionNumber?: number;
  currentQ: { display_order?: number } | null;
  currentIndex: number;
  questionIds: IQuestionResponse[];
  selectedSectionId: string | number;
  initialTimeLimit: number;
  handleSubmitSection: () => void;
  t: (key: string) => string;
}

export interface AnalyticalProps {
  currentQ: IQuestionResponse | null;
  text: string;
  role: string;
  textareaRef: any;
  buttonState: {
    paste: boolean;
    cut: boolean;
  };
  history: string[];
  redoStack: string[];
  handleCut: () => void;
  handlePaste: () => void;
  handleUndo: () => void;
  handleRedo: () => void;
  handleKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
  handleAnserChoices: (value: string, index: number, type: string) => void;
  setEditorState: React.Dispatch<React.SetStateAction<unknown>>;
  t: (key: string) => string;
}

export interface NumericalEntryInputProps {
  prefix?: string;
  suffix?: string;
  value: string;
  onChange: (val: string) => void;
  isSaving: boolean;
  t: (key: string) => string;
  currentQ: IQuestionResponse | null;
}

export interface FractionalEntryInputProps {
  numeratorValue: string;
  denominatorValue: string;
  onNumeratorChange: (value: string) => void;
  onDenominatorChange: (value: string) => void;
  isSaving: boolean;
  currentQ: IQuestionResponse | null;
}

export interface ISelectedSentenceObj {
  student_answer_choice_id: number | null; // you can initialize to 0 if new, or come from the backend
  answer_choice_id: number | null;
  answer: string;
  paragraph_answer_key: number | null;
}

export interface ExamHeaderProps {
  logo: StaticImageData;
  sherpaPreplogo: StaticImageData;
  role: string;
  selectedSectionId: string;
  allSections?: Section[];
  handleSectionChange: (value: string) => void;
  handleHelpSection: () => void;
  handleExitSection: () => void;
  handleNavigateToSectionQuestions?: () => void;
  handleExit: () => void;
  handlePrevious: () => void;
  handleNext: () => void;
  handleNavigateToSection: () => void;
  handleUpdatemark: (checked: boolean) => void;
  isSaving: boolean;
  isExamDataLoading?: boolean;
  isQuestionFetching?: boolean;
  questionIds: IQuestionResponse[];
  currentIndex: number;
  isQuestionMarked?: boolean;
  calculatorPermitted?: boolean;
  opened: boolean;
  setOpened: (open: boolean) => void;
  analyticalWriting: boolean;
  sectionSlug?: string;
  t: (key: string) => string;
  icons: {
    HelpIcon: StaticImageData;
    ExitIcon: StaticImageData;
    CalculatorIcon: StaticImageData;
    BookmarkIcon: StaticImageData;
    PrevIcon: StaticImageData;
    NextIcon: StaticImageData;
  };
}

export interface GuidelineDisplayProps {
  guidelines: string;
}

export interface FillInTheBlankInputProps {
  isQuantitiveSection: boolean;
  analyticalWriting: boolean;
  currentQ: IQuestionResponse | null;
  renderFillInTheBlank: () => React.ReactNode;
}

export interface SingleSelectionInputProps {
  currentQ: IQuestionResponse | null;
  selectAnswer: IAnswerChoices[];
  isSaving: boolean;
  handleAnserChoices: (value: string, index: number, type: string) => void;
}

export interface ClipboardButtonGroupProps {
  onCut: () => void;
  onPaste: () => void;
  onUndo: () => void;
  onRedo: () => void;
  disablePaste?: boolean;
  disableUndo?: boolean;
  disableRedo?: boolean;
  labels?: {
    cut?: string;
    paste?: string;
    undo?: string;
    redo?: string;
  };
}

export interface QuestionsRenderProps {
  analyticalWriting: boolean;
  isFillInTheBlank: boolean;
  isQuantitiveSection: boolean;
  currentQ: IQuestionResponse | null;
  sanitizedHTML: string;
  selectAnswer: IAnswerChoices[];
  isSaving: boolean;
  renderFillInTheBlank: () => React.ReactNode;
  renderMultipleSelection: () => React.ReactNode;
  handleAnserChoices: (value: string, index: number, type: string) => void;
  handleSentenceClick: (e: React.MouseEvent<HTMLDivElement>) => void;
  text: string;
  role: string;
  textareaRef: unknown;
  buttonState: {
    paste: boolean;
    cut: boolean;
  };
  history: string[];
  redoStack: string[];
  handleCut: () => void;
  handlePaste: () => void;
  handleUndo: () => void;
  handleRedo: () => void;
  handleKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
  setEditorState: any;
  getNumAndDemValueFromAnswer: (value: string) => { numerator: string; denominator: string };
}

export interface EditorState {
  text: string;
  selection: [number, number];
  history: string[];
  redoStack: string[];
  clipboard: string;
  buttonState: {
    cut: boolean;
    paste: boolean;
  };
}
