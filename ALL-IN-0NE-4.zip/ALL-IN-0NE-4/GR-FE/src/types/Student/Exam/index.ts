import { IQuestionCategory } from "@/types/Exam/ViewExam";

export interface IExamHistoryData {
  exam_id: number;
  exam_name: string;
  status: string;
  analyticalWritingScore: 0;
  attemptedQuestions: 0;
  quantitativeReasoningScore: 0;
  start_date: string;
  student_exam_id: 58;
  totalQuestions: 55;
  verbalReasoningScore: 0;
  total?: number;
  is_analytical_answer_submitted?: boolean;
  user: {
    first_name: string;
    last_name: string;
    user_id: number;
    email: string;
    subscription_status?: string;
  };
}

export interface IStudentExamSection {
  is_correct: boolean;
  student_question_id: string;
  time_taken: number | null;
  question_id: number;
  section_name: string;
  answer_status: string;
  section_slug?: string; // Optional, if it exists
  studentQuestions: IStudentExamSection[];
  section_id: number;
  analyticalWritingScore: number;
  student_exam_section_id: number;
}

export interface IExamHistoryResponse {
  data: {
    exams: IExamHistoryData[];
    analyticalWritingScore: number;
    verbalReasoningScore: number;
    quantitativeReasoningScore: number;
    start_date: string | Date;
    exam_name: string;
    studentExamSections: {
      section_name: string;
      studentQuestions: IStudentExamSection[];
      section_slug: string;
    }[];
    total?: number;
    totalPages?: number;
  };
}

interface Section {
  name: string;
  score: number | string; // Handle "NS" or numeric scores
}

export interface ScoreCardProps {
  sections: Section[];
  date: string;
  examName: string;
  userName: string;
  email: string;
  message: string;
  buttonText: string;
  status: string;
  handleViewDetails: () => void;
  gridView?: boolean;
}

export interface IQuestion {
  is_correct: boolean;
  time_taken: number | null;
  student_question_id: string;
  question?: {
    question: string;
    category?: {
      title: string;
      description: string;
    };
    answer: string;
    options: {
      option: string;
      is_correct: boolean;
    }[];
    question_id: number;
    question_type: string | null | undefined;
    difficulty_level: string;
    numeric_difficulty_level: number | null;
    questionCategory?: IQuestionCategory[];
  };
  is_attended?: boolean;
  answer_status: string;
  is_marked?: boolean;
  is_visited?: boolean;
  question_id: any;
  question_type?: string;
  analyticalWritingScore: number;
  questionNumber?: number;
  student_exam_section_id: number;
}

export interface IExamSection {
  section_name: string;
  section_slug?: string;
  studentQuestions: IStudentExamSection[];
}
export type ViewType = "grid" | "list";

export const AnswerStatusLables: Record<string, string> = {
  NOT_ENCOUNTERED: "Not Encountered",
  ANSWERED: "Answered",
  NOT_ANSWERED: "Not Answered",
  INCOMPLETE: "Incomplete",
};

export interface FormValues {
  startDate: Date | null;
  endDate: Date | null;
  searchQuery: string | undefined;
}

export interface QueryParams {
  role: string;
  page: number;
  limit: number;
  startDate: Date | null;
  endDate: Date | null;
  search: string | null;
  user_id: string | null;
}
