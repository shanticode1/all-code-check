import { IAnswerChoices, IAnswerInput } from "@/types/Exam/index";

export interface IQuestionData {
  studentAnswerChoices: IAnswerChoices[];
  currentQuestionNumber: number;
  prevId: number;
  nextId: number;
  section_slug: string;
  section_name: string;
  totalCount: number;
  AnswerChoice: IAnswerInput[];
  question_type: string;
  guidelines: string;
  question_text: string;
  time_taken: string;
  video_url: string;
  is_attended: boolean;
  student_exam_section_id: number;
  calculator_permitted: boolean;
  exam: {
    exam_id: number;
    exam_name: string;
  };
  student: {
    email: string;
    first_name: string;
    last_name: string;
    user_id: number;
  };
  start_date: string;
  question_layout : string
  instructions : string
  passage_answer_instructions : string
}

export interface IQuestionResponses {
  data: IQuestionData;
  success: boolean;
  message: string;
}

export interface IViewQuestionProps {
  currentQ?: IQuestionData;
  isLoading: boolean;
  analyticalWriting: boolean;
  selectAnswer?: IAnswerChoices[];
  isWarningShow?: boolean;
  isQuantitiveSection: boolean;
}

export interface IQuestionPayload {
  questionId: string;
  role: string;
  student_exam_section_id?: string;
}

export interface ResponsiveVideoPlayerProps {
  embedUrl?: string | null;
  videoUrl?: string;
  sectionRef?: React.RefObject<null | HTMLDivElement>;
  title?: string;
  t: (key: string) => string;
};
