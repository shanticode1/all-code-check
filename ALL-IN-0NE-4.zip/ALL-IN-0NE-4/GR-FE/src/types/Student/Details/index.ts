export interface IAddStudent {
    user_id: number
    first_name: string
    last_name: string,
    email: string,
    message: string
    is_active: boolean
    subscription_status: string,
    subscription_start_date: string,
    subscription_end_date: string
}

export interface IUpdateStudentPayload {
    user_id: number
    first_name: string
    last_name: string,
    email: string,
    message: string | undefined | null,
    is_active: boolean
    subscription_status: string,
    subscription_start_date: string,
    subscription_end_date: string
}

