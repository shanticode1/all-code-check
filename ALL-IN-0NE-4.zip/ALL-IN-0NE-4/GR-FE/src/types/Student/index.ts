export interface IStudentList {
  user_id: number;
  first_name: string;
  last_name: string | null | undefined;
  email: string;
  subscription_status: string;
  subscription_end_date: string | Date;
  subscription_start_date: string | Date;
  partner_type: string;
  id: number;
  is_active: boolean;
  message: string;
}

export interface IStudentListResponse {
  data: {
    users: IStudentList[];
    total: number;
  };
}

export interface IGetStudentExamPayload {
  role: string;
  page: number;
  limit: number;
  startDate?: Date | null;
  endDate?: Date | null;
  skip?: boolean;
  search?: string | null;
}
export interface IGetStudentListPagination {
  page: number;
  limit: number;
  search?: string;
}

export interface IGetStudentExamDetailPayload {
  id: string;
  role: string;
}

export interface IGetStudentDetail {
  id: string;
  role: string;
  data?: {
    first_name: string;
    last_name: string;
    email: string;
    user_id: number;
    student_exam_id: number;
  };
}

export interface IDownloadCsv{
  startDate?: Date | null;
  endDate?: Date | null;
  user_id?:number
}

export interface ICsvDownloadResponse {
  success: boolean;
  message: string;
  data: {
    fileUri: string;
  };
}
export interface ExamColumns {
  exam_id: number;
  exam_name: string;
  exam_type: string;
  startExam: string;
}
export interface IExam {
  exam_id: number;
  exam_name: string;
  exam_type: string;
  startExam: string;
  adaptive_learning: boolean;
  display_order: number | null;
  exam_duration: number;
  scoring_method: string;
  status: string;
  is_free: boolean;
  guidelines: string;
  _isNavigating?: boolean;
}

  export interface IStudentFormData {
    first_name: string;
    last_name: string | null;
    email: string;
    partner_type: string;
    subscription_status: string;
    subscription_start_date: Date | null;
    subscription_end_date: Date | null;
  }
export interface AddStudentFormProps {
  handleClose: () => void;
  studentDetail?: IStudentList | null;
}
