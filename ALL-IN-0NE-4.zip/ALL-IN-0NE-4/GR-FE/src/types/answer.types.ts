import { IAnswerInput as AnswerInput } from "@/types/Exam/index";

export type IAnswerInput = {
  questionId: number | undefined;
  index?: number;
  answerValue?: string | null;
  isCorrect?: boolean;
  answerGroup?: number | null;
  answer_choice_id?: number;
  isRemoveOption?: boolean;
  option_text?: string | null;
  answer_group?: number | null;
  is_correct?: boolean;
  error?: string;
};

export interface Paragraph {
  option_text: string;
  error?: string;
}

export interface IParagraphInputProps {
 readonly handleAnswerChoices: (
    value: string | null,
    index: number | null,
    action?:
      | "addMore"
      | "removeOption"
      | "handleMultipleCorrect"
      | "handleSingleCorrect"
      | "addMoreParagraph"
      | null
      | undefined,
  ) => void;
 readonly answerChoice: AnswerInput[];
}
export interface AnswerChoiceType {
  option_text?: string | null;
  is_correct: boolean | undefined;
  error?: string | null;
  answer_group?: number | null;
}

export interface IAnswerChoice {
  question_id: number | undefined;
  index: number;
  option_text: string;
  is_correct: boolean;
  answer_group: number | null;
  answer_choice_id?: number;
  composite_key?: string;
}

export interface AnswerChoice {
  answer_choice_id?: number | null;
  questionId?: number;
  option_text?: string;
  is_correct?: boolean;
  answer_group?: number | null;
  composite_key?: string;
  error?: string;
  isRemoveOption?: boolean;
  answerValue?: string | null;
  answerGroup?: number | null;
  isCorrect?: boolean;
}

export type AnswerActionType =
  | "addMore"
  | "removeOption"
  | "handleMultipleCorrect"
  | "handleSingleCorrect"
  | "addMoreParagraph";

export interface AnswerChoicesProps {
  type: string | null | undefined;
  AnswerChoice: AnswerChoice[];
  handleAnswerChoices: (
    answerText: string | null | undefined,
    key: number | undefined | null,
    type?:
      | "addMore"
      | "removeOption"
      | "handleMultipleCorrect"
      | "handleSingleCorrect"
      | "addMoreParagraph"
      | undefined
      | null,
    answer_group?: number | undefined | null,
    value?: string | undefined,
  ) => void;
  isCheckboxShow?: boolean;
  answerGroup?: number | null;
}

export interface FailedDetail {
    // Define the structure of failedDetails if known, here's a placeholder
    // Example: field: string; message: string;
    [key: string]: string;
}

export interface AlreadyExistsEntry {
    email: string;
}

export interface ImportSummary {
    created: number;
    failed: number;
    failedDetails: FailedDetail[];
    alreadyExists: AlreadyExistsEntry[];
}