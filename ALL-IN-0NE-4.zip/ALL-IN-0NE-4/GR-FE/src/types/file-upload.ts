export interface IFileUploadPayload {
  fileName: string;
  fileType: string;
  fileSize?: number;
  [key: string]: unknown;
}

export interface IPresignedUploadFields {
  [key: string]: string;
}

export interface IPresignedUploadData {
  upload_url?: string;
  uploadUrl?: string;
  url?: string;
  presigned_url?: string;
  presignedUrl?: string;
  fields?: IPresignedUploadFields;
  form_fields?: IPresignedUploadFields;
  formFields?: IPresignedUploadFields;
  file_url?: string;
  fileUrl?: string;
  public_url?: string;
  publicUrl?: string;
  asset_url?: string;
  assetUrl?: string;
  key?: string;
  object_key?: string;
  objectKey?: string;
  headers?: IPresignedUploadFields;
  upload_headers?: IPresignedUploadFields;
  uploadHeaders?: IPresignedUploadFields;
}

export interface IPresignedUploadResponse extends IPresignedUploadData {
  success?: boolean;
  message?: string;
  data?: IPresignedUploadData;
}

export interface IPresignedUploadInfo {
  uploadUrl: string;
  fields?: IPresignedUploadFields;
  headers?: IPresignedUploadFields;
  fileUrl?: string;
  key?: string;
}

export interface IUploadImageInput {
  file: Blob;
  fileName: string;
  contentType: string;
  fileSize?: number;
  meta?: Record<string, unknown>;
}

export interface IUploadedAsset {
  url: string | undefined;
  fileName: string;
  key?: string;
}
