export interface IDashboardSummary {
  data: {
    totalExams?: number;
    totalStudents?: number;
    totalActiveStudents?: number;
    totalActiveExams?: number;
    totalSmartWithHeartStudent?: number;
    totalSherpaPrepStudent?: number;
    totalPaidStudent?: number;
    totalFreeStudent?: number;
  };
}

interface BarChartPayloadProps {
  name?: string;
  value?: number;
}

export interface ChartTooltipProps {
  label: string;
  payload: BarChartPayloadProps[] | undefined
  coordinate?: { x?: number; y?: number };
}

export interface DashboardReportsParams{
  filter: string;
  enabled: boolean
}