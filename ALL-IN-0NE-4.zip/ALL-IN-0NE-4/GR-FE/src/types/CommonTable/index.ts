import { IQuestion } from "@/types/Student/Exam";
export interface CommonTableProps<T = IQuestion> {
  title?: string;
  data: T[];
  slug?: string;
  role?: string;
  examId?: string;
  studentId?: string;
  isAnalyticalWring?: boolean;
  index?: number;
}

export interface IScoreLabelType {
  is_attended?: boolean;
  is_correct?: boolean;
  is_visited?: boolean;
  analyticalWritingScore?: number | null;
}