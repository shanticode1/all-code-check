import { ISection } from "../section.types";

export interface IRetentionSettingResponse {
  success: boolean;
  message: string;
  retention_id?: number;
  data: IRetentionDays;
}

export interface IRetentionDays {
  user_id?: number;
  retention_id?: number;
  free_user_retention_days?: number | null;
  paid_user_retention_days?: number | null;
  selectedFreeDays?: number | null;
  selectedPaidDays?: number | null;
}

export interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedSection: Omit<ISection, "questions">;
  examId?: number;
  sectionId?: string; // Add sectionId as a prop
}

export interface SettingsFormValues {
  section_name: string;
  time_limit: number;
  instructions?: string;
};
