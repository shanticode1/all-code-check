export interface ISections {
  adaptive_learning: boolean;
  base_score: number;
  calculator_permitted: boolean;
  display_order: number;
  exam_id: number;
  question_counts: number;
  questions: { question_id: number; question_text: string; difficulty_level: string }[];
  section_id: number;
  section_name: string;
  section_slug: string;
  time_limit: number;
  question_no: number;
  id: number;
  sectionSlug: string;
  title: string;
  instructions?: string;
}

export interface IExamApiResponse {
  exam_id: number;
  exam_name: string;
  exam_type: string;
  paid_and_registered_student?: number;
  attempted_student?: number;
  created_at?: string;
  is_free: boolean;
  status: "Active" | "Inactive";
  guidelines?: string;
  sections?: ISections[];
  adaptive_learning: boolean;
  exam_duration: number;
  scoring_method: string;
  isPreviewable: boolean;
  verbal_penalty_per_mistake?: number | null;
  quant_penalty_per_mistake?: number | null;
  is_on_going: boolean;
}

export interface IExamRecord {
  id: number;
  examName: string;
  examType: string;
  paidAndRegisteredStudent: number;
  attemptedStudent: number;
  createdDate: string;
  accessType: string;
  status: string;
  guidelines?: string;
  sections?: ISections[];
  isPreviewable: boolean;
  penaltyQuant?: number | null;
  penaltyVerbal?: number | null;
  isOnGoing: boolean;
}

export interface IEditingExam {
  id: number;
  data: IExamRecord;
}

export interface IExamQueryParams {
  page: number;
  limit: number;
  search?: string;
  sortBy?: string;
  orderBy?: string;
  filter?: string;
}

export interface IExamResponse {
  data: {
    exams: IExamApiResponse[];
    sections: ISections[];
    exam_name: string;
    exam_id: number;
    total: number;
    page: number;
    limit: number;
    exam_duration: number;
    guidelines: string;
    student_question_id: number;
  };
  success: boolean;
  message: string;
}
