import { IExamResponse, ISections } from "../ExamList";
import { IAnswerChoices } from "../Preview";

export interface IQuestionQueryParams {
  exam_id: number;
  section_id?: number;
  question_id?: number;
}

export type IAnswerInput = {
  questionId?: number | undefined;
  index?: number;
  answerValue?: string | null;
  isCorrect?: boolean;
  answerGroup?: number | null;
  answer_choice_id?: number | null;
  isRemoveOption?: boolean;
  option_text: string | null;
  answer_group?: number | null;
  is_correct?: boolean;
  error?: string | null;
  composite_key?: string | number | null;
  answer_prefix?: string | null;
  answer_suffix?: string | null;
};
export interface IExam {
  exam_id: number;
  exam_name: string;
}
export interface IQuestionResponse {
  id: number;
  type: string | null;
  category: string[] | null;
  difficultyLevel: string | null;
  video: string | null;
  question: string;
  options?: string[];
  correct_answer?: string;
  question_type?: string | null;
  difficulty_level?: string | null;
  video_url?: string;
  category_id: number;
  section_id?: number;
  question_id: any;
  AnswerChoice: IAnswerInput[];
  questionGuidelines?: string | null;
  questionInstructions?: string | null;
  instructions?: string | null;
  guidelines?: string | null;
  title: string;
  value: string;
  label: string;
  question_text: string | null;
  answerChoices: IAnswerInput[];
  section_name: string;
  exam_id: number;
  questions: IQuestionResponse[];
  time_limit: number;
  section_slug: string;
  allocated_time: number;
  student_exam_id: number;
  time_taken: number;
  student_question_id: any;
  studentAnswerChoices: IAnswerChoices[];
  calculator_permitted: boolean;
  is_attended?: boolean;
  student_exam_section_id?: number;
  is_marked?: boolean;
  is_visited?: boolean;
  answer_groups?: number | null;
  is_correct?: boolean;
  numericDifficultyLevel?: number | null;
  numeric_difficulty_level?: number | null;
  question_layout?: string | null;
  questionLayout?: string | null;
  passage_answer_instructions?: string | null;
  exam: IExam | null | undefined;
  analyticalWritingScore: number | null;
  display_order?: number;
  questionNumber?: number | null;
  status?: string | null;
  is_on_going?: boolean;
  questionCategory?: IQuestionCategory[];
}

export interface ISelectedContext {
  sectionId: number;
  sectionName: string;
  questionId?: number;
  sectionSlug?: string;
  questionNo?: number;
}

export interface IQuestionCategory {
  category: {
    category_id: number;
    title: string;
  };
}
export interface IAddQuestionsFormValues extends IQuestionResponse {
  answer_groups: number | null | undefined;
  question_text: string | null;
}

export interface IExamQuestionResponse {
  data: IQuestionResponse | null;
}

export interface ISection {
  display_order?: number;
  time_limit?: number;
}

export interface ISectionResponse {
  data: IQuestionResponse;
  success: boolean;
  message: string;
}

export interface ICategoryQuestionResponse {
  data: IQuestionResponse[];
}

export interface IRequestedPayloadQuestion {
  exam_id?: number;
  section_id?: number;
  question_type: string | null;
  question_text: string | null;
  video_url: string | null;
  difficulty_level: string | null;
  guidelines?: string | null;
  answerChoices: IAnswerInput[];
}

export interface IExamSidebarProps {
  examId: number;
  onClick: (
    questionId: number,
    sectionId: number,
    sectionName: string,
    sectionSlug: string,
    questionNo: number,
  ) => void;
  onViewQuestions: (
    sectionId: number,
    sectionName: string,
    sectionSlug: string,
    questionNo: number,
    questionId: number,
  ) => void;
  examData: IExamResponse | undefined;
}

export type ISectionWithoutQuestions = Omit<ISections, "questions">;

export interface IAnswerChoicesProps {
  type: string;
  handleAnswerChoices: (
    text: string | null,
    idx: number | null,
    action?:
      | "addMore"
      | "removeOption"
      | "handleMultipleCorrect"
      | "handleSingleCorrect"
      | "addMoreParagraph"
      | "addSuffix"
      | "addPrefix"
      | null,
    group?: number | null,
  ) => void;
  answerChoice?: IAnswerInput[];
}

export interface ISingleSelectionProps {
  handleAnswerChoices: (
    optionText: string | null,
    index: number,
    action?: "handleSingleCorrect" | "handleMultipleCorrect" | "removeOption",
    answerGroup?: number | null,
  ) => void;
  answerChoice: IAnswerInput[];
  answerGroup: number | null;
  isCheckboxShow: boolean;
}

export interface IPreviewQuestionType {
  question_id: string;
  is_attended?: boolean;
}
