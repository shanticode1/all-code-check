
import { ReactNode } from "react";

import { IQuestion, IStudentExamSection } from "@/types/Student/Exam";

export interface ExamHistoryResponse {
    exam_id: number;
    exam_name: string;
}

export interface IQuestionColumn {
    question_id: number;
    question_text: string;
    difficulty_level: string;
    section_id: number;
    title: string;
    sectionSlug: string;
    question_no: number;
}

export type Column = {
    accessor: string;
    title: string;
    render: (item: IQuestion, index: number) => ReactNode;
};

export interface ReportCardProps {
    label: string;
    value: number;
    min: number;
    max: number;
}

export interface StudentExamData {
    analyticalWritingScore?: number;
    verbalReasoningScore?: number;
    quantitativeReasoningScore?: number;
    exam_name?: string;
    start_date?: string;
    studentExamSections?: IStudentExamSection[];
}

export interface IStudentExamDetail {
    data?: StudentExamData;
}

export type TranslateFunction = (key: string) => string;

export interface IStudentQuestion {
  section_name: string;
  studentQuestions: IStudentExamSection[];
  section_slug: string;
}