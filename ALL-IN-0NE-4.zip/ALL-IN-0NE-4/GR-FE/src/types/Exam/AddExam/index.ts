import { IEditingExam, IExamResponse } from "../ExamList";
import { IAddQuestionsFormValues } from "../ViewExam";

export interface IAddExamFormValues {
  examName: string;
  accessType: string;
  status: string;
  guidelines: string;
  penaltyQuant : number | null;
  penaltyVerbal : number | null;
}
export interface IAddExamProps {
  handleClose: () => void;
  exam: IEditingExam | null;
}

export interface IAddExam {
  exam_id?: number;
  exam_type?: string;
  exam_name?: string;
  guidelines?: string;
  is_free?: boolean;
  status?: string | null;
  adaptive_learning?: boolean;
  exam_duration?: number;
  scoring_method?: string;
  display_order?: number;
}

export interface IQuestionListProps {
  examData: IExamResponse | undefined;
  sectionId: number;
  tableColumns: Array<{ accessor: string; title: string }>;
  sectionSlug: string | undefined;
  onClick: (
    questionId: number,
    sectionId: number,
    sectionName: string,
    sectionSlug: string,
    questionNo: number,
  ) => void;
}

export interface IQuestionFormProps {
  questionData: IAddQuestionsFormValues | null;
  isLoading: boolean;
  onSubmit: (data: IAddQuestionsFormValues, editorValue: string) => void;
  sectionSlug: string | undefined;
}

export interface GroupCountMap {
  twoFillInTheBlank: number;
  threeFillInTheBlank: number;
  [key: string]: number; 
}