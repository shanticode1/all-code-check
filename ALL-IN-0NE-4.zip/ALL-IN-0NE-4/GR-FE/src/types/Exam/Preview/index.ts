import { ISections } from "../ExamList";
import { IQuestionResponse } from "../ViewExam";

export interface IAnswerChoices {
  student_answer_choice_id: number | null;
  answer_choice_id: null | number;
  answer: string;
  numerator: string | null;
  denominator: string | null;
  paragraph_answer_key: string | null;
}

export interface IAnswerChoicesSubmitPayload {
  student_question_id?: number;
  is_visited: boolean;
  answerChoices: {
    student_answer_choice_id: number | null;
    answer_choice_id: number | null;
    answer: string;
  }[];
}
export interface IPreviewSectionProps {
  currentQ: IQuestionResponse | null;
  isLoading: boolean; // Add isLoading prop
  isSaving: boolean;
  analyticalWriting: boolean;
  currentIndex: number;
  handleNext: () => void;
  handlePrevious: () => void;
  handleExit: () => void;
  handleExitSection: () => void;
  handleHelpSection: () => void;
  questionIds: IQuestionResponse[];
  handleNavigateToQuestion: (index: number) => void;
  role: string;
  handleSubmitSection: () => void;
  handleAnserChoices: (value: string | string[], index: number, type: string) => void;
  selectAnswer: IAnswerChoices[];
  isQuantitiveSection: boolean;
  handleNavigateToSectionQuestions?: () => void;
  sectionName: string;
  calculatorPermitted?: boolean;
  selectedSectionId?: string | string[];
  allSections?: ISections[];
  isExamDataLoading?: boolean;
  sectionSlug?: string;
  handleSectionChange: (sectionId: string) => void;
  handleUpdatemark: (isMarked: boolean) => void;
  isQuestionMarked?: boolean;
  timer?: number;
  setShowConfirmationModal: (shouldShow: boolean) => void;
  showConfirmationModal?: boolean;
  sectionNumber?: number;
  initialTimeLimit?: number | null;
  isQuestionFetching?: boolean;
}

export interface IQuestionPreviewModal {
  isModalOpen: boolean;
  setIsModalOpen: (isOpen: boolean) => void;
  questionIds: IQuestionResponse[];
  currentIndex: number;
  handleNavigateToQuestion: (index: number) => void;
}

export interface IPreviewSectionPayload {
  sectionId: string;
  role: string;
}

export interface IViewQuestionPayload {
  role: string;
  questionId: number;
}
export interface IQuestionExplanationVideoPayload {
  sectionSlug: string;
}

export interface IQuestionTimeTakenPayload {
  questionId: number;
  timeTaken: number;
}

export interface IQuestionMarkedPayload {
  questionId: number;
  isMarked: boolean;
}
export interface IExamExitPayload {
  student_exam_id: string;
  user_id: number;
}
export interface IExamExitTimerUpdatePayload {
  screen_time: string;
  student_exam_id: string;
}
