import { IExamApiResponse, ISections } from "../ExamList";

export interface IScoreCardProps {
  math: number | string;
  verbal: number | string;
  total: number;
  date: string;
  testType: string;
  message: string;
  buttonText: string;
  scoreColor: string;
}

export interface IStartExamResponse {
  data: {
    student_exam_section_id: number;
    student_exam_id: number;
    examId: number;
    is_terms_conditions_accepted?: boolean;
  };
}

export interface IExamsListResponse {
  data: {
    exams: IExamApiResponse[];
    sections: ISections[];
    exam_name: string;
    exam_id: number;
    total: number;
    page: number;
    limit: number;
    exam_duration: number;
    guidelines: string;
    exam_type: string;
    is_free: boolean;
  }[];
  success: boolean;
  message: string;
}

export interface IExamTimeUpdatePayload {
  sectionId: string;
  time_taken: number;
}

export interface IStartExamRequestPayload {
  id: number | string;
  is_terms_conditions_accepted?: boolean;
}
