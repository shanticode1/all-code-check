export interface ICategoryQueryParams {
  sectionSlug: string | undefined;
}
