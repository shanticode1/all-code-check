export interface IAnalytialSectionData {
  student_name: string;
  exam_name: string;
  start_date: string;
  student_question_id: number;
  email?: string | null;
  partner_type?: string | null;
}

export interface IAnalytialSectionDataResponse {
  data: {
    data: IAnalytialSectionData[];
    total: number;
  };
  message: string;
  success: boolean;
}

export interface IAnalyticalPayload {
  limit: number;
  page: number;
  search?: string | null;
  startDate?: string | null;
  endDate?: string | null;
  sortBy?: string | null;
  orderBy?: string;
}

export interface IAnalyticalScorePayload {
  totalScore: number;
  examSectionId: number;
}

export interface FormValues {
  startDate: Date | null;
  endDate: Date | null;
  searchQuery: string | undefined;
};

export type AnalyticalScoringFormValues = {
  score: number;
};
