import React from "react";

import ExitSection from "@/components/Pages/PreviewSection/ExitSection";

export default function QuestionNavigatorPage() {
  return <ExitSection />;
}
