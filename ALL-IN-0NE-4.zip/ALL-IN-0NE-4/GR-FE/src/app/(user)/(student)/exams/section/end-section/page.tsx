import React from "react";

import EndSection from "@/components/Pages/PreviewSection/EndSection";

export default function EndSectionPage() {
  return <EndSection />;
}
