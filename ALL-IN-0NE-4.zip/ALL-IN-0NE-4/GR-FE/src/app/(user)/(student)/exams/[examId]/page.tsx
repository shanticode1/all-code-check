import React from "react";

import StudentExamNavigation from "@/components/Pages/StudentExamNavigation";

export default function InstructionPage() {
  return <StudentExamNavigation />;
}
