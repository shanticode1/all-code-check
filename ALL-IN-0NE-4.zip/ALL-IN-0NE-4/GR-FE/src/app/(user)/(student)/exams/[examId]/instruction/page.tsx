
import React from "react";

import StudentExamInstruction from "@/components/Pages/StudentExamInstruction";

export default function InstructionPage() {
  return <StudentExamInstruction />;
}
