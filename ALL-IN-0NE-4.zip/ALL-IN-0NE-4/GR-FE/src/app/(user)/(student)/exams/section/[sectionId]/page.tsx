import React from "react";

import PreviewQuestionsClient from "@/components/Pages/PreviewSection/PreviewQuestionsClient";

export default function PreviewQuestions() {
  return <PreviewQuestionsClient />;
}
