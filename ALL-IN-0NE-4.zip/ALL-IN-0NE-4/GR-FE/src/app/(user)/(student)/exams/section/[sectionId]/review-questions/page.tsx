import React from "react";

import SectionQuestionsReview from "@/components/Pages/PreviewSection/SectionQuestionsReview";

export default function QuestionNavigatorPage() {
  return <SectionQuestionsReview />;
}
