import React from "react";

import StudentExams from "@/components/Pages/StudentExams";

export default function MyExams() {
  return <StudentExams />;
}
