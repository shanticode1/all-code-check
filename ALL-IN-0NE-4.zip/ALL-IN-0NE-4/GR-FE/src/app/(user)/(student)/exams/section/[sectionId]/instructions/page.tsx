import React from "react";

import SectionInstructions from "@/components/Pages/PreviewSection/SectionInstructions";

export default function SectionInstructionsPage() {
  return <SectionInstructions />;
}
