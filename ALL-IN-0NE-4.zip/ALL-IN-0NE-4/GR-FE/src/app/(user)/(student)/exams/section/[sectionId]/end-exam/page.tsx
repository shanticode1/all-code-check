import React from "react";

import SectionEndConfirmation from "@/components/Pages/PreviewSection/EndExam";

export default function QuestionNavigatorPage() {
  return <SectionEndConfirmation />;
}
