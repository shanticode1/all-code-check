import React from "react";

import HelpSection from "@/components/Pages/PreviewSection/HelpSection";

export default function QuestionNavigatorPage() {
  return <HelpSection />;
}
