import React from "react";

import StudentExamsHistory from "@/components/Pages/StudentExamsHistory";

export default function StudentExams() {
  return <StudentExamsHistory />;
}
