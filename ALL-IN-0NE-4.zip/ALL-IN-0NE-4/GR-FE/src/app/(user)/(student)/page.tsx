import React from "react";

export default function Home() {
  return <h1>Smart with a Heart student portal</h1>;
}
