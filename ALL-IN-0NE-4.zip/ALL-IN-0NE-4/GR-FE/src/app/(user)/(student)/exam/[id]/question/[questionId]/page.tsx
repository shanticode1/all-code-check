import React from "react";

import { Questions } from "@/components/Pages/Questions";

export default function PreviewQuestions() {
  return <Questions />;
}
