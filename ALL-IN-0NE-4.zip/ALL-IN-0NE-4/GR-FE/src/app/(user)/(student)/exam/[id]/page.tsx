import React from "react";

import { ExamDetails } from "@/components/Pages/StudentExamDetails";

export default function ExamDetailsPage() {
  return <ExamDetails />;
}
