import React from "react"; // Explicitly import React

import AdminProfile from "@/components/Pages/Profile";

export default function Profile() {
  return <AdminProfile />;
}
