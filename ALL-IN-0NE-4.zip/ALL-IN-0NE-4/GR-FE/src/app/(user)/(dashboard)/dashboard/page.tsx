"use client";
import React from "react";

import { AdminDashboard } from "@/components/Pages/AdminDashboard";
import { StudentDashboard } from "@/components/Pages/StudentDashboard";
import { USER_ROLE } from "@/constants";
import { useAuth } from "@/lib/Contexts/AuthProvider";

export default function Dashboard() {
  const { role } = useAuth();
  return <>{role === USER_ROLE.STUDENT ? <StudentDashboard /> : <AdminDashboard />}</>;
}
