import React from "react";

import UserList from "@/components/Pages/UserList";

export default function Home() {
  return <UserList />;
}
