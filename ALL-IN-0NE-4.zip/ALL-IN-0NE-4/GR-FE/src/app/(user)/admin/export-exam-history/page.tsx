import React from "react";

import StudentExamsHistory from "@/components/Pages/StudentExamsHistory";

export default function ExportExamHistory() {
  return <StudentExamsHistory />;
}
