import React from "react";

import StudentList from "@/components/Pages/StudentList";

export default function Home() {
  return <StudentList/>;
}
