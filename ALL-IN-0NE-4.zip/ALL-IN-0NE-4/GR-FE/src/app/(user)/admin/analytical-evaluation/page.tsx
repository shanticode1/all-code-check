import React from "react";

import AnalyticalWritingSection from "@/components/Pages/AnalyticalWritingSections";

export default function index() {
  return <AnalyticalWritingSection />;
}
