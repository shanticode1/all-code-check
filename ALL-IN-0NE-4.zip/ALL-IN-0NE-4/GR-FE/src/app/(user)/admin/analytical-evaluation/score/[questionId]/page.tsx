import React from "react";

import AnalyticalScoringSection from "@/components/Pages/AnalyticalWritingSections/AnalyticalScore";

export default function index() {
  return <AnalyticalScoringSection />;
}
