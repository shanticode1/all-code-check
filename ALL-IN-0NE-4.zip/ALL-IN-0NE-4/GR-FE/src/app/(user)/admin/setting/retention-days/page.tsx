import React from "react"; // Explicitly import React

import RetentionPeriodSelector from "@/components/Pages/RetentionPeriodSelector";

export default function RetentionDaysSettingPage() {
  return <RetentionPeriodSelector />;
}
