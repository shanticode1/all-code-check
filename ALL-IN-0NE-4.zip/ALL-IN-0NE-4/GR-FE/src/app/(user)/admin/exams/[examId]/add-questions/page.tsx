import React from "react";

import AddQuestions from "@/components/Pages/AddQuestions";

export default function AddQuestionsPage() {
  return <AddQuestions />;
}
