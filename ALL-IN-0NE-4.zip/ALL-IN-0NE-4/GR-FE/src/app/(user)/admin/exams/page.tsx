import React from "react";

import ExamManagementList from "@/components/Pages/ExamList/index";

export default function Exams() {
  return <ExamManagementList />;
}
