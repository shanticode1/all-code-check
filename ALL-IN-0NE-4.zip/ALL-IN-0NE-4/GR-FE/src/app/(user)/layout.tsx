import React from "react";

import Layout from "@/components/Common/Layout";

export default function AdminLayout( { children }: Readonly<{ children: React.ReactNode }>) {
  return <Layout>{children}</Layout>;
}
