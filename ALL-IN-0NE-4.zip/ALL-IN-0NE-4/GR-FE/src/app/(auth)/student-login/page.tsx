import React from "react";

import StudentLoginForm from "@/components/Pages/Login/StudentLogin";

export default function StudentLogin() {
  return <StudentLoginForm />;
}
