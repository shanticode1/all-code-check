import React from "react";

import ForgotPasswordForm from "@/components/Pages/ForgotPassword";

export default function ForgotPassword() {
    return <ForgotPasswordForm />;
}
