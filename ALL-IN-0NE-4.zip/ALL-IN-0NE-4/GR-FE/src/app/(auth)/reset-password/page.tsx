import React from "react";

import ResetPasswordForm from "@/components/Pages/ResetPassword";

export default function ForgotPassword() {
    return <ResetPasswordForm />;
}
