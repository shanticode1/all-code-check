import "@mantine/core/styles.css";
import "@mantine/notifications/styles.css";
import "@mantine/dates/styles.css";
import "mantine-datatable/styles.layer.css";
import "@/styles/globals.css";

import { ColorSchemeScript, mantineHtmlProps, MantineProvider } from "@mantine/core";
import { Notifications } from "@mantine/notifications";
import { Poppins } from "next/font/google";
import { NextIntlClientProvider, useLocale, useMessages } from "next-intl";
import React, { ReactNode } from "react";

import RouteTransition from "@/components/RouterTransition/RouterTransition";
import { theme } from "@/config/mantine/theme";
import { AuthProvider } from "@/lib/Contexts/AuthProvider";
import ReactQueryProvider from "@/lib/react-query-provider";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-poppins",
});

export const metadata = {
  title: "Smart with a Heart",
  description: "Non-profit organization",
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  const messages = useMessages();
  const locale = useLocale();

  return (
    <html lang="en" {...mantineHtmlProps} suppressHydrationWarning>
      <head>
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/smart-heart-icon.jpg" />
        <link rel="icon" type="image/png" sizes="16x16" href="/smart-heart-icon.jpg" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="viewport" content="minimum-scale=1, initial-scale=1, width=device-width" />
        <ColorSchemeScript />
      </head>
      <body className={`${poppins.variable}`}>
        <MantineProvider theme={theme}>
          <RouteTransition />
          <ReactQueryProvider>
            <Notifications position="top-right" />
            <NextIntlClientProvider messages={messages} locale={locale}>
              <AuthProvider>{children}</AuthProvider>
            </NextIntlClientProvider>
          </ReactQueryProvider>
        </MantineProvider>
      </body>
    </html>
  );
}
