// context/AnswerContext.tsx
"use client";
import React, { createContext, ReactNode,useContext, useState } from "react";

interface Answer {
  index: number;
  answerText: string;
}

interface AnswerContextType {
  answers: Answer[];
  setAnswerAtIndex: (index: number, text: string) => void;
}

const AnswerContext = createContext<AnswerContextType | null>(null);

export const useAnswerContext = () => {
  const context = useContext(AnswerContext);
  if (!context) throw new Error("useAnswerContext must be used within AnswerProvider");
  return context;
};

export const AnswerProvider = ({ children }: { children: ReactNode }) => {
  const [answers, setAnswers] = useState<Answer[]>([]);

  const setAnswerAtIndex = (index: number, text: string) => {
    setAnswers((prev) => {
      const updated = [...prev];
      const existing = updated.find((a) => a.index === index);

      if (existing) {
        existing.answerText = text;
      } else {
        updated.push({ index, answerText: text });
      }

      return [...updated];
    });
  };

  return (
    <AnswerContext.Provider value={{ answers, setAnswerAtIndex }}>
      {children}
    </AnswerContext.Provider>
  );
};
