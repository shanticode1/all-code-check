export const PARTNER_TYPE_OPTIONS = [
  { value: "SmartWithHeart", label: "Smart with a Heart" },
  { value: "SherpaPrep", label: "Sherpa Prep" },
];
