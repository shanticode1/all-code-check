import { questionsTypes } from "../questions"

export const selectionTypes = [
    { value: "singleSelection", label: questionsTypes.SINGLE_SELECTION },
    { value: "multipleSelection", label: questionsTypes.MULTI_SELECTION },
    { value: "input", label: questionsTypes.INPUT },
    { value: "oneFillInTheBlank", label: questionsTypes.ONE_FILL_IN_THE_BLANK },
    { value: "twoFillInTheBlank", label: questionsTypes.TWO_FILL_IN_THE_BLANK },
    { value: "threeFillInTheBlank", label: questionsTypes.THREE_FILL_IN_THE_BLANK },
    { value: "paragraph", label: questionsTypes.PARAGRAPH_SELECTION },
]

export const sectionsSlug = {
    ANALYTICAL_WRITING: "analytical-writing"
}