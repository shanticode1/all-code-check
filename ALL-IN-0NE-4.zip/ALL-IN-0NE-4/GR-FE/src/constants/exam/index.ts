export const QUESTION_TYPES = {
  ESSAY: "Essay",
  SINGLE_ANSWER: "Single answer",
  MULTIPLE_ANSWER: "Multiple answer",
  PASSAGE_SELECTION: "Passage selection",
  // PASSAGE_SELECTION_SENTENCE: "Passage selection (sentence)",
  DOUBLE_ANSWER: "Double answer",
  TRIPLE_ANSWER: "Triple answer",
  QUANTITATIVE_COMPARISON: "Quantitative comparison",
  NUMERICAL_ENTRY: "Numerical entry",
  FRACTIONAL_ENTRY: "Fractional entry",
};

export const accessType = [
  { value: "Free", label: "Free" },
  { value: "Paid", label: "Paid" },
];

export const partnerType = [
  { value: "SmartWithHeart", label: "Smart with Heart" },
  { value: "SherpaPrep", label: "Sherpa prep" },
];

export const contentOptions = [
  { id: "1", content: "", selected: false },
  { id: "2", content: "", selected: false },
  { id: "3", content: "", selected: false },
  { id: "4", content: "", selected: false },
];
export const contentOptionsForSingleSelection = ["1", "2", "3", "4"];

export const QUESTION_TYPE_OPTIONS_BY_SECTION: Record<string, { value: string; label: string }[]> =
  {
    "analytical-writing": [{ value: "essay", label: QUESTION_TYPES.ESSAY }],

    "verbal-reasoning": [
      { value: "singleSelection", label: QUESTION_TYPES.SINGLE_ANSWER },
      { value: "multipleSelection", label: QUESTION_TYPES.MULTIPLE_ANSWER },
      // { value: "paragraph", label: QUESTION_TYPES.PASSAGE_SELECTION },
      { value: "paragraph-sentence", label: QUESTION_TYPES.PASSAGE_SELECTION },
      { value: "twoFillInTheBlank", label: QUESTION_TYPES.DOUBLE_ANSWER },
      { value: "threeFillInTheBlank", label: QUESTION_TYPES.TRIPLE_ANSWER },
    ],

    "quantitative-reasoning": [
      { value: "singleSelection", label: QUESTION_TYPES.SINGLE_ANSWER },
      { value: "quantitative-comparison", label: QUESTION_TYPES.QUANTITATIVE_COMPARISON },
      { value: "multipleSelection", label: QUESTION_TYPES.MULTIPLE_ANSWER },
      { value: "numericalEntry", label: QUESTION_TYPES.NUMERICAL_ENTRY },
      { value: "fractionalEntry", label: QUESTION_TYPES.FRACTIONAL_ENTRY },
    ],
  };

export const TableColumns = [
  { accessor: "question_id", title: "Q.No." },
  { accessor: "question_text", title: "Question" },
  { accessor: "difficulty_level", title: "Difficulty Level" },
];
export const categories = [
  { value: "readingLonger", label: "Reading Comprehension - Longer Passage" },
  { value: "readingShorter", label: "Reading Comprehension - Shorter Passage" },
  { value: "textCompletion", label: "Text Completion" },
  { value: "sentenceEquivalence", label: "Sentence Equivalence" },
];

export const paginationConstants = {
  limit: 10,
  page: 1,
  search: "",
  offset: 0,
  totalPages: 0,
  totalRecords: 0,
};

export const examTableConstants = {
  EXAM_NAME: "Exam Name",
  EXAM_TYPE: "Exam Type",
  PAID_AND_REGISTERED_STUDENT: "Paid and Registered Student",
  ATTEMPTED_STUDENT: "Attempted Student",
  CREATED_DATE: "Created Date",
  ACCESS_TYPE: "Access Type",
  STATUS: "Status",
  ACTIONS: "Actions",
};

export const accessTypeConstants = {
  FREE: "Free",
  PAID: "Paid",
};

export const difficultyLevel = [
  { value: "Hard", label: "Hard" },
  { value: "Medium", label: "Medium" },
  { value: "Easy", label: "Easy" },
];

export const numericDifficultyLevel = [
  { value: "1", label: "1" },
  { value: "1.5", label: "1.5" },
  { value: "2", label: "2" },
  { value: "2.5", label: "2.5" },
  { value: "3", label: "3" },
  { value: "3.5", label: "3.5" },
  { value: "4", label: "4" },
  { value: "4.5", label: "4.5" },
  { value: "5", label: "5" },
];

export const quantitativeComparisonOptions = [
  "Quantity A is greater.",
  "Quantity B is greater.",
  "The two quantities are equal.",
  "The relationship cannot be determined from the information given.",
];

export const examStatus = [
  { value: "ACTIVE", label: "Active" },
  { value: "INACTIVE", label: "Inactive" },
];

// 1) Default mapping includes Category for Verbal entries
export const defaultInstructionsAndGuidelines = [
  // ——— Verbal ———
  {
    section: "verbal",
    qType: "multipleSelection",
    // only for Reading Comprehension passages:
    categories: [
      "Short Passage Reading Comprehension",
      "Long Passage Reading Comprehension",
      "Logical Reasoning",
    ],
    guidelines: "Consider each of the choices separately and select all that apply.",
    instructions: "Select one or more answer choices.",
  },
  {
    section: "verbal",
    qType: "paragraph",
    categories: [
      "Short Passage Reading Comprehension",
      "Long Passage Reading Comprehension",
      "Logical Reasoning",
    ],
    guidelines: "Select the sentence in the passage in which…",
    instructions: "Select the sentence in the passage.",
  },
  {
    section: "verbal",
    qType: "singleSelection",
    categories: [
      "Short Passage Reading Comprehension",
      "Long Passage Reading Comprehension",
      "Logical Reasoning",
    ],
    guidelines: "", // custom per question
    instructions: "Select one answer choice.",
  },
  {
    section: "verbal",
    qType: "oneFillInTheBlank",
    categories: ["Single Blank", "Logical Reasoning"],
    guidelines:
      "Select one entry for the blank. Fill the blank in the way that best completes the text.",
    instructions: "Select one answer choice.",
  },
  {
    section: "verbal",
    qType: "twoFillInTheBlank",
    categories: ["Double Blank", "Logical Reasoning"],
    guidelines:
      "Select one entry for each blank. Fill the blanks in the way that best completes the text.",
    instructions: "Select one entry from each column.",
  },
  {
    section: "verbal",
    qType: "threeFillInTheBlank",
    categories: ["Triple Blank", "Logical Reasoning"],
    guidelines:
      "Select one entry for each blank. Fill the blanks in the way that best completes the text.",
    instructions: "Select one entry from each column.",
  },
  {
    section: "verbal",
    qType: "multipleSelection", // Sentence Equivalence is also a “two‐answer” multipleSelection
    categories: ["Sentence Equivalence"],
    guidelines:
      "Select the two answer choices that, when used to complete the sentence, fit the meaning of the sentence as a whole and produce completed sentences that are alike in meaning.",
    instructions: "Select two answer choices.",
  },

  // ——— Quantitative ——— (no category dependency)
  {
    section: "quantitative",
    qType: "singleSelection",
    guidelines: "",
    instructions: "Select one answer choice.",
  },
  {
    section: "quantitative",
    qType: "quantitative-comparison",
    guidelines: "",
    instructions: "Select one answer choice.",
  },
  {
    section: "quantitative",
    qType: "multipleSelection",
    guidelines: "",
    instructions: "Select one or more answer choices.",
  },
  {
    section: "quantitative",
    qType: "numericalEntry",
    guidelines: "",
    instructions:
      "Enter your answer as an integer or decimal number in the answer box. Backspace to erase.",
  },
  {
    section: "quantitative",
    qType: "fractionalEntry",
    guidelines: "",
    instructions: "Enter your answer as a fraction in the answer boxes. Backspace to erase.",
  },
];

export const DEFAULT_EXAM_GUIDELINES = `
  <h3>General Test Information</h3>
  <p>Timing Information</p>
  <p>Total testing time on this test is 1 hour and 58 minutes (standard time).</p>
  <p>If you wish to leave your seat during the test, please raise your hand or otherwise indicate that you need the administrator – timing will not stop.</p>
  <h3>Test Information</h3>
  <p>If you have a concern about the wording of a test question, please note the question number and continue the test. Report your concern to the administrator after you complete the test.</p>
  <p>No credit will be given for any responses marked on scratch paper. Use the scratch paper to work out your answers. All scratch paper must be turned in to the administrator (or erased in front of the administrator in an at-home test) at the end of the testing session.</p>
  <p>Within a timed section you may skip any question and return to it later before you exit the section. You should answer as many questions as possible during the test and manage your time with this in mind. Use the Review button at any time during the test to review which questions you have answered and which questions you have skipped.</p>
   <p>Select <strong>Continue</strong> to proceed.</p>
`;

export const questionLayoutOptions = [
  { value: "TOPTOBOTTOM", label: "Top to Bottom" },
  { value: "LEFTTORIGHT", label: "Left to Right" },
];

const VERBAL_REASONING_SECTION_INSTRUCTIONS = `
    <p>For each question, indicate the best answer using the directions given. If you need more detailed directions, select <strong>Help</strong> at any time.</p>

    <p>If a question has answer choices with <strong>ovals</strong> 
    (◯)
    then the correct answer consists of a single choice. If a question has answer choices with <strong>square boxes</strong> 
    (☐)

    then the correct answer consists of one or more answer choices. Read the directions for each question carefully. The directions will indicate if you should select one or more answer choices. To answer questions based on a reading passage, you may need to scroll to read the entire passage. You may also use your keyboard to navigate through the passage.</p>

    <p>Select <strong>Continue</strong> to proceed.</p>
  `;

const QUANTITATIVE_REASONING_SECTION_INSTRUCTIONS = `
    <p>For each question, indicate the best answer, using the directions given. If you need more detailed directions, select <strong>Help</strong> at any time.</p>

    <p><strong>An on-screen calculator is available for each question in this section. To use the calculator, select the calculator button.</strong></p>

    <p>If a question has answer choices with <strong>ovals</strong>
    ◯ 
    then the correct answer consists of a single choice. If a question has answer choices with <strong>square boxes</strong> 
    ☐
    then the correct answer consists of one or more answer choices. Read the directions for each question carefully. The directions will indicate if you should select one or more answer choices. To answer questions based on a data presentation, you may need to scroll or use your keyboard to access the entire presentation.</p>

    <p>All numbers used are real numbers.</p>

    <p>All figures are assumed to lie in a plane unless otherwise indicated.</p>

    <p>Geometric figures, such as lines, circles, triangles, and quadrilaterals,<strong>are not necessarily</strong> drawn to scale. That is, you should <strong>not</strong> assume that quantities such as lengths and angle measures are as they appear in a figure. You should assume, however, that lines shown as straight are actually straight, points on a line are in the order shown, and more generally, all geometric objects are in the relative positions shown. For questions with geometric figures, you should base your answers on geometric reasoning, not on estimating or comparing quantities by sight or by measurement.</p>

    <p>Coordinate systems, such as <i>xy</i>-planes and number lines, <strong>are</strong> drawn to scale; therefore you can read, estimate, or compare quantities in such figures by sight or by measurement.</p>

    <p>Graphical data presentations, such as bar graphs, circle graphs, and line graphs, <strong>are</strong> drawn to scale; therefore, you can read, estimate, or compare data values by sight or by measurement.</p>

    <p>Select <strong>Continue</strong> to proceed.</p>
  `;

export const DEFAULT_SECTION_INSTRUCTIONS: Record<string, string> = {
  "analytical-writing": `
    <p><strong>Analyze an Issue Task</strong></p>
     <p>You will be given a brief quotation that states or implies an issue of general interest, and you will also be given specific instructions on how to respond to that issue. Standard timing for this task is 30 minutes. In that time you should plan and compose a response to the issue presented. A response to any other issue will receive a score of zero. Make sure that you respond according to the specific instructions and support your position on the issue with reasons and examples drawn from such areas as your reading, experience, observations, and/or academic studies.</p>

    <p>Trained GRE readers will evaluate your response according to how well you:</p>
    <ul>
      <li>Respond to the specific task instructions</li>
      <li>Consider the complexities of the issue</li>
      <li>Organize, develop, and express your ideas</li>
      <li>Support your position with relevant reasons and/or examples</li>
      <li>Control the elements of standard written English</li>
    </ul>

    <p>Before you begin writing, you may want to think for a few minutes about the issue and the specific task instructions and then plan your response. Be sure to develop your position fully and organize it coherently, but leave time to reread what you have written and make any revisions you think are necessary.</p>

    <p> Select <strong>Continue</strong> to proceed. Timing for the task will start when you do so.</p>
  `,
  "verbal-reasoning-1": VERBAL_REASONING_SECTION_INSTRUCTIONS,
  "verbal-reasoning-2": VERBAL_REASONING_SECTION_INSTRUCTIONS,
  "quantitative-reasoning-1": QUANTITATIVE_REASONING_SECTION_INSTRUCTIONS,
  "quantitative-reasoning-2": QUANTITATIVE_REASONING_SECTION_INSTRUCTIONS,
};

export const DEFAULT_EXAM_EXIT_SECTION = `If you select <strong>Exit Section</strong>, you WILL NOT be able to return to this section of the test. Select <strong>Exit Section</strong> to confirm that you would like to exit this section. Select <strong>Return</strong> to return to the section.`;
export const EXAM_START_SECTION_INSTRUCTIONS = `  
              <p>
                During this test, you can use the mouse OR the keyboard to move through the screens.
              </p>

              <p>You can use the following standard keys on the keyboard:</p>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                      Tab <Key width={50}>Tab</Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>
                    Press the Tab key to move from one selectable element on the page to the next.
                    The current selectable element will be indicated by a thin blue border.
                  </p>
                </div>
              </div>

              <p>Examples of selectable elements:</p>
              <ul style={{ paddingLeft: 15 }}>
                <li style={{ alignItems: "center" }}>Buttons on the menu toolbar</li>
                <li style={{ alignItems: "center" }}>Answer options for test questions</li>
              </ul>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                      Shift <Key width={50}>↑Shift</Key>
                    </strong>{" "}
                    and{" "}
                    <strong>
                      Tab <Key width={50}>Tab</Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>
                    Press the Shift and Tab keys to reverse direction through the selectable
                    elements.
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                      Spacebar <Key width={100}> </Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>
                    Press the spacebar key to select an element. Press the spacebar key again to
                    deselect the element.
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                      Up <Key width={24}>↑</Key>
                    </strong>
                    and{" "}
                    <strong>
                      Down <Key width={24}>↓</Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>Use the up and down arrows to scroll vertically.</p>
                </div>
              </div>

              <p>
                Select <strong>Continue</strong> to proceed.
              </p>
            `;
export const EXAM_HISTORY_BOTTOM_CONTENT = `<p>
 <a target="_blank"
href = ${"https://www.smartwithaheart.org"}> Smart with a Heart </a> 
      is America's first and only nonprofit test prep provider.<strong> We believe deeply in the dream of educational equity and expanding access to higher education.</strong> Through our partnership with  <a
href = ${"https://sherpaprep.com"} target="_blank"> Sherpa Prep </a>, one of the most highly-rated test prep companies in the world, we offer a comprehensive GRE prep course for just $249 (or $199 for U.S. military veterans and Pell Grant recipients). Unlike any other test prep provider, our program includes one-on-one teacher guidance at no extra cost to the student, free small-group office hours, and free admissions tutorials to help you craft an outstanding grad-school application.
</p>`;

export const EVALUATION_SCORES = [
  { value: "0", label: "0" },
  { value: "0.5", label: "0.5" },
  { value: "1", label: "1" },
  { value: "1.5", label: "1.5" },
  { value: "2", label: "2" },
  { value: "2.5", label: "2.5" },
  { value: "3", label: "3" },
  { value: "3.5", label: "3.5" },
  { value: "4", label: "4" },
  { value: "4.5", label: "4.5" },
  { value: "5", label: "5" },
  { value: "5.5", label: "5.5" },
  { value: "6", label: "6" },
];

export const MODAL_ACTIONS = {
  delete: "delete",
  status: "status",
  deActive: "deActive",
  copy: "copy",
};

export const EXAM_STATUS_CONSTANT = {
  INACTIVE: "INACTIVE",
  ACTIVE: "ACTIVE",
};

export const SORTING_ORDER = {
  DESC: "desc",
  ASC: "asc",
};
