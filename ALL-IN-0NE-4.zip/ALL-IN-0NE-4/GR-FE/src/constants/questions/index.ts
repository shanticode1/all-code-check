import { IAnswerInput } from "@/types/Exam/index";

export const questionsTypes = {
  SINGLE_SELECTION: "Single selection",
  MULTI_SELECTION: "Multiple selection",
  INPUT: "Input type (type answer)",
  ONE_FILL_IN_THE_BLANK: "One fill-in-the-blank",
  TWO_FILL_IN_THE_BLANK: "Two fill-in-the-blank",
  THREE_FILL_IN_THE_BLANK: "Three fill-in-the-blank",
  PARAGRAPH_SELECTION: "Paragraph selections",
};

export const difficultyLevel = [
  { value: "hard", label: "Hard" },
  { value: "medium", label: "Medium" },
  { value: "easy", label: "Easy" },
];

export const slugSecretKey = {
  QUANTITATIVE_REASONING: "quantitative-reasoning",
  ANALYTICAL_WRITING: "analytical-writing",
};

export const QUESTION_TYPE = {
  PARAGRAPH_SENTENCE: "paragraph-sentence",
  FRACTIONAL_ENTRY: "fractionalEntry",
  NUMERICAL_ENTRY: "numericalEntry",
  QUANTITATIVE_COMPARISON: "quantitative-comparison",
};

export const initialAnswerMap: Record<string, IAnswerInput[]> = {
  singleSelection: [
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: null },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: null },
  ],
  multipleSelection: [
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: null },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: null },
  ],
  paragraph: [
    { answer_choice_id: null, option_text: "", is_correct: true, answer_group: null },
    { answer_choice_id: null, option_text: "", is_correct: true, answer_group: null },
  ],
  "paragraph-sentence": [
    { answer_choice_id: null, option_text: "", is_correct: true, answer_group: null },
  ],
  numericalEntry: [
    {
      answer_choice_id: null,
      option_text: "",
      is_correct: true,
      answer_group: null,
      answer_suffix: null,
      answer_prefix: null,
    },
  ],
  fractionalEntry: [
    { answer_choice_id: null, option_text: "", is_correct: true, answer_group: null },
    { answer_choice_id: null, option_text: "", is_correct: true, answer_group: null },
  ],
  oneFillInTheBlank: [
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 1 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 1 },
  ],
  twoFillInTheBlank: [
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 1 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 2 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 1 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 2 },
  ],
  threeFillInTheBlank: [
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 1 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 2 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 3 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 1 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 2 },
    { answer_choice_id: null, option_text: "", is_correct: false, answer_group: 3 },
  ],
};

export const NUMERICAL_ENTRY_GROUP = {
  prefix: "Prefix",
  suffix: "Suffix",
};
export const errorFields: Array<
  | "type"
  | "category"
  | "difficultyLevel"
  | "video"
  | "questionInstructions"
  | "question_text"
  | "questionGuidelines"
  | "passage_answer_instructions"
> = ["type", "category", "questionGuidelines", "questionInstructions", "video", "question_text"];
