import * as yup from "yup";

import { accessTypeConstants } from "@/constants/exam";

export const addStudentValidationSchema = yup.object().shape({
  first_name: yup
    .string()
    .required("First name is required")
    .max(80, "First name cannot be more than 80 characters")
    .test(
      "not-only-spaces",
      "First name can only contain letters",
      (value) => value?.trim().length > 0
    )
    .matches(/^[A-Za-z]+$/, "First name can only contain letters"),

  last_name: yup
    .string()
    .nullable()
    .max(80, "Last name cannot be more than 80 characters")
    .test(
      "not-only-spaces",
      "Last name can only contain letters",
      (value) => !value || value.trim().length > 0
    )
    .matches(/^[A-Za-z]*$/, "Last name can only contain letters"),
    
    email: yup
    .string()
    .required("Email is required")
    .email("Invalid email")
    .max(80, "Email cannot be more than 80 characters")
    .test(
      "no-spaces",
      "Email cannot contain spaces",
      (value) => !/\s/.test(value || "")
    ),

  subscription_status: yup
    .string()
    .required("Subscription status is required"),

  subscription_start_date: yup.date().nullable().when("subscription_status", {
    is: accessTypeConstants.PAID,
    then: (schema) =>
      schema.required("Subscription start date is required"),
    otherwise: (schema) => schema.nullable(),
  }),

  subscription_end_date: yup.date().nullable().when("subscription_status", {
    is: accessTypeConstants.PAID,
    then: (schema) =>
    schema
      .required("Subscription end date is required")
      .test(
        "endDate-after-startDate",
        "End date must be after start date",
        function (value) {
          const { subscription_start_date } = this.parent;
          if (!value || !subscription_start_date) return true;
          return new Date(value) > new Date(subscription_start_date);
        }
      ),
    otherwise: (schema) => schema.nullable(),
  }),
});
