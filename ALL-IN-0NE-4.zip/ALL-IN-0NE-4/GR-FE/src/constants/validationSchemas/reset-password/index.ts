import * as yup from "yup";
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const forgotPasswordValidationSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .matches(emailRegex, "Invalid email format"),
});

export const resetPasswordValidationSchema = yup.object().shape({
  newPassword: yup
    .string()
    .required("New password is required")
    .matches(/^\S*$/, "Password must not contain spaces"),

  confirmPassword: yup
    .string()
    .required("Confirm Password is required")
    .oneOf([yup.ref("newPassword")], "Passwords must match")
    .matches(/^\S*$/, "Password must not contain spaces"),
});