import * as yup from "yup";

export const addUserValidationSchema = yup.object().shape({
  first_name: yup
    .string()
    .required("First name is required")
    .max(80, "First name cannot be more than 80 characters")
    .test(
      "not-only-spaces",
      "First name can only contain letters",
      (value) => value?.trim().length > 0,
    )
    .matches(/^[A-Za-z]+$/, "First name can only contain letters"),

  last_name: yup
    .string()
    .nullable()
    .max(80, "Last name cannot be more than 80 characters")
    .test(
      "not-only-spaces",
      "Last name can only contain letters",
      (value) => !value || value.trim().length > 0,
    )
    .matches(/^[A-Za-z]*$/, "Last name can only contain letters"),

  email: yup
    .string()
    .required("Email is required")
    .email("Invalid email")
    .max(80, "Email cannot be more than 80 characters")
    .test("no-spaces", "Email cannot contain spaces", (value) => !/\s/.test(value || "")),

  role: yup
    .string()
    .required("Role is required")
    .oneOf(["Admin", "Instructor"], "Role is required"), // adjust options as needed
});
