import * as yup from "yup";

export const retentionDaysValidationSchema = yup.object().shape({
    free_user_retention_days: yup
      .number()
      .required("Free user retention days is required"),
    paid_user_retention_days: yup
      .number()
      .required("Paid user retention days is required"),
  });