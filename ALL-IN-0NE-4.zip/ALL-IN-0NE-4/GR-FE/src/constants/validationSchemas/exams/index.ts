import * as yup from "yup";

export const SECTION_SETTINGS_VALIDATION_SCHEMA = yup.object().shape({
  section_name: yup
    .string()
    .required("Section name is required")
    .min(5, "Section name must be at least 5 characters")
    .max(100, "Section name must not exceed 100 characters")
    .test(
      "not-only-spaces",
      "Section name cannot be only spaces",
      (value) => value?.trim().length > 0,
    )
    .matches(/^[a-zA-Z0-9\s]+$/, "Section name must contain only alphanumeric characters"),
  time_limit: yup
    .number()
    .typeError("Time limit must be a number")
    .required("Time limit is required")
    .test(
      "is-positive",
      "Time limit must be a positive number",
      (value) => value !== undefined && value >= 0,
    )
    .min(60, "Minimum value must be 60 second")
    .max(360000, "Max value should  not exceed 36000 seconds"),
  instructions: yup.string().test("is-not-empty", "Section instructions are required", (value) => {
    if (!value) return false;
    const stripped = value.replace(/<[^>]*>?/gm, "").trim();
    return stripped.length > 0;
  }),
});
