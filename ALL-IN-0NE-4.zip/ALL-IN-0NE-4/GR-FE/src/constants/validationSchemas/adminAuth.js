import * as yup from "yup";
/**
 * Validation schema for admin login
 */
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const loginValidationSchema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .test("no-spaces", "Email cannot contain spaces", (value) => !/\s/.test(value || ""))
    .matches(emailRegex, "Invalid email format"),
    
  password: yup
    .string()
    .required("Password is required")
    .test("no-spaces", "Password cannot contain spaces", (value) => !/\s/.test(value || "")),
});

export const sendOtpSchema = yup.object({
  email: yup.string().email("Invalid email format").required("Email is required"),
  partnerType: yup
    .string()
    .oneOf(["SmartWithHeart", "SherpaPrep"], "Partner Type must be one of the predefined options")
    .required("Partner Type is required"),
});

// 3) Verify‐OTP Schema (email + partnerType + 6-digit OTP)
export const otpSchema = yup.object({
  email: yup.string().email("Invalid email format").required("Email is required"),
  partnerType: yup
    .string()
    .oneOf(["SmartWithHeart", "SherpaPrep"], "Partner Type must be one of the predefined options")
    .required("Partner Type is required"),
  otp: yup
    .string()
    .matches(/^\d{6}$/, "OTP must be exactly 6 digits")
    .required("OTP is required"),
});

/**
 * Validation schema for admin profile update
 */
export const updateProfileValidationSchema = yup.object().shape({
  first_name: yup
    .string()
    .required("First name is required")
    .max(80, "First name should not exceed 80 characters.")
    .min(2, "First name must be at least 2 characters.")
    .test(
      "not-only-spaces",
      "First name can only contain letters",
      (value) => value?.trim().length > 0,
    )
    .matches(/^[A-Za-z]+$/, "First name can only contain letters"),

  email: yup
    .string()
    .email("Invalid email")
    .required("Email is required")
    .test("not-only-spaces", "Email can only contain letters", (value) => value?.trim().length > 0)
    .max(254, "Email cannot be more than 254 characters")
    .test("no-spaces", "Email cannot contain spaces", (value) => !/\s/.test(value || ""))
    .test("valid-domain", "Email must contain a valid domain (e.g., .com, .net)", (value) => {
      const domainRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return domainRegex.test(value || "");
    })
    .test("local-part-length", "The part before @ must be 80 characters", (value) => {
      if (!value || !value.includes("@")) return true; // let other tests catch invalid formats
      const localPart = value.split("@")[0];
      return localPart.length <= 80;
    }),
});

export const changePasswordValidationSchema = yup.object().shape({
  currentPassword: yup.string().required("Current password is required"),
  newPassword: yup
    .string()
    .required("New password is required")
    .min(8, "Password must be at least 8 characters")
    .max(18, "Password cannot be more than 18 characters")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*[\W_]).{8,18}$/,
      "Password must contain at least one uppercase letter, one lowercase letter, and one special character",
    )
    .test(
      "not-same-as-current",
      "New password must be different from current password",
      function (value) {
        return value !== this.parent.currentPassword;
      },
    ),
  confirmNewPassword: yup
    .string()
    .required("Please enter confirm password")
    .test("passwords-match", "Passwords do not match", function (value) {
      return this.parent.newPassword === value;
    }),
});

/**
 * Validation schema for adding questions
 */
export const addQuestionValidationSchema = yup.object().shape({
  type: yup.string().required("Question Type is required"),
  category: yup.string().required("Category is required"),
  difficultyLevel: yup.string().required("Difficulty level is required"),
  video: yup.string(),
  // .url("Invalid URL format")
  // .required("Explanation video URL is required"),
  // .optional().allow(null)
  questionGuidelines: yup.string().required("Question Guidelines is required"),
  questionInstructions: yup.string().required("Question Instructions is required"),
  question_text: yup.string().required("Question is required"),
});

export const addAnalyticalWritingSchema = yup.object().shape({
  questionGuidelines: yup.string().required("Question Guidelines is required"),
  questionInstructions: yup.string().required("Question Instructions is required"),
  video: yup.string(),
  // .url("Invalid URL format")
  // .required("Explanation video URL is required"),
  // .optional().allow(null)
});

/**
 * Validation schema for adding or updating exams
 */
export const addExamValidationSchema = yup.object().shape({
  examName: yup
    .string()
    .required("Exam name is required")
    .test("not-only-spaces", "Exam name cannot be only spaces", (value) =>
      value ? value.trim().length > 0 : false,
    )
    .min(5, "Exam name must be at least 5 characters")
    .max(250, "Exam name must be less than 250 characters"),
  accessType: yup.string().required("Access type is required"),
  guidelines: yup
    .string()
    .test("not-empty", "Guidelines & Instructions are required", (value) => {
      if (!value) return false;
      const tempElement = document.createElement("div");
      tempElement.innerHTML = value;
      const textContent = tempElement.textContent || tempElement.innerText || "";
      return textContent.trim().length > 0;
    })
    .required("Guidelines & Instructions are required"),
  penaltyQuant: yup
    .number()
    .typeError("Penalty Per Mistake Quant is required") // when not a number or empty
    .required("Penalty Per Mistake Quant is required")
    .min(0.5, "Penalty Per Mistake Quant must be at least 0.5")
    .max(2.0, "Penalty Per Mistake Quant cannot be greater than 2.0"),

  penaltyVerbal: yup
    .number()
    .typeError("Penalty Per Mistake Verbal is required")
    .required("Penalty Per Mistake Verbal is required")
    .min(0.5, "Penalty Per Mistake Verbal must be at least 0.5")
    .max(2.0, "Penalty Per Mistake Verbal cannot be greater than 2.0"),
});

export const dateRangeValidationSchema = yup.object().shape({
  startDate: yup.date().nullable().required("Start date is required"),
  endDate: yup
    .date()
    .nullable()
    .when("startDate", (startDate, schema, { context }) => {
      if (context?.useRange && startDate) {
        return schema.required("End date is required");
      }
      return schema;
    }),
});

export const scoreValidationSchema = yup.object().shape({
  score: yup
    .number()
    .required("Score is required")
    .min(0, "Score cannot be less than 0")
    .max(6, "Score cannot be greater than 6"),
});
