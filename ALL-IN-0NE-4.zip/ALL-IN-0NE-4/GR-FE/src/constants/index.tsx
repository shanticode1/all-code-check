export const USER_ROLE = {
  STUDENT: "Student",
  SUPERADMIN: "SuperAdmin",
  ADMIN: "Admin",
  INSTRUCTOR: "Instructor",
};

export const MAX_FILE_SIZE_LIMIT = 5; // 5 MB  5 * 1024 * 1024
export const ALLOWED_FILE_TYPES = [".csv", ".xlsx", ".xls"];
export const INVALID_FILE_TYPE = "Invalid file type, only allows accepted file formats";
export const INVALID_FILE_XLSX_XLS_CSV = "Invalid File Type, Only allows xlsx, xls, or csv";
export const BYTES_PER_KILOBYTE = 1024;
export const FILE_SIZE_LIMIT_EXCEEDS = "";
export const FILE_CHUNK_LIMIT = 500;
export const MAX_LENGTH = 80;

export const USERS_COLUMNS = [
  "First Name",
  "Email",
  "Subscription Status",
  "Subscription Start Date",
  "Subscription End Date",
];
export const IGNORE_FIELDS = [
  "First Name",
  "Last Name",
  "Subscription Status",
  "Partner Type",
  "Subscription Start Date",
  "Subscription End Date",
];

export const USER_HEADS_TEXT = [
  "First Name",
  "Last Name",
  "Email",
  "Subscription Status",
  "Subscription Start Date",
  "Subscription End Date",
];
export const commonButtons = {
  student: "Student",
  user: "User",
};

export const subscriptionStatus = ["Free", "Paid"];
export const roles = ["Admin", "Instructor"];

export const status = {
  active: "ACTIVE",
  inactive: "INACTIVE",
};

export const END_SECTION_MODAL = `
      <p>You have reached the end of this section. You have time remaining to review. As long as there is time remaining, you can check your work. Once you leave this section, you <strong>WILL NOT</strong> be able to return to it.</p>
      <p>Select <strong>Review</strong> to go back to the Review screen.</p>
      <p>Select <strong>Previous</strong> to go to the last question in this section.</p>
      <p>Select <strong>Confirm</strong> to proceed to the next section of the test.</p>
    `;

// upload const

export const UPLOAD_STEPS =
  " To upload bulk Student data via Excel or CSV, please follow these steps:";

export const TEMPLATE_UPLOAD_INSTRUCTIONS = [
  "Download the template format by clicking the button below.",
  "Open the template file and fill the required data into the designated columns.",
  "Ensure all specific field data is correctly filled.",
  "Save the file once all data has been added. You can then proceed with the upload process using this completed template.",
];

export const TEMPLATE_UPLOAD_NOTES = [
  "Please do not change the sheet format, column sequence or row index. The system only accepts data in the defined format.",
  "If you're experiencing issues with the CSV file, please upload the data in an XLSX sheet instead.",
];

export const REQUIRED_DATA_NOTE = "Required data in the file to be uploaded:";

export const REQUIRED_DATA_INFO_UPLOAD_STUDENT = [
  {
    label: "First Name",
    description: "The Student first name is required. Eg: John.",
  },
  {
    label: "Last Name",
    description: "The Student Last name. Eg: Smith (Last Name is optional and can be left blank).",
  },
  {
    label: "Subscription Status",
    description: "The Subscription Status must be in the format of Paid/Free and is required.",
  },
  {
    label: "Subscription Start Date",
    description:
      "The Subscription Start Date must be in the format of YYYY-MM-DD and is required. Eg: 2025-01-21",
  },
  {
    label: "Subscription End Date",
    description:
      "The Subscription End Date must be in the format of YYYY-MM-DD and is required. Eg: 2025-01-21",
  },
  {
    label: "Email",
    description: "The student email should be unique and a valid email. Eg: Jsmith@example.com",
  },
];

export const INVALID_DATE_RANGE_ERROR = (rows: number[]) =>
  `Invalid date range in row(s): ${rows.join(", ")}. Subscription end date must be greater than subscription start date.`;

export const PARTNER_TYPE = {
  SMART_WITH_HEART: "SmartWithHeart",
  SHERPA_PREP: "SherpaPrep",
};

export const SINGLE_QUESTION_TYPES = ["singleSelection", "quantitative-comparison"];

export const QUESTION_LAYOUT = {
  LEFTTORIGHT: "LEFTTORIGHT",
  TOPTOBOTTOM: "TOPTOBOTTOM",
}

export const CLIPBOARD_ACTION = {
  COPY: "Copy",
  CUT: "Cut",
  PASTE: "Paste",
  UNDO: "Undo",
  REDO: "Redo",
}

export const allowedKeys = ["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"];

export const LOCAL_VARIABLE = {
  Hide: "Hide",
  Show: "Show",
  General: "General",
  Section: "Section"
}