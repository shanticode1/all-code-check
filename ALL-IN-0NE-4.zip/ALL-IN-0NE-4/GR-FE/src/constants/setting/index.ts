export const Days = [
  { value: "31", label: "31" },
  { value: "180", label: "180" },
  { value: "365", label: "365" },
];
