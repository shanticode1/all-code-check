export const paginationConstants = {
  limit: 10,
  page: 1,
  search: "",
  offset: 0,
  totalPages: 0,
  totalRecords: 0,
};

export const roles = {
  SUPERADMIN: "SuperAdmin",
  STUDENT: "Student",
  ADMIN: "Admin",
  INSTRUCTOR: "Instructor",
};
export const pageSizes = ["10", "20", "50", "100"];
