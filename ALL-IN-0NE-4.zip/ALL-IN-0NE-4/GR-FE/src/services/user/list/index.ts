import { IGetUserListPagination, IUserListResponse } from "@/types/User";
import { IAddUser } from "@/types/User/Details";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

interface IGetUserDetail {
  data?: {
    first_name: string;
    last_name: string;
    email: string;
    user_id: number;
  };
}
export class ListService {
  async getAllUser(params: IGetUserListPagination): Promise<IUserListResponse> {
    return http.get(API_ENDPOINTS.USER, { params });
  }
  async getUserById(id: string): Promise<IGetUserDetail> {
    return http.get(`${API_ENDPOINTS.USER}/${id}`);
  }
  async updateUser(id: number | undefined, payload: IAddUser): Promise<IAddUser> {
    if (id) {
      return http.put(`${API_ENDPOINTS.USER}/${id}`, payload);
    } else {
      return http.post(`${API_ENDPOINTS.USER}`, payload);
    }
  }
  async deleteUser(id: number): Promise<IGetUserDetail> {
    return http.delete(`${API_ENDPOINTS.USER}/${id}`);
  }
}
