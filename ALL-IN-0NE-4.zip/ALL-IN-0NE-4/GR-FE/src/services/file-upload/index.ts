import axios from "axios";

import {
  // IFileUploadPayload,
  IPresignedUploadFields,
  IPresignedUploadInfo,
  IPresignedUploadResponse,
  IUploadedAsset,
  IUploadImageInput,
} from "@/types/file-upload";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

type UnknownRecord = Record<string, unknown>;

const pickString = (source: UnknownRecord, keys: string[]): string | undefined => {
  for (const key of keys) {
    const value = source[key];
    if (typeof value === "string" && value.trim()) {
      return value;
    }
  }
  return undefined;
};

const toStringRecord = (value: unknown): IPresignedUploadFields | undefined => {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return undefined;
  }

  const entries = Object.entries(value as Record<string, unknown>);
  if (!entries.length) return undefined;

  const record: IPresignedUploadFields = {};
  for (const [key, val] of entries) {
    if (typeof val === "string") {
      record[key] = val;
    }
  }

  return Object.keys(record).length ? record : undefined;
};

const stripContentTypeHeader = (headers?: IPresignedUploadFields) => {
  if (!headers) return undefined;
  const copy = { ...headers };
  delete copy["Content-Type"];
  delete copy["content-type"];
  return Object.keys(copy).length ? copy : undefined;
};

const ensureContentTypeHeader = (
  headers: IPresignedUploadFields | undefined,
  contentType: string,
) => {
  const normalized: IPresignedUploadFields = { ...(headers ?? {}) };
  if (!normalized["Content-Type"] && !normalized["content-type"]) {
    normalized["Content-Type"] = contentType;
  }
  return normalized;
};

export class FileUploadService {
  async getPresignedUrl(formData: FormData): Promise<IPresignedUploadResponse> {
    return http.post(API_ENDPOINTS.FILE_UPLOAD, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  }

  private normalizePresignedData(response: IPresignedUploadResponse): IPresignedUploadInfo {
    const responseRecord = (response ?? {}) as UnknownRecord;
    const dataRecord =
      responseRecord.data &&
      typeof responseRecord.data === "object" &&
      !Array.isArray(responseRecord.data)
        ? (responseRecord.data as UnknownRecord)
        : undefined;
    const raw = dataRecord ? { ...responseRecord, ...dataRecord } : responseRecord;

    const uploadUrl = pickString(raw, [
      "upload_url",
      "uploadUrl",
      "url",
      "presigned_url",
      "presignedUrl",
    ]);

    if (!uploadUrl) {
      throw new Error("Presigned upload URL not found in response.");
    }

    const fields = toStringRecord(raw["fields"] ?? raw["form_fields"] ?? raw["formFields"]);
    const headers = toStringRecord(raw["headers"] ?? raw["upload_headers"] ?? raw["uploadHeaders"]);

    const fileUrl = pickString(raw, [
      "file_url",
      "fileUrl",
      "public_url",
      "publicUrl",
      "asset_url",
      "assetUrl",
    ]);

    const key =
      pickString(raw, ["key", "object_key", "objectKey"]) ??
      (fields?.key && typeof fields.key === "string" ? fields.key : undefined);

    return {
      uploadUrl,
      fields,
      headers,
      fileUrl,
      key,
    };
  }

  private async uploadToS3({
    uploadUrl,
    fields,
    headers,
    file,
    contentType,
  }: {
    uploadUrl: string;
    fields?: IPresignedUploadFields;
    headers?: IPresignedUploadFields;
    file: Blob;
    contentType: string;
  }): Promise<void> {
    const hasFields = fields && Object.keys(fields).length > 0;

    if (hasFields) {
      const formData = new FormData();
      Object.entries(fields).forEach(([key, value]) => {
        formData.append(key, value);
      });
      formData.append("file", file);

      await axios.post(uploadUrl, formData, {
        headers: stripContentTypeHeader(headers),
      });

      return;
    }

    await axios.put(uploadUrl, file, {
      headers: ensureContentTypeHeader(
        headers,
        contentType || file.type || "application/octet-stream",
      ),
    });
  }

  private deriveFileUrl(info: IPresignedUploadInfo): string | undefined {
    if (info.fields?.key) {
      const base = info.uploadUrl.replace(/\/$/, "");
      const key = info.fields.key.replace(/^\/+/, "");
      return `${base}/${key}`;
    }

    return info.uploadUrl.split("?")[0];
  }

  async uploadImage(input: IUploadImageInput): Promise<IUploadedAsset> {
    const formData = new FormData();

    formData.append("fileName", input.fileName);
    formData.append("fileType", input.contentType);
    formData.append("fileSize", String(input.fileSize));

    if (input.file) {
      formData.append("file", input.file, input.fileName);
    }
    const uploadedFile = await this.getPresignedUrl(formData);

    // const presigned = this.normalizePresignedData(presignedResponse);
    // await this.uploadToS3({
    //   uploadUrl: presigned.uploadUrl,
    //   fields: presigned.fields,
    //   headers: presigned.headers,
    //   file: input.file,
    //   contentType: input.contentType,
    // });
    const url = uploadedFile?.data?.fileUrl;
    return {
      url,
      fileName: input.fileName,
      // key: presigned.key,
    };
  }
}
