import { IExamResponse, IQuestionResponse, IRequestedPayloadQuestion } from "@/types/Exam/index";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class SectionQuestionsService {
  async updateSectionQuestions(
    question_id?: number,
    payload?: IRequestedPayloadQuestion,
  ): Promise<IExamResponse> {
    return http.put(`${API_ENDPOINTS.QUESTIONS}/${question_id}`, payload);
  }

  async updateSectionOrder(exam_id: number, payload: IQuestionResponse): Promise<IExamResponse> {
    return http.put(`${API_ENDPOINTS.EXAM_SECTION_ORDER}/${exam_id}`, payload);
  }
}
