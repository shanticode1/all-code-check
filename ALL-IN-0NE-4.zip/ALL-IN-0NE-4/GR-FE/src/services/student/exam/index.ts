import { USER_ROLE } from "@/constants";
import {
  IAnswerChoicesSubmitPayload,
  IExamResponse,
  IExamsListResponse,
  IExamTimeUpdatePayload,
  IQuestionTimeTakenPayload,
  IStartExamResponse,
} from "@/types/Exam/index";
import {
  IExamExitPayload,
  IExamExitTimerUpdatePayload,
  IQuestionMarkedPayload,
} from "@/types/Exam/Preview";
import { IStartExamRequestPayload } from "@/types/Exam/StartExam";
import { IGetStudentExamDetailPayload, IGetStudentExamPayload } from "@/types/Student";
import { IExamHistoryResponse } from "@/types/Student/Exam";
import { IQuestionPayload, IQuestionResponses } from "@/types/Student/ViewQuestion";
import { API_ENDPOINTS } from "@/utils/endpoints";
import httpJson, { httpJsonV2 } from "@/utils/protocol/http";

export class ExamService {
  async getAll(): Promise<IExamsListResponse> {
    return httpJsonV2.get(API_ENDPOINTS.EXAM);
  }

  async getById(id: string, role: string): Promise<IExamResponse> {
    return role === USER_ROLE.STUDENT
      ? httpJsonV2.get(API_ENDPOINTS.EXAM_DETAIL.replace(":examId", id.toString()))
      : httpJson.get(API_ENDPOINTS.EXAM_DETAIL.replace(":examId", id.toString()));
  }

  async startExam({
    id,
    is_terms_conditions_accepted,
  }: IStartExamRequestPayload): Promise<IStartExamResponse> {
    return httpJsonV2.patch(`${API_ENDPOINTS.EXAM_START}/${id}`, { is_terms_conditions_accepted });
  }

  async examTimerUpdate({ sectionId, time_taken }: IExamTimeUpdatePayload) {
    return httpJsonV2.put(`${API_ENDPOINTS.EXAM_SECTION_UPDATE}/${sectionId}`, {
      time_taken,
    });
  }

  async examSectionComplete(sectionId: number | unknown): Promise<IStartExamResponse> {
    return httpJsonV2.patch(`${API_ENDPOINTS.EXAM_SECTION_COMPLETE}/${sectionId}`);
  }

  async examAnswerSubmit(params: IAnswerChoicesSubmitPayload): Promise<IStartExamResponse> {
    return httpJsonV2.post(`${API_ENDPOINTS.EXAM_ANSWER_CHOICE_SUBMIT}`, {
      ...params,
    });
  }

  async getAllStudentExam({
    role,
    ...params
  }: IGetStudentExamPayload): Promise<IExamHistoryResponse> {
    return role === USER_ROLE.STUDENT
      ? httpJsonV2.get(API_ENDPOINTS.STUDENT_ALL_EXAM, { params })
      : httpJson.get(`${API_ENDPOINTS.STUDENT_ALL_EXAM}`, { params });
  }

  async getStudentExamDetails({
    id,
    role,
  }: IGetStudentExamDetailPayload): Promise<IExamHistoryResponse> {
    return role === USER_ROLE.STUDENT
      ? httpJsonV2.get(`${API_ENDPOINTS.STUDENT_ALL_EXAM}/${id}`)
      : httpJson.get(`${API_ENDPOINTS.STUDENT_ALL_EXAM}/${id}`);
  }

  async getQuestionById({
    questionId,
    role,
    ...params
  }: IQuestionPayload): Promise<IQuestionResponses> {
    return role === USER_ROLE.STUDENT
      ? httpJsonV2.get(`${API_ENDPOINTS.EXAM_QUESTIONS_STUDENT_QUESTION}/${questionId}`, { params })
      : httpJson.get(`${API_ENDPOINTS.EXAM_QUESTIONS_STUDENT_QUESTION}/${questionId}`, { params });
  }

  async questionTimeTaken({ questionId, ...params }: IQuestionTimeTakenPayload) {
    httpJsonV2.patch(
      `${API_ENDPOINTS.EXAM_QUESTION_TIME_TAKEN.replace(":student_question_id", questionId.toString())}`,
      {
        ...params,
      },
    );
  }

  async updateQuestionMarkStatus({ questionId, ...params }: IQuestionMarkedPayload): Promise<void> {
    return httpJsonV2.put(
      `${API_ENDPOINTS.EXAM_QUESTION_MARKED_UPDATE.replace(":student_question_id", questionId.toString())}`,
      {
        ...params,
      },
    );
  }

  async scheduleExit(params: IExamExitPayload): Promise<void> {
    return httpJsonV2.post(`${API_ENDPOINTS.EXAM_SCHEDULE_EXIT}`, { ...params });
  }

  async cancelExit(params: IExamExitPayload): Promise<void> {
    return httpJsonV2.post(`${API_ENDPOINTS.EXAM_CANCEL_EXIT}`, { ...params });
  }

  async examExitTimerUpdate({ student_exam_id, ...params }: IExamExitTimerUpdatePayload) {
    httpJsonV2.patch(
      `${API_ENDPOINTS.EXAM_EXIT_UPDATE_TIMER.replace(":student_exam_id", student_exam_id.toString())}`,
      {
        ...params,
      },
    );
  }
}
