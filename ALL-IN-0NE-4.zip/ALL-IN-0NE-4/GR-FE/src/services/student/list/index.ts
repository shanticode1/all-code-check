import { IExamResponse } from "@/types/Exam/index";
import { UserSubscription } from "@/types/Profile";
import { ICsvDownloadResponse, IDownloadCsv, IGetStudentListPagination, IStudentListResponse } from "@/types/Student";
import { IAddStudent } from "@/types/Student/Details";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http, { httpJsonV2 } from "@/utils/protocol/http";

interface IGetStudentDetail {
  data?: {
    first_name: string;
    last_name: string;
    email: string;
    user_id: number;
  };
}
export class ListService {
  async getAll(): Promise<IExamResponse> {
    return httpJsonV2.get(API_ENDPOINTS.EXAM);
  }
  async getAllStudent(params: IGetStudentListPagination): Promise<IStudentListResponse> {
    return http.get(API_ENDPOINTS.STUDENTS, { params });
  }
  async getStudentById(id: string): Promise<IGetStudentDetail> {
    return http.get(`${API_ENDPOINTS.STUDENTS}/${id}`);
  }

  async importStudents(payload: UserSubscription[]): Promise<IStudentListResponse> {
    return http.post(API_ENDPOINTS.UPLOAD, { file: payload });
  }

  async updateStudent(id: number | undefined, payload: IAddStudent): Promise<IAddStudent> {
    if (id) {
      return http.put(`${API_ENDPOINTS.STUDENTS}/${id}`, payload);
    } else {
      return http.post(`${API_ENDPOINTS.STUDENTS}`, payload);
    }
  }
  async deleteStudent(id: number): Promise<IGetStudentDetail> {
    return http.delete(`${API_ENDPOINTS.STUDENTS}/${id}`);
  }

  async downloadCsvFile(payload: IDownloadCsv): Promise<ICsvDownloadResponse> {    
    return http.post(API_ENDPOINTS.EXAM_FILE_DOWNLOAD, payload);
  }
}
