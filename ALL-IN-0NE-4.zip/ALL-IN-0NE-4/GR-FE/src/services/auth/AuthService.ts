import {
  ILoginFormValues,
  ILoginResponse,
  IRefreshTokenPayload,
  IRefreshTokenResponse,
} from "@/types/Login";
import {
  IOTPResponse,
  IUpdatePassword,
  IUpdateProfilePayload,
  IUpdateProfileResponse,
} from "@/types/Profile";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class AuthService {
  async login(payload: ILoginFormValues): Promise<ILoginResponse> {
    return http.post(API_ENDPOINTS.LOGIN, payload);
  }

  async logout(): Promise<void> {
    return;
  }

  async refreshToken(payload: IRefreshTokenPayload): Promise<IRefreshTokenResponse> {
    return http.post(API_ENDPOINTS.REFRESH, payload);
  }

  async getCurrentUser(): Promise<ILoginResponse> {
    return http.get(API_ENDPOINTS.ME);
  }

  async updateProfile(payload: IUpdateProfilePayload): Promise<IUpdateProfileResponse> {
    return http.put(API_ENDPOINTS.UPDATE_PROFILE, payload);
  }
  async updatePassword(payload: IUpdatePassword): Promise<IUpdateProfileResponse> {
    return http.post(API_ENDPOINTS.CHANGE_PASSWORD, payload);
  }

  async sendOtp(payload: { email: string; partnerType: string }): Promise<IOTPResponse> {
    return http.post(API_ENDPOINTS.SEND_OTP, payload);
  }

  async verifyOtp(payload: {
    email: string;
    partnerType: string;
    otp: string;
  }): Promise<IOTPResponse> {
    return http.post(API_ENDPOINTS.VERIFY_OTP, payload);
  }
}
