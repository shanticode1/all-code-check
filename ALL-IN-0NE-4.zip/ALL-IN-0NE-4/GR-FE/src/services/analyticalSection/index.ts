import {
  IAnalytialSectionDataResponse,
  IAnalyticalPayload,
  IAnalyticalScorePayload,
} from "@/types/analyticalSection";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class AnalyticalSectionService {
  async getAnalytical(params: IAnalyticalPayload): Promise<IAnalytialSectionDataResponse> {
    return http.get(API_ENDPOINTS.EXAM_SECTION_ANALYTICAL_WRITING, {
      params,
    });
  }

  async updateScore({
    examSectionId,
    ...params
  }: IAnalyticalScorePayload): Promise<IAnalytialSectionDataResponse> {
    return http.put(`${API_ENDPOINTS.STUDENT_UPDATE_TOTAL_SCORE}/${examSectionId}`, {
      ...params,
    });
  }
}
