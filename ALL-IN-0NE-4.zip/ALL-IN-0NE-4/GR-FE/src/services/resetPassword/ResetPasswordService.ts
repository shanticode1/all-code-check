import { IForgotPasswordFormValues, IForgotPasswordResponse, IResetPasswordPayload, IResetPasswordResponse } from "@/types/Login";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class ResetPasswordService {
  async forgotPassword(payload: IForgotPasswordFormValues): Promise<IForgotPasswordResponse> {
    return http.post(API_ENDPOINTS.FORGOT_PASSWORD, payload);
  }
  async resetPassword(payload: IResetPasswordPayload): Promise<IResetPasswordResponse> {
    return http.post(API_ENDPOINTS.RESET_PASSWORD, payload);
  }
}
