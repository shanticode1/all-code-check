import { ICategoryQueryParams } from "@/types/Exam/Category";
import { ICategoryQuestionResponse } from "@/types/Exam/index";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class CategoryService {
  async getAll(params: ICategoryQueryParams): Promise<ICategoryQuestionResponse> {
    return http.get(API_ENDPOINTS.CATEGORY, { params });
  }
}
