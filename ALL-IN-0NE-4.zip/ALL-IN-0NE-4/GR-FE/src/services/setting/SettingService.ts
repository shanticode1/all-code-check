import { IRetentionDays, IRetentionSettingResponse } from "@/types/setting";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class SettingService {
  async add(payload: IRetentionDays): Promise<IRetentionSettingResponse> {
    return http.post(API_ENDPOINTS.RETENTION, payload);
  }

  async update(retentionId: number, payload: IRetentionDays): Promise<IRetentionSettingResponse> {
    return http.put(`${API_ENDPOINTS.RETENTION}/${retentionId}`, payload);
  }

  async get(): Promise<IRetentionSettingResponse> {
    return http.get(`${API_ENDPOINTS.RETENTION}`);
  }
}
