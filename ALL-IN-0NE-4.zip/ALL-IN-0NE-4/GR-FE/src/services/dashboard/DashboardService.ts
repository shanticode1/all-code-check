import { IDashboardSummary } from "@/types/Dashboard";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class DashboardService {
    async getSummary(): Promise<IDashboardSummary> {
        return http.get(API_ENDPOINTS.DASHBOARD_SUMMARY);
    }
    async getReports(params: { filter: string }): Promise<IDashboardSummary> {
        return http.get(API_ENDPOINTS.DASHBOARD_REPORTS,  { params });
    }
}
