import {
  IAddExam,
  IExamQueryParams,
  IExamQuestionResponse,
  IExamResponse,
  IQuestionQueryParams,
} from "@/types/Exam/index";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http from "@/utils/protocol/http";

export class ExamService {
  async add(payload: IAddExam): Promise<IExamResponse> {
    return http.post(API_ENDPOINTS.EXAM, payload);
  }

  async updateExam(exam_id: number, payload: IAddExam): Promise<IExamResponse> {
    return http.put(`${API_ENDPOINTS.EXAM}/${exam_id}`, payload);
  }
  
  async updateExamStatus(exam_id: number, payload: IAddExam): Promise<IExamResponse> {
    return http.patch(`${API_ENDPOINTS.EXAM_STATUS}/${exam_id}`, payload);
  }

   async deleteAndDeactivateExam(id: number): Promise<IExamResponse> {
    return http.delete(`${API_ENDPOINTS.EXAM}/${id}`);
  }

  async copyExam(id: number): Promise<IExamResponse> {
    return http.post(`${API_ENDPOINTS.COPY_EXAM}/${id}`);
  }

  async getAll(params: IExamQueryParams): Promise<IExamResponse> {
    return http.get(API_ENDPOINTS.EXAM, { params });
  }

  async getById(exam_id: number | undefined): Promise<IExamResponse> {
    return http.get(`${API_ENDPOINTS.EXAM}/${exam_id}`);
  }

  async getQuestionById({
    exam_id,
    section_id,
    question_id,
  }: IQuestionQueryParams): Promise<IExamQuestionResponse> {
    return http.get(
      `${API_ENDPOINTS.QUESTIONS}${API_ENDPOINTS.EXAM}/${exam_id}/sections/${section_id}/questions/${question_id}`,
    );

    // Uncomment and implement the logic to return a question object
    // return {
    //   id: question_id ?? 0,
    //   type: "singleSelection",
    //   category: "readingLonger",
    //   difficultyLevel: "medium",
    //   video: "https://example.com/video",
    //   question: "What is the capital of France?",
    // };
  }
}
