import { USER_ROLE } from "@/constants";
import {
  IPreviewSectionPayload,
  ISection,
  ISectionResponse,
  IViewQuestionPayload,
} from "@/types/Exam/index";
import { IQuestionExplanationVideoPayload } from "@/types/Exam/Preview";
import { API_ENDPOINTS } from "@/utils/endpoints";
import http, { httpJsonV2 } from "@/utils/protocol/http";

export class ExamSectionService {
  async updateSection(section_id: number, payload: ISection): Promise<ISectionResponse> {
    return http.put(`${API_ENDPOINTS.EXAM_SECTION}/${section_id}`, payload);
  }

  async updateSectionOrder(exam_id: number, payload: ISection): Promise<ISectionResponse> {
    return http.put(`${API_ENDPOINTS.EXAM_SECTION_ORDER}/${exam_id}`, payload);
  }

  async getAllQuestionsBySectionId({
    sectionId,
    role,
  }: IPreviewSectionPayload): Promise<ISectionResponse> {
    return role === USER_ROLE.STUDENT
      ? httpJsonV2.get(`${API_ENDPOINTS.EXAM_SECTION}/${sectionId}`)
      : http.get(`${API_ENDPOINTS.EXAM_SECTION}/${sectionId}`);
  }

  async getQuestionsById({ questionId, role }: IViewQuestionPayload): Promise<ISectionResponse> {
    return role === USER_ROLE.STUDENT
      ? httpJsonV2.get(`${API_ENDPOINTS.EXAM_QUESTION}/${questionId}`)
      : http.get(`${API_ENDPOINTS.EXAM_QUESTION}/${questionId}`);
  }

  async getQuestionsBySection({
    sectionSlug,
  }: IQuestionExplanationVideoPayload): Promise<ISectionResponse> {
    return http.get(`${API_ENDPOINTS.EXAM_SECTION_VIDEO}/${sectionSlug}`);
  }
}
