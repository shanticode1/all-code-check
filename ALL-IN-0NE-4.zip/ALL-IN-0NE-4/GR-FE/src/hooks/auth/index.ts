import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";
import { usePathname } from "next/navigation";

import { useAuth } from "@/lib/Contexts/AuthProvider";
import { AuthService } from "@/services/auth/AuthService";
import { ILoginFormValues, ILoginResponse } from "@/types/Login";
import { IUpdatePassword, IUpdateProfilePayload } from "@/types/Profile";
import UtilCookieService from "@/utils/tools/cookie-service";
import UtilLocalService from "@/utils/tools/localstorage";
import { getInitialState, setInitialState } from "@/utils/tools/token-service";

const PUBLIC_ROUTES = ["/login"];

const auth = new AuthService();

const AUTH_KEY = {
  CURRENT_USER: "currentUser",
};

export const useCurrentUserQuery = () => {
  const pathname = usePathname();
  const token = getInitialState("token");

  const isPublicRoute = PUBLIC_ROUTES.includes(pathname);
  const shouldFetch = !!token && !isPublicRoute;

  return useQuery({
    queryKey: [AUTH_KEY.CURRENT_USER],
    queryFn: () => auth.getCurrentUser(),
    enabled: shouldFetch,
    refetchOnWindowFocus: false,
  });
};

export const useLoginMutation = (): UseMutationResult<ILoginResponse, Error, ILoginFormValues> => {
  const { authorize } = useAuth();
  return useMutation({
    mutationFn: (input: ILoginFormValues) => auth.login(input),

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    onSuccess: async (data: any) => {
      UtilLocalService.removeLocalStorage("token");
      UtilLocalService.setLocalStorage("token", data?.data?.token);
      UtilCookieService.setCookie("token", data?.data?.token);
      UtilCookieService.setCookie("role", data?.data?.role);
      setInitialState(data.data);
      authorize(data.data);
    },
    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useLogoutMutation = () => {
  const { unauthorize } = useAuth();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => auth.logout(),
    onSuccess: async () => {
      unauthorize();
      UtilLocalService.removeLocalStorage("token");
      UtilCookieService.removeCookie("token");
      UtilCookieService.removeCookie("role");
      queryClient.clear();
    },
  });
};

export const useUpdateProfileMutation = (): UseMutationResult<
  Awaited<ReturnType<typeof auth.updateProfile>>,
  Error,
  { payload: IUpdateProfilePayload; token: string }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ payload }) => auth.updateProfile(payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [AUTH_KEY.CURRENT_USER] });
    },
    onError: (error) => {
      console.error("Failed to update profile:", error);
    },
  });
};

export const useUpdatePasswordMutation = (): UseMutationResult<
  Awaited<ReturnType<typeof auth.updatePassword>>,
  Error,
  { payload: IUpdatePassword; token: string }
> => {
  return useMutation({
    mutationFn: ({ payload }) => auth.updatePassword(payload),
    onError: (error) => {
      console.error("Failed to update profile:", error);
    },
  });
};

export const useSendOtpMutation = (): UseMutationResult<
  Awaited<ReturnType<typeof auth.sendOtp>>,
  Error,
  { email: string; partnerType: string }
> => {
  return useMutation({
    mutationFn: ({ email, partnerType }) => auth.sendOtp({ email, partnerType }),
    onError: (error) => {
      console.error("Failed to send OTP:", error);
    },
  });
};

export const useVerifyOtpMutation = (): UseMutationResult<
  Awaited<ReturnType<typeof auth.verifyOtp>>,
  Error,
  { email: string; partnerType: string; otp: string }
> => {
  const { authorize } = useAuth();
  return useMutation({
    mutationFn: ({ email, partnerType, otp }) => auth.verifyOtp({ email, partnerType, otp }),
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    onSuccess: (data: any) => {
      UtilLocalService.removeLocalStorage("token");
      UtilLocalService.setLocalStorage("token", data?.data?.token);
      UtilCookieService.setCookie("token", data?.data?.token);
      UtilCookieService.setCookie("role", data?.data?.role);
      setInitialState(data.data);
      authorize(data.data);
    },
    onError: (error) => {
      console.error("Failed to verify OTP:", error);
    },
  });
};
