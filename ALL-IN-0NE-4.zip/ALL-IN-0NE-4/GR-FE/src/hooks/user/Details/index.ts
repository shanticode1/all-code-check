import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { USER_ROLE } from "@/constants";
import { ListService } from "@/services/user/list";
import { IGetUserDetail } from "@/types/User";
import { IAddUser, IUpdateUserPayload } from "@/types/User/Details";

const userDetail = new ListService();

export const USER = {
  DETAIL: "user-detail",
  USER: "user",
};

export const useUpdateUserMutation = (): UseMutationResult<
  IUpdateUserPayload,
  Error,
  { id: number | undefined; input: IAddUser } 
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }) => userDetail.updateUser(id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [USER.USER] });
    },
    onError: (error) => {
      console.error("Update user failed:", error);
    },
  });
};
export const useGetUserDetailsByIdQuery = (params: IGetUserDetail) => {
  return useQuery({
    queryKey: [USER.DETAIL, params.id],
    queryFn: () => userDetail.getUserById(params.id),
    enabled: !!params.id && params.role === USER_ROLE.SUPERADMIN,
    refetchOnWindowFocus: false,
  });
};

export const useDeleteUserMutation = (): UseMutationResult<unknown, Error, { id: number }> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id }) => userDetail.deleteUser(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [USER.USER] });
    },
    onError: (error) => {
      console.error("Delete user failed:", error);
    },
  });
};
