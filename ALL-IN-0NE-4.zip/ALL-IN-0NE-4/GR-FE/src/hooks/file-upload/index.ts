import { useMutation, UseMutationResult } from "@tanstack/react-query";

import { FileUploadService } from "@/services/file-upload";
import { IUploadedAsset,IUploadImageInput } from "@/types/file-upload";

const fileUploadService = new FileUploadService();

export const useUploadImageMutation = (): UseMutationResult<
  IUploadedAsset,
  Error,
  IUploadImageInput
> =>
  useMutation({
    mutationFn: (input: IUploadImageInput) => fileUploadService.uploadImage(input),
    onError: (error) => {
      console.error("Image upload failed:", error);
    },
  });
