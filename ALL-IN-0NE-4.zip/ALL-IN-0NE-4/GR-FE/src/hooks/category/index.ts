import { useQuery } from "@tanstack/react-query";

import { CategoryService } from "@/services/category/CategoryService";
import { ICategoryQueryParams } from "@/types/Exam/Category";

const category = new CategoryService();

const CATEGORY = {
  LIST: "category",
};

export const useGetCategoryQuery = (params: ICategoryQueryParams) =>
  useQuery({
    queryKey: [CATEGORY.LIST, params],
    queryFn: () => category.getAll(params),
    enabled: !!params,
  });
