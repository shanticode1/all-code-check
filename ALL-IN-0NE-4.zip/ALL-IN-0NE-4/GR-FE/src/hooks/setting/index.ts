import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { SettingService } from "@/services/setting/SettingService";
import { IRetentionDays, IRetentionSettingResponse } from "@/types/setting";

const setting = new SettingService();

const SETTING = {
  EXAM_SCHEDULER: "examScheduler",
};

export const useRetentionMutation = (): UseMutationResult<
  IRetentionSettingResponse,
  Error,
  IRetentionDays
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: IRetentionDays) => setting.add(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [SETTING.EXAM_SCHEDULER] });
    },
    onError: (error) => {
      console.error("Retention failed:", error);
    },
  });
};

export const useUpdateRetentionMutation = (): UseMutationResult<
  IRetentionSettingResponse,
  Error,
  { retention_id: number; input: IRetentionDays }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ retention_id, input }: { retention_id: number; input: IRetentionDays }) =>
      setting.update(retention_id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [SETTING.EXAM_SCHEDULER] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};

export const useGetRetentionQuery = () => {
  return useQuery({
    queryKey: [SETTING.EXAM_SCHEDULER],
    queryFn: () => setting.get(),
    enabled: true,
    refetchOnWindowFocus: false,
  });
};
