import { useEffect, useState } from "react";

export default function usePreventDuplicateTabs(sectionId: string) {
  const [isDuplicateTab, setIsDuplicateTab] = useState(false);

  useEffect(() => {
    const channel = new BroadcastChannel(`exam-duplicate-${sectionId}`);
    const myId = `${Date.now()}:${Math.random().toString(36).slice(2)}`;

    channel.postMessage({ type: "hello", from: myId });

    channel.onmessage = (ev) => {
      const msg = ev.data;
      if (msg.type === "hello" && msg.from !== myId) {
        setIsDuplicateTab(true);
      }
    };

    const onBeforeUnload = () => {
      channel.postMessage({ type: "goodbye", from: myId });
    };
    window.addEventListener("beforeunload", onBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      channel.close();
    };
  }, [sectionId]);

  return isDuplicateTab;
}
