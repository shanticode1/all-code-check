"use client";

import { useEffect, useRef, useState } from "react";

import { USER_ROLE } from "@/constants";
import { useExamTimerUpdateMutation } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import UtilLocalService from "@/utils/tools/localstorage";

interface IUseSectionTimerResult {
  timer: number;
  isTimeUp: boolean;
}

export default function useSectionTimer(
  sectionId: string,
  initialTimeLimit: number | null,
): IUseSectionTimerResult {
  const { role } = useAuth();
  const storageKey = `examSectionTimer-${sectionId}`;

  const [timer, setTimer] = useState(1);
  const [isTimeUp, setIsTimeUp] = useState(false);

  const [initialized, setInitialized] = useState(false);

  const tickRef = useRef<number | null>(null);

  const { mutateAsync: examTimerUpdate } = useExamTimerUpdateMutation();

  useEffect(() => {
    const saved = UtilLocalService.getLocalStorage(storageKey);
    if (saved !== null) {
      const savedSeconds = Number(saved);
      setTimer(savedSeconds);
      setInitialized(true);
    } else if (initialTimeLimit !== null) {
      setTimer(initialTimeLimit);
      setInitialized(true);
    }
  }, [storageKey, initialTimeLimit]);

  useEffect(() => {
    if (timer === 0) {
      setIsTimeUp(true);
    }
  }, [timer]);

  useEffect(() => {
    if (!initialized) return;
    if (isTimeUp) return;
    if (tickRef.current !== null) return;

    tickRef.current = window.setInterval(() => {
      setTimer((prev) => {
        const next = Math.max(0, prev - 1);
        UtilLocalService.setLocalStorage(storageKey, String(next));
        return next;
      });
    }, 1000);

    return () => {
      if (tickRef.current !== null) {
        clearInterval(tickRef.current);
        tickRef.current = null;
      }
    };
  }, [initialized, isTimeUp, storageKey]);

  useEffect(() => {
    if (!initialized) return;

    if (role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) return;
    const syncToServer = async () => {
      await examTimerUpdate({ sectionId, time_taken: timer });
    };

    const events: { target: Document | Window; type: string }[] = [
      { target: document, type: "visibilitychange" },
      { target: window, type: "beforeunload" },
      { target: window, type: "unload" },
      { target: window, type: "storage" },
      { target: window, type: "freeze" },
      { target: window, type: "blur" },
      { target: window, type: "offline" },
      { target: window, type: "popstate" },
    ];

    events.forEach(({ target, type }) => {
      target.addEventListener(type, syncToServer);
    });

    return () => {
      events.forEach(({ target, type }) => {
        target.removeEventListener(type, syncToServer);
      });
    };
  }, [examTimerUpdate, sectionId, timer, initialized]);

  UtilLocalService.setLocalStorage(`isTimeUp`, isTimeUp.toString());
  return { timer, isTimeUp };
}
