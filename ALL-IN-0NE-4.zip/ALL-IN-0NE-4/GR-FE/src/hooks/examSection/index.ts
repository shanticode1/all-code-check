import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { EXAM } from "@/hooks/exam";
import { ExamSectionService } from "@/services/exam/ExamSectionService";
import {
  IPreviewSectionPayload,
  ISection,
  ISectionResponse,
  IViewQuestionPayload,
} from "@/types/Exam/index";
import { IQuestionExplanationVideoPayload } from "@/types/Exam/Preview";

const section = new ExamSectionService();

export const EXAM_SECTION = {
  LIST: "section-list",
  QUESTION_DETAIL: "exam-question",
};

export const useUpdateSectionMutation = (): UseMutationResult<
  ISectionResponse,
  Error,
  { section_id: number; input: ISection }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ section_id, input }: { section_id: number; input: ISection }) =>
      section.updateSection(section_id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.DETAIL] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};

export const useUpdateSectionOrderMutation = (): UseMutationResult<
  ISectionResponse,
  Error,
  { exam_id: number; input: ISection }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ exam_id, input }) => section.updateSectionOrder(exam_id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.DETAIL] });
      queryClient.invalidateQueries({ queryKey: [EXAM_SECTION.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};
export const useGetQuestionsBySectionQuery = (params: IPreviewSectionPayload) =>
  useQuery({
    queryKey: [EXAM.LIST, params],
    queryFn: () => section.getAllQuestionsBySectionId(params),
    enabled: !!params.sectionId,
  });

export const useGetQuestionsByIdQuery = (params: IViewQuestionPayload) =>
  useQuery({
    queryKey: [EXAM_SECTION.QUESTION_DETAIL, params.questionId],
    queryFn: () => section.getQuestionsById(params),
    enabled: !!params.questionId,
    refetchOnWindowFocus: false,
  });

export const useGetSectionExplanationVideoQuery = (params: IQuestionExplanationVideoPayload) =>
  useQuery({
    queryKey: [EXAM_SECTION.QUESTION_DETAIL, params.sectionSlug],
    queryFn: () => section.getQuestionsBySection(params),
    enabled: !!params.sectionSlug,
    refetchOnWindowFocus: false,
  });
