import { useQuery } from "@tanstack/react-query";

import { DashboardService } from "@/services/dashboard/DashboardService";
import { DashboardReportsParams } from "@/types/Dashboard";

const dashboard = new DashboardService();

export const DASHBOARD = {
  SUMMARY: "Summary",
  REPORTS: "Reports",
};

export const useGetDashboardSummaryQuery = () =>
  useQuery({
    queryKey: [DASHBOARD.SUMMARY],
    queryFn: () => dashboard.getSummary(),
    enabled: true,
    refetchOnWindowFocus: false,
  });

export const useGetDashboardReportsQuery = (params: DashboardReportsParams) =>
  useQuery({
    queryKey: [DASHBOARD.REPORTS, params],
    queryFn: () => dashboard.getReports(params),
    enabled: params.enabled,
    refetchOnWindowFocus: false,
  });
