import { useMutation, UseMutationResult, useQuery } from "@tanstack/react-query";

import { AnalyticalSectionService } from "@/services/analyticalSection";
import { IAnalytialSectionDataResponse, IAnalyticalPayload, IAnalyticalScorePayload } from "@/types/analyticalSection";

const analytical = new AnalyticalSectionService();

export const ANALYTICAL = {
  LIST: "analytical-list",
};

export const useGetAnalyticalQuery = (params: IAnalyticalPayload) =>
  useQuery({
    queryKey: [ANALYTICAL.LIST, params],
    queryFn: () => analytical.getAnalytical(params),
    enabled: !!params,
    refetchOnWindowFocus: false,
  });

export const useUpdateAnalyticalScoreMutation = (): UseMutationResult<
  IAnalytialSectionDataResponse,
  Error,
  IAnalyticalScorePayload
> => {
  return useMutation({
    mutationFn: (payload: IAnalyticalScorePayload) => analytical.updateScore(payload),

    onError: (error) => {
      console.error("Failed to update profile:", error);
    },
  });
};
