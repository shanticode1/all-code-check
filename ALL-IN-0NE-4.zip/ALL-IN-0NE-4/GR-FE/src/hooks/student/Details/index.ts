import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { USER_ROLE } from "@/constants";
import { ListService } from "@/services/student/list";
import { IDownloadCsv, IGetStudentDetail } from "@/types/Student";
import { IUpdateStudentPayload } from "@/types/Student/Details";

const studentDetail = new ListService();

export const STUDENT = {
  DETAIL: "student-detail",
  STUDENT: "student"
};

export const useUpdateStudentMutation = (): UseMutationResult<
  IUpdateStudentPayload,
  Error,
  { id: number | undefined; input: any } // will update this type
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, input }) => studentDetail.updateStudent(id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [STUDENT.STUDENT] });
    },
    onError: (error) => {
      console.error("Update student failed:", error);
    },
  });
};
export const useGetStudentDetailsByIdQuery = (params: IGetStudentDetail) => {
  return useQuery({
    queryKey: [STUDENT.DETAIL, params.id],
    queryFn: () => studentDetail.getStudentById(params.id),
    enabled: !!params.id && params.role === USER_ROLE.SUPERADMIN,
    refetchOnWindowFocus: false,
  });
};

export const useDownloadCsvFile = (): UseMutationResult<unknown, Error,IDownloadCsv> => {  
  return useMutation({
    mutationFn: ( params:IDownloadCsv ) => studentDetail.downloadCsvFile(params),
    onError: (error) => {
      console.error("Download exam failed:", error);
    },
  });
};

export const useDeleteStudentMutation = (): UseMutationResult<
  any,
  Error,
  { id: number }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id }) => studentDetail.deleteStudent(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [STUDENT.STUDENT] });
    },
    onError: (error) => {
      console.error("Delete student failed:", error);
    },
  });
};
