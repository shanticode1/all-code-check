import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { USER_ROLE } from "@/constants";
import { EXAM_SECTION } from "@/hooks/examSection";
import { ExamService } from "@/services/student/exam";
import {
  IAnswerChoicesSubmitPayload,
  IExamTimeUpdatePayload,
  IQuestionTimeTakenPayload,
  IStartExamResponse,
} from "@/types/Exam/index";
import {
  IExamExitPayload,
  IExamExitTimerUpdatePayload,
  IQuestionMarkedPayload,
} from "@/types/Exam/Preview";
import { IStartExamRequestPayload } from "@/types/Exam/StartExam";
import { IGetStudentExamDetailPayload, IGetStudentExamPayload } from "@/types/Student";
import { IQuestionPayload } from "@/types/Student/ViewQuestion";

const exam = new ExamService();

export const EXAM = {
  LIST: "exam",
  STUDENT_EXAM_LIST: "student-exam-list",
  DETAIL: "exam-detail",
  STUDENT_EXAM_DETAIL: "student-exam-detail",
};

export const useGetStudentExamQuery = (role: string) =>
  useQuery({
    queryKey: [EXAM.LIST],
    queryFn: () => exam.getAll(),
    enabled: role === USER_ROLE.STUDENT,
    refetchOnWindowFocus: false,
  });

export const useGetExamByIdQuery = (id: string, role: string) => {
  return useQuery({
    queryKey: [EXAM.DETAIL, id],
    queryFn: () => exam.getById(id, role),
    enabled: !!id,
    refetchOnWindowFocus: false,
  });
};

export const useStartExamMutation = (): UseMutationResult<
  IStartExamResponse,
  Error,
  IStartExamRequestPayload
> => {
  return useMutation({
    mutationFn: (input) => exam.startExam(input),

    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useExamTimerUpdateMutation = (): UseMutationResult<
  IStartExamResponse,
  Error,
  IExamTimeUpdatePayload
> => {
  return useMutation({
    mutationFn: (input: IExamTimeUpdatePayload) => exam.examTimerUpdate(input),

    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useExamSectionCompleteMutation = (): UseMutationResult<IStartExamResponse, Error> => {
  return useMutation({
    mutationFn: (input: number | unknown) => exam.examSectionComplete(input),

    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useExamAnswerSubmitMutation = (): UseMutationResult<
  IStartExamResponse,
  Error,
  IAnswerChoicesSubmitPayload
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: IAnswerChoicesSubmitPayload) => exam.examAnswerSubmit(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.LIST] });
    },
    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useGetStudentExamHistoryQuery = (params: IGetStudentExamPayload) =>
  useQuery({
    queryKey: [EXAM.STUDENT_EXAM_LIST, params],
    queryFn: () => exam.getAllStudentExam(params),
    enabled: true,
    refetchOnWindowFocus: false,
  });

export const useGetStudentExamDetailsQuery = (params: IGetStudentExamDetailPayload) =>
  useQuery({
    queryKey: [EXAM.STUDENT_EXAM_DETAIL],
    queryFn: () => exam.getStudentExamDetails(params),
    enabled: true,
    refetchOnWindowFocus: false,
  });

export const useGetQuestionDetailsByIdQuery = (params: IQuestionPayload) =>
  useQuery({
    queryKey: [EXAM.STUDENT_EXAM_DETAIL],
    queryFn: () => exam.getQuestionById(params),
    enabled: true,
    refetchOnWindowFocus: false,
  });

export const useExamQuestionTimeTakenMutation = (): UseMutationResult<
  void,
  Error,
  IQuestionTimeTakenPayload
> => {
  return useMutation({
    mutationFn: (input: IQuestionTimeTakenPayload) => exam.questionTimeTaken(input),

    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

// updateQuestionMarkStatus

export const useExamQuestionMarkedMutation = (): UseMutationResult<
  void,
  Error,
  IQuestionMarkedPayload
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: IQuestionMarkedPayload) => exam.updateQuestionMarkStatus(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM_SECTION.QUESTION_DETAIL] });
    },
    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useExamCancelExitMutation = (): UseMutationResult<void, Error, IExamExitPayload> => {
  return useMutation({
    mutationFn: (input: IExamExitPayload) => exam.cancelExit(input),
    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};
export const useExamScheduleExitMutation = (): UseMutationResult<void, Error, IExamExitPayload> => {
  return useMutation({
    mutationFn: (input: IExamExitPayload) => exam.scheduleExit(input),
    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};

export const useExamExitTimerUpdateMutation = (): UseMutationResult<
  void,
  Error,
  IExamExitTimerUpdatePayload
> => {
  return useMutation({
    mutationFn: (input: IExamExitTimerUpdatePayload) => exam.examExitTimerUpdate(input),
    onError: (error) => {
      console.error("Login failed:", error);
    },
  });
};
