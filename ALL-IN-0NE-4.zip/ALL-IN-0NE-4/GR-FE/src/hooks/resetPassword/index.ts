import { useMutation, UseMutationResult, useQueryClient } from "@tanstack/react-query";

import { ResetPasswordService } from "@/services/resetPassword/ResetPasswordService";
import { IForgotPasswordFormValues, IForgotPasswordResponse, IResetPasswordPayload, IResetPasswordResponse } from "@/types/Login";

const resetPassword = new ResetPasswordService();

const PASSWORD = {
  FORGOT_PASSWORD: "forgotPassword",
  RESET_PASSWORD: "resetPassword",
};

export const useForgotPasswordMutation = (): UseMutationResult<
  IForgotPasswordResponse,
  Error,
  IForgotPasswordFormValues
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: IForgotPasswordFormValues): Promise<IForgotPasswordResponse> => {
      return await resetPassword.forgotPassword(input);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [PASSWORD.FORGOT_PASSWORD] });
    },
    onError: (error) => {
      console.error("Forgot Password Failed:", error);
    },
  });
};

export const useResetPasswordMutation = (): UseMutationResult<
 IResetPasswordResponse,
  Error,
  IResetPasswordPayload
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (input: IResetPasswordPayload): Promise<IResetPasswordResponse> => {
      return await resetPassword.resetPassword(input);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [PASSWORD.RESET_PASSWORD] });
    },
    onError: (error) => {
      console.error("Reset Password Failed:", error);
    },
  });
};