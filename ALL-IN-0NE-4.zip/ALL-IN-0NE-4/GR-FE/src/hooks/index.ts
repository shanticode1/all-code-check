import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { ListService } from "@/services/student/list";
import { ListService as UserListService } from "@/services/user/list";
import { UserSubscription } from "@/types/Profile";
import { IGetStudentListPagination, IStudentListResponse } from "@/types/Student";

const list = new ListService();
const userList = new UserListService();

export const STUDENT = {
  LIST: "student",
};
export const USER = {
  LIST: "user",
};

export const useGetAllStudentQuery = (params: IGetStudentListPagination) =>
  useQuery({
    queryKey: [STUDENT.LIST, params],
    queryFn: () => list.getAllStudent(params),
    enabled: true,
    refetchOnWindowFocus: false,
  });

export const useGetAllUserQuery = (params: IGetStudentListPagination) =>
  useQuery({
    queryKey: [USER.LIST, params],
    queryFn: () => userList.getAllUser(params),
    enabled: true,
    refetchOnWindowFocus: false,
  });

export const useUploadBlukStudentsMutation = (): UseMutationResult<
  IStudentListResponse,
  Error,
  UserSubscription[]
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: UserSubscription[]) => list.importStudents(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [STUDENT.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};
