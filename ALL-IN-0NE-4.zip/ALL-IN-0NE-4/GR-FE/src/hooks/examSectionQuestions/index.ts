import { useMutation, UseMutationResult, useQueryClient } from "@tanstack/react-query";

import { EXAM } from "@/hooks/exam";
import { SectionQuestionsService } from "@/services/questions/SectionQuestionsService";
import { IExamResponse, IRequestedPayloadQuestion } from "@/types/Exam/index";

const sectionQuestions = new SectionQuestionsService();

export const useUpdateSectionQuestionsMutation = (): UseMutationResult<
  IExamResponse,
  Error,
  { question_id?: number; input: IRequestedPayloadQuestion }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ question_id, input }) =>
      sectionQuestions.updateSectionQuestions(question_id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.DETAIL] });
      queryClient.invalidateQueries({ queryKey: [EXAM.QUESTION] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};
