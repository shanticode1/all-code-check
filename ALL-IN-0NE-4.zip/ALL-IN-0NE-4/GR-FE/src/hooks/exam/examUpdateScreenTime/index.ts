import dayjs from "dayjs";

import { useExamExitTimerUpdateMutation } from "@/hooks/student/exam";
export const useUpdateScreenTime = () => {
  const { mutateAsync: examExitTimerUpdate } = useExamExitTimerUpdateMutation();

  const updateScreenTime = async (student_exam_id: string) => {
    try {
      if (student_exam_id) {
        const payload = {
          student_exam_id,
          screen_time: dayjs().toISOString(),
        };

        await examExitTimerUpdate(payload);
      }
    } catch (error) {
      console.error("Failed to update screen time:", error);
    }
  };

  return { updateScreenTime };
};
