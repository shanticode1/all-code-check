import { useMutation, UseMutationResult, useQuery, useQueryClient } from "@tanstack/react-query";

import { ExamService } from "@/services/exam/ExamService";
import {
  IAddExam,
  IExamQueryParams,
  IExamResponse,
  IQuestionQueryParams,
} from "@/types/Exam/index";

const exam = new ExamService();

export const EXAM = {
  LIST: "exam",
  DETAIL: "exam-detail",
  QUESTION: "question",
  SECTION: "section",
};

export const useGetExamQuery = (params: IExamQueryParams) =>
  useQuery({
    queryKey: [EXAM.LIST, params],
    queryFn: () => exam.getAll(params),
    enabled: !!params,
    refetchOnWindowFocus: false,
  });

export const useExamMutation = (): UseMutationResult<IExamResponse, Error, IAddExam> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: IAddExam) => exam.add(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};

export const useUpdateExamMutation = (): UseMutationResult<
  IExamResponse,
  Error,
  { exam_id: number; input: IAddExam }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ exam_id, input }) => exam.updateExam(exam_id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};

export const useGetExamByIdQuery = (id: number) => {
  return useQuery({
    queryKey: [EXAM.DETAIL, id],
    queryFn: () => exam.getById(id),
    enabled: !!id,
    refetchOnWindowFocus: false,
  });
};

export const useGetQuestionByIdQuery = (params: IQuestionQueryParams) => {
  return useQuery({
    queryKey: [EXAM.QUESTION, params],
    queryFn: () => exam.getQuestionById(params),
    enabled: !!params.question_id || !!params.section_id,
    refetchOnWindowFocus: false,
  });
};

export const useUpdateExamStatusMutation = (): UseMutationResult<
  IExamResponse,
  Error,
  { exam_id: number; input: IAddExam }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ exam_id, input }) => exam.updateExamStatus(exam_id, input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};

export const usedeleteDeactivateExamMutation = (): UseMutationResult<
  IExamResponse,
  Error,
  { exam_id: number }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ exam_id }) => exam.deleteAndDeactivateExam(exam_id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};

export const useCopyExamExamMutation = (): UseMutationResult<
  IExamResponse,
  Error,
  { exam_id: number }
> => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ exam_id }) => exam.copyExam(exam_id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [EXAM.LIST] });
    },
    onError: (error) => {
      console.error("Exam failed:", error);
    },
  });
};
