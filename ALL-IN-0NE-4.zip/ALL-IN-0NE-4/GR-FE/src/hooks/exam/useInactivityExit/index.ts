"use client";

import { useEffect, useRef } from "react";

type Props = {
  onInactive: () => void; // callback when inactive
  inactiveLimitMs?: number; // default = 2 minutes
};

export const useGlobalActivityTracker = ({
  onInactive,
  inactiveLimitMs = 10 * 60 * 1000,
}: Props) => {
  const lastActivityRef = useRef(Date.now());
  const hasFiredRef = useRef(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const handleUserActivity = () => {
    lastActivityRef.current = Date.now();
    hasFiredRef.current = false;
  };

  useEffect(() => {
    const activityEvents = [
      "mousemove",
      "mousedown",
      "keydown",
      "touchstart",
      "scroll",
      "visibilitychange",
    ];

    activityEvents.forEach((event) => window.addEventListener(event, handleUserActivity));

    intervalRef.current = setInterval(() => {
      const now = Date.now();
      const diff = now - lastActivityRef.current;

      if (diff > inactiveLimitMs && !hasFiredRef.current) {
        hasFiredRef.current = true;
        onInactive();
      }
    }, 1000);

    return () => {
      activityEvents.forEach((event) => window.removeEventListener(event, handleUserActivity));
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [inactiveLimitMs, onInactive]);
};
