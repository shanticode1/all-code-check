"use client";

import { useEffect, useRef } from "react";

type Props = {
  onInactive: () => void; // Har 2 minute me call hoga
  inactiveLimitMs?: number; // Optional: default 2 minute
};

export const useGlobalActivityTrackerAfterTwoMin = ({
  onInactive,
  inactiveLimitMs = 2 * 60 * 1000, // 2 minutes
}: Props) => {
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      onInactive();
    }, inactiveLimitMs);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [inactiveLimitMs, onInactive]);
};
