"use client";
import { useRouter } from "next/navigation";
import React, { useEffect } from "react";

import Loader from "@/components/Common/Loaders/Loader";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { IAuthGateProps } from "@/types/Login";

const AuthGate = ({ allowedRoles = [], children }: IAuthGateProps) => {
  const { isAuthorized, isLoading, role } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading) {
      if (!isAuthorized) {
        router.push(paths.ROOT_LOGIN);
      } else if (
        isAuthorized &&
        allowedRoles.length &&
        typeof role === "string" &&
        !allowedRoles.includes(role)
      ) 
        router.push(paths.ROOT_LOGIN);
    }
  }, [isAuthorized, isLoading, role]);

  if (isLoading || !isAuthorized) {
    return <Loader />;
  }

  return <>{children}</>;
};

export default AuthGate;
