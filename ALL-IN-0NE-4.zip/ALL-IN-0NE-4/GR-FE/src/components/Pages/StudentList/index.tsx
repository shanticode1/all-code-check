//@ts-nocheck
"use client";
import {
  ActionIcon,
  Box,
  Button,
  Chip,
  Container,
  Group,
  Menu,
  Modal,
  Paper,
  Select,
  Tooltip,
} from "@mantine/core";
import { useDebouncedValue } from "@mantine/hooks";
import { showNotification } from "@mantine/notifications";
import {
  IconChevronDown,
  IconEdit,
  IconEye,
  IconFileUpload,
  IconPlus,
  IconTrash,
} from "@tabler/icons-react";
import { DataTable } from "mantine-datatable";
import Link from "next/link";
import { usePathname, useRouter ,useSearchParams} from "next/navigation";
import { useTranslations } from "next-intl";
import React, { JSX, useEffect, useState } from "react";

import { ConfirmationModal, UploadFileModal } from "@/components/Common/Modals";
import SearchInput from "@/components/Common/SearchInput";
import SectionHeader from "@/components/Common/SectionHeader";
import { commonButtons, PARTNER_TYPE, USER_ROLE } from "@/constants";
import { accessType } from "@/constants/exam";
import { useGetAllStudentQuery, useUploadBlukStudentsMutation } from "@/hooks";
import { useDeleteStudentMutation, useUpdateStudentMutation } from "@/hooks/student/Details";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { IImportSummary, UserSubscription } from "@/types/Profile";
import { IStudentList } from "@/types/Student";
import { formatDate, truncateName } from "@/utils";

import AddStudentForm from "../AddStudentForm";

export default function StudentList(): JSX.Element {
  const { userData } = useAuth();
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const router = useRouter();
  const page = Number(searchParams.get("page") ?? 1);
  const pageSize = Number(searchParams.get("pageSize") ?? 10);
  const sortBy = (searchParams.get("sortBy") as "asc" | "desc") || null;
  const orderBy = searchParams.get("orderBy") as keyof IStudentList | null;
  const [searchQuery, setSearchQuery] = useState<string>(searchParams.get("search") ?? "");
  const [uploadError, setUploadError] = useState<string>("");
  const [formattedMessage, setFormattedMessage] = useState<IImportSummary | undefined>(undefined);
  const [showFileUploadModal, setShowFileUploadModal] = useState<boolean>(false);
  const t = useTranslations("studentDetails");
  const tGeneric = useTranslations("generic");

  const [debouncedSearchQuery] = useDebouncedValue(searchQuery.trim(), 500);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [studentDetail, setStudentDetail] = useState<IStudentList | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const { mutateAsync: deleteStudent } = useDeleteStudentMutation();
  const [filter, setFilter] = useState<{
    partner_type?: string | null;
    subscription_status?: string | null;
  }>({});

  const {
    data: studentData,
    isLoading: isStudentListLoading,
    isFetching: isStudentListFetching,
  } = useGetAllStudentQuery({
    page,
    limit: pageSize,
    search: debouncedSearchQuery,
    sortBy: sortBy ?? undefined,
    orderBy: orderBy ?? undefined,
    filter: JSON.stringify(filter),
  });

  const noRecordsMessage = searchQuery?.trim()
    ? t("messages.noResultFoundForSearch")
    : t("messages.noUserFound");

  const { mutateAsync: importStudents, isPending: isImportPending } =
    useUploadBlukStudentsMutation();

  const { mutateAsync: updateStudent } = useUpdateStudentMutation();

  const handleDelete = async () => {
    if (selectedUserId) {
      const result = await deleteStudent({ id: selectedUserId });
      if (result) {
        showNotification({
          color: "green",
          title: "Success",
          message: result.message,
        });
      }
      setShowDeleteModal(false);
      setSelectedUserId(null);
    }
  };

  const updateQueryParams = (updates: Record<string, string | number | null>) => {
    const q = new URLSearchParams(searchParams.toString());

    Object.entries(updates).forEach(([key, value]) => {
      if (value == null) q.delete(key);
      else q.set(key, String(value));
    });

    router.replace(`${pathname}?${q.toString()}`);
  };

  useEffect(() => {
    updateQueryParams({ search: debouncedSearchQuery, page: 1 });
  }, [debouncedSearchQuery]);

  const handlePageChange = (newPage: number) => {
    updateQueryParams({ page: newPage });
  };

  const handlePageSizeChange = (newPageSize: number) => {
    updateQueryParams({ pageSize: newPageSize, page: 1 });
  };

  const handleFileSubmit = async (selectedFile: UserSubscription[]) => {
    if (!selectedFile) {
      setUploadError(t("message.error.text"));
      return;
    }
    try {
      const { data } = await importStudents(selectedFile);
      setFormattedMessage(data);
    } catch (error) {
      setUploadError(`${(error as Error).message}`);
    }
  };
  const handleCloseFileModal = () => {
    setShowFileUploadModal(false);
    setUploadError("");
    setFormattedMessage(undefined);
  };
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setStudentDetail(null);
  };

  const handleSortChange = ({ columnAccessor }: { columnAccessor: string }) => {
    if (orderBy === columnAccessor) {
      if (sortBy === "asc") {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "desc" });
      } else if (sortBy === "desc") {
        updateQueryParams({ orderBy: null, sortBy: null });
      } else {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
      }
    } else {
      updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
    }
  };

  useEffect(() => {
    const accessType = searchParams.get("subscription_status");
    const partnerType = searchParams.get("partner_type");

    const newFilter: { partner_type?: string | null; subscription_status?: string | null } = {};

    if (accessType === "Free" || accessType === "Paid") {
      newFilter.subscription_status = accessType;
    }

    if (partnerType === "SherpaPrep" || partnerType === "SmartWithHeart") {
      newFilter.partner_type = partnerType;
    }

    setFilter(newFilter);
  }, [searchParams]);

  const handleAccessTypeFilterChange = (value: string | null) => {
    const params = new URLSearchParams(searchParams.toString());

    if (value === "Free") {
      params.set("subscription_status", "Free");
    } else if (value === "Paid") {
      params.set("subscription_status", "Paid");
    } else {
      params.delete("subscription_status");
    }

    params.set("page", "1");
    router.push(`?${params.toString()}`);
  };

  const handlePartnerTypeChange = (value: string | null) => {
    const params = new URLSearchParams(searchParams.toString());

    if (value) {
      params.set("partner_type", value);
    } else {
      params.delete("partner_type");
    }
    params.set("page", "1"); // reset page to 1
    router.push(`?${params.toString()}`);
  };

  const columns = [
    {
      accessor: "student_name",
      title: t("table.columns.title.name"),
      sortable: true,
      render: (row: IStudentList) => {
        const fullName = `${row.first_name} ${row.last_name ?? ""}`.trim();
        const truncatedName = truncateName(fullName, 20);
        const shouldShowTooltip = fullName.length > 20;

        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={fullName}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedName : fullName}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },
    {
      accessor: "email",
      title: t("table.columns.title.email"),
      render: (row: IStudentList) => {
        const email = row.email;
        const truncated = truncateName(email, 30);
        const shouldShowTooltip = email.length > 30;
        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={email}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncated : email}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },
    {
      accessor: "partner_type",
      title: t("table.columns.title.portalName"),
      width: "200px",
      render: (row: IStudentList) => {
        return (
          <p>
            {row.partner_type === "SmartWithHeart"
              ? t("partnerType.smartWithHeart")
              : t("partnerType.sherpaPrep")}
          </p>
        );
      },
    },
    {
      accessor: "subscription_start_date",
      sortable: true,
      title: t("table.columns.title.subscriptionStartDate"),
      render: (row: IStudentList) =>
        row.subscription_start_date ? formatDate(row.subscription_start_date) : "-",
    },
    {
      accessor: "subscription_end_date",
      sortable: true,
      title: t("table.columns.title.subscriptionEndDate"),
      render: (row: IStudentList) =>
        row.subscription_end_date ? formatDate(row.subscription_end_date) : "-",
    },
    {
      accessor: "created_at",
      title: t("table.columns.title.createdDate"),
      sortable: true,
      textAlignment: "center",
      width: "120px",
      render: (row) => formatDate(row.created_at),
    },
    {
      accessor: "subscription_status",
      title: t("table.columns.title.accessType"),
      render: (row: IStudentList) => (
        <Box style={{ width: "100px" }}>
          <Chip
            color={row.subscription_status === "Paid" ? "orange" : "green"}
            variant="light"
            checked
            className="accesss-type-chip"
            style={{ width: "100%" }}
          >
            {row.subscription_status ? row.subscription_status : "-"}
          </Chip>
        </Box>
      ),
    },
    {
      accessor: "status",
      title: t("table.columns.title.status"),
      render: (row: IStudentList) => {
        const handleStatusChange = async (newStatus: "ACTIVE" | "INACTIVE") => {
          try {
            const updatedPayload = {
              first_name: row.first_name,
              last_name: row.last_name ?? null,
              email: row.email,
              partner_type: row.partner_type,
              subscription_status: row.subscription_status,
              subscription_start_date: row.subscription_start_date ?? null,
              subscription_end_date: row.subscription_end_date ?? null,
              is_active: newStatus === "ACTIVE",
            };
            const { message } = await updateStudent({ id: row.user_id, input: updatedPayload });
            showNotification({
              color: "green",
              title: "Success",
              message: message,
            });
          } catch (error) {
            console.error("Status update failed", error);
          }
        };
        const isSuperAdmin = userData?.role === USER_ROLE.SUPERADMIN;
        return (
          <Box style={{ width: "100px" }}>
            <Menu disabled={!isSuperAdmin}>
              <Menu.Target>
                <Box
                  style={{
                    cursor: isSuperAdmin ? "pointer" : "default",
                    padding: "4px 8px",
                    borderRadius: "4px",
                    textAlign: "center",
                    backgroundColor: row.is_active ? "#40c0571a" : "#fa52521f",
                    color: row.is_active ? "#40c057" : "#fa5252",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  {row.is_active
                    ? t("table.columns.status.active")
                    : t("table.columns.status.inactive")}
                  <IconChevronDown size={14} style={{ marginLeft: "8px" }} />
                </Box>
              </Menu.Target>
              <Menu.Dropdown p="0" w="100">
                {!row.is_active && (
                  <Menu.Item onClick={() => handleStatusChange("ACTIVE")}>
                    {t("table.columns.status.active")}
                  </Menu.Item>
                )}
                {row.is_active && (
                  <Menu.Item onClick={() => handleStatusChange("INACTIVE")}>
                    {t("table.columns.status.inactive")}
                  </Menu.Item>
                )}
              </Menu.Dropdown>
            </Menu>
          </Box>
        );
      },
    },
    {
      accessor: "actions",
      title: "Actions",
      cellsStyle: () => ({ backgroundColor: "#fff" }),
      render: (row: IStudentList) => (
        <Box style={{ display: "flex", gap: "2px" }}>
          <Tooltip label="View Exam History">
            <Link href={`/admin/student/exams/${row.user_id}`}>
              <ActionIcon color="blue">
                <IconEye size={20} />
              </ActionIcon>
            </Link>
          </Tooltip>
          {userData?.role === USER_ROLE.SUPERADMIN && (
            <>
              <Tooltip
                label={
                  row.partner_type === PARTNER_TYPE.SMART_WITH_HEART ? "Edit not allowed" : "Edit"
                }
              >
                <ActionIcon
                  disabled={row.partner_type === PARTNER_TYPE.SMART_WITH_HEART}
                  color="blue"
                  onClick={() => {
                    setStudentDetail(row);
                    setIsModalOpen(true);
                  }}
                >
                  <IconEdit size={16} />
                </ActionIcon>
              </Tooltip>
              <Tooltip
                label={
                  row.partner_type === PARTNER_TYPE.SMART_WITH_HEART
                    ? "Delete not allowed"
                    : "Delete"
                }
              >
                <ActionIcon
                  disabled={row.partner_type === PARTNER_TYPE.SMART_WITH_HEART}
                  color="red"
                  onClick={() => {
                    setSelectedUserId(Number(row.user_id));
                    setShowDeleteModal(true);
                  }}
                >
                  <IconTrash size={16} />
                </ActionIcon>
              </Tooltip>
            </>
          )}
        </Box>
      ),
    },
  ];

  return (
    <Container size="xxl" my="lg">
      <SectionHeader title={t("title")}>
        {userData?.role === USER_ROLE.SUPERADMIN && (
          <Button
            variant="default"
            onClick={() => setIsModalOpen(true)}
            leftSection={<IconPlus size={14} />}
            size="md"
          >
            {tGeneric("buttons.add", { value: commonButtons.student })}
          </Button>
        )}
      </SectionHeader>
      <Paper>
        <Box p={"sm"} flex={true}>
          <Group justify="space-between">
            <Group gap="md" align="center">
              <Box style={{ width: "400px" }}>
                <SearchInput
                  handleChange={(e) => setSearchQuery(e.currentTarget.value)}
                  placeholder="Search by name or email"
                  value={searchQuery}
                  handleClear={() => {
                    setSearchQuery("");
                    updateQueryParams({ search: "", page: 1 });
                  }}
                />
              </Box>
              <Select
                placeholder="Filter by Access Type"
                value={filter.subscription_status ?? null}
                onChange={handleAccessTypeFilterChange}
                data={accessType}
                clearable
                style={{ width: "200px" }}
              />

              <Select
                placeholder="Filter by Partner Type"
                value={filter.partner_type || null}
                onChange={handlePartnerTypeChange}
                data={[
                  { value: "SherpaPrep", label: "Sherpa Prep" },
                  { value: "SmartWithHeart", label: "Smart With Heart" },
                ]}
                clearable
                style={{ width: "200px" }}
              />
            </Group>
            {userData?.role === USER_ROLE.SUPERADMIN && (
              <Button
                size="md"
                leftSection={<IconFileUpload size={18} />}
                onClick={() => {
                  setShowFileUploadModal(true);
                }}
                variant="gradient"
                gradient={{ from: "blue", to: "cyan", deg: 90 }}
              >
                {t("button.import.text")}
              </Button>
            )}
          </Group>
        </Box>
        <DataTable
          records={studentData?.data?.users || []}
          minHeight={350}
          columns={columns}
          withTableBorder={false}
          withColumnBorders={false}
          borderRadius="sm"
          highlightOnHover
          fetching={isStudentListLoading || isStudentListFetching}
          loaderType="oval"
          striped
          noRecordsText={noRecordsMessage}
          verticalAlign="top"
          pinLastColumn
          className="data-table"
          totalRecords={studentData?.data?.total || 0}
          recordsPerPage={studentData?.data?.total > 0 ? pageSize : undefined}
          page={studentData?.data?.total > 0 ? page : undefined}
          onPageChange={studentData?.data ? handlePageChange : undefined}
          onRecordsPerPageChange={studentData?.data ? handlePageSizeChange : undefined}
          recordsPerPageOptions={studentData?.data?.total > 0 ? [5, 10, 20, 50] : undefined}
          c={{ dark: "#000", light: "#555" }}
          styles={{
            header: {
              backgroundColor: "#f0f0f0",
            },
          }}
          sortStatus={{
            columnAccessor: orderBy ?? "",
            direction: (sortBy) ?? "asc",
          }}
          onSortStatusChange={handleSortChange}
        />
      </Paper>
      {showDeleteModal && (
        <ConfirmationModal
          opened={showDeleteModal}
          title={t("confirmDelete.title")}
          description={
            <span>
              {t("confirmDelete.message")}
              <br />
              {t("confirmDelete.description")}
            </span>
          }
          onCancel={() => setShowDeleteModal(false)}
          onConfirm={handleDelete}
          buttonText={t("confirmDelete.delete")}
          buttonCancelText={t("confirmDelete.cancel")}
        />
      )}
      {showFileUploadModal && (
        <UploadFileModal
          opened={showFileUploadModal}
          onCancel={handleCloseFileModal}
          handleFileSubmit={handleFileSubmit}
          isImportPending={isImportPending}
          uploadError={uploadError}
          setUploadError={() => setUploadError("")}
          sampleFile={"/student-sample.csv"}
          formattedMessage={formattedMessage}
          setFormattedMessage={setFormattedMessage}
        />
      )}
      <Modal
        opened={isModalOpen}
        onClose={handleCloseModal}
        size="lg"
        title={studentDetail?.user_id ? t("edit.modal.title") : t("create.modal.title")}
      >
        <AddStudentForm handleClose={handleCloseModal} studentDetail={studentDetail} />
      </Modal>
    </Container>
  );
}
