"use client";

import { Box, Button, Card, Center, Divider, Flex, Loader, Text, Title } from "@mantine/core";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import DualLogoHeader from "@/components/Common/DualLogoHeader";
import TimerDisplay from "@/components/Common/Timer";
import { USER_ROLE } from "@/constants";
import useSectionTimer from "@/hooks/common/useSectionTimer";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGlobalActivityTracker } from "@/hooks/exam/useInactivityExit";
import { useGlobalActivityTrackerAfterTwoMin } from "@/hooks/exam/useInactivityUpdateAfterTwoMin";
import { useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import { useExamSectionCompleteMutation } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import BookmarkIcon from "@/public/icons/bookmark-icon.svg";
import PrevIcon from "@/public/icons/left-arrow.svg";
import NextIcon from "@/public/icons/right-arrow.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import UtilLocalService from "@/utils/tools/localstorage";

import ExamErrorHandle from "../../ExamErrorHandle";

export default function EndSection() {
  useBlockBrowserNavigation(true);
  const t = useTranslations("section");
  const tExam = useTranslations("examDetail");
  const router = useRouter();
  const { role } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isNavigating, setIsNavigating] = useState(false);
  const [redirectPath, setRedirectPath] = useState<string | null>(null);
  const student_exam_section_id = UtilLocalService.getLocalStorage("student_exam_section_id") || "";
  const { mutateAsync: examSectionComplete } = useExamSectionCompleteMutation();

  const { data: sectionData, error } = useGetQuestionsBySectionQuery({
    sectionId: typeof student_exam_section_id === "string" ? student_exam_section_id : "",
    role: typeof role === "string" ? role : "",
  });
  const [sortedQuestions, setSortedQuestions] = useState(sectionData?.data?.questions || []);
  const initialTimeLimit = sectionData?.data
    ? Number(sectionData.data.time_taken ?? sectionData.data.time_limit)
    : null;
  const question_id = UtilLocalService.getLocalStorage("question_id");
  const { updateScreenTime } = useUpdateScreenTime();
  const { timer } = useSectionTimer(
    typeof student_exam_section_id === "string" ? student_exam_section_id : "",
    initialTimeLimit,
  );
  useGlobalActivityTracker({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
        router.push("/exams");
      }
    },
  });
  useGlobalActivityTrackerAfterTwoMin({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
      }
    },
  });
  // On Page Load (Reload) redirect if navigation in progress
  useEffect(() => {
    const path = UtilLocalService.getLocalStorage("redirect_after_reload_section");
    if (path) {
      UtilLocalService.removeLocalStorage("redirect_after_reload_section");
      router.push(path.toString());
    }
  }, [router]);
  // Disable Back Navigation and Reload Icon during Navigation
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isNavigating) {
        e.preventDefault();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (isNavigating && (e.key === "F5" || (e.ctrlKey && e.key === "r"))) {
        e.preventDefault();
      }
    };

    const handlePopState = (e: PopStateEvent) => {
      if (isNavigating && redirectPath) {
        e.preventDefault();
        window.history.pushState(null, "", window.location.href);
        router.push(redirectPath);
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("popstate", handlePopState);
    };
  }, [isNavigating, redirectPath, router]);
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [sectionData]);

  useEffect(() => {
    if (sectionData?.data?.questions) {
      const numberedQuestions = sectionData.data.questions.map((q, index) => ({
        ...q,
        questionNumber: index + 1,
      }));
      const index = numberedQuestions.findIndex(
        (q) =>
          (q.question_id !== undefined && q.question_id === question_id) ||
          (q.student_question_id !== undefined && q.student_question_id === question_id),
      );

      if (index !== -1) {
        setCurrentIndex(index);
      }
      setSortedQuestions(numberedQuestions);
    }
  }, [sectionData]);

  const handleSubmitSection = async () => {
    try {
      if (isNavigating) return;
      setIsNavigating(true);
      const data = await examSectionComplete(student_exam_section_id);
      let nextPath = `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${data?.data?.student_exam_section_id}/instructions`;
      UtilLocalService.removeLocalStorage("student_exam_section_id");
      if (data?.data?.student_exam_section_id) {
        UtilLocalService.setLocalStorage(
          "student_exam_section_id",
          data?.data?.student_exam_section_id.toString(),
        );
        nextPath = `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${data?.data?.student_exam_section_id}/instructions`;
        UtilLocalService.setLocalStorage("is_visible_timer", "true");
        UtilLocalService.setLocalStorage("redirect_after_reload_section", nextPath);
        setRedirectPath(nextPath);
        (window as WindowWithNextNav).__allowNextNavigation__?.();
        router.push(nextPath);
        return;
      } else {
        UtilLocalService.removeLocalStorage("is_visible_timer");
        (window as WindowWithNextNav).__allowNextNavigation__?.();
        nextPath =
          role === USER_ROLE.STUDENT
            ? `${paths.ROOT_END_EXAM(String(student_exam_section_id))}?id=${data?.data?.student_exam_id}`
            : paths.ROOT_ADMIN_EXAM;
        UtilLocalService.setLocalStorage("redirect_after_reload_section", nextPath);
        setRedirectPath(nextPath);
        router.push(nextPath);
        return;
      }
    } catch (error) {
      setIsNavigating(false);
      console.error("Failed to update exam timer:", error);
      UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    }
  };

  const handleReviewSection = async () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString());
    }
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(paths.ROOT_SECTION_REVIEW_QUESTIONS(String(student_exam_section_id)));
  };

  const handleReturnToLastQuestion = () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString());
    }
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    const lastQuestion = sectionData?.data.questions?.[sectionData.data.questions.length - 1];
    if (lastQuestion) {
      const basePath = role === USER_ROLE.STUDENT ? "exams" : "admin/preview";
      (window as WindowWithNextNav).__allowNextNavigation__?.();
      router.push(
        `/${basePath}/section/${student_exam_section_id}?question_id=${lastQuestion.student_question_id}`,
      );
    }
  };

  if (error && !error?.message?.includes("Pending section not found")) {
    return <ExamErrorHandle errorMsg={`${tExam("error.lable")}`} />;
  }

  return (
    <Box mih={400} className="exam-preview-section">
      <Box className="exam-header">
        <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
        <Flex gap="3px">
          {timer !== 0 && (
            <>
              {sectionData?.data && sectionData?.data?.section_slug !== "analytical-writing" && (
                <Button
                  disabled={isNavigating}
                  onClick={handleReviewSection}
                  className="btn-blue btn-utility"
                  rightSection={<Image src={BookmarkIcon} width={16} alt="next" />}
                >
                  Review
                </Button>
              )}
              <Button
                onClick={handleReturnToLastQuestion}
                disabled={isNavigating}
                className="btn-blue"
                rightSection={<Image src={PrevIcon} width={18} alt="next" />}
              >
                Return
              </Button>
            </>
          )}
          <Button
            onClick={() => {
              if (sectionData?.data.student_exam_id) {
                updateScreenTime(sectionData?.data.student_exam_id.toString());
              }
              handleSubmitSection();
            }}
            disabled={isNavigating}
            className="btn-blue"
            rightSection={<Image src={NextIcon} width={18} alt="next" />}
          >
            {t("endSection.continue")}
          </Button>
        </Flex>
      </Box>
      {isNavigating ? (
        <Center style={{ height: "40vh" }}>
          <Loader type="oval" size="lg" />
        </Center>
      ) : (
        <>
          <Box className="exam-section-details">
            {timer !== 0 && (
              <>
                <Box>
                  <Text size="sm" c="black">
                    <Text span size="sm" fw={700}>
                      Section {sectionData?.data?.display_order} of 5{" "}
                    </Text>{" "}
                    | Question {currentIndex + 1} of {sortedQuestions?.length}
                  </Text>
                </Box>
                <TimerDisplay
                  selectedSectionId={String(student_exam_section_id)}
                  initialTimeLimit={initialTimeLimit}
                  handleSubmitSection={handleSubmitSection}
                />
              </>
            )}
          </Box>

          <Card radius="0" shadow="none" className="instructions-container">
            <Title order={3} className="arial-font-heading">
              {t("endSection.title")}
            </Title>
            <Divider mt={20} pb={20} />
            <Text mb="sm">
              {timer === 0 ? t("endSection.description") : t("endSection.otherDescription")}
            </Text>
            {timer !== 0 && (
              <>
                {sectionData?.data && sectionData?.data?.section_slug !== "analytical-writing" && (
                  <Text>
                    {t("endSection.select")}{" "}
                    <Text component="span" fw={700}>
                    {t("endSection.review")}
                    </Text>{" "}
                    {t("endSection.goTBack")}
                  </Text>
                )}
                <Text>
                {t("endSection.select")}{" "}
                  <Text component="span" fw={700}>
                  {t("endSection.return")}
                  </Text>{" "}
                  {t("endSection.goToQuestion")}
                </Text>
              </>
            )}
            <Text>
            {t("endSection.select")}{" "}
              <Text component="span" fw={700}>
                {t("endSection.continue")}
              </Text>{" "}
              {t("endSection.toProceed")}
            </Text>
          </Card>
        </>
      )}
    </Box>
  );
}
