"use client";

import {
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Container,
  Flex,
  Group,
  Modal,
  Text,
} from "@mantine/core";
import Image from "next/image";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useRef, useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import WarningAlertModal from "@/components/Common/Modals/WarningAlertModal";
import PreviewSection from "@/components/Pages/PreviewSection";
import { USER_ROLE } from "@/constants";
import usePreventDuplicateTabs from "@/hooks/common/usePreventDuplicateTabs";
import { useGetExamByIdQuery } from "@/hooks/exam";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGlobalActivityTracker } from "@/hooks/exam/useInactivityExit";
import { useGlobalActivityTrackerAfterTwoMin } from "@/hooks/exam/useInactivityUpdateAfterTwoMin";
import { useGetQuestionsByIdQuery, useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import {
  useExamAnswerSubmitMutation,
  useExamQuestionMarkedMutation,
  useExamQuestionTimeTakenMutation,
} from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import examAlert from "@/public/exam-alert.png";
import firework from "@/public/firework.png";
import { paths } from "@/routes/index";
import { WindowWithNextNav } from "@/types";
import { IAnswerChoices, IQuestionResponse } from "@/types/Exam/index";
import UtilLocalService from "@/utils/tools/localstorage";
import logger from "@/utils/tools/logger";

import ExamErrorHandle from "../../ExamErrorHandle";

export default function PreviewQuestionsClient() {
  useBlockBrowserNavigation(true);

  const { sectionId } = useParams() as { sectionId: string };
  const router = useRouter();
  const tStart = useTranslations("startExam");
  const tGeneric = useTranslations("generic");
  const t = useTranslations("examDetail");
  const searchParams = useSearchParams();
  const queryQuestionId = searchParams.get("question_id") || "";
  const [isLoading, setIsLoading] = useState(false);
  const { role } = useAuth();

  const [isQuestionMarked, setIsQuestionMarked] = useState(false);
  const timerIdRef = useRef(0);
  const timeRef = useRef(0);

  const storageKey = `examSectionTimer-${sectionId}`;
  const adminStudentRoute = role === USER_ROLE.STUDENT ? "/exams" : "/admin/exams";

  const [currentIndex, setCurrentIndex] = useState(0);
  const [currentQuestion, setCurrentQuestion] = useState<IQuestionResponse | null>(null);
  const [selectedSectionId, setSelectedSectionId] = useState<string | null>(sectionId);
  const [selectAnswer, setSelectAnswer] = useState<IAnswerChoices[]>([]);
  const [isExamEndModalOpen, setIsExamEndModalOpen] = useState(false);
  const isDuplicateTab = usePreventDuplicateTabs(sectionId);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const { updateScreenTime } = useUpdateScreenTime();
  const {
    data: sectionData,
    isLoading: isSectionLoading,
    error,
  } = useGetQuestionsBySectionQuery({
    sectionId: selectedSectionId || "",
    role: typeof role === "string" ? role : "",
  });
  const questionIds = sectionData?.data?.questions || [];

  const initialTimeLimit = sectionData?.data
    ? Number(sectionData.data.time_taken ?? sectionData.data.time_limit)
    : null;

  const isTimeUp = UtilLocalService.getLocalStorage("isTimeUp") === "true";

  const { data: examData, isLoading: isExamDataLoading } = useGetExamByIdQuery(
    sectionData?.data?.exam_id ?? 0,
  );

  const allSections = examData?.data?.sections || [];
  const { mutateAsync: examQuestionTimeTaken } = useExamQuestionTimeTakenMutation();
  const { mutateAsync: updateQuestionMarkStatus } = useExamQuestionMarkedMutation();

  const { mutateAsync: examAnswerSubmit, isPending: isExamAnswerSubmitPending } =
    useExamAnswerSubmitMutation();
  useGlobalActivityTracker({
    onInactive: () => {
      if (sectionData?.data?.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString() || "");
        router.push("/exams");
      }
    },
  });
  useGlobalActivityTrackerAfterTwoMin({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
      }
    },
  });
  const questionId =
    (questionIds?.[currentIndex]?.question_id ||
      questionIds?.[currentIndex]?.student_question_id ||
      queryQuestionId) ??
    null;

  const {
    data,
    isLoading: isQuestionLoading,
    isFetching: isQuestionFetching,
    error: questionError,
  } = useGetQuestionsByIdQuery({
    questionId: questionId,
    role: typeof role === "string" ? role : "",
  });

  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sectionData?.data?.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [sectionData]);

  useEffect(() => {
    if (data?.data) {
      startHandler();
      setSelectAnswer(data?.data?.studentAnswerChoices);
      setCurrentQuestion(data?.data);
      if (role === USER_ROLE.STUDENT) {
        updateScreenTime(sectionData?.data.student_exam_id?.toString() || "");
      }
    }
  }, [data?.data]);

  const submitAnswerBeforeUnload = async () => {
    if (role === USER_ROLE.STUDENT) {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id?.toString() || ""); // Tab Close / Reload API Call
      }
      await examAnswerSubmit({
        student_question_id: currentQuestion?.student_question_id || 0,
        answerChoices: selectAnswer,
        is_visited: true,
      });
      updateScreenTime(currentQuestion?.student_exam_id.toString() || "");
    }
  };

  useEffect(() => {
    const handleUnload = () => {
      submitAnswerBeforeUnload();
    };
    window.addEventListener("beforeunload", handleUnload);
    return () => {
      window.removeEventListener("beforeunload", handleUnload);
    };
  }, [selectAnswer, currentQuestion]);

  const hasSetIndex = useRef(false);

  useEffect(() => {
    if (hasSetIndex.current || !queryQuestionId || questionIds.length === 0) return;

    const index = questionIds.findIndex(
      (q) =>
        (q.question_id !== undefined && q.question_id?.toString() === queryQuestionId) ||
        (q.student_question_id !== undefined &&
          q.student_question_id?.toString() === queryQuestionId),
    );

    if (index !== -1 && index !== currentIndex) {
      setCurrentIndex(index);
      hasSetIndex.current = true; // prevents further runs
    }
  }, [queryQuestionId, questionIds]);

  // Only call the API when questionIds and currentIndex are valid

  const handleUpdatemark = async (checked: boolean) => {
    setIsQuestionMarked(checked);
    try {
      if (role === USER_ROLE.STUDENT) {
        await examAnswerSubmit({
          student_question_id: currentQuestion?.student_question_id || 0,
          answerChoices: selectAnswer,
          is_visited: true,
        });
      }
      await updateQuestionMarkStatus({
        questionId: questionId ?? 0,
        isMarked: checked,
      });
    } catch (error) {
      console.error("Failed to submit answer:", error);
    }
  };
  const handleSubmitSection = async () => {
    try {
      UtilLocalService.setLocalStorage("student_exam_section_id", String(selectedSectionId) || "");
      if (role === USER_ROLE.STUDENT) {
        await examAnswerSubmit({
          student_question_id: currentQuestion?.student_question_id || 0,
          answerChoices: selectAnswer,
          is_visited: true,
        });
      }
      setShowConfirmationModal(false);
      setTimeout(() => {
        if (role === USER_ROLE.STUDENT) {
          handleExit();
          UtilLocalService.removeLocalStorage("redirect_after_reload_section");
          UtilLocalService.removeLocalStorage("redirect_after_reload");
          router.push(`${paths.ROOT_STUDENT_PREVIEW_SECTION}/end-section`);
        }
      }, 5000);
      role === USER_ROLE.STUDENT && handleQuestionTimeTaken();
      stopHandler();
    } catch (error) {
      console.error("Failed to update exam timer:", error);
    }
  };

  const handleAnserChoices = async (value: string | string[], index: number = 0, type: string) => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    const answerChoices = currentQuestion?.AnswerChoice || [];
    const studentAnswerChoices = currentQuestion?.studentAnswerChoices || [];

    const answerType = type === "textInput";
    let updatedAnswers;

    if (Array.isArray(value)) {
      if (currentQuestion?.question_type === "multipleSelection" && studentAnswerChoices.length) {
        const selectedIds = value.filter(Boolean).map((v) => Number(v));

        // Step 1: Start with all entries from studentAnswerChoices
        const studentMapped = studentAnswerChoices.map((studentChoice) => {
          const isSelected = selectedIds.includes(Number(studentChoice.answer_choice_id));

          return {
            student_answer_choice_id: Number(studentChoice.student_answer_choice_id) || null,
            answer_choice_id: isSelected ? Number(studentChoice.answer_choice_id) : null,
            answer: studentChoice.answer || "",
            numerator: "",
            denominator: "",
            paragraph_answer_key: studentChoice.paragraph_answer_key || null,
          };
        });

        // Step 2: Add entries from value that are not already in studentAnswerChoices
        const existingIds = studentAnswerChoices.map((s) => Number(s.answer_choice_id));
        const newIdsToAdd = selectedIds.filter((id) => !existingIds.includes(id));

        const newMapped = answerChoices
          .filter((choice) => newIdsToAdd.includes(Number(choice.answer_choice_id)))
          .map((choice) => ({
            student_answer_choice_id: null,
            answer_choice_id: Number(choice.answer_choice_id),
            answer: "",
            numerator: "",
            denominator: "",
            paragraph_answer_key: null,
          }));

        // Final result
        updatedAnswers = [...studentMapped, ...newMapped];
      } else if (
        currentQuestion?.question_type === "paragraph-sentence" &&
        studentAnswerChoices.length > 0 &&
        value.length === 0
      ) {
        updatedAnswers = studentAnswerChoices.map((choice) => ({
          student_answer_choice_id: Number(choice.student_answer_choice_id),
          answer_choice_id: null,
          answer: "",
          numerator: "",
          denominator: "",
          paragraph_answer_key: choice.paragraph_answer_key,
        }));
      } else {
        updatedAnswers = value.map((val, idx) => ({
          student_answer_choice_id: studentAnswerChoices[idx]?.student_answer_choice_id
            ? Number(studentAnswerChoices[idx]?.student_answer_choice_id)
            : null,
          answer_choice_id: !answerType
            ? val
              ? Number(val)
              : null
            : answerChoices?.[idx]?.answer_choice_id
              ? Number(answerChoices?.[idx]?.answer_choice_id)
              : null,
          //@ts-expect-error ts(2322)
          answer: type === "paragraph-sentence" ? val.answer : "",
          numerator: "",
          denominator: "",
          //@ts-expect-error ts(2322)
          paragraph_answer_key: type === "paragraph-sentence" ? val.paragraph_answer_key : null,
        }));
      }
    } else if (
      currentQuestion?.question_type === "twoFillInTheBlank" ||
      currentQuestion?.question_type === "threeFillInTheBlank"
    ) {
      const answerChoices = currentQuestion?.AnswerChoice || [];
      if ((value === "" || value === null) && typeof index === "number") {
        const answerGroup = index;

        const updatedStudentAnswers = [...selectAnswer].map((entry) => {
          const choice = answerChoices.find((ch) => ch.answer_choice_id === entry.answer_choice_id);
          const group = choice?.answer_group;

          if (group === answerGroup) {
            return {
              ...entry,
              answer_choice_id: null,
            };
          }
          return entry;
        });

        updatedAnswers = updatedStudentAnswers;
        setSelectAnswer(updatedAnswers);
        return;
      }

      // Existing logic: handle selection/change
      const selectedAnswerId = Number(value);
      const selectedChoice = answerChoices.find((ch) => ch.answer_choice_id === selectedAnswerId);
      const selectedGroup = selectedChoice?.answer_group;

      if (selectedGroup === undefined) return;

      const updatedStudentAnswers = [...selectAnswer];

      const existingIndex = updatedStudentAnswers.findIndex((entry) => {
        const entryChoice = answerChoices.find(
          (ch) => ch.answer_choice_id === entry.answer_choice_id,
        );
        const entryGroup = entryChoice?.answer_group;
        return entryGroup === selectedGroup;
      });

      const isAlreadySelected =
        existingIndex !== -1 &&
        updatedStudentAnswers[existingIndex]?.answer_choice_id === selectedAnswerId;

      if (isAlreadySelected) {
        updatedStudentAnswers[existingIndex] = {
          ...updatedStudentAnswers[existingIndex],
          answer_choice_id: null,
        };
      } else if (existingIndex !== -1) {
        updatedStudentAnswers[existingIndex] = {
          ...updatedStudentAnswers[existingIndex],
          answer_choice_id: selectedAnswerId,
        };
      } else {
        updatedStudentAnswers.push({
          student_answer_choice_id: null,
          answer_choice_id: selectedAnswerId,
          answer: "",
          numerator: "",
          denominator: "",
          paragraph_answer_key: null,
        });
      }

      updatedAnswers = updatedStudentAnswers;
      setSelectAnswer(updatedAnswers);
      return;
    } else {
      const prev = selectAnswer[index] || {};
      const base = {
        student_answer_choice_id: studentAnswerChoices[index]?.student_answer_choice_id
          ? Number(studentAnswerChoices[index]?.student_answer_choice_id)
          : null,
        answer_choice_id:
          type === "denominator" || type === "numerator"
            ? null
            : !answerType
              ? value
                ? Number(value)
                : null
              : answerChoices?.[index]?.answer_choice_id
                ? Number(answerChoices?.[index]?.answer_choice_id)
                : null,
        answer: "",
        numerator: prev.numerator ?? "",
        denominator: prev.denominator ?? "",
        paragraph_answer_key: prev.paragraph_answer_key ?? null,
      };

      const newEntry = { ...base };

      if (type === "textInput") {
        newEntry.answer = value;
      } else if (type === "paragraph-sentence") {
        newEntry.answer = "";
      } else if (type === "numerator") {
        newEntry.numerator = value;
      } else if (type === "denominator") {
        newEntry.denominator = value;
      }

      if (newEntry.numerator && newEntry.denominator) {
        // newEntry.answer_choice_id = 0
        newEntry.answer = `${newEntry.numerator}/${newEntry.denominator}`;
      }

      updatedAnswers = [
        ...selectAnswer.slice(0, index),
        newEntry,
        ...selectAnswer.slice(index + 1),
      ];
    }

    setSelectAnswer(updatedAnswers);
  };

  useEffect(() => {
    if (currentQuestion) {
      setIsQuestionMarked(currentQuestion.is_marked ?? false);
    }
  }, [currentQuestion]);

  const startHandler = () => {
    if (timerIdRef.current) return;

    timerIdRef.current = window.setInterval(() => {
      timeRef.current += 1;
    }, 1000);
  };

  const stopHandler = () => {
    if (timerIdRef.current) {
      clearInterval(timerIdRef.current);
      timerIdRef.current = 0;
      timeRef.current = 0;
    }
  };

  const handleQuestionTimeTaken = async () => {
    try {
      await examQuestionTimeTaken({
        questionId: currentQuestion?.student_question_id ?? 0,
        timeTaken: timeRef.current + (currentQuestion?.time_taken ?? 0),
      });
      stopHandler();
    } catch (error) {
      console.error("Failed to submit answer:", error);
    }
  };

  const navigateToQuestion = (sectionId: string | null, questionId: number) => {
    const basePath = role === USER_ROLE.STUDENT ? "exams" : "admin/preview";
    UtilLocalService.setLocalStorage("question_id", questionId || "");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(`/${basePath}/section/${sectionId}?question_id=${questionId}`);
  };

  const handlePrevious = async () => {
    if (role === USER_ROLE.STUDENT) {
      stopHandler();
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
      }
      const student_question_id = currentQuestion?.student_question_id;
      try {
        await examAnswerSubmit({
          student_question_id,
          answerChoices: selectAnswer,
          is_visited: true,
        });
      } catch (error) {
        logger.error("Failed to submit answer:", error);
      }
    }
    if (currentIndex > 0) {
      const newIndex = currentIndex - 1;
      setCurrentIndex(newIndex);
      const previousQuestionId =
        questionIds[newIndex]?.question_id || questionIds[newIndex]?.student_question_id;
      navigateToQuestion(selectedSectionId, previousQuestionId);
    }
  };

  const handleNext = async () => {
    if (role === USER_ROLE.STUDENT) {
      handleQuestionTimeTaken();
      stopHandler();
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
      }
      const student_question_id = currentQuestion?.student_question_id;
      try {
        await examAnswerSubmit({
          student_question_id,
          answerChoices: selectAnswer,
          is_visited: true,
        });
      } catch (error) {
        logger.error("Failed to submit answer:", error);
      }
    }

    if (currentIndex < questionIds.length - 1) {
      const newIndex = currentIndex + 1;
      setCurrentIndex(newIndex);
      const nextQuestionId =
        questionIds[newIndex]?.question_id || questionIds[newIndex]?.student_question_id;
      navigateToQuestion(selectedSectionId, nextQuestionId);
    }
    if (currentIndex === questionIds?.length - 1) {
      if (role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) {
        const { data: { section_id } = {} } = data || {};
        router.push(`${paths.ROOT_ADMIN_PREVIEW_SECTION}/${section_id}/instructions`);
      }
    }
  };

  const handleSectionChange = (value: string | null) => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    if (value) {
      UtilLocalService.removeLocalStorage(storageKey);
      setCurrentIndex(0);

      if (role === USER_ROLE.STUDENT) {
        router.push(`${paths.ROOT_STUDENT_PREVIEW_SECTION}/${value}/instructions`);
      } else {
        router.push(`${paths.ROOT_ADMIN_PREVIEW_SECTION}/${value}/instructions`);
      }
      setSelectedSectionId(value);
    }
  };

  const items = [
    { title: "Exam Management", href: adminStudentRoute },
    { title: examData?.data.exam_name || sectionData?.data?.section_name, active: true },
  ].map((item, index) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
        {item.title}
      </Anchor>
    ),
  );

  const handleExit = () => {
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(
      role === USER_ROLE.STUDENT ? paths.ROOT_END_EXAM(sectionId) : paths.ROOT_ADMIN_EXAM,
    );
  };

  const handleNavigateToQuestion = (index: number) => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    setCurrentIndex(index);
    const questionNavigate =
      questionIds[index]?.question_id || questionIds[index]?.student_question_id;
    navigateToQuestion(selectedSectionId, questionNavigate);
  };

  const handleNavigateToSectionQuestions = async () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    setIsLoading(true);
    if (role === USER_ROLE.STUDENT) {
      await examAnswerSubmit({
        student_question_id: currentQuestion?.student_question_id || 0,
        answerChoices: selectAnswer,
        is_visited: true,
      });
    }
    UtilLocalService.setLocalStorage("question_id", queryQuestionId || "");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(paths.ROOT_SECTION_REVIEW_QUESTIONS(sectionId));
  };

  const handleExitSection = async () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    UtilLocalService.setLocalStorage("question_id", queryQuestionId || "");
    if (role === USER_ROLE.STUDENT) {
      await examAnswerSubmit({
        student_question_id: currentQuestion?.student_question_id || 0,
        answerChoices: selectAnswer,
        is_visited: true,
      });
      handleQuestionTimeTaken();
    }
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(paths.ROOT_SECTION_EXIT(sectionId));
  };
  const handleHelpSection = async () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    setIsLoading(true);
    UtilLocalService.setLocalStorage("question_id", queryQuestionId || "");
    if (role === USER_ROLE.STUDENT) {
      await examAnswerSubmit({
        student_question_id: currentQuestion?.student_question_id || 0,
        answerChoices: selectAnswer,
        is_visited: true,
      });
    }
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(paths.ROOT_SECTION_HELP(sectionId));
  };
  if ((error && !error?.message?.includes("Pending section not found")) || questionError) {
    return <ExamErrorHandle errorMsg={`${t("error.lable")}`} />;
  }
  return (
    <Container size="xl" my="md">
      {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
        <Card mb="xl" p="sm">
          <Group justify="space-between" align="center" style={{ width: "100%" }}>
            <Breadcrumbs separatorMargin="xs" className="breadcrumbs-size">
              {items}
            </Breadcrumbs>
          </Group>
        </Card>
      )}
      <Box>
        <PreviewSection
          sectionName={sectionData?.data?.section_name || ""}
          currentQ={currentQuestion}
          isLoading={isSectionLoading || isExamDataLoading || isQuestionLoading}
          isSaving={isLoading || isQuestionFetching || isExamAnswerSubmitPending}
          currentIndex={currentIndex}
          handleNext={handleNext}
          handlePrevious={handlePrevious}
          questionIds={questionIds}
          handleExit={handleExit}
          handleHelpSection={handleHelpSection}
          handleExitSection={handleExitSection}
          analyticalWriting={
            sectionData?.data?.section_slug === "analytical-writing"
          }
          isQuantitiveSection={
            !!sectionData?.data?.section_slug?.includes("quantitative-reasoning")
          }
          role={typeof role === "string" ? role : ""}
          handleNavigateToQuestion={handleNavigateToQuestion} // Pass the navigation handler
          handleSubmitSection={handleSubmitSection}
          handleAnserChoices={handleAnserChoices}
          selectAnswer={selectAnswer}
          handleNavigateToSectionQuestions={handleNavigateToSectionQuestions}
          calculatorPermitted={sectionData?.data?.calculator_permitted}
          selectedSectionId={selectedSectionId || []}
          allSections={allSections || []}
          isExamDataLoading={isExamDataLoading}
          sectionSlug={sectionData?.data?.section_slug || ""}
          handleSectionChange={handleSectionChange}
          handleUpdatemark={handleUpdatemark}
          isQuestionMarked={isQuestionMarked}
          // timer={timer}
          setShowConfirmationModal={setShowConfirmationModal}
          showConfirmationModal={showConfirmationModal}
          sectionNumber={sectionData?.data?.display_order}
          initialTimeLimit={initialTimeLimit}
          isQuestionFetching={isQuestionFetching}
        />
      </Box>

      {role === USER_ROLE.STUDENT && (
        <>
          <Modal
            size={"lg"}
            withCloseButton={false}
            opened={isExamEndModalOpen}
            centered
            onClose={() => {
              setIsExamEndModalOpen(false);
            }}
          >
            <Flex direction="column" justify="center" align="center" mb="sm">
              <Box mt="sm" p={12}>
                <Image
                  src={isTimeUp ? examAlert : firework}
                  alt="Congratulations"
                  width={100}
                  height={100}
                />
              </Box>

              <Text c={isTimeUp ? "red.5" : "green.5"} size={"xxl"} ta="center">
                {isTimeUp
                  ? tStart("modal.success.timesUp")
                  : tStart("modal.success.completed.text")}
              </Text>
            </Flex>
            <Box mt="sm" p={24}>
              {isTimeUp ? (
                <Flex justify="center" align="center" mb="md" direction="column" gap="xl">
                  <Text size="md" ta="center" c="dimmed">
                    You’ve reached the end of this section. Hang tight you’re being moved to the
                    next part of the test.
                  </Text>
                  <Button variant="light" color="red">
                    Please do not refresh or close the window.
                  </Button>
                </Flex>
              ) : (
                <Flex justify="center" align="center" mb="md" direction="column" gap="xl">
                  <Text size="md" ta="center" c="dimmed">
                    {tStart("modal.success.text")}
                  </Text>

                  <Button variant="light" color="green">
                    {tStart("modal.success.button.text")}
                  </Button>
                </Flex>
              )}
            </Box>
          </Modal>
          <WarningAlertModal
            isShow={isDuplicateTab}
            onClose={() => {}}
            description={tGeneric("messages.modal.duplicateTabWarning.description")}
            showButtons={false}
          />
        </>
      )}
    </Container>
  );
}
