"use client";

import { Box, Button, Divider, Flex, Text } from "@mantine/core";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useRef, useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import TimerDisplay from "@/components/Common/Timer";
import { USER_ROLE } from "@/constants";
import { DEFAULT_EXAM_EXIT_SECTION } from "@/constants/exam";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGlobalActivityTracker } from "@/hooks/exam/useInactivityExit";
import { useGlobalActivityTrackerAfterTwoMin } from "@/hooks/exam/useInactivityUpdateAfterTwoMin";
import { useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import { useExamSectionCompleteMutation } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import ExitIcon from "@/public/icons/exit-icon.svg";
import PrevIcon from "@/public/icons/left-arrow.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import UtilLocalService from "@/utils/tools/localstorage";
import logger from "@/utils/tools/logger";

export default function ExitSection() {
  const router = useRouter();
  const t = useTranslations("preview");
  const { role } = useAuth();
  const { sectionId } = useParams<{ sectionId: string }>();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [isNavigating, setIsNavigating] = useState(false);
  const [redirectPath, setRedirectPath] = useState<string | null>(null);
  const buttonClickedRef = useRef(false);
  const { mutateAsync: examSectionComplete } = useExamSectionCompleteMutation();

  const { data: sectionData } = useGetQuestionsBySectionQuery({
    sectionId: sectionId,
    role: typeof role === "string" ? role : "",
  });

  const [sortedQuestions, setSortedQuestions] = useState(sectionData?.data?.questions || []);
  const question_id = UtilLocalService.getLocalStorage("question_id");
  const { updateScreenTime } = useUpdateScreenTime();

  useGlobalActivityTracker({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
        router.push("/exams");
      }
    },
  });
  useGlobalActivityTrackerAfterTwoMin({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
      }
    },
  });

  // On Page Load (Reload) redirect if navigation in progress
  useEffect(() => {
    const path = UtilLocalService.getLocalStorage("redirect_after_reload");
    if (path) {
      UtilLocalService.removeLocalStorage("redirect_after_reload");
      router.push(path.toString());
    }
  }, [router]);

  // Disable Back Navigation and Reload Icon during Navigation
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isNavigating) {
        useBlockBrowserNavigation(true);
        e.preventDefault();
        e.returnValue = "";
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (isNavigating && (e.key === "F5" || (e.ctrlKey && e.key === "r"))) {
        e.preventDefault();
      }
    };

    const handlePopState = (e: PopStateEvent) => {
      if (isNavigating && redirectPath) {
        e.preventDefault();
        window.history.pushState(null, "", window.location.href);
        router.push(redirectPath);
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("popstate", handlePopState);
    };
  }, [isNavigating]);

  useEffect(() => {
    if (sectionData?.data?.questions) {
      const numberedQuestions = sectionData.data.questions.map((q, index) => ({
        ...q,
        questionNumber: index + 1,
      }));

      const index = numberedQuestions.findIndex(
        (q) =>
          (q.question_id !== undefined && q.question_id === question_id) ||
          (q.student_question_id !== undefined && q.student_question_id === question_id),
      );

      if (index !== -1) {
        setCurrentIndex(index);
      }
      setSortedQuestions(numberedQuestions);
    }
  }, [sectionData]);

  const handleSubmitSection = async () => {
    // If any button clicked, block

    buttonClickedRef.current = true;
    setIsLoading(true);
    setIsNavigating(true);

    try {
      UtilLocalService.setLocalStorage("student_exam_section_id", String(sectionId) || "");
      const data = await examSectionComplete(sectionId);

      let nextPath = `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${data?.data?.student_exam_section_id}/instructions`;
      if (!data?.data?.student_exam_section_id) {
        nextPath =
          role === USER_ROLE.STUDENT
            ? `${paths.ROOT_END_EXAM(sectionId)}?id=${data?.data?.student_exam_id}`
            : paths.ROOT_ADMIN_EXAM;
      }

      UtilLocalService.setLocalStorage("redirect_after_reload", nextPath);
      setRedirectPath(nextPath);
      (window as WindowWithNextNav).__allowNextNavigation__?.();
      router.push(nextPath);
      return;
    } catch (error) {
      logger.error("Failed to complete section:", error);
      setIsNavigating(false);
      UtilLocalService.removeLocalStorage("redirect_after_reload");
    }
  };

  const handleGoBack = () => {
    // If any button clicked, block
    buttonClickedRef.current = true;
    setIsLoading(true);
    setIsNavigating(true);
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString());
    }
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(
      `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${sectionId}?question_id=${question_id ?? ""}`,
    );
  };

  return (
    <Box mih={400} className="exam-preview-section">
      {isLoading && (
        <Box
          style={{
            position: "absolute",
            inset: 0,
            backgroundColor: "rgba(255,255,255,0.4)",
            zIndex: 9999,
            cursor: "not-allowed",
          }}
        ></Box>
      )}
      <Box className="exam-header">
        <Box style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Box style={{ backgroundColor: "#fff", height: 50, borderRadius: "4px" }} pl={2}>
            <Image
              src={sherpaPreplogo}
              alt="Logo"
              width={150}
              height={50}
              style={{ objectFit: "contain", marginRight: "10px" }}
            />
          </Box>
          <Box style={{ backgroundColor: "#fff", height: 50, borderRadius: "4px" }}>
            <Image
              src={logo}
              alt="Logo"
              width={150}
              height={50}
              style={{ objectFit: "contain", marginRight: "10px" }}
            />
          </Box>
        </Box>

        <Flex justify="space-between" align="center">
          <Button
            variant="filled"
            onClick={handleGoBack}
            disabled={buttonClickedRef.current}
            className="btn-blue"
            rightSection={<Image src={PrevIcon} width={13} height={20} alt="next" />}
            mr={3}
          >
            Return
          </Button>

          <Button
            variant="default"
            onClick={() => {
              if (sectionData?.data.student_exam_id) {
                updateScreenTime(sectionData.data.student_exam_id.toString());
              }
              handleSubmitSection();
            }}
            disabled={buttonClickedRef.current}
            className="btn-blue btn-exit"
            rightSection={<Image src={ExitIcon} width={13} height={20} alt="next" />}
          >
            {t("buttons.exitSection.label")}
          </Button>
        </Flex>
      </Box>

      <Box className="exam-section-details">
        <Text size="sm" c="black">
          <Text span size="sm" fw={700}>
            Section {sectionData?.data?.display_order} of 5
          </Text>{" "}
          | Question {currentIndex + 1} of {sortedQuestions?.length}
        </Text>
        <TimerDisplay
          selectedSectionId={sectionId}
          initialTimeLimit={
            sectionData?.data
              ? Number(sectionData.data.time_taken ?? sectionData.data.time_limit)
              : null
          }
          handleSubmitSection={handleSubmitSection}
        />
      </Box>

      <Box className="instructions-container">
        <Flex justify="space-between" align="center">
          <Text fw={900} size="lg">
            Exit Section Confirmation
          </Text>
          <Box display={"flex"} miw={100}></Box>
        </Flex>
        <Divider my="sm" />
        <Box miw="20%" mb={80} mt={20}>
          <div dangerouslySetInnerHTML={{ __html: DEFAULT_EXAM_EXIT_SECTION }} />
        </Box>
      </Box>
    </Box>
  );
}
