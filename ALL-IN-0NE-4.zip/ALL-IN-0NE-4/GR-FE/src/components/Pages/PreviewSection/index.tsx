import { Box, Center, Checkbox, Group, Loader, Radio, Text } from "@mantine/core";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { memo, useCallback, useEffect, useRef, useState } from "react";

import DraggableCalculator from "@/components/Common/DraggableCalculator";
import ExamHeader from "@/components/Common/ExamHeader";
import ExamTimeAndSectionDetails from "@/components/Common/ExamTimeAndSectionDetails";
import GuidelineDisplay from "@/components/Common/GuidelineDisplay";
import { ConfirmationModal } from "@/components/Common/Modals";
import QuestionRenderer from "@/components/Common/QuestionRenderer";
import { END_SECTION_MODAL, QUESTION_LAYOUT } from "@/constants";
import { QUESTION_TYPE } from "@/constants/questions";
import BookmarkIcon from "@/public/icons/bookmark-icon.svg";
import CalculatorIcon from "@/public/icons/calculator.svg";
import ExitIcon from "@/public/icons/exit-icon.svg";
import HelpIcon from "@/public/icons/help-icon.svg";
import PrevIcon from "@/public/icons/left-arrow.svg";
import NextIcon from "@/public/icons/right-arrow.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { ISelectedSentenceObj, WindowWithNextNav } from "@/types";
import { IAnswerInput, IPreviewSectionProps } from "@/types/Exam/index";
import { cleanBrokenImagesFromHTML } from "@/utils";
import { highlightBySentence } from "@/utils/tools/highlightBySentence";
import UtilLocalService from "@/utils/tools/localstorage";

import QuestionPreviewModal from "./QuestionPreviewModal";
import classes from "./styles.module.css";

const PreviewSection = ({
  currentQ,
  isLoading,
  isSaving,
  currentIndex,
  handleNext,
  handlePrevious,
  questionIds,
  handleExit,
  handleExitSection,
  handleHelpSection,
  analyticalWriting,
  handleNavigateToQuestion,
  role,
  handleSubmitSection,
  handleAnserChoices,
  selectAnswer,
  isQuantitiveSection,
  handleNavigateToSectionQuestions,
  calculatorPermitted,
  selectedSectionId,
  allSections,
  sectionSlug,
  isExamDataLoading,
  handleSectionChange,
  handleUpdatemark,
  isQuestionMarked,
  setShowConfirmationModal,
  showConfirmationModal,
  sectionNumber,
  initialTimeLimit,
  isQuestionFetching,
}: Readonly<IPreviewSectionProps>) => {
  const [editorState, setEditorState] = useState({
    text: "",
    history: [] as string[],
    redoStack: [] as string[],
    clipboard: "",
    selection: [0, 0] as [number, number],
    buttonState: { cut: false, paste: false },
  });

  // Destructure for easy access
  const { text, history, redoStack, clipboard, buttonState } = editorState;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSentences, setSelectedSentences] = useState<ISelectedSentenceObj[]>([]);
  const [highlightedHTML, setHighlightedHTML] = useState("");
  const [opened, setOpened] = useState(false);
  const draggableRef = useRef<HTMLElement>(null);
  const t = useTranslations("preview");
  const tGeneric = useTranslations("generic");
  const router = useRouter();
  const [sanitizedHTML, setSanitizedHTML] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (currentQ?.question_type === QUESTION_TYPE.PARAGRAPH_SENTENCE) {
      const rawHTML = currentQ?.question_text ?? "";
      const wrapped = highlightBySentence(
        rawHTML,
        selectedSentences,
        "rgba(255, 255, 0, 0.4)",
        "rgba(255, 255, 0, 0.8)",
      );
      setHighlightedHTML(wrapped);
    } else {
      setHighlightedHTML(currentQ?.question_text ?? "");
    }
  }, [currentQ?.question_text, selectedSentences]);

  const modalDescription = <Box dangerouslySetInnerHTML={{ __html: END_SECTION_MODAL || "" }} />;

  useEffect(() => {
    const rawHTML =
      currentQ?.question_type === QUESTION_TYPE.PARAGRAPH_SENTENCE
        ? highlightedHTML
        : (currentQ?.question_text ?? t("messages.noQuestion"));

    setSanitizedHTML(cleanBrokenImagesFromHTML(rawHTML));
  }, [currentQ?.question_text, highlightedHTML]);

  useEffect(() => {
    if (currentQ?.question_type === QUESTION_TYPE.PARAGRAPH_SENTENCE) {
      const mappedAnswers = currentQ?.studentAnswerChoices?.map((ans) => ({
        answer_choice_id: ans.answer_choice_id,
        student_answer_choice_id: ans.student_answer_choice_id,
        answer: ans.answer,
        paragraph_answer_key:
          ans.paragraph_answer_key === null
            ? null
            : typeof ans.paragraph_answer_key === "number"
              ? ans.paragraph_answer_key
              : Number(ans.paragraph_answer_key),
      }));
      setSelectedSentences(mappedAnswers || []);
    }
  }, [currentQ]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "PrintScreen") {
        document.body.style.filter = "blur(10px)";
        setTimeout(() => {
          document.body.style.filter = "none";
        }, 1000);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const handleNavigateToSection = () => {
    UtilLocalService.setLocalStorage("student_exam_section_id", String(selectedSectionId) || "");
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(`${paths.ROOT_STUDENT_PREVIEW_SECTION}/end-section`);
  };
  useEffect(() => {
    if (currentQ?.question_type === QUESTION_TYPE.PARAGRAPH_SENTENCE) {
      handleAnserChoices(
        // @ts-expect-error ts(2349)
        selectedSentences,
        0,
        "paragraph-sentence",
      );
    }
  }, [selectedSentences]);

  useEffect(() => {
    setEditorState((prev) => ({
      ...prev,
      text: selectAnswer?.[0]?.answer || "",
    }));
  }, [selectAnswer]);

  useEffect(() => {
    const hasText = text.trim().length > 0;
    setEditorState((prev) => ({
      ...prev,
      buttonState: {
        cut: hasText,
        paste: clipboard?.length > 0,
      },
    }));
  }, [text, clipboard]);

  const handleCut = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    if (start === end) return;

    const cutText = text.slice(start, end);
    const newText = text.slice(0, start) + text.slice(end);

    setEditorState((prev) => ({
      ...prev,
      clipboard: cutText,
      text: newText,
      history: [...prev.history, prev.text],
      redoStack: [],
      buttonState: { cut: newText.length > 0, paste: true },
    }));

    // Set cursor to where cut was made
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start, start);
    }, 0);

    handleAnserChoices(newText, 0, "textInput");
  };

  const handlePaste = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const scrollTop = textarea.scrollTop;

    const newText = text.slice(0, start) + clipboard + text.slice(end);
    const newCursor = start + clipboard.length;

    setEditorState((prev) => ({
      ...prev,
      text: newText,
      history: [...prev.history, prev.text],
      redoStack: [],
      buttonState: { ...prev.buttonState, cut: newText.length > 0 },
    }));

    // Set cursor after pasted content
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursor, newCursor);
      textarea.scrollTop = scrollTop;
    }, 0);

    handleAnserChoices(newText, 0, "textInput");
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const prevText = history[history.length - 1];

    setEditorState((prev) => ({
      ...prev,
      text: prevText,
      history: prev.history.slice(0, -1),
      redoStack: [prev.text, ...prev.redoStack],
      buttonState: { ...prev.buttonState, cut: prevText.length > 0 },
    }));
    handleAnserChoices(prevText, 0, "textInput");
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const nextText = redoStack[0];

    setEditorState((prev) => ({
      ...prev,
      text: nextText,
      history: [...prev.history, prev.text],
      redoStack: prev.redoStack.slice(1),
      buttonState: { ...prev.buttonState, cut: nextText.length > 0 },
    }));
    handleAnserChoices(nextText, 0, "textInput");
  };

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      const isCmd = e.metaKey || e.ctrlKey;

      if (isCmd && e.key.toLowerCase() === "x") {
        e.preventDefault();
        handleCut();
      } else if (isCmd && e.key.toLowerCase() === "v") {
        e.preventDefault();
        handlePaste();
      } else if (isCmd && !e.shiftKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        handleUndo();
      } else if (
        isCmd &&
        (e.key.toLowerCase() === "y" || (e.shiftKey && e.key.toLowerCase() === "z"))
      ) {
        e.preventDefault();
        handleRedo();
      }
    },
    [handleCut, handlePaste, handleUndo, handleRedo],
  );

  const renderMultipleSelection = () => (
    <Box className={"answer-box"}>
      <Box className="answer-instructions-box mb-2">
        <Text>{currentQ?.passage_answer_instructions}</Text>
      </Box>
      <Checkbox.Group
        size="sm"
        className={classes["radio-group"]}
        // @ts-expect-error ts(2349)
        value={selectAnswer?.map((ans) => ans.answer_choice_id?.toString())}
        onChange={(value) => handleAnserChoices(value || [], 0, "")}
      >
        {currentQ?.AnswerChoice.map((opt: IAnswerInput, i: number) => {
          const val = opt.answer_choice_id?.toString() ?? `${i}`;
          return (
            <Checkbox.Card
              key={val}
              className={classes.root}
              value={val}
              checked={selectAnswer?.some((ans) => ans.answer_choice_id?.toString() === val)}
              disabled={isSaving}
              style={{ cursor: isSaving ? "not-allowed" : "pointer" }}
            >
              <Group wrap="nowrap" align="flex-start">
                <Checkbox.Indicator className="customCheckBoxIndicator" />
                <div>
                  <Text className={classes.label}>
                    <span
                      dangerouslySetInnerHTML={{
                        __html: opt.option_text ?? "",
                      }}
                    />
                  </Text>
                </div>
              </Group>
            </Checkbox.Card>
          );
        })}
      </Checkbox.Group>
    </Box>
  );

  const renderFillInTheBlank = () => {
    const options = currentQ?.AnswerChoice || [];
    const groupsMap = options.reduce<Record<number, IAnswerInput[]>>((acc, opt) => {
      const grp = opt.answer_group ?? 0;
      if (!acc[grp]) acc[grp] = [];
      acc[grp].push(opt);
      return acc;
    }, {});

    const blankCount =
      {
        twoFillInTheBlank: 2,
        threeFillInTheBlank: 3,
      }[currentQ?.question_type as string] ?? 1;

    const columns: IAnswerInput[][] = [];
    for (let grp = 1; grp <= blankCount; grp++) {
      columns.push(groupsMap[grp] || []);
    }

    return (
      <Box className="answer-box fill-in-the-blank">
        <Box className="answer-instructions-box mb-2">
          <Text>{currentQ?.passage_answer_instructions}</Text>
        </Box>
        <Group mt="md" align="start" justify="center" wrap="wrap" className="times-font">
          {columns.map((col, idx) => {
            const selectedVal =
              selectAnswer
                ?.find((ans) => col.some((opt) => opt.answer_choice_id === ans.answer_choice_id))
                ?.answer_choice_id?.toString() ?? "";

            return (
              <Box
                key={col.map((opt) => opt.answer_choice_id).join(",")}
                className={classes["clickable-boxes"]}
              >
                <Text fw={600} mb="xs" style={{ textAlign: "center" }}>
                  Blank ({["i", "ii", "iii"][idx]})
                </Text>
                <Radio.Group
                  name={`blank-${idx}`}
                  size="sm"
                  value={selectedVal}
                  className="fillInBlankGroupBlock"
                >
                  {col.map((opt) => {
                    const val = opt.answer_choice_id!.toString();
                    const isSel = selectAnswer?.some(
                      (ans) => ans.answer_choice_id?.toString() === val,
                    );
                    return (
                      <Radio.Card
                        key={val}
                        value={val}
                        checked={isSel}
                        disabled={isSaving}
                        className={"fillInBlankGroup"}
                        radius="md"
                        style={{ cursor: isSaving ? "not-allowed" : "pointer" }}
                        onClick={() =>
                          handleAnserChoices(isSel ? "" : val, Number(opt?.answer_group), "")
                        }
                      >
                        <Group wrap="nowrap" align="flex-start">
                          <div>
                            <Text className={classes.label}>
                              <span
                                dangerouslySetInnerHTML={{
                                  __html: opt.option_text ?? "",
                                }}
                              />
                            </Text>
                          </div>
                        </Group>
                      </Radio.Card>
                    );
                  })}
                </Radio.Group>
              </Box>
            );
          })}
        </Group>
      </Box>
    );
  };

  const isFillInTheBlank = [
    "oneFillInTheBlank",
    "twoFillInTheBlank",
    "threeFillInTheBlank",
  ].includes(currentQ?.question_type ?? "");

  const handleSentenceClick = (e: React.MouseEvent<HTMLDivElement>) => {
    let target = e.target as HTMLElement;

    while (target && (!target.dataset.sentIndex || target.tagName !== "SPAN")) {
      target = target.parentElement as HTMLElement;
      if (!target) return; // In case we reach the top without finding it
    }

    const idx = Number(target.dataset.sentIndex);
    const txt = target.dataset.sentText ?? "";

    // Is this the currently selected sentence?
    const isSelected = selectedSentences.some((s) => s.paragraph_answer_key === idx);

    if (isSelected) {
      // Deselect it
      setSelectedSentences([]);
    } else {
      // Select only this one (clear any previous)
      const newObj: ISelectedSentenceObj = {
        student_answer_choice_id: null,
        answer_choice_id: null,
        paragraph_answer_key: idx,
        answer: txt,
      };
      setSelectedSentences([newObj]);
    }
  };

  const cancelLeave = () => {
    setShowConfirmationModal(false);
  };

  const getNumAndDemValueFromAnswer = (value: string) => {
    if (!value) return { numerator: "", denominator: "" };
    const numerator = value.split("/")[0];
    const denominator = value.split("/")[1];
    return { numerator, denominator };
  };

  return (
    <Box mih={400} className="exam-preview-section">
      <DraggableCalculator
        opened={opened}
        setOpened={setOpened}
        draggableRef={draggableRef}
        currentQ={currentQ}
        role={role}
        handleAnserChoices={handleAnserChoices}
      />
      <ExamHeader
        logo={logo}
        sherpaPreplogo={sherpaPreplogo}
        role={role}
        selectedSectionId={String(selectedSectionId)}
        allSections={allSections}
        handleSectionChange={handleSectionChange}
        handleHelpSection={handleHelpSection}
        handleExitSection={handleExitSection}
        handleNavigateToSectionQuestions={handleNavigateToSectionQuestions}
        handleExit={handleExit}
        handlePrevious={handlePrevious}
        handleNext={handleNext}
        handleNavigateToSection={handleNavigateToSection}
        handleUpdatemark={handleUpdatemark}
        isSaving={isSaving}
        isExamDataLoading={isExamDataLoading}
        isQuestionFetching={isQuestionFetching}
        questionIds={questionIds}
        currentIndex={currentIndex}
        isQuestionMarked={isQuestionMarked}
        calculatorPermitted={calculatorPermitted}
        opened={opened}
        setOpened={setOpened}
        analyticalWriting={analyticalWriting}
        sectionSlug={sectionSlug}
        t={t}
        icons={{
          HelpIcon,
          ExitIcon,
          CalculatorIcon,
          BookmarkIcon,
          PrevIcon,
          NextIcon,
        }}
      />
      <ExamTimeAndSectionDetails
        role={role}
        sectionNumber={sectionNumber}
        currentQ={currentQ}
        currentIndex={currentIndex}
        questionIds={questionIds}
        selectedSectionId={String(selectedSectionId) || ""}
        initialTimeLimit={initialTimeLimit ?? 0}
        handleSubmitSection={handleSubmitSection}
        t={t}
      />
      <Box
        p={2}
        className={`question-container ${
          currentQ?.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM && "question-container-vertical"
        }`}
      >
        {isLoading ? (
          <Center style={{ height: "300px", backgroundColor: "transparent" }}>
            <Loader type="oval" size="lg" />
          </Center>
        ) : (
          <>
            {!isQuantitiveSection &&
              !analyticalWriting &&
              currentQ?.guidelines &&
              currentQ.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM && (
                <GuidelineDisplay guidelines={currentQ?.guidelines ?? t("messages.noGuidelines")} />
              )}
            <Box
              className={
                currentQ?.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM
                  ? "vertical-layout"
                  : "horizontal-layout"
              }
            >
              <QuestionRenderer
                analyticalWriting={analyticalWriting}
                isFillInTheBlank={isFillInTheBlank}
                isQuantitiveSection={isQuantitiveSection}
                currentQ={currentQ}
                sanitizedHTML={sanitizedHTML}
                selectAnswer={selectAnswer}
                isSaving={isSaving}
                renderFillInTheBlank={renderFillInTheBlank}
                renderMultipleSelection={renderMultipleSelection}
                handleAnserChoices={handleAnserChoices}
                handleSentenceClick={handleSentenceClick}
                text={text}
                role={role}
                textareaRef={textareaRef}
                buttonState={buttonState}
                history={history}
                redoStack={redoStack}
                handleCut={handleCut}
                handlePaste={handlePaste}
                handleUndo={handleUndo}
                handleRedo={handleRedo}
                handleKeyDown={handleKeyDown}
                setEditorState={setEditorState}
                getNumAndDemValueFromAnswer={getNumAndDemValueFromAnswer}
              />

              {currentQ?.instructions?.trim() &&
                currentQ?.question_layout === QUESTION_LAYOUT.LEFTTORIGHT && (
                  <Box className={`instructions-box-outer ${analyticalWriting && "d-none"}`}>
                    <Box className="instructions-box">
                      <Text>{currentQ?.instructions}</Text>
                    </Box>
                  </Box>
                )}
              <QuestionPreviewModal
                isModalOpen={isModalOpen}
                setIsModalOpen={setIsModalOpen}
                questionIds={questionIds}
                currentIndex={currentIndex}
                handleNavigateToQuestion={handleNavigateToQuestion}
              />
            </Box>
            {currentQ?.instructions?.trim() &&
              currentQ?.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM && (
                <Box className={`instructions-box-outer ${analyticalWriting && "d-none"}`}>
                  <Box className="instructions-box">
                    <Text>{currentQ?.instructions}</Text>
                  </Box>
                </Box>
              )}
          </>
        )}
      </Box>
      <ConfirmationModal
        opened={showConfirmationModal ?? false}
        title={tGeneric("buttons.warning")}
        description={modalDescription}
        onConfirm={handleSubmitSection}
        onCancel={cancelLeave}
        buttonText={tGeneric("buttons.confirm")}
        disabled={isSaving}
      />
    </Box>
  );
};

export default memo(PreviewSection);
