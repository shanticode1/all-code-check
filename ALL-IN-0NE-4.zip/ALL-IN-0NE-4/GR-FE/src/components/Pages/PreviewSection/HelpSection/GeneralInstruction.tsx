"use client";
import { Box, Card, Center, Divider, Loader, Stack, Text, Title } from "@mantine/core";
import { IconClock } from "@tabler/icons-react";
import { usePathname } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useMemo } from "react";
import sanitizeHtml from "sanitize-html";

import { useGetExamByIdQuery } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { convertSecondsToHoursAndMinutes } from "@/utils";

import ExamErrorHandle from "../../ExamErrorHandle";

interface GeneralInstructionProps {
  exam_id: string;
}

export default function GeneralInstruction({ exam_id }: Readonly<GeneralInstructionProps>) {
  const t = useTranslations("examDetail");
  const { role } = useAuth();
  const pathname = usePathname();

  const {
    data: examDetail,
    isLoading: isExamDataLoading,
    isFetching: isExamDataFetching,
    error,
  } = useGetExamByIdQuery(exam_id, role as string);

  const examData = examDetail?.data;

  const sanitizedInstructions = useMemo(() => {
    let rawHtml = examData?.guidelines || "";
    // remove continue text from help section page
    if (pathname?.includes("help-section")) {
      rawHtml = rawHtml.replace(
        /<p>\s*Press the start button below to Continue your exam.\s*<\/p>/i,
        "",
      );
    }
    return sanitizeHtml(rawHtml, {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat(["img", "h1", "h2", "p"]),
      allowedAttributes: {
        ...sanitizeHtml.defaults.allowedAttributes,
        img: ["src", "alt", "width", "height"],
      },
      allowedSchemes: ["http", "https", "data"],
    });
  }, [examData]);

  if (isExamDataLoading || isExamDataFetching) {
    return (
      <Center h="50vh">
        <Loader type="oval" />
      </Center>
    );
  }
  if (error && !error?.message?.includes("Pending section not found")) {
    return <ExamErrorHandle errorMsg={`${t("error.lable")}`} />;
  }

  return (
    <Box mx="auto">
      <Card padding={30} shadow="none" radius="0">
        <Stack gap="md">
          <Text fw={800} size="xl">
            {examData?.exam_name}
          </Text>
          <Box style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 8 }}>
            <IconClock size={24} />
            <Text size="sm" c="dimmed">
              {t("help.card.text")}: {convertSecondsToHoursAndMinutes(examData?.exam_duration ?? 0)}
            </Text>
          </Box>
          <Divider my="sm" />
          <Title order={3}> {t("help.card.title")}</Title>
          <div
            style={{ fontSize: 18, lineHeight: 1.6 }}
            dangerouslySetInnerHTML={{ __html: sanitizedInstructions }}
          />
        </Stack>
      </Card>
    </Box>
  );
}
