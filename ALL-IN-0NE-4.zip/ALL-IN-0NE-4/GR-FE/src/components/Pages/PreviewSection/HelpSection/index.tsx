"use client";

import { Box, Button, Paper, Tabs, Text } from "@mantine/core";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import DualLogoHeader from "@/components/Common/DualLogoHeader";
import TimerDisplay from "@/components/Common/Timer";
import { LOCAL_VARIABLE, USER_ROLE } from "@/constants";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGlobalActivityTracker } from "@/hooks/exam/useInactivityExit";
import { useGlobalActivityTrackerAfterTwoMin } from "@/hooks/exam/useInactivityUpdateAfterTwoMin";
import { useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import arrowLeftLong from "@/public/icons/arrow-left-long.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import UtilLocalService from "@/utils/tools/localstorage";
import logger from "@/utils/tools/logger";

import ExamErrorHandle from "../../ExamErrorHandle";
import GeneralInstruction from "./GeneralInstruction";
import SectionInstruction from "./SectionInstruction";

export default function SectionQuestionsReview() {
  useBlockBrowserNavigation(true);
  const router = useRouter();
  const { role } = useAuth();
  const { updateScreenTime } = useUpdateScreenTime();
  const { sectionId } = useParams<{ sectionId: string }>();
  const t = useTranslations("examDetail");
  const [isLoading, setIsLoading] = useState(false);
  const { data: sectionData, error } = useGetQuestionsBySectionQuery({
    sectionId: sectionId || "",
    role: typeof role === "string" ? role : "",
  });

  const question_id = UtilLocalService.getLocalStorage("question_id");
  const initialTimeLimit = sectionData?.data
    ? Number(sectionData.data.time_taken ?? sectionData.data.time_limit)
    : null;

  useGlobalActivityTracker({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
        router.push("/exams");
      }
    },
  });
  useGlobalActivityTrackerAfterTwoMin({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
      }
    },
  });
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [sectionData]);
  const handleSubmitSection = async () => {
    try {
      if (role === USER_ROLE.SUPERADMIN) {
        router.push(paths.ROOT_ADMIN_EXAM);
        return;
      }
      UtilLocalService.setLocalStorage("student_exam_section_id", String(sectionId) || "");
      UtilLocalService.removeLocalStorage("redirect_after_reload_section");
      UtilLocalService.removeLocalStorage("redirect_after_reload");
      (window as WindowWithNextNav).__allowNextNavigation__?.();
      router.push(`${paths.ROOT_STUDENT_PREVIEW_SECTION}/end-section`);
      return;
    } catch (error) {
      logger.error("Failed to update exam timer:", error);
    }
  };

  const handleGoBack = () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    setIsLoading(true);
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(
      `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${sectionId}?question_id=${question_id ?? ""}`,
    );
  };
  if (error && !error?.message?.includes("Pending section not found")) {
    return <ExamErrorHandle errorMsg={`${t("error.lable")}`} />;
  }
  return (
    <Box mih={400} className="exam-preview-section">
      <Box className="exam-header">
      <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
        <Box>
          <Button
            disabled={isLoading}
            variant="filled"
            onClick={() => handleGoBack()}
            className="btn-blue"
          >
            <Box
              style={{
                display: "flex",
                flexFlow: "column",
                alignItems: "center",
                gap: "3px",
                minHeight: "30px",
              }}
            >
              <Text size="sm" c="#fff">
                Return
              </Text>
              <Image src={arrowLeftLong} width={20} alt="next" />
            </Box>
          </Button>
        </Box>
      </Box>
      <Box className="exam-section-details">
        <Box></Box>
        <TimerDisplay
          selectedSectionId={sectionId}
          initialTimeLimit={initialTimeLimit}
          handleSubmitSection={handleSubmitSection}
        />
      </Box>
      <Paper p="xl" withBorder radius={0}>
        <Tabs defaultValue="general" mt="md">
          <Tabs.List>
            <Tabs.Tab value="general">{t("help.tabs", { value: LOCAL_VARIABLE.General })}</Tabs.Tab>
            <Tabs.Tab value="section">{t("help.tabs",{value:LOCAL_VARIABLE.Section})}</Tabs.Tab>
          </Tabs.List>

          <Tabs.Panel value="general" pt="xs">
            <GeneralInstruction exam_id={String(sectionData?.data?.exam?.exam_id) || ""} />
          </Tabs.Panel>

          <Tabs.Panel value="section" pt="xs">
            <SectionInstruction />
          </Tabs.Panel>
        </Tabs>
      </Paper>
    </Box>
  );
}
