"use client";

import { Box, Card, Divider, Group, Text, Title } from "@mantine/core";
import { IconClock, IconProgressHelp } from "@tabler/icons-react";
import { useParams, usePathname } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useMemo } from "react";
import sanitizeHtml from "sanitize-html";

import Loader from "@/components/Common/Loaders/Loader";
import { useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import { useAuth } from "@/lib/Contexts/AuthProvider";

export default function SectionInstruction() {
  const { sectionId } = useParams<{ sectionId: string }>();
  const t = useTranslations("generic");
  const pathname = usePathname();
  const { role } = useAuth() as { role: string };
  const {
    data: sectionData,
    isLoading: isFetchingSection,
    isError: hasSectionError,
  } = useGetQuestionsBySectionQuery({ sectionId, role });

  const sanitizedInstructions = useMemo(() => {
    let rawHtml = sectionData?.data?.instructions ?? "";
    // remove continue text from help section page 
    if (pathname?.includes("help-section")) {
      rawHtml = rawHtml.replace(
        /<p>\s*Select\s*<strong>Continue<\/strong>\s*to\s*proceed\.\s*<\/p>/i,
        "",
      );
    }
    return sanitizeHtml(rawHtml, {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat(["img", "h1", "h2"]),
      allowedAttributes: {
        ...sanitizeHtml.defaults.allowedAttributes,
        img: ["src", "alt", "width", "height"],
      },
      allowedSchemes: ["http", "https", "data"],
    });
  }, [sectionData]);

  return (
    <Box maw={1024} mx="auto">
      {isFetchingSection ? (
        <Loader />
      ) : hasSectionError || !sectionData ? (
        <Card shadow="sm" p="lg">
          <Title order={2} mb="md">
            {t("messages.error.general.label")}
          </Title>
          <Text c="dimmed">{t("messages.error.general.description")}</Text>
        </Card>
      ) : (
        <Card shadow="none" p="xl">
          <Title order={3} pb="md">
            {sectionData?.data?.section_name}
          </Title>
          <Group gap="xs" wrap="nowrap">
            <Group gap="xs" wrap="nowrap">
              <IconClock />
              <Text size="sm" component="span">
                {Math.floor(Number(sectionData?.data?.time_limit || 0) / 60)} minutes
              </Text>
            </Group>
            <Group gap="xs" wrap="nowrap">
              <IconProgressHelp />
              <Box>
                <Text size="sm" component="span">
                  {sectionData?.data?.questions?.length}{" "}
                  {sectionData?.data?.questions?.length === 1 ? "Question" : "Questions"}
                </Text>
              </Box>
            </Group>
          </Group>
          <Divider my="sm" />
          <div
            style={{ fontSize: 18, lineHeight: 1.6 }}
            dangerouslySetInnerHTML={{ __html: sanitizedInstructions }}
          />
        </Card>
      )}
    </Box>
  );
}
