"use client";

import { Box, Button, Card, Divider, Text } from "@mantine/core";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import DualLogoHeader from "@/components/Common/DualLogoHeader";
import { USER_ROLE } from "@/constants";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import arrowRightLong from "@/public/icons/arrow-right-long.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import UtilLocalService from "@/utils/tools/localstorage";

export default function SectionEndConfirmation() {
  useBlockBrowserNavigation(true);
  const router = useRouter();
  const { role } = useAuth();
  const searchParams = useSearchParams();
  const id = searchParams.get("id");
  const t = useTranslations("generic");
  const tPreview = useTranslations("preview");
  const [isLoading, setIsLoading] = useState(false);

  const handleEndExam = () => {
    setIsLoading(true);
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    UtilLocalService.removeLocalStorage("question_id");
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(role === USER_ROLE.STUDENT ? `/exam/${id}` : paths.ROOT_ADMIN_EXAM);
  };

  return (
    <Box mih={400} className="exam-preview-section">
      <Box className="exam-header">
        <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
        <Box>
          <Button
            className="btn-blue"
            variant="filled"
            color="blue"
            onClick={() => handleEndExam()}
            disabled={isLoading}
            rightSection={<Image src={arrowRightLong} width={20} alt="next" />}
          >
            {t("buttons.continue", { value: "exam" })}
          </Button>
        </Box>
      </Box>
      <Box className="exam-section-details">
        <Text size="sm" c="black"></Text>
      </Box>
      <Card radius="0" shadow="none" className="instructions-container">
        <Text fw={900} size="lg">
         {tPreview("endTest.card.title")}
        </Text>
        <Divider my="md" />
        <br />
        {tPreview("endTest.card.sessionComplete")}
        <br />
        <br />
        <Text>
          Please {t("buttons.select")} <strong> {t("buttons.continue")}</strong> to {t("buttons.exit")}
        </Text>
      </Card>
    </Box>
  );
}
