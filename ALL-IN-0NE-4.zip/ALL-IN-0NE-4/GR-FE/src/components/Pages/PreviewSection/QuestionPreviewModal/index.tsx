import { Badge,Button, Divider, Modal, SimpleGrid, Text } from "@mantine/core";
import React from "react";

import { IQuestionPreviewModal, IQuestionResponse } from "@/types/Exam/index";
import { IPreviewQuestionType } from "@/types/Exam/ViewExam";
export default function QuestionPreviewModal({
  isModalOpen,
  setIsModalOpen,
  questionIds,
  currentIndex,
  handleNavigateToQuestion,
}: Readonly<IQuestionPreviewModal>) {

  function getColor(q: IPreviewQuestionType, index: number, currentIndex: number) {
    if (q?.is_attended) return "green.6";
    if (index === currentIndex) return "blue";
    return "gray.4";
  }
 
  return (
    <div>
      <Modal
        opened={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Question Navigator"
        size="lg"
        
      >
        <Text py="lg" px="lg" c="dimmed">
          You can simply navigate to another question in this section by clicking the question number.
        </Text>
        <SimpleGrid cols={5} spacing="lg" mt="sm" py="lg" px="lg">
          {questionIds.map((q: IQuestionResponse, index: number) => (
            <Button
              key={q.question_id}
              // variant={index === currentIndex || q?.is_attended ? "filled" : "outline"}
              variant={"filled"}
              style={{ color: q?.is_attended || index === currentIndex ? "#fff" : "#444" }}
              onClick={() => {
                handleNavigateToQuestion(index);
                setIsModalOpen(false);
              }}
              color={getColor(q, index, currentIndex)}
            >
              {index + 1}
            </Button>
          ))}

        </SimpleGrid>
          <Divider my="sm" />
          <Text py="sm" px="sm" c="dimmed">
          Status : <Badge color="gray.4" style={{ color: "#444"}}>Unanswered</Badge> <Badge color="blue">Current</Badge> <Badge color="green.6">Answered</Badge>  
        </Text>
      </Modal>
    </div>
  );
}
