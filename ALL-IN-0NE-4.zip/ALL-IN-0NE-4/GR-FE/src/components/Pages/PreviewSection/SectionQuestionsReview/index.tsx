"use client";

import { Box, Button, Divider, Flex, Group, Text, Title, Tooltip } from "@mantine/core";
import { IconCheck } from "@tabler/icons-react";
import { DataTable } from "mantine-datatable";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import DualLogoHeader from "@/components/Common/DualLogoHeader";
import TimerDisplay from "@/components/Common/Timer";
import { USER_ROLE } from "@/constants";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGlobalActivityTracker } from "@/hooks/exam/useInactivityExit";
import { useGlobalActivityTrackerAfterTwoMin } from "@/hooks/exam/useInactivityUpdateAfterTwoMin";
import { useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import arrowLeftLong from "@/public/icons/arrow-left-long.svg";
import arrowRightLong from "@/public/icons/arrow-right-long.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import { AnswerStatusLables,IQuestion } from "@/types/Student/Exam";
import UtilLocalService from "@/utils/tools/localstorage";

import ExamErrorHandle from "../../ExamErrorHandle";

export default function SectionQuestionsReview() {
  useBlockBrowserNavigation(true);
  const router = useRouter();
  const t = useTranslations("preview");
  const t_start = useTranslations("startExam");
  const tExam = useTranslations("examDetail");
  const { role } = useAuth();
  const { sectionId } = useParams<{ sectionId: string }>();
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const { data: sectionData, error } = useGetQuestionsBySectionQuery({
    sectionId: sectionId || "",
    role: typeof role === "string" ? role : "",
  });
  const { updateScreenTime } = useUpdateScreenTime();
  const [sortedQuestions, setSortedQuestions] = useState(sectionData?.data?.questions || []);

  useGlobalActivityTracker({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
        router.push("/exams");
      }
    },
  });
  useGlobalActivityTrackerAfterTwoMin({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
      }
    },
  });
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [sectionData]);

  useEffect(() => {
    if (sectionData?.data?.questions) {
      const numberedQuestions = sectionData.data.questions.map((q, index) => ({
        ...q,
        questionNumber: index + 1,
      }));

      const index = numberedQuestions.findIndex(
        (q) =>
          (q.question_id !== undefined && q.question_id === question_id) ||
          (q.student_question_id !== undefined && q.student_question_id === question_id),
      );

      if (index !== -1) {
        setCurrentIndex(index);
      }
      setSortedQuestions(numberedQuestions);
    }
  }, [sectionData]);

  const [sortStatus, setSortStatus] = useState<{
    columnAccessor: string;
    direction: "asc" | "desc";
  }>({
    columnAccessor: "question",
    direction: "asc",
  });

  const handleSort = (status: { columnAccessor: string; direction: "asc" | "desc" }) => {
    setSortStatus(status);

    const sorted = [...sortedQuestions].sort((a, b) => {
      const aVal = a.questionNumber ?? a.student_question_id;
      const bVal = b.questionNumber ?? b.student_question_id;

      return status.direction === "asc" ? aVal - bVal : bVal - aVal;
    });
    setSortedQuestions(sorted);
  };

  const initialTimeLimit = sectionData?.data
    ? Number(sectionData.data.time_taken ?? sectionData.data.time_limit)
    : null;

  const question_id = UtilLocalService.getLocalStorage("question_id");

  useEffect(() => {
    if (!sortedQuestions?.length || !question_id) return;

    const id = question_id?.toString() ?? "";
    const rec = sortedQuestions.find((q) => {
      const qid = role === USER_ROLE.STUDENT ? q.student_question_id : q.question_id;
      return qid === id && q.is_visited;
    });
    if (rec) {
      setSelectedRowId(id);
    }
  }, [sortedQuestions, question_id, role]);

  const handleSubmitSection = async () => {
    setIsLoading(true);
    if (role === USER_ROLE.SUPERADMIN) {
      router.push(paths.ROOT_ADMIN_EXAM);
      return;
    }
    try {
      UtilLocalService.setLocalStorage("student_exam_section_id", String(sectionId) || "");
      UtilLocalService.removeLocalStorage("redirect_after_reload_section");
      UtilLocalService.removeLocalStorage("redirect_after_reload");
      (window as WindowWithNextNav).__allowNextNavigation__?.();
      router.push(`${paths.ROOT_STUDENT_PREVIEW_SECTION}/end-section`);
    } catch (error) {
      console.error("Failed to update exam timer:", error);
    }
  };

  const questionColumns = [
    {
      title: "Number",
      accessor: "question", // This must match the sortStatus key
      sortable: true,
      render: (item: IQuestion) => {
        const isHighlighted =
          role === USER_ROLE.STUDENT
            ? item.student_question_id === question_id
            : item.question_id === question_id;
        return (
          <Group gap={8} align="center" wrap="nowrap">
            <Text span fw={isHighlighted ? "600" : "500"} size="sm">
              Question {item.questionNumber}
            </Text>
          </Group>
        );
      },
    },
    {
      title: "Status",
      accessor: "is_attended",
      render: ({ answer_status }: IQuestion) => {
        return (
          <Text span size="sm">
            {AnswerStatusLables[answer_status]}
          </Text>
        );
      },
    },
    {
      title: "Marked",
      accessor: "is_marked",
      render: ({ is_marked }: IQuestion) => {
        return is_marked ? (
          <Tooltip label={t("tooltip.label.marked")}>
            <IconCheck size={24} stroke={2} color="black" />
          </Tooltip>
        ) : (
          "-"
        );
      },
    },
  ];

  const handleGoBack = () => {
    setIsLoading(true);
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    if (selectedRowId) {
      (window as WindowWithNextNav).__allowNextNavigation__?.();
      router.push(
        `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${sectionId}?question_id=${selectedRowId || ""}`,
      );
    }
  };
  const handleReturn = () => {
    if (sectionData?.data.student_exam_id) {
      updateScreenTime(sectionData?.data.student_exam_id.toString()); // Tab Close / Reload API Call
    }
    setIsLoading(true);
    (window as WindowWithNextNav).__allowNextNavigation__?.();
    router.push(
      `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${sectionId}?question_id=${question_id ?? ""}`,
    );
    UtilLocalService.removeLocalStorage("question_id");
  };

  if (error && !error?.message?.includes("Pending section not found")) {
    return <ExamErrorHandle errorMsg={`${tExam("error.lable")}`} />;
  }
  return (
    <Box mih={400} className="exam-preview-section">
      <Box maw={1024} ml={"auto"} mr={"auto"}>
        <Box className="exam-header">
          <Flex justify="space-between" align="center" w={"100%"}>
            <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
            <Box>
              <Group justify="space-between" gap={0}>
                <Button
                  variant="filled"
                  onClick={handleReturn}
                  disabled={isLoading}
                  className="btn-blue"
                  mr={3}
                >
                  <Box
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "3px",
                      minHeight: "30px",
                    }}
                  >
                    <Text size="sm" c="#fff">
                      {t_start("buttons.return")}
                    </Text>
                    <Image src={arrowLeftLong} width={20} alt="next" />
                  </Box>
                </Button>

                <Button
                  variant="filled"
                  onClick={handleGoBack}
                  className="btn-blue"
                  disabled={!selectedRowId || isLoading}
                >
                  <Box
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "3px",
                      minHeight: "30px",
                    }}
                  >
                    <Text size="sm" c="#fff">
                      {t_start("buttons.goToQuestion")}
                    </Text>
                    <Image src={arrowRightLong} width={20} alt="next" />
                  </Box>
                </Button>
              </Group>
            </Box>
          </Flex>
        </Box>

        <Box
          display={"flex"}
          bg={"#f0e1e4"}
          p={"4px 8px"}
          style={{
            justifyContent: "space-between",
            borderTop: "2px solid #882f5c",
          }}
        >
          <Box>
            <Text size="sm" c="black">
              <Text span size="sm" fw={700}>
               {t("other.section")} {sectionData?.data?.display_order} of 5{" "}
              </Text>{" "}
              | {t("other.question")} {currentIndex + 1} of {sortedQuestions?.length}
            </Text>
          </Box>
          <TimerDisplay
            selectedSectionId={sectionId}
            initialTimeLimit={initialTimeLimit}
            handleSubmitSection={handleSubmitSection}
          />
        </Box>

        <Box className="arial-font" bg={"#fff"} pl={100} pr={100} pt={50} pb={30}>
          <Title order={3} className="arial-font-heading">
            {t("other.reviewSection")}
          </Title>
          <Divider mt={20} pb={20} />
          <Box miw="20%" mb={80}>
            {t("text.reviewSection.label")}
          </Box>
          <Box className="question-container review-box">
            <Box className="question-box">
              <Group align="center" mb={8}>
                <Text>
                  First {sortedQuestions?.length}  {t("other.sortingText")}{" "}
                  {sortStatus.direction === "asc" ? "Ascending" : "Descending"} Order
                </Text>
              </Group>
              <DataTable
                columns={questionColumns}
                // @ts-expect-error ts-migrate(2322) FIXME: Type '{ columns: { title: string; accessor: strin... Remove this comment
                records={sortedQuestions}
                sortStatus={sortStatus}
                onSortStatusChange={handleSort}
                withColumnBorders
                withRowBorders
                withTableBorder
                highlightOnHover
                backgroundColor={{ dark: "#959595", light: "#959595" }}
                verticalAlign="top"
                pinLastColumn
                borderColor="#000000"
                rowBorderColor="#000000"
                noRecordsText="No questions found"
                onRowClick={(row) => {
                  const selectedId =
                    role === USER_ROLE.STUDENT
                      ? row.record.student_question_id
                      : row.record.question_id;

                  if (role === USER_ROLE.STUDENT && row.record.is_visited) {
                    UtilLocalService.setLocalStorage("question_id", String(selectedId));
                    setSelectedRowId(selectedId);
                  }
                }}
                rowStyle={(row) => {
                  const selectedRowQuestionId =
                    role === USER_ROLE.STUDENT ? row.student_question_id : row.question_id;

                  const isSelected = selectedRowQuestionId === selectedRowId;

                  const allStatusFalse =
                    !row.is_attended && !row.is_correct && !row.is_marked && !row.is_visited;

                  //  Disable interaction completely if all statuses are false
                  if (allStatusFalse) {
                    return {
                      backgroundColor: "#959595",
                      pointerEvents: "none",
                      cursor: "not-allowed",
                    };
                  }

                  // Determine base background color
                  let backgroundColor = "transparent";

                  if (row.is_attended && row.is_visited) {
                    backgroundColor = "#ffffff";
                  } else if (!row.is_attended && row.is_visited) {
                    backgroundColor = "#ffffff";
                  } else if (row.is_visited) {
                    backgroundColor = "#D1E4EF";
                  } else if (isSelected) {
                    backgroundColor = "#959595";
                  }

                  // Override background if selected (to ensure visibility)
                  if (isSelected) {
                    if (!row.is_attended && row.is_visited) {
                      backgroundColor = "#e6f4fa"; // subtle selected-white
                    } else if (row.is_visited) {
                      backgroundColor = "#D1E4EF";
                    } else {
                      backgroundColor = "#959595";
                    }
                  }

                  return {
                    backgroundColor,
                    fontWeight: isSelected ? "500" : "normal",
                    cursor: "pointer",
                  };
                }}
                style={{
                  cells: {
                    fontSize: "14px",
                  },
                }}
              />
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
