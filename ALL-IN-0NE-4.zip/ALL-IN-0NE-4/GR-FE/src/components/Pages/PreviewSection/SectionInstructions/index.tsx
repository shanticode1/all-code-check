"use client";

import {
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Container,
  Divider,
  Flex,
  Group,
  Text,
  Title,
} from "@mantine/core";
import { IconClock, IconProgressHelp } from "@tabler/icons-react";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useMemo, useState } from "react";
import sanitizeHtml from "sanitize-html";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import DualLogoHeader from "@/components/Common/DualLogoHeader";
import Loader from "@/components/Common/Loaders/Loader";
import WarningAlertModal from "@/components/Common/Modals/WarningAlertModal";
import { USER_ROLE } from "@/constants";
import usePreventDuplicateTabs from "@/hooks/common/usePreventDuplicateTabs";
import { useGetExamByIdQuery } from "@/hooks/exam";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGlobalActivityTracker } from "@/hooks/exam/useInactivityExit";
import { useGlobalActivityTrackerAfterTwoMin } from "@/hooks/exam/useInactivityUpdateAfterTwoMin";
import { useGetQuestionsBySectionQuery } from "@/hooks/examSection";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import NextIcon from "@/public/icons/arrow-right-long.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import UtilLocalService from "@/utils/tools/localstorage";

import ExamErrorHandle from "../../ExamErrorHandle";

export default function SectionInstructionsPage() {
  useBlockBrowserNavigation(true);
  const { sectionId } = useParams<{ sectionId: string }>();
  const t = useTranslations("generic");
  const { role } = useAuth() as { role: string };
  const router = useRouter();
  const sessionKey = `section-${sectionId}-seen`;
  const [isLoading, setIsLoading] = useState(false);
  const tExam = useTranslations("examDetail");
  const { updateScreenTime } = useUpdateScreenTime();
  const adminStudentRoute = role === USER_ROLE.STUDENT ? "/exams" : "/admin/exams";
  const {
    data: sectionData,
    isLoading: isFetchingSection,
    isError: hasSectionError,
    error,
  } = useGetQuestionsBySectionQuery({ sectionId, role });

  const { data: examData } = useGetExamByIdQuery(sectionData?.data?.exam_id ?? 0);

  const isDuplicateTab = usePreventDuplicateTabs(sectionId);

  const firstQuestionId = useMemo(
    () =>
      role === USER_ROLE.STUDENT
        ? sectionData?.data?.questions?.[0]?.student_question_id
        : sectionData?.data?.questions?.[0]?.question_id,
    [sectionData],
  );

  useGlobalActivityTracker({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
        router.push("/exams");
      }
    },
  });
  useGlobalActivityTrackerAfterTwoMin({
    onInactive: () => {
      if (sectionData?.data.student_exam_id) {
        updateScreenTime(sectionData?.data.student_exam_id.toString());
      }
    },
  });
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (sectionData?.data?.student_exam_id) {
        updateScreenTime(sectionData?.data?.student_exam_id.toString()); // Tab Close / Reload API Call
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [sectionData]);

  useEffect(() => {
    if (sessionStorage.getItem(sessionKey) && firstQuestionId && USER_ROLE.STUDENT === role) {
      router.replace(
        `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${sectionId}?question_id=${firstQuestionId}`,
      );
    }
  }, [sessionKey, firstQuestionId, router, sectionId]);

  const sanitizedInstructions = useMemo(() => {
    const rawHtml = sectionData?.data?.instructions || "";
    return sanitizeHtml(rawHtml, {
      allowedTags: sanitizeHtml.defaults.allowedTags.concat(["img", "h1", "h2"]),
      allowedAttributes: {
        ...sanitizeHtml.defaults.allowedAttributes,
        img: ["src", "alt", "width", "height"],
      },
      allowedSchemes: ["http", "https", "data"],
    });
  }, [sectionData]);

  const handleStartSection = () => {
    UtilLocalService.removeLocalStorage("redirect_after_reload_section");
    UtilLocalService.removeLocalStorage("redirect_after_reload");
    sessionStorage.setItem(sessionKey, "true");
    if (firstQuestionId) {
      UtilLocalService.setLocalStorage(
        "student_exam_id",
        sectionData?.data?.student_exam_id?.toString() || "",
      );
      setIsLoading(true);
      if (role === USER_ROLE.STUDENT) {
        (window as WindowWithNextNav).__allowNextNavigation__?.();
        router.push(
          `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${sectionId}?question_id=${firstQuestionId}`,
        );
        return;
      } else {
        router.push(
          `${paths.ROOT_ADMIN_PREVIEW_SECTION}/${sectionId}?question_id=${firstQuestionId}`,
        );
        return;
      }
    }
  };

  const items = [
    { title: "Exam Management", href: adminStudentRoute },
    { title: examData?.data.exam_name || sectionData?.data?.section_name, active: true },
  ].map((item) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
        {item.title}
      </Anchor>
    ),
  );

  if (error && !error?.message?.includes("Pending section not found")) {
    return <ExamErrorHandle errorMsg={`${tExam("error.lable")}`} />;
  }
  return (
    <Container size="xl" my="md">
      {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
        <Card mb="xl" p="sm">
          <Group justify="space-between" align="center" style={{ width: "100%" }}>
            <Breadcrumbs separatorMargin="xs" className="breadcrumbs-size">
              {items}
            </Breadcrumbs>
          </Group>
        </Card>
      )}
      <Box maw={1024} mx="auto">
        <Box bg={"#393736"} p="2px 8px">
          <Flex justify="space-between" align="center">
            <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
            <Box>
              <Button
                onClick={handleStartSection}
                disabled={!firstQuestionId || isFetchingSection || isLoading}
                className="btn-blue"
                rightSection={<Image src={NextIcon} width={20} height={20} alt="next" />}
              >
                {USER_ROLE.STUDENT === role
                  ? t("buttons.continue")
                  : t("buttons.preview", { value: "Section" })}
              </Button>
            </Box>
          </Flex>
        </Box>
        <Box className="exam-section-details"></Box>
        {isFetchingSection ? (
          <Loader />
        ) : hasSectionError || !sectionData ? (
          <Card shadow="sm" p="lg">
            <Title order={2} mb="md">
              {t("messages.error.general.label")}
            </Title>
            <Text c="dimmed">{t("messages.error.general.description")}</Text>
          </Card>
        ) : (
          <Card radius="0" shadow="none" className="instructions-container">
            <Flex justify="space-between" align="center">
              <Title order={3} className="arial-font-heading">
                {sectionData?.data?.section_name}
              </Title>
              <Group gap="xs" wrap="nowrap">
                <Group gap="xs" wrap="nowrap">
                  <IconClock />
                  <Text size="sm" component="span">
                    {Math.floor(Number(sectionData?.data?.time_limit || 0) / 60)} minutes
                  </Text>
                </Group>
                <Group gap="xs" wrap="nowrap">
                  <IconProgressHelp />
                  <Box>
                    <Text size="sm" component="span">
                      {sectionData?.data?.questions?.length}{" "}
                      {sectionData?.data?.questions?.length === 1 ? "Question" : "Questions"}
                    </Text>
                  </Box>
                </Group>
              </Group>
            </Flex>
            <Divider my="sm" />
            <div
              style={{ fontSize: 18, lineHeight: 1.6 }}
              dangerouslySetInnerHTML={{ __html: sanitizedInstructions }}
            />
          </Card>
        )}
      </Box>

      {role === USER_ROLE.STUDENT && (
        <WarningAlertModal
          isShow={isDuplicateTab}
          onClose={() => { }}
          description={t("messages.modal.duplicateTabWarning.description")}
          showButtons={false}
        />
      )}
    </Container>
  );
}
