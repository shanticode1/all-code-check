"use client";
import { Button, Container, Paper, Text } from "@mantine/core";
import { DataTable } from "mantine-datatable";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { JSX, useEffect } from "react";

import SectionHeader from "@/components/Common/SectionHeader";
import { useGetStudentExamQuery } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { ExamColumns, IExam } from "@/types/Student";
import UtilLocalService from "@/utils/tools/localstorage";

export default function StudentExams(): JSX.Element {
  const { role } = useAuth();
  const router = useRouter();
  const [examList, setExamList] = React.useState<IExam[]>([]);
  const t= useTranslations('studentDetails')
  const {
    data: examData,
    isLoading: isExamListLoading,
    isFetching: isExamListFetching,
  } = useGetStudentExamQuery(role as string);

  useEffect(() => {
    if (examData && Array.isArray(examData.data)) {
      setExamList(
        examData.data.map((item) => ({
          exam_id: item.exam_id,
          exam_name: item.exam_name,
          exam_type: item.exam_type,
          exam_duration: item.exam_duration,
          is_free: item.is_free || false,
          guidelines: item.guidelines || "",
        })) as IExam[],
      );
    }
  }, [examData]);

  const columns = [
    {
      accessor: "examName",
      title: t("exam.table.columns.title.examName"),
      render: (row: ExamColumns) => (
        <Text span c="#212121">
          {row.exam_name}
        </Text>
      ),
    },
    {
      accessor: "examType",
      title: t("exam.table.columns.title.examType"),
      render: (row: ExamColumns) => (
        <Text span c="#212121">
          {row.exam_type}
        </Text>
      ),
    },
    {
      accessor: "startExam",
      title:t("exam.table.columns.title.action"),
      render: (row: ExamColumns) => (
        <Button
          disabled={
            !!row.exam_id && examList.some((e) => e.exam_id === row.exam_id && e._isNavigating)
          }
          onClick={async (event) => {
            event.preventDefault();
            setExamList((prev) =>
              prev.map((e) => (e.exam_id === row.exam_id ? { ...e, _isNavigating: true } : e)),
            );
            UtilLocalService.removeLocalStorage("isStudentHistoryPage");
            router.push(`${paths.ROOT_EXAMS}/${row.exam_id}`);
          }}
        >
         {t("exam.button.start")}
        </Button>
      ),
    },
  ];

  return (
    <Container size="xxl">
      <Paper mih={"80vh"}>
        <SectionHeader title="Exams" />
        <DataTable
          records={examList}
          columns={columns}
          minHeight={350}
          withTableBorder={false}
          withColumnBorders={false}
          borderRadius="sm"
          highlightOnHover
          fetching={isExamListFetching || isExamListLoading}
          loaderType="oval"
          striped
          noRecordsText="No Exam found"
          verticalAlign="center"
          pinLastColumn
          className="data-table"
          styles={{
            header: {
              backgroundColor: "#f0f0f0",
            },
          }}
        />
      </Paper>
    </Container>
  );
}
