import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, Grid, Select, TextInput } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { useTranslations } from "next-intl";
import React from "react";
import { Controller, useForm } from "react-hook-form";

import FormDatePicker from "@/components/Common/FormDatePicker/FormDatePicker";
import { commonButtons, subscriptionStatus } from "@/constants";
import { accessTypeConstants } from "@/constants/exam";
import { addStudentValidationSchema } from "@/constants/validationSchemas/student";
import { useUpdateStudentMutation } from "@/hooks/student/Details";
import { IStudentFormData,AddStudentFormProps } from "@/types/Student";
import { formatDateToUTCISOString } from "@/utils";

export default function AddStudentForm({ handleClose, studentDetail }: Readonly<AddStudentFormProps>) {
  const t = useTranslations("studentDetails");
  const tGeneric = useTranslations("generic");

  const { mutateAsync: updateStudent, isPending: isUpdating } = useUpdateStudentMutation();

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(addStudentValidationSchema),
    defaultValues: {
      first_name: studentDetail?.first_name ?? "",
      last_name: studentDetail?.last_name ?? null,
      email: studentDetail?.email ?? "",
      partner_type: studentDetail?.partner_type ?? "SherpaPrep",
      subscription_status: studentDetail?.subscription_status ?? "",
      subscription_start_date: studentDetail?.subscription_start_date
        ? new Date(studentDetail.subscription_start_date)
        : null,
      subscription_end_date: studentDetail?.subscription_end_date
        ? new Date(studentDetail.subscription_end_date)
        : null,
    },
  });
  const [selectedSubscriptionStatus] = watch(["subscription_status"]);

  const onFormSubmit = async (data: IStudentFormData) => {
    try {
      const payload = {
        ...data,
        subscription_start_date:
          selectedSubscriptionStatus === accessTypeConstants.PAID
            ? formatDateToUTCISOString(data.subscription_start_date) ?? undefined
            : null,
        subscription_end_date:
          selectedSubscriptionStatus === accessTypeConstants.PAID
            ? formatDateToUTCISOString(data.subscription_end_date) ?? undefined
            : null,
      };
      const id = studentDetail?.user_id;

      const { message } = await updateStudent({ id, input: payload });

      showNotification({
        color: "green",
        title: "Success",
        message,
      });

      handleClose();
    } catch (error) {
      showNotification({
        color: "red", // fixed typo from "eed"
        title: "Warning",
        message:`${(error as Error).message}` || "Something went wrong",
      });
    }
  };

  return (
    <Box p={15}>
      <form onSubmit={handleSubmit(onFormSubmit)}>
        <Grid>
          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.firstName.label")}
              placeholder={t("create.form.firstName.placeholder")}
              withAsterisk
              {...register("first_name")}
              error={errors.first_name?.message}
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.lastName.label")}
              placeholder={t("create.form.lastName.placeholder")}
              {...register("last_name")}
              error={errors.last_name?.message}
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.email.label")}
              placeholder={t("create.form.email.placeholder")}
              withAsterisk
              {...register("email")}
              error={errors.email?.message}
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.partnerType.label")}
              placeholder={t("create.form.partnerType.placeholder")}
              withAsterisk
              value={
                watch("partner_type") === "SherpaPrep"
                  ? t("partnerType.sherpaPrep")
                  : t("partnerType.smartWithHeart")
              }
              error={errors.partner_type?.message}
              disabled
              readOnly
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <Controller
              name="subscription_status"
              control={control}
              render={({ field }) => (
                <Select
                  label={t("create.form.subscriptionStatus.label")}
                  placeholder={t("create.form.subscriptionStatus.placeholder")}
                  data={subscriptionStatus}
                  clearable
                  {...field}
                  error={errors.subscription_status?.message}
                  withAsterisk
                />
              )}
            />
          </Grid.Col>
          {selectedSubscriptionStatus === accessTypeConstants.PAID && (
            <>
              <Grid.Col span={6}>
                <FormDatePicker
                  name="subscription_start_date"
                  control={control}
                  placeholderKey={t("create.form.subscriptionStartDate.placeholder")}
                  errors={errors}
                  isRequired={true}
                  label={t("create.form.subscriptionStartDate.label")}
                  isClearable={true}
                />
              </Grid.Col>
              <Grid.Col span={6}>
                <FormDatePicker
                  name="subscription_end_date"
                  control={control}
                  placeholderKey={t("create.form.subscriptionEndDate.placeholder")}
                  errors={errors}
                  isRequired={true}
                  label={t("create.form.subscriptionEndDate.label")}
                  isClearable={true}
                />
              </Grid.Col>
            </>
          )}

          <Grid.Col span={12} style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
            <Button type="button" variant="default" onClick={handleClose}>
              {tGeneric("buttons.cancel")}
            </Button>
            <Button type="submit" loading={isUpdating}>
              {studentDetail?.user_id
                ? tGeneric("buttons.update", { value: commonButtons.student })
                : tGeneric("buttons.add", { value: commonButtons.student })}
            </Button>
          </Grid.Col>
        </Grid>
      </form>
    </Box>
  );
}
