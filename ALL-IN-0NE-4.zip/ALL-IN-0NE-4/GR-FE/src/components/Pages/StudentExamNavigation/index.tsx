"use client";

import {
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Container,
  Divider,
  Flex,
  Group,
  Stack,
  Title,
} from "@mantine/core";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React from "react";

import DualLogoHeader from "@/components/Common/DualLogoHeader";
import { USER_ROLE } from "@/constants";
import { useGetExamByIdQuery } from "@/hooks/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import arrowRightLong from "@/public/icons/arrow-right-long.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import UtilLocalService from "@/utils/tools/localstorage";

// SVG components for keyboard keys
const Key = ({ children, width = 40 }: { children: React.ReactNode; width?: number }) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: `${width}px`,
      height: "24px",
      backgroundColor: "#f0f0f0",
      border: "1px solid #999",
      borderRadius: "3px",
      marginRight: "8px",
      fontSize: "12px",
      fontWeight: "bold",
      color: "#333",
    }}
  >
    {children}
  </div>
);

export default function StudentExamNavigation() {
  const router = useRouter();
  const { examId } = useParams();
  const t = useTranslations("generic");
  const tInstruction= useTranslations("instruction");
  const { role } = useAuth();
  const adminStudentRoute = role === USER_ROLE.STUDENT ? paths.ROOT_EXAMS : paths.ROOT_ADMIN_EXAM;

  const handleExamStart = async () => {
    try {
      UtilLocalService.removeLocalStorage("student_exam_id");
      router.push(`${paths.ROOT_EXAMS}/${examId}/instruction`);
    } catch (error) {
      console.error("Failed to start the exam:", error);
    }
  };

  const { data: examData ,isLoading: isExamDataLoading } = useGetExamByIdQuery(Number(examId));

  const items = [
    { title: "Exam Management", href: adminStudentRoute },
    { title: examData?.data.exam_name, active: true },
  ].map((item) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
        {item.title}
      </Anchor>
    ),
  );

  return (
    <Container size="xl" my="md">
      {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
        <Card mb="xl" p="sm">
          <Group justify="space-between" align="center" style={{ width: "100%" }}>
            <Breadcrumbs separatorMargin="xs" className="breadcrumbs-size">
              {items}
            </Breadcrumbs>
          </Group>
        </Card>
      )}

      <Box mih={400} className="exam-preview-section">
        <Box className="exam-header">
          {/* Title and Buttons aligned in a row */}
          <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
          <Flex gap="xs">
            <Button
              className="btn-blue"
              variant="filled"
              color="blue"
              disabled={isExamDataLoading}
              onClick={() => handleExamStart()}
              rightSection={<Image src={arrowRightLong} width={20} alt="next" />}
            >
              {role === USER_ROLE.STUDENT
                ? t("buttons.continue", { value: "exam" })
                : t("buttons.preview", { value: "exam" })}
            </Button>
          </Flex>
        </Box>

        <Card padding={30} shadow="none" radius="0">
          <Stack gap="md">
            <Title order={3}>{tInstruction("title")}</Title>
            <Divider my="xs" />
            <div style={{ fontSize: 18, lineHeight: 1.6 }}>
              <p>
              {tInstruction("keyboardHelp.intro")}
              </p>

              <p> {tInstruction("keyboardHelp.standardKeys")}</p>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                    {tInstruction("keyboardHelp.tabTitle")} <Key width={50}>{tInstruction("keyboardHelp.tabTitle")}</Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>
                  {tInstruction("keyboardHelp.tabDescription")}
                  </p>
                </div>
              </div>

              <p>{tInstruction("keyboardHelp.selectableExamples")}</p>
              <ul style={{ paddingLeft: 15 }}>
                <li style={{ alignItems: "center" }}>{tInstruction("keyboardHelp.exampleButtons")}</li>
                <li style={{ alignItems: "center" }}>{tInstruction("keyboardHelp.exampleOptions")}</li>
              </ul>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                    {tInstruction("keyboardHelp.shift")} <Key width={50}>↑ {tInstruction("keyboardHelp.shift")}</Key>
                    </strong>{" "}
                    and{" "}
                    <strong>
                    {tInstruction("keyboardHelp.tabTitle")} <Key width={50}>{tInstruction("keyboardHelp.tabTitle")}</Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>
                  {tInstruction("keyboardHelp.shiftTabDescription")}
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong style={{ display: "flex", gap: "4px" }}>
                    {tInstruction("keyboardHelp.spacebar")} <Key width={100}> </Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>
                  {tInstruction("keyboardHelp.spacebarDescription")}
                  </p>
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: "10px", margin: "10px 0" }}>
                <div>
                  <p style={{ margin: 0 }}>
                    <strong>
                      {tInstruction("keyboardHelp.up")} <Key width={24}>↑</Key>
                    </strong>
                    and{" "}
                    <strong>
                    {tInstruction("keyboardHelp.down")} <Key width={24}>↓</Key>
                    </strong>
                  </p>
                  <p style={{ margin: 0 }}>{tInstruction("keyboardHelp.arrowKeysDescription")}</p>
                </div>
              </div>

              <p>
                {t("buttons.select")} <strong>{t("buttons.continue")}</strong> {t("buttons.toProceed")}
              </p>
            </div>
          </Stack>
        </Card>
      </Box>
    </Container>
  );
}
