//@ts-nocheck
"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  ActionIcon,
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  CloseButton,
  Container,
  Flex,
  Group,
  Paper,
  Tooltip,
} from "@mantine/core";
import { useDebouncedValue } from "@mantine/hooks";
import { showNotification } from "@mantine/notifications";
import { IconEye } from "@tabler/icons-react";
import { DataTable } from "mantine-datatable";
import Link from "next/link";
import { useParams, usePathname, useRouter,useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import FormDatePicker from "@/components/Common/FormDatePicker/FormDatePicker";
import SearchInput from "@/components/Common/SearchInput";
import SectionHeader from "@/components/Common/SectionHeader";
import { USER_ROLE } from "@/constants";
import { paginationConstants } from "@/constants/common";
import { dateRangeValidationSchema } from "@/constants/validationSchemas/adminAuth";
import { useDownloadCsvFile, useGetStudentDetailsByIdQuery } from "@/hooks/student/Details";
import { useGetStudentExamHistoryQuery } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { FormValues, IExamHistoryData, QueryParams } from "@/types/Student/Exam";
import { formatDate, formatDateToUTCISOString, truncateName } from "@/utils";
import UtilLocalService from "@/utils/tools/localstorage";

export default function StudentExamsHistory() {
  const t = useTranslations("examHistory");
  const router = useRouter();
  const { id } = useParams();
  const { role } = useAuth();
  const searchParams = useSearchParams();
  const page = Number(searchParams.get("page") ?? 1);
  const searchQuery = searchParams.get("search") || "";
  const pageSize = Number(searchParams.get("pageSize") ?? paginationConstants.limit);
  const sortBy = (searchParams.get("sortBy") as "asc" | "desc") || null;
  const orderBy = searchParams.get("orderBy") as keyof IExamHistoryData | null;

  const pathname = usePathname();
  const isExportHistoryPage = pathname.includes(paths.ROOT_EXPORT_EXAM_HISTORY);
  const isStudentHistoryPage = pathname.includes(paths.ROOT_EXAMS_HISTORY);
  const [search, setSearch] = useState(searchQuery);
  const [debouncedSearch] = useDebouncedValue(search, 500);

  const {
    control,
    watch,
    clearErrors,
    setValue,
    formState: { errors },
    reset,
  } = useForm<FormValues>({
    defaultValues: {
      startDate: null,
      endDate: null,
    },
    resolver: yupResolver(dateRangeValidationSchema),
  });

  const [startDate, endDate] = watch(["startDate", "endDate"]);

  const queryParams: QueryParams = {
    role: role as string,
    page,
    limit: pageSize,
    startDate: startDate ? formatDateToUTCISOString(startDate) : null,
    endDate: endDate ? formatDateToUTCISOString(endDate) : null,
    search: searchQuery || null,
    user_id: id || null,
    sortBy: sortBy ?? undefined,
    orderBy: orderBy ?? undefined,
  };

  if (role === USER_ROLE.INSTRUCTOR && pathname.includes(paths.ROOT_EXPORT_EXAM_HISTORY)) {
    router.push(paths.ROOT_DASHBOARD);
    return null;
  }

  const {
    data: studentExamHistory,
    isLoading: isStudentExamHistoryLoading,
    isFetching: isStudentExamHistoryFetching,
  } = useGetStudentExamHistoryQuery(queryParams);

  const { data: studentDetail, isLoading: isStudentDetailLoading } = useGetStudentDetailsByIdQuery({
    id,
    role: role as string,
  });

  const { mutateAsync: downloadCsvFile, isPending: isStudentCsvLoading } = useDownloadCsvFile();
  const { first_name, last_name } = studentDetail?.data ?? {
    first_name: "",
    last_name: "",
  };

  const studentName = last_name ? `${first_name} ${last_name}` : first_name;
  const noRecordsMessage =
    searchQuery?.trim() || startDate || endDate
      ? t("messages.noResultFoundForSearch")
      : t("messages.noExamFound");

  const updateQueryParams = (updates: Record<string, string | number | null>) => {
    const q = new URLSearchParams(searchParams.toString());

    Object.entries(updates).forEach(([key, value]) => {
      if (value == null) q.delete(key);
      else q.set(key, String(value));
    });

    router.replace(`${pathname}?${q.toString()}`);
  };

  useEffect(() => {
    if (!debouncedSearch) return;
    updateQueryParams({ search: debouncedSearch || null, page: 1 });
  }, [debouncedSearch]);

  useEffect(() => {
    if (!searchParams) return;
    const startDateParam = searchParams.get("startDate");
    const endDateParam = searchParams.get("endDate");

    const startDate = startDateParam ? new Date(startDateParam) : null;
    const endDate = endDateParam ? new Date(endDateParam) : null;

    setValue("startDate", startDate);
    setValue("endDate", endDate);
  }, [searchParams, setValue]);

  useEffect(() => {
    if (!startDate && !endDate && !debouncedSearch) return;
    updateQueryParams({
      search: debouncedSearch || null,
      page,
      startDate: formatDateToUTCISOString(startDate),
      endDate: formatDateToUTCISOString(endDate),
    });
  }, [debouncedSearch, startDate, endDate]);

  const handleClearFilters = () => {
    updateQueryParams({ startDate: null, endDate: null, page: 1 });
    reset({
      startDate: null,
      endDate: null,
    });
    clearErrors();
  };

  const items = [
    { title: t("breadcrumbs.studentManagement"), href: paths.ROOT_STUDENT },
    { title: truncateName(studentName ?? " -- ", 120), active: true },
  ].map((item, index) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor key={item.title} href={item.href}>
        {truncateName(item.title, 120)}
      </Anchor>
    ),
  );

  const handleSortChange = ({ columnAccessor }: { columnAccessor: string }) => {
    if (orderBy === columnAccessor) {
      if (sortBy === "asc") {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "desc" });
      } else if (sortBy === "desc") {
        updateQueryParams({ orderBy: null, sortBy: null });
      } else {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
      }
    } else {
      updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
    }
  };
  const handleDownloadExamCsv = async () => {
    try {
      if (studentExamHistory?.data == null) {
        showNotification({
          title: "No Data",
          message: t("messages.noDataForDownload"),
          color: "yellow",
          autoClose: 3000,
        });
        return;
      }
      const paramsRequest = { startDate: startDate, endDate: endDate, user_id: id };
      // Add API call or logic to save the exam
      const examCsvRes = await downloadCsvFile(paramsRequest);
      const { data, message } = examCsvRes;
      const { fileUri } = data;
      const link = document.createElement("a");
      link.href = fileUri;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showNotification({
        title: "Success",
        message: message,
        color: "green",
        autoClose: 3000, // Closes after 3s
      });
    } catch (error) {
      showNotification({
        title: "Error",
        message: `${(error as Error).message}`,
        color: "red",
      });
      return;
    }
  };

  const setLocalStoragePath = () => {
    UtilLocalService.setLocalStorage("isStudentHistoryPage", isStudentHistoryPage);
  };

  const columns = [
    {
      accessor: "exam_name",
      title: t("table.headers.examDetails"),
      sortable: true,
      width: "350px",
      render: (row: IExamHistoryData) => {
        const examName = row.exam_name ?? "-";
        const truncatedName = truncateName(examName, 40);
        const shouldShowTooltip = examName.length > 40;
        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={examName}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedName : examName}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },
    ...(role !== USER_ROLE.STUDENT
      ? [
          {
            accessor: "student_name",
            title: t("table.headers.studentName"),
            sortable: true,
            render: (row: IExamHistoryData) => {
              const { first_name, last_name } = row.user || {};
              const fullName = `${first_name ?? ""} ${last_name ?? ""}`.trim() || "-";
              const truncatedName = truncateName(fullName, 40);
              const shouldShowTooltip = fullName.length > 40;

              return (
                <Box>
                  <Tooltip
                    multiline
                    withArrow
                    w={250}
                    label={fullName}
                    disabled={!shouldShowTooltip}
                    position="top"
                    offset={10}
                    styles={{
                      tooltip: {
                        padding: "8px 12px",
                        whiteSpace: "normal",
                        wordBreak: "break-word",
                      },
                    }}
                  >
                    <p style={{ margin: "0", color: "#212121" }}>
                      {shouldShowTooltip ? truncatedName : fullName}
                    </p>
                  </Tooltip>
                </Box>
              );
            },
          },
          {
            accessor: "email",
            title: t("table.headers.studentEmail"),
            sortable: true,
            render: (row: IExamHistoryData) => {
              const { email } = row.user || {};
              const emailText = email ?? "-";
              const truncatedEmail = truncateName(emailText, 40);
              const shouldShowTooltip = emailText.length > 40;
              return (
                <Box>
                  <Tooltip
                    multiline
                    withArrow
                    w={250}
                    label={emailText}
                    disabled={!shouldShowTooltip}
                    position="top"
                    offset={10}
                    styles={{
                      tooltip: {
                        padding: "8px 12px",
                        whiteSpace: "normal",
                        wordBreak: "break-word",
                      },
                    }}
                  >
                    <p style={{ margin: "0", color: "#212121" }}>
                      {shouldShowTooltip ? truncatedEmail : emailText}
                    </p>
                  </Tooltip>
                </Box>
              );
            },
          },
        ]
      : []),
    {
      accessor: "exam_date",
      title: t("table.headers.examDate"),
      sortable: true,
      width: "120px",
      render: (row: IExamHistoryData) => <Box>{formatDate(row.start_date)}</Box>,
    },
    {
      accessor: t("table.headers.analyticalWriting"),
      title: t("table.headers.analyticalWriting"),
      width: "200px",
      textAlign: "center",
      titleStyle: () => ({ background: "#fff2b4" }),
      cellsStyle: () => ({ background: "#fff2b4" }),
      render: (row: IExamHistoryData) => (
        <Box>
          <p style={{ margin: "0", color: "#212121" }}>
            {row.user.subscription_status === "Free"
              ? "N/A"
              : row.user.subscription_status === "Paid"
                ? row.analyticalWritingScore ?? (row.is_analytical_answer_submitted
                    ? "Pending"
                    : "N/A")
                : "N/A"}
          </p>
        </Box>
      ),
    },
    {
      accessor: t("table.headers.verbalReasoning"),
      title: t("table.headers.verbalReasoning"),
      width: "150px",
      textAlign: "center",
      titleStyle: () => ({ background: "#dbe1ec" }),
      cellsStyle: () => ({ background: "#dbe1ec" }),
      render: (row: IExamHistoryData) => (
        <Box>
          <p style={{ margin: "0", color: "#212121" }}>{row.verbalReasoningScore}</p>
        </Box>
      ),
    },
    {
      accessor: t("table.headers.quantitativeReasoning"),
      title: t("table.headers.quantitativeReasoning"),
      width: "180px",
      textAlign: "center",
      titleStyle: () => ({ background: "#ebeef3" }),
      cellsStyle: () => ({ background: "#ebeef3" }),
      render: (row: IExamHistoryData) => (
        <Box>
          <p style={{ margin: "0", color: "#212121" }}>{row.quantitativeReasoningScore}</p>
        </Box>
      ),
    },
    {
      accessor: "Total Score",
      title: "Total Score",
      width: "150px",
      textAlign: "center",
      titleStyle: () => ({ background: "#abdfc9" }),
      cellsStyle: () => ({ background: "#abdfc9" }),
      render: (row: IExamHistoryData) => (
        <Box>
          <p style={{ margin: "0", color: "#212121" }}>
            {Number(row.verbalReasoningScore) + Number(row.quantitativeReasoningScore)}
          </p>
        </Box>
      ),
    },
    {
      accessor: t("table.headers.actions"),
      title: t("table.headers.actions"),
      width: "80px",
      textAlign: "center",
      cellsStyle: () => ({ backgroundColor: "#fff" }),
      render: (row: IExamHistoryData) => (
        <Box
          style={{ display: "flex", gap: "2px", alignItems: "center", justifyContent: "center" }}
        >
          <Tooltip label="View Exam History">
            <Link
              href={
                role === USER_ROLE.STUDENT
                  ? `/exam/${row.student_exam_id}`
                  : `/admin/student/exams/${id || row.user.user_id}/detail/${row.student_exam_id}`
              }
            >
              <ActionIcon color="blue" onClick={setLocalStoragePath}>
                <IconEye size={16} />
              </ActionIcon>
            </Link>
          </Tooltip>
        </Box>
      ),
    },
  ];

  const handlePageChange = (newPage: number) => {
    updateQueryParams({ page: newPage });
  };
  const handlePageSizeChange = (newPageSize: number) => {
    updateQueryParams({ pageSize: newPageSize, page: 1 });
  };

  return (
    <Container size="xxl" my="lg">
      {role === USER_ROLE.SUPERADMIN && !isExportHistoryPage && (
        <Group justify="space-between" align="center" w="100%" mb="xl">
          <Breadcrumbs c="dimmed" separatorMargin="xs">
            {items}
          </Breadcrumbs>
        </Group>
      )}

      <SectionHeader title={isExportHistoryPage ? t("exportHistory.title") : t("title")}>
        {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
          <Tooltip
            label="Please select start and end dates to enable download"
            disabled={startDate && endDate}
            withArrow
            position="top"
          >
            <Button
              onClick={handleDownloadExamCsv}
              type="button"
              color="white"
              variant="default"
              disabled={!startDate || !endDate || isStudentCsvLoading}
            >
              {t("buttons.downloadCSV")}
            </Button>
          </Tooltip>
        )}
      </SectionHeader>

      <Paper>
        <Box p={"sm"}>
          <form>
            <Flex justify="space-between" align="center" wrap="wrap">
              <Group gap="md" align="center">
                <Box style={{ width: "400px" }}>
                  <SearchInput
                    placeholder={
                      role === USER_ROLE.SUPERADMIN
                        ? t("search.input.placeholder")
                        : t("search.input.studentSearchPlaceholder")
                    }
                    handleChange={(e) => setSearch(e.currentTarget.value)}
                    value={search}
                    handleClear={() => {
                      setSearch("");
                      updateQueryParams({ search: null, page: 1 });
                      clearErrors("searchQuery");
                    }}
                    // Prevent form submit on Enter key in search input
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                      }
                    }}
                  />
                </Box>
              </Group>

              <Box>
                <Group gap="md" align="center">
                  <FormDatePicker
                    name="startDate"
                    control={control}
                    placeholderKey={t("datePicker.startDate.placeholder")}
                    errors={errors}
                    maxDate={endDate ?? new Date()}
                  />
                  <FormDatePicker
                    name="endDate"
                    control={control}
                    placeholderKey={t("datePicker.endDate.placeholder")}
                    errors={errors}
                    minDate={startDate || undefined}
                    maxDate={new Date()}
                  />
                  <CloseButton
                    aria-label="Clear filters"
                    onClick={handleClearFilters}
                    style={{ display: startDate || endDate ? undefined : "none" }}
                  />
                </Group>
              </Box>
            </Flex>
          </form>
        </Box>

        <DataTable
          records={studentExamHistory?.data?.exams || []}
          columns={columns}
          minHeight={350}
          borderRadius="sm"
          highlightOnHover
          fetching={
            isStudentExamHistoryLoading || isStudentExamHistoryFetching || isStudentDetailLoading
          }
          loaderType="oval"
          striped={true}
          noRecordsText={noRecordsMessage}
          verticalAlign="center"
          pinLastColumn
          className="data-table"
          totalRecords={studentExamHistory?.data?.total || 0}
          recordsPerPage={studentExamHistory?.data ? pageSize : undefined}
          page={studentExamHistory?.data ? page : undefined}
          onPageChange={studentExamHistory?.data ? handlePageChange : undefined}
          onRecordsPerPageChange={studentExamHistory?.data ? handlePageSizeChange : undefined}
          recordsPerPageOptions={studentExamHistory?.data ? [5, 10, 20, 50] : undefined}
          c={{ dark: "#000", light: "#555" }}
          styles={{
            header: {
              backgroundColor: "#f0f0f0",
            },
          }}
          sortStatus={{
            columnAccessor: orderBy ?? "",
            direction: (sortBy) ?? "asc",
          }}
          onSortStatusChange={handleSortChange}
        />
      </Paper>
    </Container>
  );
}
