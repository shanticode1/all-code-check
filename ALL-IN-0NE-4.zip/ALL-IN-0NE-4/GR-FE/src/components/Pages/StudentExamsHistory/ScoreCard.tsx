import { Badge, Box, Button, Card, Flex, Stack, Text, Tooltip } from "@mantine/core";
import { IconCalendar, IconEye } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React from "react";

import { ScoreCardProps } from "@/types/Student/Exam";

const ScoreCard: React.FC<ScoreCardProps> = ({
  sections,
  date,
  examName,
  userName,
  email,
  message,
  buttonText,
  status,
  handleViewDetails,
  gridView
}) => {
  const tSection = useTranslations("section");
  const totalScore = sections.reduce((sum, section) => {
    if (section.name === 'Analytical Writing') return sum;
    return sum + (typeof section.score === 'number' ? section.score : 0);
  }, 0);

  return (
    <Card shadow="sm" p="lg" radius="md" withBorder>
      <Flex align={gridView ? "start":"center"} gap={gridView ? "sm" : "lg"} direction={{ sm: gridView ? 'column-reverse' : 'column', lg: 'row' }}>
        {/* Left side: Section names and scores */}
        {!gridView && (
          <Flex
            gap="xs"
            direction={!gridView ? "column" : "row"}
            style={{ flexGrow: 1 }}
            maw={{ lg: 500 }}
            miw={220}
          >
            <Text fw={500} size={"sm"} mb={2} >
              <IconCalendar size={16} /> {new Date(date).toLocaleDateString()}
            </Text>
            <Text fw={600} size="14px" mb={6} lineClamp={2} style={{ lineHeight: 1.5 }}>
              {examName}
            </Text>
            <Text fw={600} size="14px" mb={6} lineClamp={2} >
              {userName}
            </Text>
            <Text fw={600} size="14px" mb={6} lineClamp={2} >
              {email}
            </Text>
          </Flex>
        )}
        <Flex
          gap="xs"
          direction={gridView ? "column" : "row"}
          maw={!gridView ? 500 : 260}
          style={{ flexGrow: 1 }}
        >
          {sections.map((section) => (
            <Flex
              gap={gridView ? "xl" : "md"}
              key={section.name}
              direction={gridView ? "row" : "column"}
              align="center"
            >
              <Box w={gridView ? 170 : 100} h={30}>
                <Text size="sm" fw={400} c="dimmed" ta={gridView ? "left" : "center"}>
                  {section.name}
                </Text>
              </Box>
              <Box
                w={50}
                h={30}
                bg={section.score === "NS" ? "#e0e0e0" : "#e6def7"}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  borderRadius: "8px",
                }}
              >
                <Text size="sm" fw={600}>
                  {section.score || 0}
                </Text>
              </Box>
            </Flex>
          ))}
          <Flex 
            gap={gridView ? "xl" : "md"} 
            direction={gridView ? "row" : "column"}
            align="center">
            <Box w={gridView ? 170 : 130} h={30}>
              <Text fw={600}>{tSection("score.card.totalScore")}</Text>
            </Box>
            <Box
              w={50}
              h={30}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "8px",
                backgroundColor: totalScore > 0 ? "#e6def7" : "#e0e0e0",
              }}
            >
              <Text size="sm" fw={600}>
                {totalScore}
              </Text>
            </Box>
          </Flex>
        </Flex>

        {/* Right side: Date, Test Type, Message, and Button */}
        <Stack gap={4} align="flex-start">
          {gridView && (
            <>
              <Text fw={500} size={"sm"} mb={2} >
                <IconCalendar size={16} /> {new Date(date).toLocaleDateString()}
              </Text>
              <Text fw={600} size="14px" mb={6} lineClamp={2} >
                {examName}
              </Text>
            </>
          )}
          {gridView &&
            <Text size="xs" c="dimmed" mb={10} >
              {message}
            </Text>
          }
          <Flex 
            direction={!gridView ? "row" : "column"} gap={!gridView ? "xl" : "xs"}
            align={!gridView ? "center" : "flex-start"}
            justify={!gridView ? "space-between" : "flex-start"}
            miw={!gridView ? 150 : "auto"}
          >
            <Badge size="xs" color="green">
              {status}
            </Badge>
            <Tooltip label="See Result Detail" position="top" withArrow>
            <Button size="xs" variant="default" mt={!gridView ? 0 :"xs"} onClick={handleViewDetails}>
              {gridView ? buttonText : <IconEye size={16} />}
            </Button>
            </Tooltip>
          </Flex>
        </Stack>
      </Flex>
    </Card>
  );
};

export default ScoreCard;
