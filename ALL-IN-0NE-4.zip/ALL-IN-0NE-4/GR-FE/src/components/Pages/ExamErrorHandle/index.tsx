"use client";
import { Button, Group, Modal, Stack,Text } from "@mantine/core";
import { IconAlertTriangle } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React from "react";

export default function ExamErrorHandle({ errorMsg }: Readonly<{ errorMsg?: string }>) {
  const router = useRouter();
  const t = useTranslations("generic")

  return (
    <Modal
      opened={true}
      onClose={() => {}}
      title={
        <Group>
          <IconAlertTriangle color="red" size={28} />
          <Text fw={700} size="lg" c="red">
            {t("messages.error.modal.title")}
          </Text>
        </Group>
      }
      centered
      withCloseButton={false}
      size="lg"
      overlayProps={{
        blur: 2,
        opacity: 0.55,
      }}
      radius="md"
    >
      <Stack align="center">
        <IconAlertTriangle color="red" size={48} />
        <Text color="red" size="lg" fw={500} ta="center">
          {errorMsg ?? "Something went wrong. Please try again later."}
        </Text>
        <Button color="blue" fullWidth variant="outline" onClick={() => router.push("/exams")}>
          {t("messages.error.modal.button")}
        </Button>
      </Stack>
    </Modal>
  );
}
