"use client";
import {
  ActionIcon,
  Box,
  Button,
  Chip,
  Container,
  Group,
  Menu,
  Modal,
  Paper,
  Select,
  Text,
  Tooltip,
} from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import {
  IconBan,
  IconChevronDown,
  IconCopy,
  IconEdit,
  IconEye,
  IconPlus,
  IconSettingsUp,
  IconTrash,
} from "@tabler/icons-react";
import { DataTable } from "mantine-datatable";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { JSX, useEffect, useState } from "react";

import { ConfirmationModal } from "@/components/Common/Modals";
import SearchInput from "@/components/Common/SearchInput";
import { status, USER_ROLE } from "@/constants";
import {
  accessType,
  accessTypeConstants,
  EXAM_STATUS_CONSTANT,
  examStatus,
  MODAL_ACTIONS,
  SORTING_ORDER,
} from "@/constants/exam/index";
import {
  useCopyExamExamMutation,
  usedeleteDeactivateExamMutation,
  useGetExamQuery,
  useUpdateExamStatusMutation,
} from "@/hooks/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { IEditingExam, IExamApiResponse, IExamRecord } from "@/types/Exam/ExamList";
import { formatDate, getNextCopyName, truncateName } from "@/utils";

import AddExamPage from "../AddExams";

export default function ExamManagementList(): JSX.Element {
  const searchParams = useSearchParams();
  const router = useRouter();
  const t = useTranslations("exam");
  const tGeneric = useTranslations("generic");
  const { role } = useAuth();

  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingExam, setEditingExam] = useState<IEditingExam | null>(null);
  const [exams, setExams] = useState<IExamRecord[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [modalActionType, setModalActionType] = useState<
    "delete" | "status" | "deActive" | "copy" | null
  >(null);

  const [selectedExamId, setSelectedExamId] = useState<string | null>(null);
  const [selectedExamNames, setSelectedExamNames] = useState<{
    original: string | null;
    copy: string | null;
  }>({ original: null, copy: null });

  const page = Number(searchParams.get("page") || 1);
  const pageSize = Number(searchParams.get("pageSize") || 10);
  const sortBy = (searchParams.get("sortBy") as "asc" | "desc") || null;
  const orderBy = searchParams.get("orderBy") as keyof IExamRecord | null;
  const [searchQuery, setSearchQuery] = useState<string>(searchParams.get("search") ?? "");
  const [examFilter, setExamFilter] = useState<{
    status?: string | null;
    is_free?: boolean | null;
  }>({});

  const {
    data: examQueryData,
    isLoading: isExamListLoading,
    isFetching: isExamListFetching,
  } = useGetExamQuery({
    page,
    limit: pageSize,
    sortBy: sortBy ?? undefined,
    orderBy: orderBy ?? undefined,
    search: searchQuery ?? undefined,
    filter: JSON.stringify(examFilter),
  });

  const { mutateAsync: updateExamStatus, isPending: isUpdatingStatus } =
    useUpdateExamStatusMutation();
  const { mutateAsync: deleteAndDeactivateExam, isPending: isDeletingExam } =
    usedeleteDeactivateExamMutation();
  const { mutateAsync: copyExam, isPending: isCopyExam } = useCopyExamExamMutation();

  useEffect(() => {
    if (examQueryData?.data?.exams) {
      const formattedExams: IExamRecord[] = examQueryData.data.exams.map(
        (exam: IExamApiResponse) => ({
          id: exam.exam_id,
          examName: exam.exam_name,
          examType: exam.exam_type,
          paidAndRegisteredStudent: exam.paid_and_registered_student ?? 0,
          attemptedStudent: exam.attempted_student ?? 0,
          createdDate: exam.created_at ? formatDate(exam.created_at) : "N/A",
          accessType: exam.is_free ? accessTypeConstants.FREE : accessTypeConstants.PAID,
          status: exam.status,
          guidelines: exam.guidelines,
          sections: exam?.sections ?? [],
          isPreviewable: exam.isPreviewable,
          penaltyQuant: exam.quant_penalty_per_mistake,
          penaltyVerbal: exam.verbal_penalty_per_mistake,
          isOnGoing: exam.is_on_going,
        }),
      );
      setExams(formattedExams);
    }
  }, [examQueryData]);

  useEffect(() => {
    const isFreeParam = searchParams.get("is_free");
    const statusParam = searchParams.get("status");
    const search = searchParams.get("search");
    const newFilter: { status?: string | null; is_free?: boolean | null; search?: string | null } =
      {};

    if (isFreeParam === "true") newFilter.is_free = true;
    else if (isFreeParam === "false") newFilter.is_free = false;

    if (statusParam) newFilter.status = statusParam;
    if (search) newFilter.search = search;

    setExamFilter(newFilter);
  }, [searchParams]);

  const updateQueryParams = (params: Record<string, string | number | null>) => {
    const url = new URL(window.location.href);

    Object.entries(params).forEach(([key, value]) => {
      if (value === null || value === undefined) {
        url.searchParams.delete(key);
      } else {
        url.searchParams.set(key, String(value));
      }
    });

    window.history.pushState({}, "", url.toString());
  };
  const handleAccessTypeFilterChange = (value: string | null) => {
    const params = new URLSearchParams(searchParams.toString());

    if (value === accessTypeConstants.FREE) {
      params.set("is_free", "true");
    } else if (value === accessTypeConstants.PAID) {
      params.set("is_free", "false");
    } else {
      params.delete("is_free");
    }
    params.set("page", "1");
    router.push(`?${params.toString()}`);
  };

  const handleStatusFilterChange = (value: string | null) => {
    const params = new URLSearchParams(searchParams.toString());

    if (value) {
      params.set("status", value);
    } else {
      params.delete("status");
    }
    params.set("page", "1");
    router.push(`?${params.toString()}`);
  };
  const handlePageChange = (newPage: number) => {
    updateQueryParams({ page: newPage });
  };

  const handlePageSizeChange = (newPageSize: number) => {
    updateQueryParams({ pageSize: newPageSize, page: 1 });
  };

  const handleSortChange = ({ columnAccessor }: { columnAccessor: string }) => {
    if (orderBy === columnAccessor) {
      if (sortBy === SORTING_ORDER.ASC) {
        updateQueryParams({ orderBy: columnAccessor, sortBy: SORTING_ORDER.DESC });
      } else if (sortBy === SORTING_ORDER.DESC) {
        updateQueryParams({ orderBy: null, sortBy: null });
      } else {
        updateQueryParams({ orderBy: columnAccessor, sortBy: SORTING_ORDER.ASC });
      }
    } else {
      updateQueryParams({ orderBy: columnAccessor, sortBy: SORTING_ORDER.ASC });
    }
  };

  const handleStatusToggle = async (examId: string) => {
    const examToUpdate = exams.find((exam) => exam.id === Number(examId));
    if (!examToUpdate) return;

    const newStatus = examToUpdate.status === EXAM_STATUS_CONSTANT.ACTIVE ? "Inactive" : "Active";

    try {
      await updateExamStatus({
        exam_id: Number(examId),
        input: { status: newStatus },
      });

      setExams((prevExams) =>
        prevExams.map((exam) =>
          exam.id === Number(examId) ? { ...exam, status: newStatus } : exam,
        ),
      );
    } catch (error) {
      const err = error as Error;
      showNotification({
        title: "Error",
        message: err.message,
        color: "red",
      });
    }
  };

  const handlePreview = (examId: number) => {
    return `${paths.ROOT_EXAMS}/${examId}`;
  };

  const handleUpdateStatus = () => {
    if (selectedExamId) {
      handleStatusToggle(selectedExamId);
    }
    setModalActionType(null);
    setShowConfirmModal(false);
  };

  const handleCancelModal = () => {
    setShowConfirmModal(false);
    setModalActionType(null);
    setSelectedExamNames({ original: null, copy: null });
  };
  const handleDeleteExam = async () => {
    try {
      if (!selectedExamId) return;
      const { message } = await deleteAndDeactivateExam({ exam_id: Number(selectedExamId) });
      setModalActionType(null);
      showNotification({
        title: "Success",
        message: message,
        color: "green",
      });
      setShowConfirmModal(false);
    } catch (error) {
      console.error("Error deleting the exam:", error);
      showNotification({
        title: "Error",
        message: error instanceof Error ? error.message : "An unknown error occurred",
        color: "red",
      });
    }
  };

  const handleCopyExam = async () => {
    try {
      if (!selectedExamId) return;
      const { message } = await copyExam({ exam_id: Number(selectedExamId) });
      showNotification({
        title: "Success",
        message: message,
        color: "green",
      });
      setModalActionType(null);
      setShowConfirmModal(false);
      setSelectedExamNames({ original: null, copy: null });
    } catch (error) {
      showNotification({
        title: "Error",
        message: error instanceof Error ? error.message : "Failed to copy the exam",
        color: "red",
      });
    }
  };

  const columns = [
    {
      accessor: "exam_id",
      title: "Exam ID",
      width: "80px",
      render: (row: IExamRecord) => <>#{row.id}</>,
    },
    {
      accessor: "exam_name",
      title: t("table.columns.examName"),
      sortable: true,
      ellipsis: true,
      render: (row: IExamRecord) => {
        const examName = row.examName ?? "-";
        const truncatedName = truncateName(examName, 40);
        const shouldShowTooltip = examName.length > 40;
        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={examName}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedName : examName}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },
    { accessor: "examType", title: t("table.columns.examType"), width: "150px" },
    {
      accessor: "attemptedStudent",
      title: t("table.columns.attemptedStudent"),
      textAlignment: "center",
    },
    {
      accessor: "createdDate",
      title: t("table.columns.createdDate"),
      textAlignment: "center",
      width: "120px",
    },
    {
      accessor: "accessType",
      title: t("table.columns.accessType"),
      with: "100px",
      render: (row: IExamRecord) => (
        <Box style={{ width: "100px" }}>
          <Chip
            color={row.accessType === accessTypeConstants.FREE ? "blue" : "orange"}
            variant="light"
            checked
            className="accesss-type-chip"
          >
            {row.accessType}
          </Chip>
        </Box>
      ),
    },
    {
      accessor: "status",
      title: t("table.columns.status"),
      with: 100,
      render: (row: IExamRecord) => {
        const isOnGoing = row.isOnGoing;

        const statusBox = (
          <Box
            style={{
              cursor: isOnGoing ? "not-allowed" : "pointer",
              padding: "2px 8px",
              borderRadius: "4px",
              textAlign: "center",
              backgroundColor:
                row.status === EXAM_STATUS_CONSTANT.ACTIVE ? "#40c0571a" : "#fa52521f",
              color: row.status === EXAM_STATUS_CONSTANT.ACTIVE ? "#40c057" : "#fa5252",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              opacity: isOnGoing ? 0.6 : 1,
            }}
          >
            {row.status === EXAM_STATUS_CONSTANT.ACTIVE ? "Active" : "Inactive"}
            <IconChevronDown size={14} style={{ marginLeft: "8px" }} />
          </Box>
        );

        return (
          <Box style={{ width: "100px" }}>
            <Menu disabled={isOnGoing}>
              <Menu.Target>
                <Tooltip
                  label={t("messages.tooltip.label.ongoingExam")}
                  withArrow
                  w={250}
                  disabled={!isOnGoing}
                  position="top"
                  offset={10}
                  styles={{
                    tooltip: {
                      padding: "8px 12px",
                      whiteSpace: "normal",
                      wordBreak: "break-word",
                    },
                  }}
                >
                  {statusBox}
                </Tooltip>
              </Menu.Target>
              <Menu.Dropdown p="0" w="100">
                {row.status !== EXAM_STATUS_CONSTANT.ACTIVE && (
                  <Menu.Item
                    onClick={() => {
                      setModalActionType("status");
                      setSelectedExamId(row.id.toString());
                      setShowConfirmModal(true);
                    }}
                  >
                    {t("status.active")}
                  </Menu.Item>
                )}
                {row.status !== EXAM_STATUS_CONSTANT.INACTIVE && (
                  <Menu.Item
                    onClick={() => {
                      setModalActionType("status");
                      setSelectedExamId(row.id.toString());
                      setShowConfirmModal(true);
                    }}
                  >
                    {t("status.inactive")}
                  </Menu.Item>
                )}
              </Menu.Dropdown>
            </Menu>
          </Box>
        );
      },
    },

    {
      accessor: "actions",
      title: t("table.columns.actions"),
      with: "100px",
      cellsStyle: () => ({ backgroundColor: "#fff" }),
      render: (row: IExamRecord) => (
        <Box style={{ display: "flex", gap: "2px" }}>
          <Tooltip
            label={
              row?.status === status.active ? (
                <div>
                  {t("messages.tooltip.label.disableEdit")}.<br />
                  {t("messages.tooltip.label.setExamStatus")}
                </div>
              ) : (
                t("messages.tooltip.label.examDetails")
              )
            }
          >
            <Link href={`${paths.ROOT_ADMIN_EXAM}/${row.id}${paths.ROOT_ADD_QUESTIONS}`}>
              <ActionIcon color="blue" disabled={row?.status === status.active}>
                <IconSettingsUp size={18} />
              </ActionIcon>
            </Link>
          </Tooltip>
          <Tooltip
            label={
              row?.isPreviewable ? (
                t("modal.tooltips.preview")
              ) : (
                <div>
                  {t("messages.tooltip.label.disablePreview")}.<br />
                  {t("messages.tooltip.label.notAddedQuestion")}
                </div>
              )
            }
          >
            <Link href={handlePreview(row?.id)}>
              <ActionIcon color="blue" disabled={!row?.isPreviewable}>
                <IconEye size={18} />
              </ActionIcon>
            </Link>
          </Tooltip>
          <Tooltip label={t("modal.tooltips.edit")}>
            <ActionIcon
              color="blue"
              onClick={() => {
                setEditingExam({ id: Number(row.id), data: row });
                setIsModalOpen(true);
              }}
            >
              <IconEdit size={18} />
            </ActionIcon>
          </Tooltip>
          {role === USER_ROLE.SUPERADMIN && (
            <Tooltip
              label={
                row.status === EXAM_STATUS_CONSTANT.ACTIVE
                  ? t("messages.tooltip.label.notDeleteExam")
                  : row.attemptedStudent === 0
                    ? t("modal.tooltips.delete")
                    : t("modal.tooltips.deactivate")
              }
            >
              <ActionIcon
                color="red"
                onClick={() => {
                  setModalActionType(row.attemptedStudent === 0 ? "delete" : "deActive");
                  setSelectedExamId(row.id.toString());
                  setShowConfirmModal(true);
                }}
                disabled={row.status === EXAM_STATUS_CONSTANT.ACTIVE}
              >
                {row.attemptedStudent === 0 ? <IconTrash size={18} /> : <IconBan size={18} />}
              </ActionIcon>
            </Tooltip>
          )}

          {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
            <Tooltip label={t("modal.confirmation.title.copy")}>
              <ActionIcon
                color="blue"
                onClick={() => {
                  const originalName = row.examName;
                  const examNames = exams.map((exam) => ({ examName: exam.examName }));
                  const newCopyName = getNextCopyName(originalName, examNames as IExamRecord[]);

                  setModalActionType("copy");
                  setSelectedExamId(row.id.toString());
                  setShowConfirmModal(true);

                  setSelectedExamNames({
                    original: originalName,
                    copy: newCopyName,
                  });
                }}
              >
                <IconCopy size={18} />
              </ActionIcon>
            </Tooltip>
          )}
        </Box>
      ),
    },
  ];

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingExam(null);
    setSelectedExamNames({ original: null, copy: null });
  };

  return (
    <Container size="xxl" my="lg">
      <Box
        p="xs"
        bg="#3e6494"
        w="100%"
        display="flex"
        flex={1}
        style={{
          borderTopLeftRadius: "8px",
          borderTopRightRadius: "8px",
          justifyContent: "space-between",
          alignItems: "center",
          minHeight: "60px",
          alinItems: "center",
        }}
      >
        <Text size="md" c="white" fw={600}>
          {t("title")}
        </Text>
        <Button
          color="white"
          variant="default"
          onClick={() => {
            setEditingExam(null);
            setIsModalOpen(true);
          }}
          leftSection={<IconPlus size={14} />}
          size="md"
        >
          {t("buttons.add")}
        </Button>
      </Box>

      <Paper>
        <Group p="md">
          <Box style={{ width: "400px" }}>
            <SearchInput
              handleChange={(e) => setSearchQuery(e.currentTarget.value)}
              placeholder={t("search.placeholder")}
              value={searchQuery}
              handleClear={() => {
                setSearchQuery("");
                updateQueryParams({ search: "", page: 1 });
              }}
            />
          </Box>

          <Select
            placeholder={t("filters.accessType.placeholder")}
            value={
              examFilter.is_free === true
                ? accessTypeConstants.FREE
                : examFilter.is_free === false
                  ? accessTypeConstants.PAID
                  : null
            }
            onChange={handleAccessTypeFilterChange}
            data={accessType}
            clearable
            style={{ width: "200px" }}
          />

          <Select
            placeholder={t("filters.status.placeholder")}
            value={examFilter.status || null}
            onChange={handleStatusFilterChange}
            data={examStatus || []}
            clearable
            style={{ width: "200px" }}
          />
        </Group>
        {/* <Divider my="md" /> */}
        <DataTable
          records={exams}
          minHeight={350}
          columns={columns}
          withTableBorder={false}
          withColumnBorders={false}
          highlightOnHover
          fetching={isExamListFetching || isUpdatingStatus || isExamListLoading}
          loaderType="oval"
          striped
          noRecordsText={t("messages.noExamFound")}
          verticalAlign="top"
          pinLastColumn
          className="data-table"
          totalRecords={examQueryData?.data?.total || 0}
          recordsPerPage={pageSize}
          page={page}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handlePageSizeChange}
          recordsPerPageOptions={[5, 10, 20, 50]}
          sortStatus={{
            columnAccessor: orderBy ?? "",
            direction: sortBy ?? "asc",
          }}
          onSortStatusChange={handleSortChange}
          c={{ dark: "#000", light: "#555" }}
          styles={{
            header: {
              backgroundColor: "#f0f0f0",
            },
          }}
        />
      </Paper>
      <Modal
        opened={isModalOpen}
        onClose={handleCloseModal}
        size="lg"
        title={editingExam?.id ? t("form.title.update.label") : t("form.title.add.label")}
        closeOnClickOutside={false}
        closeOnEscape={false}
      >
        <AddExamPage handleClose={handleCloseModal} exam={editingExam || null} />
      </Modal>
      <ConfirmationModal
        opened={showConfirmModal}
        title={
          modalActionType === MODAL_ACTIONS.delete
            ? t("modal.confirmation.title.delete")
            : modalActionType === MODAL_ACTIONS.deActive
              ? t("modal.confirmation.title.Deactivate")
              : modalActionType === MODAL_ACTIONS.copy
                ? t("modal.confirmation.title.copy")
                : exams.find((exam) => exam.id === Number(selectedExamId))?.status ===
                    EXAM_STATUS_CONSTANT.ACTIVE
                  ? t("modal.confirmation.title.inActive")
                  : t("modal.confirmation.title.active")
        }
        description={
          modalActionType === MODAL_ACTIONS.delete ? (
            <div
              dangerouslySetInnerHTML={{ __html: t("modal.confirmation.deleteExamDscription") }}
            />
          ) : modalActionType === MODAL_ACTIONS.deActive ? (
            <div
              dangerouslySetInnerHTML={{
                __html: t("modal.confirmation.deactivateExamDescription"),
              }}
            />
          ) : modalActionType === MODAL_ACTIONS.copy ? (
            <div
              dangerouslySetInnerHTML={{ __html: t("modal.confirmation.copyExamDescription") }}
            />
          ) : exams.find((exam) => exam.id === Number(selectedExamId))?.status === "ACTIVE" ? (
            <div
              dangerouslySetInnerHTML={{ __html: t("modal.confirmation.inActiveDescription") }}
            />
          ) : (
            <div dangerouslySetInnerHTML={{ __html: t("modal.confirmation.activeDescription") }} />
          )
        }
        onCancel={handleCancelModal}
        onConfirm={
          modalActionType === MODAL_ACTIONS.delete || modalActionType === MODAL_ACTIONS.deActive
            ? handleDeleteExam
            : modalActionType === MODAL_ACTIONS.copy
              ? handleCopyExam
              : handleUpdateStatus
        }
        buttonText={
          modalActionType === MODAL_ACTIONS.delete
            ? t("modal.confirmation.buttons.delete")
            : modalActionType === MODAL_ACTIONS.deActive
              ? t("modal.confirmation.buttons.inActive")
              : modalActionType === MODAL_ACTIONS.copy
                ? t("modal.confirmation.buttons.copy")
                : exams.find((exam) => exam.id === Number(selectedExamId))?.status ===
                    EXAM_STATUS_CONSTANT.ACTIVE
                  ? t("modal.confirmation.buttons.inActive")
                  : t("modal.confirmation.buttons.active")
        }
        buttonCancelText={tGeneric("buttons.cancel")}
        disabled={isDeletingExam || isUpdatingStatus || isCopyExam}
        examNames={selectedExamNames}
        copyConfirmText={
          modalActionType === MODAL_ACTIONS.copy ? t("modal.confirmation.confirmText") || "" : ""
        }
      />
    </Container>
  );
}
