import { Card, Container, Grid, Stack, Text, Title } from "@mantine/core";
import Image from "next/image";
import { useTranslations } from "next-intl";
import React from "react";

import banner from "@/public/banner.png";

export const StudentDashboard = () => {
  const t= useTranslations("dashboard");
  return (
    <Container size="xl" my="lg">
      <Card
        mb="lg"
        radius="lg"
        bg="#EDF6FF"
        shadow="md"
        style={{ paddingLeft: "2rem", paddingBottom: "0" }}
      >
        <Grid align="center">
          <Grid.Col span={4}>
            <Stack>
              <Text
                size="xl"
                style={{
                  fontSize: "32px",
                  lineHeight: "1.2",
                  fontWeight: 500,
                  color: "#1F1F1F",
                }}
                dangerouslySetInnerHTML={{ __html: t("student.greetingTitle") }}
              >
              </Text>
              <Text style={{ color: "#081021" }}>
              {t("student.greetingSubtitle")}
              </Text>
            </Stack>
          </Grid.Col>
          <Grid.Col span={8}>
            <Image src={banner} width={800} height={300} alt="Banner Image" />
          </Grid.Col>
        </Grid>
      </Card>

      <Card style={{ padding: "2rem" }} shadow="md" radius="lg">
        <Grid>
          <Grid.Col span={12}>
            <Stack gap="md">
              <Title order={3} style={{ fontWeight: 500, color: "#1F1F1F" }}>
                {t("student.card.title")}
              </Title>
              <Text style={{ color: "#081021" }}>
              {t("student.card.welcomeText")}
              </Text>
              <Text style={{ color: "#5F6367" }}>
              {t("student.card.text")} <strong>GRE exam</strong>. To begin,{" "}
                <strong>
                {t("student.card.examTabInstruction")}
                </strong>
              </Text>
              <Text style={{ color: "#5F6367" }}>
                When you’ve completed the exam, you’ll receive your <strong>score report</strong>.
                Each score report includes step-by-step <strong>video solutions</strong> that will
                help you to understand your errors and improve your score! We’ll email you a copy of
                the report for your records, and you can access it again by clicking on the “Score
                Reports” tab to the left.
              </Text>
              <Text style={{ color: "#5F6367" }}>
              {t("student.card.sortDescription")}
                &nbsp;
                <a href="mailto:info@smartwithaheart.org" target="_blank" rel="noreferrer">
                  {t("student.email.smartWithHeart")}
                </a>{" "}
                or{" "}
                <a href="mailto:info@sherpaprep.com" target="_blank" rel="noreferrer">
                {t("student.email.sherpaPrep")}.
                </a>
              </Text>
              <Text style={{ color: "#5F6367" }} fw={600}>
              {t("student.goodLuck")}
              </Text>
            </Stack>
          </Grid.Col>
        </Grid>
      </Card>
    </Container>
  );
};
