"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { Anchor, Button, Center, Divider, Stack, Text, TextInput, ThemeIcon, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconMail } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React, { useState } from "react";
import { useForm } from "react-hook-form";

import { forgotPasswordValidationSchema } from "@/constants/validationSchemas/reset-password";
import { useForgotPasswordMutation } from "@/hooks/resetPassword";
import { BUTTON_TYPES } from "@/types/button.types";
import { IForgotPasswordFormValues, IForgotPasswordResponse } from "@/types/Login";

export default function ForgotPasswordForm() {
  const t = useTranslations("login");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IForgotPasswordFormValues>({
    defaultValues: { email: "" },
    resolver: yupResolver(forgotPasswordValidationSchema),
  });
  const { mutateAsync: forgotPassword, isPending: isSending } = useForgotPasswordMutation();
  const handleForgotPassword = async (data: IForgotPasswordFormValues) => {
    try {
      const { email } = data;
      const response: IForgotPasswordResponse = await forgotPassword({ email });
      setSuccessMessage(response?.message || t("form.forgotPassword.successDefault"));
    } catch (error) {
      showNotification({
        color: "red",
        title: "Warning",
        message: (error as Error)?.message || "An error occurred",
      });
    }
  };
  if (successMessage) {
    return (
      <Center mih={200}>
        <Stack align="center" gap="xs" w="100%">
          <Center>
            <ThemeIcon color="blue" size={60} radius="xl" mb={10}>
              <IconMail size={35} />
            </ThemeIcon>
          </Center>
          <Text fw={600} size="20px" style={{ textAlign: "center", lineHeight: "1.5" }}>
            {t("form.forgotPassword.message.text")}
          </Text>
          <Text style={{ textAlign: "center" }}>
            {t("form.forgotPassword.message.description")}
          </Text>
          <Divider color="#000000" my="sm"/>
          <Text ta={"center"}>
          {t("form.forgotPassword.rememberPassword")} <Anchor href="/login">{t("form.forgotPassword.signIn")} </Anchor>
          </Text>
        </Stack>
      </Center>
    );
  }
  return (
    <>
      <Title ta="center">{t("form.forgotPassword.title")}</Title>
      <form onSubmit={handleSubmit(handleForgotPassword)}>
        <TextInput
          withAsterisk
          label={t("form.email.label")}
          placeholder={t("form.email.placeholder")}
          {...register("email")}
          error={errors.email?.message}
          mt="md"
        />
        <Button type={BUTTON_TYPES.SUBMIT} fullWidth mt="xl" disabled={isSending}>
          {t("form.forgotPassword.buttons.send")}
        </Button>
      </form>
    </>
  );
}
