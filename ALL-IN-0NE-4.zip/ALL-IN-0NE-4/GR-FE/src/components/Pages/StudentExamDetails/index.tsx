// @ts-nocheck
"use client";

import {
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  Center,
  Container,
  Flex,
  Grid,
  Group,
  Loader,
  Paper,
  Stack,
  Text,
  Title,
  Tooltip,
} from "@mantine/core";
import { IconCalendar, IconDownload, IconMail, IconUser } from "@tabler/icons-react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import { ExamRecordsTable } from "@/components/Common/ExamRecordsTable";
import { ReportCards } from "@/components/Common/ReportCards";
import { USER_ROLE } from "@/constants";
import { EXAM_HISTORY_BOTTOM_CONTENT } from "@/constants/exam";
import { useGetStudentDetailsByIdQuery } from "@/hooks/student/Details";
import { useGetStudentExamDetailsQuery } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { IStudentExamDetail, IStudentQuestion, TranslateFunction } from "@/types/Exam/ExamHistory";
import { capitalize, formatName, getScoreSections, truncateName } from "@/utils";
import UtilLocalService from "@/utils/tools/localstorage";

import { Details } from "./details";

export const ExamDetails = () => {
  const t = useTranslations("examDetail");
  const tExam = useTranslations("exam");
  const [isDownloading, setIsDownloading] = useState(false);
  const isPathExamsHistory = UtilLocalService.getLocalStorage("isStudentHistoryPage");

  const { id, studentId } = useParams() as { id: string; studentId: string };
  const { role, name, userData } = useAuth();
  const router = useRouter();
  const adminStudentRoute =
    role === USER_ROLE.STUDENT ? paths.ROOT_EXAMS_HISTORY : paths.ROOT_STUDENT;

  const { data: studentExamDetail, isFetching: isExamDetailsFetching, error: QuestionDetailsError } =
    useGetStudentExamDetailsQuery({
      id: role === USER_ROLE.STUDENT ? id : studentId,
      role: role as string,
    });

  useEffect(() => {
    if (!QuestionDetailsError) return;

    const { status } = QuestionDetailsError as { status?: number };

    if (status === 404) {
      router.push(paths.ROOT_NOT_FOUND);
    }
  }, [QuestionDetailsError, studentExamDetail, router]);

  const scoreSections = getScoreSections(
    studentExamDetail as IStudentExamDetail,
    t as TranslateFunction,
  );

  const { data: studentDetail } = useGetStudentDetailsByIdQuery({
    id,
    role: role as string,
  }); // need to add condition for user role student this API shpould not call here

  const items = [
    {
      title:
        role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN || role === USER_ROLE.INSTRUCTOR
          ? "Student Management"
          : "Score Reports",
      href: adminStudentRoute,
    },
    {
      title:
        studentDetail?.data?.first_name +
        (studentDetail?.data?.last_name ? ` ${studentDetail?.data?.last_name}` : ""),
      active: true,
      role: USER_ROLE.SUPERADMIN,
    },
    {
      title:
        (studentExamDetail?.data?.exam_name ?? "").length > 60
          ? studentExamDetail?.data?.exam_name.slice(0, 60) + "..."
          : studentExamDetail?.data?.exam_name,
      active: true,
    },
  ]
    .filter((item) => item.role === undefined || item.role === role) // Filter out the student name breadcrumb if role is not SUPERADMIN
    .filter((item) => !item.role || item.role === role)
    .map((item) =>
      item.active ? (
        <span key={item.title}>{item.title}</span>
      ) : (
        <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
          {truncateName(item.title ?? "", 130)}
        </Anchor>
      ),
    );

  const downloadPDF = async () => {
    setIsDownloading(true);
    setTimeout(() => setIsDownloading(false), 500);

    const pdfDoc = new jsPDF({
      orientation: "portrait",
      unit: "pt",
      format: "a4",
      compress: true,
    });

    const pdfPageWidth = pdfDoc.internal.pageSize.getWidth();
    const pdfPageHeight = pdfDoc.internal.pageSize.getHeight();
    const paddingTop = 20;
    const paddingBottom = 60;
    const availablePageHeight = pdfPageHeight - paddingTop - paddingBottom;

    const sectionElements = document.querySelectorAll(".pdf-clone-wrapper");

    for (let sectionIndex = 0; sectionIndex < sectionElements.length; sectionIndex++) {
      const sectionElement = sectionElements[sectionIndex] as HTMLElement;

      // Add a page manually at the 4th section (index 3)
      if (sectionIndex === 3 && sectionIndex !== 0) {
        pdfDoc.addPage();
      }

      // Clone and scale the element
      const clone = sectionElement.cloneNode(true) as HTMLElement;
      const scaleFactor = 1.6;

      clone.style.transform = `scale(${scaleFactor})`;
      clone.style.transformOrigin = "top left";
      clone.style.width = `${100 / scaleFactor}%`;
      clone.style.position = "absolute";
      clone.style.left = "-9999px";
      clone.style.top = "0";
      clone.style.zIndex = "-1";
      document.body.appendChild(clone);

      // Convert clone to canvas
      const canvas = await html2canvas(clone, {
        scale: 1.1,
        useCORS: true,
        allowTaint: true,
        scrollX: 0,
        scrollY: 0,
      });

      document.body.removeChild(clone); // Clean up

      const imageWidth = pdfPageWidth;
      const imageHeight = (canvas.height * imageWidth) / canvas.width;

      let remainingImageHeight = imageHeight;
      let renderedImageHeight = 0;
      let currentPage = 0;

      while (remainingImageHeight > 0) {
        if (currentPage > 0) pdfDoc.addPage();

        const sourceY = (renderedImageHeight * canvas.height) / imageHeight;
        const sliceHeight = Math.min(
          (availablePageHeight * canvas.height) / imageHeight,
          canvas.height - sourceY,
        );

        const pageSliceCanvas = document.createElement("canvas");
        const pageSliceContext = pageSliceCanvas.getContext("2d")!;
        pageSliceCanvas.width = canvas.width;
        pageSliceCanvas.height = sliceHeight;

        pageSliceContext.drawImage(
          canvas,
          0,
          sourceY,
          canvas.width,
          sliceHeight,
          0,
          0,
          canvas.width,
          sliceHeight,
        );

        const pageSliceImageDataURL = pageSliceCanvas.toDataURL("image/png");
        const scaledSliceHeight = (sliceHeight * imageWidth) / canvas.width;

        pdfDoc.addImage(
          pageSliceImageDataURL,
          "WEBP",
          0,
          paddingTop,
          imageWidth,
          scaledSliceHeight,
          undefined,
          "FAST",
        );

        renderedImageHeight += availablePageHeight;
        remainingImageHeight -= availablePageHeight;
        currentPage++;
      }
    }

    // ---------- PDF Filename Formatting ----------
    const examRawDate = studentExamDetail?.data?.start_date;
    const examFormattedDate = examRawDate ? new Date(examRawDate).toISOString().split("T")[0] : "";

    const firstName = capitalize(studentDetail?.data?.first_name || "");
    const lastName = capitalize(studentDetail?.data?.last_name || "");
    const studentFullName = lastName ? `${firstName}_${lastName}` : firstName;

    const finalPDFFileName =
      "Scorecard_" +
      (role === USER_ROLE.SUPERADMIN ? studentFullName : formatName(name)) +
      "_" +
      studentExamDetail?.data?.exam_name +
      "_" +
      examFormattedDate +
      ".pdf";

    pdfDoc.save(finalPDFFileName);
  };

  useEffect(() => {
    if (role === USER_ROLE.STUDENT && !isPathExamsHistory) {
      window.history.pushState(null, "", window.location.href);
      const onPopState = (e: PopStateEvent) => {
        e.preventDefault();
        window.history.pushState(null, "", window.location.href);
      };
      window.addEventListener("popstate", onPopState);
      return () => window.removeEventListener("popstate", onPopState);
    }
  }, [role]);

  if (isExamDetailsFetching)
    return (
      <Center h="80vh">
        <Loader type="oval" />
      </Center>
    );

  const shouldShowTooltip = userData?.name.length > 70 || userData?.name.includes(" ");

  return (
    <Container size="xxl" my="lg">
      <Group justify="space-between" align="center" w="100%" mb="xl" wrap="nowrap">
        <Breadcrumbs c="dimmed" separatorMargin="xs">
          {items}
        </Breadcrumbs>
        {role !== USER_ROLE.STUDENT && (
          <Button
            size="md"
            leftSection={<IconDownload size={18} />}
            onClick={downloadPDF}
            variant="gradient"
            gradient={{ from: "blue", to: "cyan", deg: 90 }}
            flexShrink={0}
            flex={"0 0 200px"}
          >
            {isDownloading ? tExam("buttons.isdownload") : tExam("buttons.download")}
          </Button>
        )}
      </Group>

      {/* This is the container that will be cloned for PDF generation */}
      <Details details={studentExamDetail} studentDetail={studentDetail} />

      <Box>
        <Paper p="md" radius={0} withBorder mb="md" style={{ borderTop: "3px solid #10b2cb" }}>
          <Grid>
            <Grid.Col span={{ sm: 12, md: 5, lg: 5 }}>
              <Stack gap={0}>
                <Title order={3} textWrap="wrap">
                  {studentExamDetail?.data?.exam_name}
                </Title>
                <Flex pt="xs" gap="xs" align="center" color="gray">
                  <IconCalendar size={18} color="gray" />
                  <Text component="span" size="md" c="gray">
                    {studentExamDetail?.data?.start_date
                      ? new Date(studentExamDetail.data.start_date).toLocaleDateString()
                      : "N/A"}
                  </Text>
                </Flex>
                {role === USER_ROLE.STUDENT && (
                  <>
                    <Flex pt="xs" gap="xs" align="center" color="gray">
                      <IconUser size={18} color="gray" style={{ flexShrink: 0 }} />
                      <Tooltip
                        label={userData?.name}
                        multiline
                        withArrow
                        disabled={!shouldShowTooltip}
                        w={250}
                        position="top"
                        offset={10}
                        styles={{
                          tooltip: {
                            padding: "8px 12px",
                            whiteSpace: "normal",
                            wordBreak: "break-word",
                          },
                        }}
                      >
                        <Text component="span" size="md" c="gray" className="truncate-text">
                          {userData?.name}
                        </Text>
                      </Tooltip>
                    </Flex>
                    <Flex pt="xs" gap="xs" align="center" color="gray">
                      <IconMail size={18} color="gray" style={{ flexShrink: 0 }} />
                      <Text component="span" size="md" c="gray">
                        {userData?.email}
                      </Text>
                    </Flex>
                  </>
                )}
                {role === USER_ROLE.SUPERADMIN && (
                  <>
                    <Flex align="center" gap="xs" pt="xs" color="gray">
                      <IconUser size={18} color="gray" style={{ flexShrink: 0 }} />
                      <Text component="span" size="md" c="gray" className="word-wrap">
                        {studentDetail?.data?.first_name} {studentDetail?.data?.last_name}
                      </Text>
                    </Flex>
                    <Flex align="center" gap="xs" pt="xs" color="gray">
                      <IconMail size={18} color="gray" />
                      <Text component="span" size="md" c="gray">
                        {studentDetail?.data?.email}
                      </Text>
                    </Flex>
                  </>
                )}
              </Stack>
            </Grid.Col>
            <Grid.Col span={{ sm: 12, md: 7, lg: 7 }}>
              <Box>
                <Grid gutter="xs">
                  {scoreSections.map((section) => (
                    <ReportCards
                      key={section.label}
                      label={section.label}
                      value={section.value}
                      min={section.min}
                      max={section.max}
                    />
                  ))}
                </Grid>
              </Box>
            </Grid.Col>
          </Grid>
        </Paper>
        <Paper p="xl" withBorder radius={0}>
          <p>
            <font style={{ color: "red" }}>{t("note.text")} :</font>{" "}
            <font style={{ color: "gray" }}>
              {" "}
              {t("note.message")}
            </font>
          </p>
          {studentExamDetail?.data?.studentExamSections?.map((section: IStudentQuestion, idx) => {
            const isAnalyticalWring = section.section_slug === "analytical-writing";
            return (
              <Box
                key={section.section_slug}
                style={{
                  pageBreakInside: "avoid",
                  breakInside: "avoid",
                  pageBreakBefore: isDownloading && idx !== 0 ? "always" : undefined,
                }}
              >
                <ExamRecordsTable
                  data={section.studentQuestions}
                  title={section.section_name}
                  role={role}
                  examId={id}
                  studentId={studentId}
                  isAnalyticalWring={isAnalyticalWring}
                />
              </Box>
            );
          })}
        </Paper>
        <div
          style={{ fontSize: 18, lineHeight: 1.6 }}
          dangerouslySetInnerHTML={{ __html: EXAM_HISTORY_BOTTOM_CONTENT || "" }}
        />
      </Box>
    </Container>
  );
};
