import { Box, Flex, Grid, Paper, Stack, Text, Title } from "@mantine/core";
import { IconCalendar, IconMail,IconUser } from "@tabler/icons-react";
import Image from "next/image";
import { useTranslations } from "next-intl";
import React from "react";

import { ExamRecordsTable } from "@/components/Common/ExamRecordsTable";
import { ReportCards } from "@/components/Common/ReportCards";
import { USER_ROLE } from "@/constants";
import { EXAM_HISTORY_BOTTOM_CONTENT } from "@/constants/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import logo from "@/public/sherpa_prep-logo.png";
import smrtLogo from "@/public/smart-with-heart-logo.jpg";
import {
  IStudentExamDetail,
  TranslateFunction,
} from "@/types/Exam/ExamHistory";
import { IExamHistoryResponse } from "@/types/Student/Exam";
import { getScoreSections } from "@/utils";

interface DetailsProps {
  details?: IStudentExamDetail;
  studentExamSections?: IExamHistoryResponse;
  studentDetail: {
    data: {
      first_name: string;
      last_name: string;
      email: string
    };
  };
}

export const Details: React.FC<DetailsProps> = ({ details, studentDetail }) => {
  const { role } = useAuth();
  const t = useTranslations("examDetail");
  const scoreSections = getScoreSections(details as IStudentExamDetail, t as TranslateFunction);

  return (
    <Box p="sm" id="pdf-clone" className="pdf-clone-wrapper">
      <Box className="report-pdf-header" style={{ height: "80px" }}>
        <Image src={smrtLogo} alt="Logo" width={240} height={75} />
        <Image src={logo} alt="Logo" width={150} height={50} />
      </Box>
      <Paper p="md" radius={0} withBorder mb="md" style={{ borderTop: "3px solid #10b2cb" }}>
        <Grid>
          <Grid.Col span={{ sm: 12, md: 5, lg: 5 }}>
            <Stack gap={0}>
              <Title order={3} textWrap="wrap">
                {details?.data?.exam_name}
              </Title>
              <Flex pt="xs" gap="xs" align="center" color="gray">
                <IconCalendar size={18} color="gray" />
                <Text component="span" size="md" c="gray">
                  {details?.data?.start_date
                    ? new Date(details.data.start_date).toLocaleDateString()
                    : "N/A"}
                </Text>
              </Flex>
              {role === USER_ROLE.SUPERADMIN && (
                <>
                  <Flex align="center" gap="xs" pt="xs" color="gray">
                    <IconUser size={18} color="gray" />
                    <Text component="span" size="md" c="gray">
                      {studentDetail?.data?.first_name} {studentDetail?.data?.last_name}
                    </Text>
                  </Flex>
                  <Flex align="center" gap="xs" pt="xs" color="gray">
                    <IconMail size={18} color="gray" />
                    <Text component="span" size="md" c="gray">
                      {studentDetail?.data?.email}
                    </Text>
                  </Flex>
                </>
              )}
            </Stack>
          </Grid.Col>
          <Grid.Col span={{ sm: 12, md: 7, lg: 7 }}>
            <Box>
              <Grid gutter="xs">
                {scoreSections.map((section) => (
                  <ReportCards
                    key={section.label}
                    label={section.label}
                    value={section.value}
                    min={section.min}
                    max={section.max}
                  />
                ))}
              </Grid>
            </Box>
          </Grid.Col>
        </Grid>
      </Paper>
      <Paper p="md" withBorder radius={0}>
        {details?.data?.studentExamSections &&
          Array.isArray(details.data.studentExamSections) &&
          details.data.studentExamSections.map((section, idx) => {
            // Use the correct type for section if possible, otherwise fallback to 'any'
            const isAnalyticalWring = section?.section_slug === "analytical-writing";
            // Prefer a unique key, fallback to idx if necessary
            const key = section.section_slug || section.section_name || idx;
            return (
              <Box
                key={key}
                style={{
                  pageBreakInside: "avoid",
                  breakInside: "avoid",
                  pageBreakBefore: idx !== 0 ? "avoid" : undefined,
                }}
                data-slug={section.section_slug}
              >
                <ExamRecordsTable
                  data={section.studentQuestions}
                  title={section.section_name}
                  slug={section.section_slug}
                  isAnalyticalWring={isAnalyticalWring}
                />
              </Box>
            );
          })}
      </Paper>
      <div
        style={{ fontSize: 18, lineHeight: 1.6, paddingTop: "30px" }}
        dangerouslySetInnerHTML={{ __html: EXAM_HISTORY_BOTTOM_CONTENT || "" }}
      />
    </Box>
  );
};
