"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { ActionIcon, Button, Container, Grid, Paper, TextInput, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconEye, IconEyeOff } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import { USER_ROLE } from "@/constants";
import {
  changePasswordValidationSchema,
  updateProfileValidationSchema,
} from "@/constants/validationSchemas/adminAuth";
import {
  useCurrentUserQuery,
  useUpdatePasswordMutation,
  useUpdateProfileMutation,
} from "@/hooks/auth";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { BUTTON_TYPES } from "@/types/button.types";
import {
  IChangePasswordFormValues,
  IUpdatePassword,
  IUpdateProfileFormValues,
} from "@/types/Profile";
import { getToken } from "@/utils/tools/token-service";

// Initial values for password change form only
const passwordInitialValues = {
  currentPassword: "",
  newPassword: "",
  confirmNewPassword: "",
};

export default function AdminProfile() {
  const { data: currentUser } = useCurrentUserQuery();
  const [showPassword, setShowPassword] = useState(false); // State to toggle password visibility
  const { mutate: updateProfile, isPending: isProfileUpdatePending } = useUpdateProfileMutation();
  const { mutate: updatePassword, isPending: isPasswordUpdatePending } =
    useUpdatePasswordMutation();
  const token = getToken();
  const { role } = useAuth();
  const router = useRouter();
  const {
    register,
    handleSubmit: handleProfileSubmit,
    reset: resetProfileForm,
    formState: { errors: profileErrors }, // Capture validation errors
  } = useForm<IUpdateProfileFormValues>({
    resolver: yupResolver(updateProfileValidationSchema),
  });
  const t = useTranslations("profile");

  useEffect(() => {
    if (role === USER_ROLE.STUDENT) {
      router.push(paths.ROOT_DASHBOARD);
    }
  }, [role, router]);

  // Set form values from API response
  useEffect(() => {
    if (currentUser) {
      resetProfileForm({
        first_name: currentUser?.data?.first_name || "",
        last_name: currentUser?.data?.last_name || "",
        email: currentUser?.data?.email || "",
      });
    }
  }, [currentUser, resetProfileForm]);

  const {
    register: registerPassword,
    handleSubmit: handlePasswordSubmit,
    formState: { errors: passwordErrors }, // Capture validation errors
    reset: resetPasswordForm, // Reset function for password form
  } = useForm<IChangePasswordFormValues>({
    defaultValues: passwordInitialValues,
    resolver: yupResolver(changePasswordValidationSchema),
  });

  const onUpdateProfile = async (data: IUpdateProfileFormValues) => {
    try {
      if (!token) {
        return;
      }
      const payload = {
        ...data,
        email: data.email.toLowerCase(),
        last_name: data.last_name?.trim() || null
      };

      updateProfile(
        { payload, token },
        {
          onSuccess: (response) => {
            if (response) {
              showNotification({
                title: "Success",
                message: response.message,
                color: "green",
              });
            }
          },
          onError: (error) => {
            showNotification({
              title: "Error",
              message: error.message,
              color: "red",
            });
          },
        },
      );
    } catch (error) {
      console.error("Unexpected error:", error);
    }
  };
  const onChangePassword = (data: IChangePasswordFormValues) => {
    try {
      if (!token) {
        return;
      }
      const payload: IUpdatePassword = {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      };

      updatePassword(
        { payload, token },
        {
          onSuccess: (response) => {
            if (response) {
              showNotification({
                title: "Success",
                message: response.message,
                color: "green",
              });
            }
            // Reset password form after successful update
            resetPasswordForm(passwordInitialValues);
            setShowPassword(false);
          },
          onError: (error) => {
            showNotification({
              title: "Error",
              message: error.message,
              color: "red",
            });
          },
        },
      );
    } catch (error) {
      console.error("Unexpected error:", error);
    }
  };

  return (
    <Container size="xl" my="lg">
      <Title>{t("title")}</Title>
      <Grid>
        {/* Update Profile Form */}
        <Grid.Col span={6}>
          <Paper p="md" shadow="sm">
            <Title order={4} mb="md">
              {t("updateProfile.form.title")}
            </Title>
            <form onSubmit={handleProfileSubmit(onUpdateProfile)}>
              <TextInput
                label={t("updateProfile.form.firstName.label")}
                placeholder={t("updateProfile.form.firstName.placeholder")}
                mb="md"
                defaultValue={currentUser?.data.first_name}
                {...register("first_name")}
                error={profileErrors.first_name?.message}
                withAsterisk
              />
              <TextInput
                label={t("updateProfile.form.lastName.label")}
                placeholder={t("updateProfile.form.lastName.placeholder")}
                mb="md"
                defaultValue={currentUser?.data.last_name}
                {...register("last_name")}
                error={profileErrors.last_name?.message}
              />
              <TextInput
                label={t("updateProfile.form.email.label")}
                placeholder={t("updateProfile.form.email.placeholder")}
                mb="md"
                {...register("email")}
                defaultValue={currentUser?.data.email}
                error={profileErrors.email?.message}
                withAsterisk
                disabled={!!currentUser?.data.email}
              />
              <Button type={BUTTON_TYPES.SUBMIT} fullWidth mt="md" loading={isProfileUpdatePending}>
                {t("updateProfile.form.button.text")}
              </Button>
            </form>
          </Paper>
        </Grid.Col>

        {/* Change Password Form */}
        <Grid.Col span={6}>
          <Paper p="md" shadow="sm">
            <Title order={4} mb="md">
              {t("changePassword.form.title")}
            </Title>
            <form onSubmit={handlePasswordSubmit(onChangePassword)}>
              <TextInput
                label={t("changePassword.form.currentPassword.label")}
                placeholder={t("changePassword.form.currentPassword.placeholder")} // Use a placeholder for security
                type={showPassword ? "text" : "password"}
                mb="md"
                {...registerPassword("currentPassword")}
                rightSection={
                  <ActionIcon onClick={() => setShowPassword(!showPassword)}>
                    {showPassword ? <IconEye size={16} /> : <IconEyeOff size={16} />}
                  </ActionIcon>
                }
                withAsterisk
                error={passwordErrors.currentPassword?.message}
                onCopy={(e) => {
                  e.preventDefault();
                }}
                onCut={(e) => {
                  e.preventDefault();
                }}
              />
              <TextInput
                label={t("changePassword.form.newPassword.label")}
                placeholder={t("changePassword.form.newPassword.placeholder")}
                type="password"
                mb="md"
                {...registerPassword("newPassword")}
                error={passwordErrors.newPassword?.message}
                withAsterisk
                onCopy={(e) => {
                  e.preventDefault();
                }}
                onCut={(e) => {
                  e.preventDefault();
                }}
              />
              <TextInput
                label={t("changePassword.form.confirmPassword.label")}
                placeholder={t("changePassword.form.confirmPassword.placeholder")}
                type="password"
                mb="md"
                {...registerPassword("confirmNewPassword")}
                error={passwordErrors.confirmNewPassword?.message}
                withAsterisk
                onCopy={(e) => {
                  e.preventDefault();
                }}
                onCut={(e) => {
                  e.preventDefault();
                }}
              />
              <Button
                type={BUTTON_TYPES.SUBMIT}
                fullWidth
                mt="md"
                loading={isPasswordUpdatePending}
              >
                {t("changePassword.button.text")}
              </Button>
            </form>
          </Paper>
        </Grid.Col>
      </Grid>
    </Container>
  );
}
