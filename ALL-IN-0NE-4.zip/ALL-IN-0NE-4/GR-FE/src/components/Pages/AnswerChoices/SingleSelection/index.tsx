import { Button, Checkbox, Flex, Grid, Radio } from "@mantine/core";
import { IconSquareXFilled } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React from "react";

import CommonEditor from "@/components/Common/Editor/Editor";
import { IAnswerInput, ISingleSelectionProps } from "@/types/Exam/ViewExam";

export default function SingleSelection({
  handleAnswerChoices,
  answerChoice,
  answerGroup,
  isCheckboxShow,
}: Readonly<ISingleSelectionProps>) {
  const t = useTranslations("question")

  let slNo = 0;
  return (
    <Grid.Col span={12}>
      {answerChoice.map((option: IAnswerInput, index: number) => {
        if (option.answer_group !== answerGroup) return null;
        slNo++;
        return (
          <div
            key={option.questionId}
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: "10px",
              marginBottom: "20px",
              position: "relative",
            }}
          >
            {/* Serial number */}
            <span
              style={{
                minWidth: "25px",
                height: "25px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: 500,
                fontSize: "16px",
                borderRadius: "20px",
                backgroundColor: "rgb(232, 237, 242)",
              }}
            >
              {slNo}
            </span>

            <Flex style={{ width: "100%" }} gap={10} align="flex-start">
              <Flex direction="column" style={{ flex: 1, gap: "5px" }}>
                <CommonEditor
                  guidelines={answerChoice[index]?.option_text ?? undefined}
                  placeholder={t("form.editor.placeholder")}
                  height={150}
                  onContentChange={(content) => handleAnswerChoices(content, index)}
                />
                {answerChoice[index]?.error && (
                  <p style={{ color: "red", fontSize: "14px", margin: 0 }}>
                    {answerChoice[index].error}
                  </p>
                )}
              </Flex>

              {!isCheckboxShow ? (
                <Radio
                  checked={answerChoice[index]?.is_correct}
                  onChange={() =>
                    handleAnswerChoices(null, index, "handleSingleCorrect", answerGroup)
                  }
                  style={{ marginTop: "10px" }}
                />
              ) : (
                <Checkbox
                  checked={answerChoice[index]?.is_correct}
                  onChange={() =>
                    handleAnswerChoices(null, index, "handleMultipleCorrect", answerGroup)
                  }
                  style={{ marginTop: "10px" }}
                />
              )}
            </Flex>

            <Button
              variant="transparent"
              size="xs"
              color="red"
              disabled={
                answerChoice.filter((item: IAnswerInput) => item.answer_group === answerGroup)
                  .length === 2
              }
              onClick={() => handleAnswerChoices("", index, "removeOption", null)}
              className="remove-option-button"
            >
              <IconSquareXFilled size={25} />
            </Button>
          </div>
        );
      })}
    </Grid.Col>
  );
}
