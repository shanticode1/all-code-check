"use client";
import { Button, Flex, Grid, TextInput, Title } from "@mantine/core";
import { IconCirclePlus, IconMathFunction } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

import FractionalInput from "@/components/Common/Inputs/FractionalInput";
import EquationEditorModal from "@/components/Common/NumericalEntryInput/EquationEditorModal";
import ParagraphInput from "@/components/Common/ParagraphInput";
import { NUMERICAL_ENTRY_GROUP, QUESTION_TYPE } from "@/constants/questions";
import { IAnswerChoicesProps, IAnswerInput } from "@/types/Exam/index";
import { containsHTML } from "@/utils";

import SingleSelection from "./SingleSelection";

export default function AnswerChoices({
  type,
  handleAnswerChoices,
  answerChoice,
}: Readonly<IAnswerChoicesProps>) {
  const answerChoices = answerChoice ?? [];
  const [isPrefixDisabled, setIsPrefixDisabled] = useState(false);
  const [isSuffixDisabled, setIsSuffixDisabled] = useState(false);
  const [editorModalOpened, setEditorModalOpened] = useState(false);
  const [editorType, setEditorType] = useState<"prefix" | "suffix" | null>(null);

  const prefixValue = answerChoices[0]?.answer_prefix ?? "";
  const suffixValue = answerChoices[0]?.answer_suffix ?? "";
  const hasHTML = containsHTML(prefixValue || suffixValue);
  const t = useTranslations("answer");

  const blankGroupsMap: Record<string, number[]> = {
    oneFillInTheBlank: [1],
    twoFillInTheBlank: [1, 2],
    threeFillInTheBlank: [1, 2, 3],
  };

  const selectionConfig: Record<
    string,
    {
      isCheckboxShow: boolean;
      transform?: (choices: IAnswerInput[]) => IAnswerInput[];
    }
  > = {
    singleSelection: { isCheckboxShow: false },
    multipleSelection: { isCheckboxShow: true },
    "quantitative-comparison": {
      isCheckboxShow: false,
      transform: (choices) =>
        choices.map((choice, idx) => ({
          ...choice,
          composite_key: idx.toString(),
        })),
    },
  };

  const onAddMore = () => {
    const blankGroups = blankGroupsMap[type];
    if (blankGroups) {
      const counts = blankGroups.map(
        (grp) => answerChoices.filter((item) => item.answer_group === grp).length,
      );
      const maxCount = Math.max(...counts);
      const behind = blankGroups.filter((grp, i) => counts[i] < maxCount);
      const targetGroups = behind.length > 0 ? behind : blankGroups;
      targetGroups.forEach((grp) => handleAnswerChoices(null, null, "addMore", grp));
      return;
    }

    handleAnswerChoices(null, null, "addMore", null);
  };

  const handleNumericChange = (e: React.ChangeEvent<HTMLInputElement>) =>
    handleAnswerChoices(e.target.value, 0);

  const renderSingle = (
    group: number | null,
    section: string,
    span: number = 12,
    isCheckbox: boolean = false,
    choices: IAnswerInput[] = answerChoices,
  ) => (
    <Grid.Col span={span}>
      {group && `(${section}.) `}
      <SingleSelection
        handleAnswerChoices={handleAnswerChoices}
        answerChoice={choices}
        answerGroup={group}
        isCheckboxShow={isCheckbox}
      />
    </Grid.Col>
  );
  // Determine if this is a selection/rendering type
  const selection = selectionConfig[type];
  const isBlankType = Boolean(blankGroupsMap[type]);
  return (
    <div>
      <Title order={5} mb="md">
        <Flex align="center" gap={4}>
          {t("title")} <span style={{ color: "red" }}>*</span>
        </Flex>
      </Title>

      <Grid>
        {type === QUESTION_TYPE.NUMERICAL_ENTRY && (
          <Grid.Col span={12}>
            <Grid>
              {/* Answer */}
              <Grid.Col span={4}>
                {/* Flex layout: Input and Edit button side-by-side */}
                <div>
                  <Flex gap="sm" align="flex-end">
                    {/* Show input only if NO HTML */}
                    <TextInput
                      label={t("input.labels.prefix")}
                      placeholder="e.g. @, #, %"
                      value={hasHTML ? "" : (answerChoices[0]?.answer_prefix ?? "")}
                      onChange={(e) => {
                        handleAnswerChoices(e.target.value, 0, "addPrefix");
                        setIsPrefixDisabled(!!e.target.value);
                      }}
                      disabled={isSuffixDisabled || !!answerChoices[0]?.answer_suffix || hasHTML}
                      error={
                        answerChoices[0]?.error?.includes(NUMERICAL_ENTRY_GROUP.prefix)
                          ? answerChoices[0].error
                          : undefined
                      }
                    />

                    <Button
                      variant="light"
                      size="sm"
                      onClick={() => {
                        setEditorType("prefix");
                        setEditorModalOpened(true);
                      }}
                      disabled={!!answerChoices[0]?.answer_suffix}
                      title={t("editor.openFor", { type: "prefix" })}
                    >
                      <IconMathFunction size={16} />
                    </Button>
                  </Flex>

                  {hasHTML && (
                    <div
                      style={{ marginTop: 10, wordBreak: "break-word" }}
                      dangerouslySetInnerHTML={{ __html: prefixValue }}
                    />
                  )}
                </div>
              </Grid.Col>
              <Grid.Col span={4}>
                <TextInput
                  label={t("input.answer.answer")}
                  placeholder={t("input.answer.placeholder")}
                  onChange={(e) => {
                    const value = e.target.value;
                    // Allow only numbers, decimal point, and optional leading '-'
                    if (/^-?\d*\.?\d*$/.test(value)) {
                      // Count digits excluding '-' and '.'
                      const digitsOnly = value.replace(/\D/g, "");
                      if (digitsOnly.length > 8) {
                        return;
                      }
                      handleNumericChange(e);
                    }
                  }}
                  value={answerChoices[0]?.option_text ?? ""}
                  error={
                    !answerChoices[0]?.error?.includes(NUMERICAL_ENTRY_GROUP.prefix) &&
                    !answerChoices[0]?.error?.includes(NUMERICAL_ENTRY_GROUP.suffix)
                      ? answerChoices[0]?.error
                      : undefined
                  }
                />
              </Grid.Col>

              <Grid.Col span={4}>
                {/* Flex layout: Input and Edit button side-by-side */}
                <div>
                  <Flex gap="sm" align="flex-end">
                    <TextInput
                      label={t("input.labels.suffix")}
                      placeholder="e.g. @, #, %"
                      value={hasHTML ? "" : (answerChoices[0]?.answer_suffix ?? "")}
                      onChange={(e) => {
                        handleAnswerChoices(e.target.value, 0, "addSuffix");
                        setIsSuffixDisabled(!!e.target.value);
                      }}
                      disabled={isPrefixDisabled || !!answerChoices[0]?.answer_prefix || hasHTML}
                      error={
                        answerChoices[0]?.error?.includes(NUMERICAL_ENTRY_GROUP.suffix)
                          ? answerChoices[0].error
                          : undefined
                      }
                    />
                    <Button
                      variant="light"
                      size="sm"
                      onClick={() => {
                        setEditorType("suffix");
                        setEditorModalOpened(true);
                      }}
                      disabled={!!answerChoices[0]?.answer_prefix}
                      title={t("editor.openFor", { type: "suffix" })}
                    >
                      <IconMathFunction size={16} />
                    </Button>
                  </Flex>
                  {hasHTML && (
                    <div
                      style={{ marginTop: 10, wordBreak: "break-word" }}
                      dangerouslySetInnerHTML={{ __html: suffixValue }}
                    />
                  )}
                </div>
              </Grid.Col>
            </Grid>
          </Grid.Col>
        )}
        {/* Editor Modal for Prefix/Suffix */}
        <EquationEditorModal
          opened={editorModalOpened && (editorType === "prefix" || editorType === "suffix")}
          type={editorType as "prefix" | "suffix"}
          value={
            editorType === "prefix"
              ? (answerChoices[0]?.answer_prefix ?? "")
              : (answerChoices[0]?.answer_suffix ?? "")
          }
          onClose={() => {
            setEditorModalOpened(false);
            setEditorType(null);
          }}
          onSave={(content) => {
            if (editorType === "prefix") {
              handleAnswerChoices(content, 0, "addPrefix");
            } else {
              handleAnswerChoices(content, 0, "addSuffix");
            }
          }}
          setIsPrefixDisabled={setIsPrefixDisabled}
          setIsSuffixDisabled={setIsSuffixDisabled}
        />

        {type === QUESTION_TYPE.PARAGRAPH_SENTENCE && (
          <ParagraphInput handleAnswerChoices={handleAnswerChoices} answerChoice={answerChoices} />
        )}

        {type === QUESTION_TYPE.FRACTIONAL_ENTRY && (
          <FractionalInput handleAnswerChoices={handleAnswerChoices} answerChoice={answerChoices} />
        )}

        {isBlankType && (
          <>
            {blankGroupsMap[type].map((grp, idx) =>
              renderSingle(
                grp,
                String.fromCharCode(65 + idx),
                12 / blankGroupsMap[type].length,
                false,
              ),
            )}
          </>
        )}

        {selection && !isBlankType && (
          <Grid.Col span={12}>
            {renderSingle(
              null,
              "A",
              12,
              selection.isCheckboxShow,
              selection.transform ? selection.transform(answerChoices) : answerChoices,
            )}
          </Grid.Col>
        )}

        {type !== QUESTION_TYPE.NUMERICAL_ENTRY &&
          type !== QUESTION_TYPE.FRACTIONAL_ENTRY &&
          type !== QUESTION_TYPE.PARAGRAPH_SENTENCE && (
            <Button
              variant="transparent"
              onClick={onAddMore}
              style={{ marginLeft: 22, padding: 0, marginTop: -10 }}
            >
              <Flex align="center" justify="center" gap={5}>
                <IconCirclePlus size={20} />
                {t("buttons.addMore")}
              </Flex>
            </Button>
          )}
      </Grid>
    </div>
  );
}
