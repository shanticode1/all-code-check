import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, Grid, Select, TextInput } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { useTranslations } from "next-intl";
import React from "react";
import { Controller, useForm } from "react-hook-form";

import { commonButtons, roles } from "@/constants";
import { addUserValidationSchema } from "@/constants/validationSchemas/user";
import { useUpdateUserMutation } from "@/hooks/user/Details";
import { UserFormValues ,AddUserFormProps} from "@/types/User";
import { IAddUser } from "@/types/User/Details";


export default function AddUserForm({ handleClose, userDetail }: Readonly<AddUserFormProps>) {
  const t = useTranslations("userDetails");
  const tGeneric = useTranslations("generic");

  const { mutateAsync: updateUser, isPending: isUpdating } = useUpdateUserMutation();

  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(addUserValidationSchema),
    defaultValues: {
      first_name: userDetail?.first_name ?? "",
      last_name: userDetail?.last_name ?? null,
      email: userDetail?.email ?? "",
      role: userDetail?.role ?? "",
    },
  });

  const onFormSubmit = async (data: UserFormValues) => {
    try {
      const payload = {
        ...data,
      };
      const id = userDetail?.user_id;

      const { message } = await updateUser({ id, input: payload as IAddUser});

      showNotification({
        color: "green",
        title: "Success",
        message,
      });

      handleClose();
    } catch (error) {
      showNotification({
        color: "red", // fixed typo from "eed"
        title: "Warning",
        message:`${(error as Error).message}` || "Something went wrong",
      });
    }
  };

  return (
    <Box p={15}>
      <form onSubmit={handleSubmit(onFormSubmit)}>
        <Grid>
          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.firstName.label")}
              placeholder={t("create.form.firstName.placeholder")}
              withAsterisk
              {...register("first_name")}
              error={errors.first_name?.message}
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.lastName.label")}
              placeholder={t("create.form.lastName.placeholder")}
              {...register("last_name")}
              error={errors.last_name?.message}
            />
          </Grid.Col>

          <Grid.Col span={6}>
            <TextInput
              label={t("create.form.email.label")}
              placeholder={t("create.form.email.placeholder")}
              withAsterisk
              {...register("email")}
              error={errors.email?.message}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <Controller
              name="role"
              control={control}
              render={({ field }) => (
                <Select
                  label={t("create.form.role.label")}
                  placeholder={t("create.form.role.placeholder")}
                  data={roles}
                  clearable
                  {...field}
                  error={errors.role?.message}
                  withAsterisk
                />
              )}
            />
          </Grid.Col>

          <Grid.Col span={12} style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
            <Button type="button" variant="default" onClick={handleClose}>
              {tGeneric("buttons.cancel")}
            </Button>
            <Button type="submit" loading={isUpdating}>
              {userDetail?.user_id
                ? tGeneric("buttons.update", { value: commonButtons.user })
                : tGeneric("buttons.add", { value: commonButtons.user })}
            </Button>
          </Grid.Col>
        </Grid>
      </form>
    </Box>
  );
}
