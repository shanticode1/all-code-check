import { BarChart } from "@mantine/charts";
import {
  Box,
  Card,
  Center,
  Container,
  Flex,
  Grid,
  Group,
  Loader,
  Paper,
  Select,
  SimpleGrid,
  Stack,
  Tabs,
  Text,
  Title,
  Tooltip,
} from "@mantine/core";
import Image from "next/image";
import { useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import IconSchool from "@/components/Common/IconSchool/IconSchool";
import InfoTooltip from "@/components/Common/Tooltip/iconTooltip";
import { USER_ROLE } from "@/constants";
import { selectOption, selectYearOption } from "@/constants/dashboard";
import { useGetDashboardReportsQuery, useGetDashboardSummaryQuery } from "@/hooks/dashboard";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import banner from "@/public/banner.png";
import { ChartTooltipProps } from "@/types/Dashboard";

export const AdminDashboard = () => {
  const { data: responseData } = useGetDashboardSummaryQuery();
  const {
    totalActiveStudents,
    totalSmartWithHeartStudent,
    totalSherpaPrepStudent,
    totalFreeStudent,
  } = responseData?.data || {};
  const t = useTranslations("dashboard");
  // Get initial filter from URL or default to "month"
  const searchParams = useSearchParams();
  const initialFilter = searchParams.get("filter") || "month";
  const [filterType, setFilterType] = useState<string>(initialFilter);
  const [selectedDayRange, setSelectedDayRange] = useState<string | null>(null);
  const [selectedYearRange, setSelectedYearRange] = useState<string | null>(null);
  const [xAxisKey, setXAxisKey] = useState("month");
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const auth = useAuth();
  const role = auth?.role;
  const {
    data: reportData,
    isLoading: isReportListLoading,
    isFetching: isReportListFetching,
  } = useGetDashboardReportsQuery({
    filter: filterType,
    enabled: role !== USER_ROLE.INSTRUCTOR,
  });

  function ChartTooltip({ label, payload, coordinate }: Readonly<ChartTooltipProps>) {
    if (!payload || payload.length === 0 || !coordinate?.x || !coordinate?.y) return null;

    return (
      <div
        style={{
          position: "absolute",
          left: coordinate.x,
          top: coordinate.y - 40, // move above the bar
          transform: "translate(-50%, -100%)",
          pointerEvents: "none",
          zIndex: 1000,
          minWidth: "180px",
        }}
      >
        <Paper px="md" py="sm" withBorder shadow="md" radius="md">
          <Text fw={500} mb={5}>
            {label}
          </Text>
          {payload.map((item) => (
            <Text key={item.name} c={"#000000"} fz="sm">
              {item.name}: {item.value}
            </Text>
          ))}
        </Paper>
      </div>
    );
  }
  // Transform API data (object of dates) to array for BarChart
  const rawData =
    reportData?.data && typeof reportData.data === "object" && !Array.isArray(reportData.data)
      ? Object.entries(reportData.data).map(([date, values]) => ({
          date,
          ...(typeof values === "object" && values !== null ? values : {}),
        }))
      : Array.isArray(reportData?.data)
        ? reportData.data
        : [];

  // Step 2: Dynamically derive series keys from first item (excluding 'date')
  const seriesKeys =
    rawData.length > 0
      ? Object.keys(rawData[0]).filter((key) => key !== "date" && key !== "month")
      : [];

  // Optional: still keeping total per item for debugging or tooltip use
  const data = rawData.map((item) => {
    const total = seriesKeys.reduce((acc, key) => acc + (Number(item[key]) || 0), 0);
    return {
      ...item,
      total,
    };
  });

  const totalSum = seriesKeys.reduce((acc, key) => {
    return acc + rawData.reduce((sum, item) => sum + (Number(item[key]) || 0), 0);
  }, 0);
  const yAxisProps = {
    domain: totalSum > 0 ? [0, Math.ceil(totalSum)] : [0, 100],
    tick: {
      fontSize: 12,
      fill: "#404252",
    },
  };

  // Dynamically set width based on data length

  const yearValues = selectYearOption.map((option) => option.value);
  const chartweekWidth = Math.max(7 * 180);
  const fullchart = Math.max(7 * 400);
  const updateQueryParams = (params: { filter: string }) => {
    const searchParams = new URLSearchParams(window.location.search);
    searchParams.set("filter", params.filter); // Set new filter
    const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
    window.history.replaceState({}, "", newUrl);
  };

  const widthStyle = (() => {
    if (filterType === "365" || yearValues.includes(filterType)) {
      return { width: fullchart };
    }
    if (["month", "30", "60"].includes(filterType)) return { width: "auto" };
    return { width: chartweekWidth };
  })();

 const handleFilterChange = (value: string | null) => {
  if (!value) return;

  updateQueryParams({ filter: value });
  setFilterType(value);

  const isDayRange = selectOption.some((item) => item.value === value);
  const isYearRange = selectYearOption.some((item) => item.value === value);

   function getActiveTab(): "days" | "year" | null {
     if (isDayRange) return "days";
     if (isYearRange) return "year";
     return null;
   }
   setActiveTab(getActiveTab());
  setSelectedDayRange(isDayRange ? value : null);
  setSelectedYearRange(isYearRange ? value : null);
  setXAxisKey(value === "week" ? "day" : "month");
  console.log("activeTab",activeTab ,isDayRange ,isYearRange)
};

  // Called on select dropdown change
 const handleDayRangeChange = (value: string | null) => {
  handleFilterChange(value);
};

  // Called on select Year dropdown change
 const handleYearRangeChange = (value: string | null) => {
  handleFilterChange(value);
};

 const handleTabChange = (value: string | null) => {
 const currentYear = new Date().getFullYear().toString();
  if (value === "days") {
    handleFilterChange("30");
  } else if (value === "year") {
    handleFilterChange(currentYear);
  }
};

useEffect(() => {
  if (role !== USER_ROLE.SUPERADMIN) return;

  const searchParams = new URLSearchParams(window.location.search);
  let filter = searchParams.get("filter");

  if (!filter) {
    filter = "month";
    searchParams.set("filter", filter);
    window.history.replaceState({}, "", `${window.location.pathname}?${searchParams.toString()}`);
  }

  handleFilterChange(filter);
}, []);

  const Barchartview = () => {
    return (
      <div style={widthStyle}>
        <BarChart
          h={470}
          data={rawData}
          barProps={(bar) => {
            let shift = 0;

            // shift bars based on their "name" (dataKey)
            if (bar.name === "Free") shift = -10;
            else if (bar.name === "SWAHT") shift = 10;

            return {
              barSize: 40,
              style: {
                transform: `translateX(${shift}px)`,
              },
            };
          }}
          dataKey={xAxisKey}
          withYAxis={true}
          maxBarWidth={80}
          cursorFill="transparent"
          tooltipProps={{
            content: ({ label, payload, coordinate }) => (
              <ChartTooltip label={label} payload={payload} coordinate={coordinate} />
            ),
          }}
          tooltipAnimationDuration={100}
          className="admin-dashboard-bar-chart"
          series={[
            { name: "Free", color: "#FFEA96" },
            { name: "Sherpa", color: "#CCCCCC" },
            { name: "SWAHT", color: "#A7E9FF" },
          ]}
          xAxisProps={{
            tick: {
              dy: 30,
              fontSize: 12,
              fill: "#404252",
              fontWeight: 500,
            },
          }}
          yAxisProps={yAxisProps}
          gridAxis="x"
          tickLine="none"
          valueLabelProps={(barSeries) => {
            let shift = 0;

            if (barSeries.name === "Free") shift = -8;
            else if (barSeries.name === "SWAHT") shift = 8;

            return {
              children: `${barSeries.name}`,
              fill: "#404252",
              position: "bottom",
              style: {
                fontWeight: 400,
                fontSize: "11px",
                whiteSpace: "pre-line",
                textAlign: "center",
                transform: `translateX(${shift}px)`, // dynamic shift per bar
              },
              dy: 5,
            };
          }}
          withBarValueLabel
        />
      </div>
    );
  };

  return (
    <Container size="xl" my="lg">
      <Title order={2} mb="lg">
        {t("title")}
      </Title>
      {role === USER_ROLE.SUPERADMIN ? (
        <>
          <SimpleGrid
            type="container"
            cols={{ base: 1, "767px": 2, "992px": 3, "1355px": 4 }}
            spacing="lg"
          >
            <Card shadow="sm" padding="lg" radius="md">
              <Group align="center">
                <div
                  style={{
                    backgroundColor: "#FFF4C5",
                    borderRadius: 12,
                    width: 56,
                    height: 56,
                    placeContent: "center",
                    textAlign: "center",
                  }}
                >
                  <IconSchool size={40} color="#FFCC00" />
                </div>
                <Stack gap={4}>
                  <Text className="font-size-24" fw="600">
                    {totalFreeStudent}
                  </Text>
                  <Text c="#081021" style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {t("cards.title.freeStudent")}
                  </Text>
                  <Box className="tooltips">
                    <Tooltip
                      label={t("tooltips.labels.totalFreeStudent")}
                      position="top"
                      withArrow
                      multiline
                      w={250}
                      offset={10}
                      styles={{
                        tooltip: {
                          padding: "8px 12px",
                          whiteSpace: "normal",
                          wordBreak: "break-word",
                        },
                      }}
                    >
                      <span style={{ cursor: "pointer" }}>
                        <InfoTooltip />
                      </span>
                    </Tooltip>
                  </Box>
                </Stack>
              </Group>
            </Card>
            <Card shadow="sm" padding="lg" radius="md">
              <Group align="center">
                <div
                  style={{
                    backgroundColor: "#EBEBEB",
                    borderRadius: 12,
                    width: 56,
                    height: 56,
                    placeContent: "center",
                    textAlign: "center",
                  }}
                >
                  <IconSchool size={40} color="#171717" />
                </div>
                <Stack gap={4}>
                  <Text className="font-size-24" fw="600">
                    {totalSherpaPrepStudent}
                  </Text>
                  <Text c="#081021" style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {t("cards.title.sherpaPrepStudent")}
                  </Text>
                  <Box className="tooltips">
                    <Tooltip
                      label={t("tooltips.labels.totalSherpaPrepStudent")}
                      position="top"
                      withArrow
                      multiline
                      w={250}
                      offset={10}
                      styles={{
                        tooltip: {
                          padding: "8px 12px",
                          whiteSpace: "normal",
                          wordBreak: "break-word",
                        },
                      }}
                    >
                      <span style={{ cursor: "pointer" }}>
                        <InfoTooltip />
                      </span>
                    </Tooltip>
                  </Box>
                </Stack>
              </Group>
            </Card>

            <Card shadow="sm" padding="lg" radius="md">
              <Group align="center">
                <div
                  style={{
                    backgroundColor: "#CFF3FF",
                    borderRadius: 12,
                    width: 56,
                    height: 56,
                    placeContent: "center",
                    textAlign: "center",
                  }}
                >
                  <IconSchool size={40} color="#49A8C7" />
                </div>
                <Stack gap={4}>
                  <Text className="font-size-24" fw="600">
                    {totalSmartWithHeartStudent}
                  </Text>
                  <Text c="#081021" style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {t("cards.title.smartWithHeartStudent")}
                  </Text>
                  <Box className="tooltips">
                    <Tooltip
                      label={t("tooltips.labels.totalSmartWithHeartStudent")}
                      position="top"
                      withArrow
                      multiline
                      w={250}
                      offset={10}
                      styles={{
                        tooltip: {
                          padding: "8px 12px",
                          whiteSpace: "normal",
                          wordBreak: "break-word",
                        },
                      }}
                    >
                      <span style={{ cursor: "pointer" }}>
                        <InfoTooltip />
                      </span>
                    </Tooltip>
                  </Box>
                </Stack>
              </Group>
            </Card>

            <Card shadow="sm" padding="lg" radius="md">
              <Group align="center">
                <div
                  style={{
                    backgroundColor: "#E6E5FF",
                    borderRadius: 12,
                    width: 56,
                    height: 56,
                    placeContent: "center",
                    textAlign: "center",
                  }}
                >
                  <IconSchool size={40} color="#5856D6" />
                </div>
                <Stack gap={4}>
                  <Text className="font-size-24" fw="600">
                    {totalActiveStudents}
                  </Text>
                  <Text c="#081021" style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    {t("cards.title.activestudent")}
                  </Text>
                  <Box className="tooltips">
                    <Tooltip
                      label={t("tooltips.labels.totalActiveStudents")}
                      position="top"
                      withArrow
                      multiline
                      w={250}
                      offset={10}
                      styles={{
                        tooltip: {
                          padding: "8px 12px",
                          whiteSpace: "normal",
                          wordBreak: "break-word",
                        },
                      }}
                    >
                      <span style={{ cursor: "pointer" }}>
                        <InfoTooltip />
                      </span>
                    </Tooltip>
                  </Box>
                </Stack>
              </Group>
            </Card>
          </SimpleGrid>
          <Box className="barchart-header" mt={"lg"}>
            <Flex justify="space-between" align="center" mb="md">
              <Text fw={600} c="#3D474F" size="lg">
                {rawData.length === 0 && totalSum > 0
                  ? "Loading..."
                  : `Number of New Students (${totalSum})`}
              </Text>
              <Flex align="center" justify="end" wrap="wrap">
                {/* Tabs for Week & Month */}
                <Group className="filterTabsall" gap={0}>
                  <Tabs
                    value={filterType}
                    defaultValue="month"
                    onChange={handleFilterChange}
                    className="dashboard-tabs"
                  >
                    <Tabs.List>
                      <Tabs.Tab value="week">{t("filters.week")}</Tabs.Tab>
                      <Tabs.Tab value="month">{t("filters.month")}</Tabs.Tab>
                    </Tabs.List>
                  </Tabs>

                  <Tabs
                    value={activeTab}
                    onChange={handleTabChange}
                    className="dashboard-tabs days-year"
                  >
                    <Tabs.List>
                      <Tabs.Tab value="days">{t("filters.days")}</Tabs.Tab>
                      <Tabs.Tab value="year">{t("filters.year")}</Tabs.Tab>
                    </Tabs.List>
                  </Tabs>
                </Group>

                {activeTab === "days" && (
                  <Select
                    placeholder="Select Days"
                    data={selectOption}
                    value={selectedDayRange}
                    onChange={handleDayRangeChange}
                    size="sm"
                    radius="md"
                    w={200}
                    className="select-filter"
                  />
                )}

                {activeTab === "year" && (
                  <Select
                    placeholder="Select Year"
                    data={selectYearOption}
                    value={selectedYearRange}
                    onChange={handleYearRangeChange}
                    size="sm"
                    radius="md"
                    w={200}
                    className="select-filter"
                  />
                )}
              </Flex>
            </Flex>
          </Box>
          <Box className="admin-dashboard-bar-chart-container">
            {/* BarChart loader, empty message, or chart below filter controls */}
            {isReportListLoading && isReportListFetching ? (
              <Center h={470}>
                <Loader type="oval" size="xl" />
              </Center>
            ) : data.length === 0 ? (
              <Text c="black" ta="center" mt="xl">
                No data available for the selected filter.
              </Text>
            ) : (
              // ""
              <Barchartview />
            )}
          </Box>
        </>
      ) : (
        <Card
          mb="lg"
          radius="lg"
          bg="#EDF6FF"
          shadow="md"
          style={{ paddingLeft: "2rem", paddingBottom: "0" }}
        >
          <Grid align="center">
            <Grid.Col span={4}>
              <Stack>
                <Text
                  size="xl"
                  style={{
                    fontSize: "32px",
                    lineHeight: "1.2",
                    fontWeight: 500,
                    color: "#1F1F1F",
                  }}
                >
                  Good to See <br /> You Again!
                </Text>
                {role === USER_ROLE.INSTRUCTOR || role === USER_ROLE.ADMIN ? (
                  <Text style={{ color: "#081021" }}>{t("messages.welcome")}</Text>
                ) : (
                  <Text style={{ color: "#081021" }}>
                    Stay focused, stay consistent. Your GRE journey continues—let’s unlock your full
                    potential today.
                  </Text>
                )}
              </Stack>
            </Grid.Col>
            <Grid.Col span={8}>
              <Image src={banner} width={800} height={300} alt="Banner Image" />
            </Grid.Col>
          </Grid>
        </Card>
      )}
    </Container>
  );
};

