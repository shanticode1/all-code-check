"use client";

import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, Grid, Select, TextInput, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { useTranslations } from "next-intl";
import React, { useRef } from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";

import CommonEditor, { CommonEditorHandle } from "@/components/Common/Editor/Editor";
import { accessType, DEFAULT_EXAM_GUIDELINES } from "@/constants/exam";
import { addExamValidationSchema } from "@/constants/validationSchemas/adminAuth"; // Import validation schema
import { useExamMutation, useUpdateExamMutation } from "@/hooks/exam";
import { IAddExam, IAddExamFormValues, IAddExamProps } from "@/types/Exam/AddExam";

import { BUTTON_TYPES } from "../../../types/button.types";

export default function AddExamPage({ handleClose, exam }: Readonly<IAddExamProps>) {
  const editorRef = useRef<CommonEditorHandle>(null);
  const examId = exam ? exam.id : null;
  const t = useTranslations("exam");
  const tGeneric = useTranslations("generic");
  const { mutateAsync: addExam, isPending: isAddingExam } = useExamMutation();
  const { mutateAsync: updateExam, isPending: isUpdatingExam } = useUpdateExamMutation();
  const isEdit = !!exam;
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
    setError,
    clearErrors,
  } = useForm<IAddExamFormValues>({
    resolver: yupResolver(addExamValidationSchema),
    defaultValues: {
      examName: exam?.data?.examName ?? "",
      accessType: exam?.data?.accessType ?? "",
      guidelines: exam?.data?.guidelines ?? DEFAULT_EXAM_GUIDELINES,
      penaltyQuant: exam?.data?.penaltyQuant ?? 1.2,
      penaltyVerbal: exam?.data?.penaltyVerbal ?? 1.3,
    },
  });

  const guidelines = watch("guidelines");

  const handleEditorChange = (newContent: string) => {
    setValue("guidelines", newContent); // updates RHF value

    const tempElement = document.createElement("div");
    tempElement.innerHTML = newContent;
    const textContent = tempElement.textContent ?? tempElement.innerText ?? "";

    if (!textContent.trim()) {
      setError("guidelines", {
        type: "manual",
        message: t("messages.guidelinesRequired.label"),
      });
    } else {
      clearErrors("guidelines");
    }
  };

  const onSubmit = async (data: IAddExamFormValues) => {
    const currentValue = editorRef.current ? editorRef.current.getContent() : "";
    // using this for to manage the editor space which e are getting like this &nbsp
    const tempElement = document.createElement("div");
    tempElement.innerHTML = currentValue;
   
    const penaltyQuant = isEdit
      ? data.penaltyQuant
      : data.penaltyQuant ?? 1.2;
    const penaltyVerbal = isEdit
      ? data.penaltyVerbal
      : data.penaltyVerbal ?? 1.3;
      
    const requestData = {
      exam_name: data.examName,
      guidelines: currentValue,
      is_free: data.accessType === "Free",
      quant_penalty_per_mistake: penaltyQuant,
      verbal_penalty_per_mistake: penaltyVerbal,
    };

    try {
      if (examId) {
        // Update existing exam
        const updatedData = { ...requestData };
        await handleUpdateExam(examId, updatedData);
      } else {
        // Add API call or logic to save the exam
        const examAddRes = await addExam(requestData);
        const { message } = examAddRes;
        // Reset form or show success message
        setValue("examName", "");
        setValue("accessType", "");
        setValue("status", "");
        setValue("guidelines", "");
        clearErrors("guidelines");
        showNotification({
          title: "Success",
          message: message,
          color: "green",
          autoClose: 3000, // Closes after 3s
        });
      }
      handleClose();
    } catch (error) {
      if (error) {
        showNotification({
          title: "Error",
          message: `${(error as Error).message}`,
          color: "red",
        });
        return;
      }
      handleClose();
    }
  };

  const handlePenaltyChange =
    (field: "penaltyQuant" | "penaltyVerbal") => (e: React.ChangeEvent<HTMLInputElement>) => {
      const value = parseFloat(e.target.value);
      setValue(field, value, { shouldValidate: true });

      try {
        addExamValidationSchema.validateSync(value);
        clearErrors(field);
      } catch (error) {
        if (error instanceof yup.ValidationError) {
          setError(field, { type: "manual", message: error.message });
        }
      }
    };

  const handleUpdateExam = async (examId: number, updatedData: IAddExam) => {
    try {
      const response = await updateExam({ exam_id: examId, input: updatedData });
      const { message } = response;
      if (response) {
        showNotification({
          title: "Success",
          message: message,
          color: "green",
        });
      }
    } catch (error) {
      showNotification({
        title: "Error",
        message: `${(error as Error).message}`,
        color: "red",
      });
    }
  };

  const onChange = (value: string | null): void => {
    if (value) {
      setValue("accessType", value, { shouldValidate: true });
    }
  };

  return (
    <Box p={15}>
      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <Grid>
          {/* Exam Name */}
          <Grid.Col span={6}>
            <TextInput
              label={t("form.labels.examName")}
              withAsterisk
              placeholder={t("form.inputs.placeholder.examName")}
              {...register("examName")}
              error={errors.examName?.message}
            />
          </Grid.Col>
          {/* Access Type */}
          <Grid.Col span={6}>
            <Select
              label={t("form.labels.accessType")}
              placeholder={t("form.inputs.placeholder.accessType")}
              data={accessType}
              onChange={onChange}
              value={watch("accessType")}
              error={errors.accessType?.message}
              withAsterisk
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              withAsterisk
              label={t("form.labels.quantPanulty")}
              placeholder={t("form.inputs.placeholder.quantPanulty")}
              type="number"
              {...register("penaltyQuant", { valueAsNumber: true })}
              onChange={handlePenaltyChange("penaltyQuant")}
              error={errors.penaltyQuant?.message}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              withAsterisk
              label={t("form.labels.verbalPanulty")}
              placeholder={t("form.inputs.placeholder.verbalPanulty")}
              type="number"
              {...register("penaltyVerbal", {
                valueAsNumber: true,
              })}
              onChange={handlePenaltyChange("penaltyVerbal")}
              error={errors.penaltyVerbal?.message}
            />
          </Grid.Col>
          {/* Guidelines & Instructions */}
          <Grid.Col span={12}>
            <Title order={6} style={{ fontWeight: 500 }}>
              {t("form.labels.guidelinesAndInstructions")}
              <span style={{ color: "red" }}> *</span>
            </Title>
            <div style={{ width: "100%" }}>
              <CommonEditor
                guidelines={guidelines ?? undefined}
                ref={editorRef}
                onContentChange={handleEditorChange}
                placeholder={t("form.inputs.placeholder.guidelinesAndInstructions")} // Custom placeholder
                height={300}
              />
            </div>

            {errors.guidelines && (
              <p style={{ color: "red", fontSize: "14px", marginTop: "5px" }}>
                {errors.guidelines.message}
              </p>
            )}
          </Grid.Col>

          {/* Submit Button */}
          <Grid.Col span={12} style={{ display: "flex", justifyContent: "flex-end", gap: "10px" }}>
            <Button
              type="button"
              mt="md"
              variant="default"
              disabled={isUpdatingExam || isAddingExam}
              onClick={handleClose}
            >
              {tGeneric("buttons.cancel")}
            </Button>
            <Button type={BUTTON_TYPES.SUBMIT} mt="md" disabled={isUpdatingExam || isAddingExam}>
              {examId ? t("buttons.update") : t("buttons.add")}
            </Button>
          </Grid.Col>
        </Grid>
      </form>
    </Box>
  );
}
