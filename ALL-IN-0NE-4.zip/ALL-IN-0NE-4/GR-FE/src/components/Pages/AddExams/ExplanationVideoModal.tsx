import { Accordion, Grid,Modal, ScrollArea, Text } from "@mantine/core";
import { IconFolder } from "@tabler/icons-react";
import React, { useEffect } from "react";

import { useGetSectionExplanationVideoQuery } from "@/hooks/examSection";
import { ExplanationVideoProps } from "@/types";

const ExplanationVideoModal: React.FC<ExplanationVideoProps> = ({
  opened,
  onClose,
  onVideoSelect,
  sectionSlug,
  selectedVideoUrl,
  t
}) => {
  const { data } = useGetSectionExplanationVideoQuery({ sectionSlug });
  const videos = data?.data || {};
  const [selectedUrl, setSelectedUrl] = React.useState<string | null>(selectedVideoUrl ?? null);
  const [openedAccordion, setOpenedAccordion] = React.useState<string | null>(null);

  // Set selected video when modal opens
  useEffect(() => {
    if (opened && selectedVideoUrl) {
      setSelectedUrl(selectedVideoUrl);
    }
  }, [opened, selectedVideoUrl]);

  const handleSelection = (url: string) => {
    setSelectedUrl(url);
    onVideoSelect(url);
    onClose();
  };

  return (
    <Modal
      style={{ paddingRight: "0" }}
      opened={opened}
      onClose={onClose}
      title={t("form.video.title")}
      size="xl"
      centered
      className="explanation-video-modal"
    >
      <ScrollArea type="auto" h={450} style={{ marginTop: 16 }}>
        <Accordion
          variant="contained"
          value={openedAccordion}
          onChange={setOpenedAccordion}
          multiple={false}
          style={{ paddingRight: "20px" }}
        >
          {Object.entries(videos).map(([folderName, videoUrls]) => (
            <Accordion.Item value={folderName} key={folderName}>
              <Accordion.Control icon={<IconFolder size={16} />}>{folderName}</Accordion.Control>
              <Accordion.Panel>
                <Grid gutter={16} justify="center" mt={10}>
                  {(videoUrls as string[]).map((url) => {
                    const videoTitle = decodeURIComponent(url.split("/").pop() ?? "");
                    const isActive = selectedUrl == url;
                    return (
                      <Grid.Col
                        key={url}
                        style={{
                          cursor: "pointer",
                          textAlign: "left",
                          padding: "8px",
                          borderRadius: 8,
                          border: isActive ? "2px solid #228be6" : "1px solid #ccc",
                          backgroundColor: isActive ? "#e7f5ff" : "#fff",
                          marginBottom: "8px",
                        }}
                        span={{ md: 12 }}
                        onClick={() => handleSelection(url)}
                      >
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: "20px",
                            marginBottom: "16px",
                          }}
                        >
                          <video
                            src={url}
                            muted
                            style={{
                              width: "150px",
                              height: "auto",
                              objectFit: "cover",
                              borderRadius: 8,
                            }}
                          />
                          <Text size="md" mt={4} lineClamp={2}>
                            🎥 {videoTitle}
                          </Text>
                        </div>
                      </Grid.Col>
                    );
                  })}
                </Grid>
              </Accordion.Panel>
            </Accordion.Item>
          ))}
        </Accordion>
      </ScrollArea>
    </Modal>
  );
};

export default ExplanationVideoModal;
