/* eslint-disable react/prop-types */
"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Center,
  Flex,
  Grid,
  Loader,
  MultiSelect,
  Paper,
  Select,
  Text,
  Textarea,
  TextInput,
  Tooltip,
} from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconX } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as yup from "yup";

import CommonEditor, { CommonEditorHandle } from "@/components/Common/Editor/Editor";
import { QUESTION_LAYOUT } from "@/constants";
import {
  defaultInstructionsAndGuidelines,
  difficultyLevel,
  numericDifficultyLevel,
  quantitativeComparisonOptions,
  QUESTION_TYPE_OPTIONS_BY_SECTION,
  questionLayoutOptions,
} from "@/constants/exam";
import { errorFields, initialAnswerMap, QUESTION_TYPE, slugSecretKey } from "@/constants/questions";
import { useGetCategoryQuery } from "@/hooks/category";
import { useUpdateSectionQuestionsMutation } from "@/hooks/examSectionQuestions";
import { GroupCountMap } from "@/types/Exam/AddExam";
import { IAddQuestionsFormValues, IAnswerInput, IQuestionFormProps } from "@/types/Exam/index";
import {
  extractPlainTextFromHtml,
  getSectionKey,
  sanitizeHtmlToText,
  validatePrefixOrSuffix,
} from "@/utils";

import AnswerChoices from "../../AnswerChoices";
import ExplanationVideoModal from "../ExplanationVideoModal";

const QuestionForm: React.FC<IQuestionFormProps> = React.memo(
  ({ questionData, isLoading, sectionSlug }) => {
    const sectionKey = getSectionKey(sectionSlug);

    const validationSchema = useMemo(() => {
      const base = yup.object().shape({
        type: yup.string().nullable().required("Question Type is required"),
        category: yup.array().of(yup.string()).min(1, "Category is required"),
        difficultyLevel: yup.string().required("Difficulty level is required"),
        numericDifficultyLevel:
          sectionKey === slugSecretKey.ANALYTICAL_WRITING
            ? yup.number().nullable().notRequired()
            : yup.number().required("Numeric Difficulty level is required"),
        video: yup.string(),
        questionInstructions:
          sectionKey === slugSecretKey.ANALYTICAL_WRITING
            ? yup.string().notRequired()
            : yup.string().required("Question Instructions is required"),
        question_text: yup
          .string()
          .required("Question is required")
          .test("not-empty-after-strip", "Question is required", (value) => {
            return !sanitizeHtmlToText(value || "");
          }),
        questionLayout: yup.string().required("Question Layout is required"),
        passage_answer_instructions: yup.string().when("type", {
          is: "paragraph-sentence",
          then: (schema) => schema.required("Passage instructions are required."),
          otherwise: (schema) => schema.notRequired(),
        }),
      });
      const requiredMessage =
        sectionKey === slugSecretKey.ANALYTICAL_WRITING
          ? "Question answer prompt is required"
          : "Question Guidelines is required";

      return base.shape({
        questionGuidelines:
          sectionKey === "quantitative-reasoning"
            ? yup.string()
            : yup.string().required(requiredMessage),
      });
    }, [sectionKey]);

    const t = useTranslations("question");
    const [explanationModalOpened, setExplanationModalOpened] = useState(false);
    const {
      register,
      handleSubmit,
      reset,
      setValue,
      clearErrors,
      watch,
      setError,
      formState: { errors },
    } = useForm<IAddQuestionsFormValues>({
      resolver: yupResolver(validationSchema),
      defaultValues: {
        id: 0,
        type: sectionKey === slugSecretKey.ANALYTICAL_WRITING ? "essay" : null,
        category: sectionKey === slugSecretKey.ANALYTICAL_WRITING ? ["Analyze an Issue"] : [],
        difficultyLevel: "",
        video: "",
        question_text: "",
        questionGuidelines: "",
        questionInstructions: "",
        questionLayout: "",
        passage_answer_instructions: "",
      },
      mode: "onChange",
    });

    const editorRef = useRef<CommonEditorHandle>(null);
    const { data: categoryData } = useGetCategoryQuery({ sectionSlug });
    const { mutateAsync: updateSectionQuestions, isPending: isUpdating } =
      useUpdateSectionQuestionsMutation();

    const [answerData, setAnswerData] = useState<IAnswerInput[]>([]);

    const [
      questionText,
      selectedType,
      selectedCategory,
      selectedGuidelines,
      selectedInstructions,
      videoUrl,
      selectedDifficultyLevel,
      selectedNumericDifficultyLevel,
      selectedQuestionLayout,
      passage_answer_instructions,
    ] = watch([
      "question_text",
      "type",
      "category",
      "questionGuidelines",
      "questionInstructions",
      "video",
      "difficultyLevel",
      "numericDifficultyLevel",
      "questionLayout",
      "passage_answer_instructions",
    ]);

    const questionTypeOptions = useMemo(
      () => QUESTION_TYPE_OPTIONS_BY_SECTION[sectionKey] || [],
      [sectionKey],
    );

    const filteredQuestionLayoutOptions = useMemo(
      () =>
        questionLayoutOptions.map((option) => ({
          ...option,
          disabled:
            sectionSlug === slugSecretKey.ANALYTICAL_WRITING &&
            option.value === QUESTION_LAYOUT.TOPTOBOTTOM,
        })),
      [sectionSlug],
    );

    const categoryOptions = useMemo(
      () =>
        (categoryData?.data ?? [])
          .map((c: { title: string; category_id: number }) => ({
            value: c.title,
            label: c.title,
            category_id: c.category_id,
          }))
          .sort((a, b) => a.label.localeCompare(b.label)),
      [categoryData],
    );

    const generatedAnswerChoices = useMemo(
      () =>
        quantitativeComparisonOptions.map((text, idx) => ({
          answer_choice_id: null,
          question_id: questionData?.question_id,
          option_text: `<p>${text}</p>`,
          is_correct: false,
          answer_group: null,
          composite_key: idx.toString(),
        })),
      [quantitativeComparisonOptions, questionData?.question_id],
    );

    useEffect(() => {
      const defaults: Partial<IAddQuestionsFormValues> = questionData
        ? {
            id: questionData.question_id,
            type:
              questionData.question_type ||
              (sectionKey === slugSecretKey.ANALYTICAL_WRITING ? "essay" : null),
            category: questionData?.questionCategory?.length
              ? questionData.questionCategory
                  .map(
                    (qc: { category: { category_id: number; title: string } }) =>
                      categoryData?.data?.find(
                        (c: { title: string; category_id: number }) =>
                          c.category_id === qc.category.category_id,
                      )?.title || qc.category.title,
                  )
                  .filter(Boolean)
              : sectionKey === slugSecretKey.ANALYTICAL_WRITING
                ? ["Analyze an Issue"]
                : [],
            difficultyLevel: questionData.difficulty_level || null,
            video: questionData.video_url || "",
            questionGuidelines: questionData.guidelines || "",
            questionInstructions: questionData.instructions || null,
            question_text: questionData.question_text || null,
            numericDifficultyLevel: questionData.numeric_difficulty_level || null,
            passage_answer_instructions: questionData.passage_answer_instructions || null,
            questionLayout:
              sectionKey === slugSecretKey.ANALYTICAL_WRITING
                ? QUESTION_LAYOUT.LEFTTORIGHT
                : questionData.question_layout || null,
          }
        : {};

      reset({
        ...defaults,
        type: defaults.type ?? (sectionKey === slugSecretKey.ANALYTICAL_WRITING ? "essay" : null),
        category: Array.isArray(defaults.category)
          ? defaults.category
          : defaults.category
            ? [defaults.category]
            : sectionKey === slugSecretKey.ANALYTICAL_WRITING
              ? ["Analyze an Issue"]
              : [],
        difficultyLevel: defaults.difficultyLevel ?? null,
        video: defaults.video ?? "",
        questionGuidelines: defaults.questionGuidelines ?? null,
        questionInstructions: defaults.questionInstructions ?? null,
        question_text: defaults.question_text ?? null,
        passage_answer_instructions: defaults.passage_answer_instructions ?? null,
      });

      setAnswerData(
        questionData?.question_type === QUESTION_TYPE.QUANTITATIVE_COMPARISON
          ? questionData?.AnswerChoice && questionData?.AnswerChoice?.length > 0
            ? questionData.AnswerChoice
            : generatedAnswerChoices
          : questionData?.AnswerChoice || [],
      );
    }, [questionData, categoryData, reset, sectionKey, generatedAnswerChoices]);

    useEffect(() => {
      if (selectedType === QUESTION_TYPE.QUANTITATIVE_COMPARISON) {
        let answers = [];

        if (selectedType === QUESTION_TYPE.QUANTITATIVE_COMPARISON) {
          if (questionData?.AnswerChoice && questionData.AnswerChoice.length > 0) {
            answers = questionData.AnswerChoice;
          } else {
            answers = generatedAnswerChoices;
          }
        } else {
          answers = questionData?.AnswerChoice || [];
        }

        setAnswerData(answers);
      }
    }, [selectedType]);

    useEffect(() => {
      if (questionData?.guidelines || questionData?.instructions) return;
      if (!selectedType) return;

      const baseSection = sectionSlug?.split("-")?.[0]?.toLowerCase();
      const def = defaultInstructionsAndGuidelines.find((d) => {
        if (d.section !== baseSection) return false;
        if (d.qType.toLowerCase() !== selectedType.toLowerCase()) return false;
        if (baseSection === "verbal" && d.categories) {
          const selectedCat = Array.isArray(selectedCategory)
            ? selectedCategory[0] || ""
            : selectedCategory || "";
          return d.categories.includes(selectedCat);
        }
        return true;
      });

      if (def) {
        setValue("questionGuidelines", def.guidelines);
        setValue("questionInstructions", def.instructions);
      }
    }, [selectedType, sectionSlug, selectedCategory, questionData, setValue]);

    const getInitialAnswers = (type: string): IAnswerInput[] =>
      (initialAnswerMap[type] ?? []).map((ans) => ({ ...ans }));

    const handleQuestionTypeChange = useCallback(
      (value: string | null) => {
        clearErrors(errorFields);
        if (!value) {
          setValue("type", null);
          setAnswerData([]);
          return;
        }
        setValue("type", value);
        setAnswerData(getInitialAnswers(value));
      },
      [clearErrors, setValue],
    );

    const handleAnswerChoices = useCallback(
      (
        text: string | null,
        idx: number | null,
        action?:
          | "addMore"
          | "removeOption"
          | "handleMultipleCorrect"
          | "handleSingleCorrect"
          | "addMoreParagraph"
          | "addSuffix"
          | "addPrefix"
          | null,
        group?: number | string | null,
      ) => {
        setAnswerData((prev) => {
          let data = [...prev];
          switch (action) {
            case "addMore":
              data.push({
                answer_choice_id: null,
                option_text: "",
                is_correct: false,
                answer_group: group as number | null,
              });
              break;
            case "addMoreParagraph":
              data.push({
                answer_choice_id: null,
                option_text: "",
                is_correct: true,
                answer_group: group as number | null,
              });
              break;
            case "removeOption":
              if (idx !== null) data.splice(idx, 1);
              break;

            case "handleSingleCorrect":
              data = data.map((d, i) => {
                const sameGroup =
                  d.answer_group === group || (d.answer_group == null && group == null);

                return sameGroup ? { ...d, is_correct: i === idx } : d;
              });
              break;

            case "handleMultipleCorrect":
              data = data.map((d, i) => {
                const sameGroup =
                  d.answer_group === group || (d.answer_group == null && group == null);

                if (sameGroup && i === idx) {
                  return { ...d, is_correct: !d.is_correct };
                }
                return d;
              });
              break;
            case "addPrefix":
              if (idx !== null && text !== null) {
                data[idx].answer_prefix = text;
                if (text.trim()) delete data[idx].error;
              }
              break;
            case "addSuffix":
              if (idx !== null && text !== null) {
                data[idx].answer_suffix = text;
                if (text.trim()) delete data[idx].error;
              }
              break;
            default:
              if (idx !== null && text !== null) {
                data[idx].option_text = text;
                if (text.trim()) delete data[idx].error;
              }
              break;
          }
          return data;
        });
      },
      [],
    );

    const handleAsyncSubmit = useCallback(
      async (data: IAddQuestionsFormValues) => {
        // Map all selected category labels to their IDs
        const selectedCategoryIds = categoryOptions
          .filter((c) =>
            Array.isArray(data.category)
              ? data.category.includes(c.label)
              : c.label === data.category,
          )
          .map((c) => c.category_id);

        const payload = {
          exam_id: questionData?.exam_id,
          section_id: questionData?.section_id,
          category_id: selectedCategoryIds,
          question_type: data.type,
          question_text: data.question_text,
          video_url: data.video,
          difficulty_level: data.difficultyLevel,
          guidelines:
            sectionKey === slugSecretKey.QUANTITATIVE_REASONING ? null : data.questionGuidelines,
          instructions: data.questionInstructions,
          answerChoices: answerData.map((ans, i) => ({ ...ans, composite_key: i })),
          numeric_difficulty_level:
            sectionKey === slugSecretKey.ANALYTICAL_WRITING ? null : data.numericDifficultyLevel,
          question_layout: data.questionLayout,
          passage_answer_instructions: data.passage_answer_instructions,
        };

        try {
          const res = await updateSectionQuestions({
            question_id: questionData?.question_id,
            input: {
              ...payload,
            },
          });
          showNotification({ title: "Success", message: res.message, color: "green" });
        } catch (error) {
          const err = error as Error;
          showNotification({
            title: "Error",
            message: err?.message,
            color: "red",
          });
        }
      },
      [answerData, categoryOptions, questionData, updateSectionQuestions, selectedType, sectionKey],
    );

    const handleFormSubmit = (formData: IAddQuestionsFormValues) => {
      clearErrors(errorFields);

      if (sectionKey === slugSecretKey.ANALYTICAL_WRITING && !formData?.question_text?.trim()) {
        setError("question_text", {
          type: "manual",
          message: t("errorMessages.questionTextRequired"),
        });
        return;
      }
      if (answerData.length > 0) {
        let hasEmpty = false;
        const normalized = answerData.map((ans) => {
          if (sanitizeHtmlToText(ans.option_text || "")) {
            hasEmpty = true;
            return { ...ans, error: t("errorMessages.answerTextRequired") };
          }

          if (selectedType === "numericalEntry") {
            // Only allow numbers, decimal point, and optional leading '-'

            const value = ans.option_text || "";
            // Only allow numbers, decimal point, and optional leading '-'
            // Only allow numbers, decimal point, and optional leading '-'
            if (!/^-?\d*\.?\d*$/.test(value)) {
              // Special case: if '-' is present but not at the start, show a specific error
              if (/-/.test(value) && !/^-\d*\.?\d*$/.test(value)) {
                hasEmpty = true;
                return {
                  ...ans,
                  error: t("errorMessages.minusUsedAtBegnining"),
                };
              }
              hasEmpty = true;
              return {
                ...ans,
                error: t("errorMessages.onlyNumberDecimalAllow"),
              };
            }
            // Disallow numbers ending with a decimal point (e.g., '123.' or '-123.')
            if (/^-?\d+\.$/.test(value)) {
              hasEmpty = true;
              return {
                ...ans,
                error: t("errorMessages.canNotEndWithDecimal"),
              };
            }

            // Count digits excluding '-' and '.'
            const digitsOnly = value.replace(/\D/g, "");
            if (digitsOnly.length > 8) {
              hasEmpty = true;
              return {
                ...ans,
                error: t("errorMessages.allowedDigit"),
              };
            }
            const prefixError = validatePrefixOrSuffix(ans.answer_prefix || "", "Prefix");
            if (prefixError) {
              hasEmpty = true;
              return { ...ans, error: prefixError };
            }

            // Apply for suffix
            const suffixError = validatePrefixOrSuffix(ans.answer_suffix || "", "Suffix");
            if (suffixError) {
              hasEmpty = true;
              return { ...ans, error: suffixError };
            }
            if (/[a-zA-Z,]/.test(ans.option_text || "")) {
              hasEmpty = true;
              return {
                ...ans,
                error: t("errorMessages.characterNotAllowed"),
              };
            }

            ans.option_text = value.toString();
          }

          return { ...ans, error: "" };
        });
        if (hasEmpty) {
          setAnswerData(normalized);
          return;
        }

        // Duplicate Option Text Check
        const globalSeen = new Set<string>(); // Original global check
        const groupSeen = new Map<number, Set<string>>(); // New group-based check

        for (const ans of answerData) {
          const cleaned = extractPlainTextFromHtml(ans.option_text || "");
          const group = ans.answer_group;

          // If answer_group is a number, do group-based check
          if (typeof group === "number") {
            if (!groupSeen.has(group)) {
              groupSeen.set(group, new Set());
            }

            const groupSet = groupSeen.get(group)!;

            if (groupSet.has(cleaned)) {
              showNotification({
                title: "Error",
                message: t("messages.duplicateAnswer", { value: cleaned }),
                color: "red",
              });
              return;
            }

            groupSet.add(cleaned);
          } else {
            // Global check (your existing logic)
            if (globalSeen.has(cleaned)) {
              showNotification({
                title: "Error",
                message: t("messages.duplicateAnswer", { value: cleaned }),
                color: "red",
              });
              return;
            }

            globalSeen.add(cleaned);
          }
        }

        const groupCountMap: GroupCountMap = {
          twoFillInTheBlank: 2,
          threeFillInTheBlank: 3,
          customKey: 5,
        };
        const groups = selectedType ? groupCountMap[selectedType] || 0 : 0;
        if (groups && answerData.length % groups !== 0) {
          showNotification({
            title: "Error",
            message: `Number of answer boxes must be a multiple of ${groups} for ${
              groups === 2 ? "Two" : "Three"
            } Fill In The Blank.`,
            color: "red",
          });
          return;
        }
        if (groups) {
          const groupLabels = ["A", "B", "C"];
          for (let i = 1; i <= groups; i++) {
            if (!answerData.some((a) => a.is_correct && a.answer_group === i)) {
              showNotification({
                title: "Error",
                message: `At least one answer must be marked as correct in Group ${groupLabels[i - 1]}.`,
                color: "red",
              });
              return;
            }
          }
        } else {
          if (
            !answerData.some((a) => a.is_correct) &&
            selectedType !== "numericalEntry" &&
            selectedType !== "paragraph-sentence" &&
            selectedType !== "fractionalEntry"
          ) {
            showNotification({
              title: "Error",
              message: t("errorMessages.markedOneCOrrectAns"),
              color: "red",
            });
            return;
          }
        }
      }

      handleAsyncSubmit(formData);
    };

    if (isLoading)
      return (
        <Center h="50vh">
          <Loader type="oval" />
        </Center>
      );

    return (
      <>
        <form onSubmit={handleSubmit(handleFormSubmit)}>
          <Paper p="md" shadow="sm">
            <Grid>
              <Grid.Col span={12}>
                <Select
                  label={t("form.questionType.select.label")}
                  placeholder={t("form.questionType.select.placeholder")}
                  required
                  data={questionTypeOptions}
                  value={selectedType}
                  defaultValue={selectedType}
                  onChange={(val) => {
                    if (
                      (val === selectedType || val === null) &&
                      sectionKey === slugSecretKey.ANALYTICAL_WRITING
                    )
                      return;
                    handleQuestionTypeChange(val);
                  }}
                  error={errors.type?.message}
                  clearable={sectionKey !== slugSecretKey.ANALYTICAL_WRITING}
                  comboboxProps={{ withinPortal: false }}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <Select
                  label={t("form.questionLayout.select.label")}
                  required
                  placeholder={t("form.questionLayout.select.placeholder")}
                  data={filteredQuestionLayoutOptions}
                  value={selectedQuestionLayout?.toString() || ""}
                  onChange={(v) => {
                    setValue("questionLayout", v || "");
                    clearErrors(["questionLayout"]);
                  }}
                  clearable
                  error={errors.questionLayout?.message}
                  comboboxProps={{ withinPortal: false }}
                />
              </Grid.Col>
              <Grid.Col span={12}>
                <MultiSelect
                  label={t("form.category.select.label")}
                  placeholder={t("form.category.select.placeholder")}
                  required
                  data={categoryOptions}
                  value={selectedCategory || []}
                  onChange={(values) => setValue("category", values)}
                  error={errors.category?.message}
                  clearable={sectionKey !== slugSecretKey.ANALYTICAL_WRITING}
                  comboboxProps={{ withinPortal: false }}
                />
              </Grid.Col>

              {(sectionSlug === "verbal-reasoning-2" ||
                sectionSlug === "quantitative-reasoning-2") && (
                <Grid.Col span={12}>
                  <Select
                    label={t("form.difficultyLevel.select.label")}
                    required
                    placeholder={t("form.difficultyLevel.select.placeholder")}
                    data={difficultyLevel}
                    value={selectedDifficultyLevel}
                    onChange={(v) => {
                      setValue("difficultyLevel", v || "");
                      clearErrors(["difficultyLevel"]);
                    }}
                    error={errors.difficultyLevel?.message}
                    disabled
                    comboboxProps={{ withinPortal: false }}
                  />
                </Grid.Col>
              )}
              {sectionKey !== slugSecretKey.ANALYTICAL_WRITING && (
                <Grid.Col span={12}>
                  <Select
                    label={t("form.numericDifficultyLevel.select.label")}
                    required
                    placeholder={t("form.numericDifficultyLevel.select.placeholder")}
                    data={numericDifficultyLevel}
                    value={selectedNumericDifficultyLevel?.toString()}
                    onChange={(v) => {
                      setValue("numericDifficultyLevel", Number(v));
                      clearErrors(["numericDifficultyLevel"]);
                    }}
                    error={errors.numericDifficultyLevel?.message}
                    comboboxProps={{ withinPortal: false }}
                  />
                </Grid.Col>
              )}
              {sectionKey !== slugSecretKey.ANALYTICAL_WRITING && (
                <Grid.Col span={12}>
                  <Flex direction="column" gap="xs">
                    <Flex align="center" gap={6}>
                      <Text fw={500} size="sm">
                        {t("form.video.label")}
                      </Text>
                      <Tooltip
                        label={
                          <Text size="sm" style={{ whiteSpace: "normal" }}>
                            {t("form.video.tooltip.message.importNote")} <br />
                            {t("form.video.tooltip.message.httpDomain")} <br />
                            {t("form.video.tooltip.message.validData")}
                          </Text>
                        }
                        position="top"
                        withArrow
                      >
                        <Text color="blue" style={{ cursor: "pointer" }}>
                          ℹ️
                        </Text>
                      </Tooltip>
                    </Flex>
                    <Flex>
                      <Button
                        variant="fill"
                        size="sm"
                        onClick={() => setExplanationModalOpened(true)}
                      >
                        {t("form.video.button.text")}
                      </Button>
                      <TextInput
                        placeholder={t("form.video.placeholder")}
                        {...register("video")}
                        value={videoUrl || ""}
                        readOnly
                        error={
                          sectionSlug === "verbal-reasoning-2" ? errors.video?.message : undefined
                        }
                        rightSection={
                          videoUrl ? (
                            <Text
                              style={{ cursor: "pointer", color: "red", fontWeight: "bold" }}
                              onClick={(e) => {
                                e.stopPropagation(); // prevent modal from opening
                                setValue("video", ""); // reset in react-hook-form
                              }}
                            >
                              <span style={{ display: "flex", alignItems: "center" }}>
                                <IconX size={18} />
                              </span>
                            </Text>
                          ) : null
                        }
                        style={{ flex: 1, marginLeft: "8px" }}
                      />
                    </Flex>
                  </Flex>
                </Grid.Col>
              )}

              {sectionKey !== "quantitative-reasoning" && (
                <Grid.Col span={12}>
                  <Textarea
                    withAsterisk
                    resize="vertical"
                    label={
                      sectionKey === slugSecretKey.ANALYTICAL_WRITING
                        ? t("form.answerPrompt.label")
                        : t("form.guidelines.label")
                    }
                    placeholder={
                      sectionKey === slugSecretKey.ANALYTICAL_WRITING
                        ? t("form.answerPrompt.placeholder")
                        : t("form.guidelines.placeholder")
                    }
                    {...register("questionGuidelines")}
                    value={selectedGuidelines || ""}
                    onChange={(e) => {
                      setValue("questionGuidelines", e.target.value);
                      clearErrors(["questionGuidelines"]);
                    }}
                    error={errors.questionGuidelines?.message}
                  />
                </Grid.Col>
              )}
              {sectionKey !== slugSecretKey.ANALYTICAL_WRITING && (
                <Grid.Col span={12}>
                  <Textarea
                    withAsterisk
                    resize="vertical"
                    label={t("form.instruction.label")}
                    placeholder={t("form.instruction.placeholder")}
                    {...register("questionInstructions")}
                    value={selectedInstructions || ""}
                    onChange={(e) => {
                      setValue("questionInstructions", e.target.value);
                      clearErrors(["questionInstructions"]);
                    }}
                    error={errors.questionInstructions?.message}
                  />
                </Grid.Col>
              )}
            </Grid>

            <Text fz="sm" fw="500" mt={20}>
              {t("form.question.label")} <span style={{ color: "red" }}> *</span>
            </Text>
            <CommonEditor
              guidelines={questionText || ""}
              ref={editorRef}
              onContentChange={(content) => {
                setValue("question_text", content);
                clearErrors(["question_text"]);
              }}
              placeholder={t("form.editor.placeholder")}
              height={300}
            />
            {errors.question_text && (
              <Text color="red" size="sm">
                {errors.question_text.message}
              </Text>
            )}

            <Grid.Col span={12} mt={10}>
              <Text fz="sm" fw={500}>
                {t("form.answer.instruction.label")}
              </Text>
              <CommonEditor
                guidelines={passage_answer_instructions || ""}
                onContentChange={(content) => {
                  setValue("passage_answer_instructions", content);
                  clearErrors(["passage_answer_instructions"]);
                }}
                placeholder={t("form.answer.instruction.placeholder")}
                height={200}
              />
              {errors.passage_answer_instructions && (
                <Text color="red" size="sm">
                  {errors.passage_answer_instructions.message}
                </Text>
              )}
            </Grid.Col>
          </Paper>

          {selectedType && sectionKey !== slugSecretKey.ANALYTICAL_WRITING && (
            <Paper p="md" shadow="sm" mt="md">
              <AnswerChoices
                type={selectedType}
                handleAnswerChoices={handleAnswerChoices}
                answerChoice={answerData ?? []}
              />
            </Paper>
          )}
          <Flex justify="flex-end">
            <Button type="submit" mt="md" loading={isUpdating}>
              {questionData ? t("form.buttons.update.text") : t("form.buttons.add.text")}
            </Button>
          </Flex>
        </form>
        {sectionKey !== slugSecretKey.ANALYTICAL_WRITING && (
          <ExplanationVideoModal
            opened={explanationModalOpened}
            onClose={() => setExplanationModalOpened(false)}
            onVideoSelect={(url) => {
              setValue("video", url);
              clearErrors(["video"]);
            }}
            sectionSlug={String(sectionSlug)}
            selectedVideoUrl={videoUrl ?? undefined}
            t={t}
          />
        )}
      </>
    );
  },
);

QuestionForm.displayName = "QuestionForm";

export default QuestionForm;
