/* eslint-disable react/prop-types */
"use client";

import { CheckIcon, Text } from "@mantine/core";
import { IconX } from "@tabler/icons-react";
import { DataTable } from "mantine-datatable";
import React, { useMemo } from "react";

import Loader from "@/components/Common/Loaders/Loader";
import { IQuestionListProps } from "@/types/Exam/AddExam";
import { IQuestionColumn } from "@/types/Exam/ExamHistory";
import { truncateHtml } from "@/utils";

// eslint-disable-next-line react/display-name
const QuestionList: React.FC<IQuestionListProps> = React.memo(
  ({ examData, sectionId, tableColumns, onClick }) => {
    const records = useMemo(() => {
      const section = examData?.data?.sections?.find(
        (sec: { section_id: number }) => sec.section_id === sectionId,
      );
      if (!section) return [];
      return (
        section.questions?.map(
          (
            q: { question_id: number; question_text: string; difficulty_level: string },
            idx: number,
          ) => ({
            id: idx + 1,
            question_id: q.question_id,
            question_text: q?.question_text || "",
            difficulty_level: q.difficulty_level || "",
            section_id: section.section_id,
            title: section.section_name,
            sectionSlug: section.section_slug,
            question_no: idx + 1,
          }),
        ) || []
      );
    }, [examData, sectionId]);

    const questionColumns = useMemo(
      () =>
        tableColumns.map((column) => ({
          ...column,
          render: (row: IQuestionColumn) =>
            column.accessor === "question_text" ? (
              <span
                className="question-table-link"
                onClick={() =>
                  onClick(
                    row.question_id,
                    row.section_id,
                    row.title,
                    row.sectionSlug,
                    row.question_no,
                  )
                }
              >
                {row?.question_text ? (
                  <Text display="flex" className="align-center">
                    <CheckIcon size={10} style={{ color: "green", marginRight: "8px" }} />
                    <span
                      className="link"
                      dangerouslySetInnerHTML={{
                        __html: truncateHtml(row.question_text, 80),
                      }}
                    />
                  </Text>
                ) : (
                  <Text display="flex" className="align-center">
                    <IconX
                      size={14}
                      fontWeight="bold"
                      style={{ color: "red", marginRight: "8px" }}
                    />
                    <span>Question {row.question_no}</span>
                  </Text>
                )}
              </span>
            ) : (
              row[column.accessor as keyof IQuestionColumn]
            ),
        })),
      [tableColumns, onClick],
    );

    if (!examData) return <Loader />;

    return (
      <DataTable
        records={records}
        columns={questionColumns}
        withTableBorder
        withColumnBorders
        borderRadius="sm"
        highlightOnHover
        striped
        verticalAlign="top"
        pinLastColumn
        noRecordsText="No questions found"
      />
    );
  },
);

export default QuestionList;
