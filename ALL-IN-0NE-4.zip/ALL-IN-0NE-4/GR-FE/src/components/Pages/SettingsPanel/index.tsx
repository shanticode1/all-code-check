import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, Drawer, Grid, Text, TextInput } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { useTranslations } from "next-intl";
import React, { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";

import CommonEditor, { CommonEditorHandle } from "@/components/Common/Editor/Editor";
import { DEFAULT_SECTION_INSTRUCTIONS } from "@/constants/exam";
import { SECTION_SETTINGS_VALIDATION_SCHEMA } from "@/constants/validationSchemas/exams";
import { useUpdateSectionMutation } from "@/hooks/examSection";
import { BUTTON_TYPES } from "@/types/button.types";
import { SettingsFormValues, SettingsPanelProps } from "@/types/setting";
import logger from "@/utils/tools/logger";

export default function SettingsPanel({ isOpen, onClose, selectedSection }: Readonly<SettingsPanelProps>) {
  const editorRef = useRef<CommonEditorHandle>(null);
  const t = useTranslations("exam");
  const t_generic = useTranslations("generic");

  const sectionId: string = String(selectedSection.section_id);
  const { mutateAsync: updateSection, isPending: isUpdatingExam } = useUpdateSectionMutation();
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    clearErrors,
    formState: { errors },
  } = useForm<SettingsFormValues>({
    resolver: yupResolver(SECTION_SETTINGS_VALIDATION_SCHEMA),
    defaultValues: {
      section_name: selectedSection.section_name,
      time_limit: selectedSection.time_limit,
      instructions:
        selectedSection.instructions?.trim() ||
        (selectedSection.section_slug &&
          DEFAULT_SECTION_INSTRUCTIONS[selectedSection.section_slug]) ||
        "",
    },
  });

  const instructions = watch("instructions");

  useEffect(() => {
    if (isOpen) {
      clearErrors();
      setValue("section_name", selectedSection.section_name);
      setValue("time_limit", selectedSection.time_limit);
      setValue(
        "instructions",
        selectedSection.instructions?.trim() ||
          (selectedSection.section_slug &&
            DEFAULT_SECTION_INSTRUCTIONS[selectedSection.section_slug]) ||
          "",
      );
    }
  }, [isOpen, selectedSection, setValue]);

  const onSubmit = async (data: SettingsFormValues) => {
    // UPDATE section
    try {
      // Call the API to update the section order
      const response = await updateSection({ section_id: parseInt(sectionId ?? "0"), input: data });
      if (response) {
        showNotification({
          title: "Success",
          message: response.message,
          color: "green",
        });
      }
      onClose();
      // @ts-expect-error ts(2349)
    } catch (error: Error) {
      logger.error("Error updating exam:", error);
      showNotification({
        title: "Error",
        message: error.message ?? "Failed to update exam",
        color: "red",
      });
    }

    if (!sectionId) {
      showNotification({
        title: "Error",
        message: "Exam ID is missing. Cannot update exam.",
        color: "red",
      });
    }
  };

  const handleEditorChange = (newContent: string) => {
    clearErrors("instructions");
    setValue("instructions", newContent);
  };

  return (
    <Drawer
      opened={isOpen}
      onClose={onClose}
      title={t("exam_setting.title")}
      position="right"
      padding="lg"
      size="70vw"
    >
      <form onSubmit={handleSubmit(onSubmit)}>
        <Grid>
          <Grid.Col span={6}>
            <TextInput
              withAsterisk
              label={t("exam_setting.labels.sectionName")}
              placeholder={t("exam_setting.inputs.placeholder.sectionName")}
              {...register("section_name")}
              error={errors.section_name?.message}
            />
          </Grid.Col>
          <Grid.Col span={6}>
            <TextInput
              withAsterisk
              label={t("exam_setting.labels.timeLimit")}
              placeholder={t("exam_setting.inputs.placeholder.timeLimit")}
              type="number"
              min={1}
              {...register("time_limit", {
                valueAsNumber: true,
              })}
              error={errors.time_limit?.message}
            />
          </Grid.Col>
          <Grid.Col span={12}>
            <Box mt="md">
              <Text fz="sm" fw="500">
                {t("exam_setting.labels.sectionInstructions")}{" "}
                <span style={{ color: "red" }}> *</span>
              </Text>
              <CommonEditor
                guidelines={instructions ?? undefined}
                ref={editorRef}
                onContentChange={handleEditorChange}
                placeholder={t("exam_setting.inputs.placeholder.sectionInstructions")}
                height={400}
              />
              {errors.instructions && (
                <Text c="red" size="sm">
                  {errors.instructions.message}
                </Text>
              )}
            </Box>
          </Grid.Col>
        </Grid>

        <Button type={BUTTON_TYPES.SUBMIT} fullWidth mt="md" loading={isUpdatingExam}>
          {t_generic("buttons.update", { value: "Section" })}
        </Button>
      </form>
    </Drawer>
  );
}
