import {
  Accordion,
  ActionIcon,
  Badge,
  Button,
  CheckIcon,
  Flex,
  Text,
  Tooltip,
} from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconArrowDown, IconArrowUp, IconSettings, IconX } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

import { slugSecretKey } from "@/constants/questions";
import { useUpdateSectionOrderMutation } from "@/hooks/examSection";
import { IExamSidebarProps, ISections, ISectionWithoutQuestions } from "@/types/Exam/index";

import SettingsPanel from "../SettingsPanel";

export default function ExamSidebar({
  examId,
  onClick,
  onViewQuestions,
  examData,
}: Readonly<IExamSidebarProps>) {
  const t = useTranslations("sidebar.examSideBar");
  const [openSection, setOpenSection] = useState<number | null>(null);
  const [questions, setQuestions] = useState<{ [key: number]: string[] }>({});
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [selectedSection, setSelectedSection] = useState<ISectionWithoutQuestions>();
  const { mutateAsync: updateSectionOrder } = useUpdateSectionOrderMutation();
  const [loadingSections, setLoadingSections] = useState<{ [key: number]: boolean }>({});
  const examSections = examData?.data?.sections?.map((section: ISections) => ({
    id: section.section_id,
    section_id: section.section_id,
    exam_id: section.exam_id,
    section_name: section.section_name,
    sectionSlug: section.section_slug,
    instructions: section.instructions,
    title: section.section_name,
    question_counts: section.question_counts,
    calculator_permitted: section.calculator_permitted,
    base_score: section.base_score,
    time_limit: section.time_limit,
    adaptive_learning: section.adaptive_learning,
    display_order: section.display_order,
    questions: section.questions,
    section_slug: section.section_slug,
    question_no: section.questions?.length || 0,
  }));

  const toggleSection = (id: number) => {
    if (openSection === id) {
      setOpenSection(null);
    } else {
      setOpenSection(id);
      if (!questions[id]) {
        setQuestions((prev) => ({ ...prev, [id]: [""] })); // Auto add one input field
      }
    }
  };

  const openSettingsModal = (sectionValue: ISectionWithoutQuestions) => {
    setSelectedSection(sectionValue);
    setSettingsOpen(true);
  };

  const handleUpdateDisplayOrder = async (display_order: number, sectionId: number) => {
    setLoadingSections((prev) => ({ ...prev, [sectionId]: true }));
    try {
      // Call the API to update the section order
      const response = await updateSectionOrder({
        exam_id: examId,
        input: { display_order: display_order },
      });
      if (response) {
        showNotification({
          title: "Success",
          message: response.message,
          color: "green",
        });
      }
    } catch (error) {
      console.error("Error updating exam:", error);
      showNotification({
        title: "Error",
        message: "Failed to update exam",
        color: "red",
      });
    } finally {
      setLoadingSections((prev) => ({ ...prev, [sectionId]: false }));
    }
  };

  return (
    <div style={{ position: "sticky", top: "80px" }}>
      <Accordion>
        {examSections?.map((section, index: number) => (
          <Accordion.Item key={section.id} value={section.title} className="accordian">
            <Accordion.Control onClick={() => toggleSection(section.id)} className="accordianItem">
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  width: "100%",
                }}
              >
                <Flex align="center">
                  {section.sectionSlug === "verbal-reasoning-1" ||
                  section.sectionSlug === "quantitative-reasoning-1" ? (
                    <Tooltip label="Order Update">
                        <ActionIcon
                          color="gray"
                          mr={5}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUpdateDisplayOrder(section.display_order, section.id);
                          }}
                          loading={loadingSections[section.id]}
                        >
                          {index === 1 ? (
                            <IconArrowDown size={20} />
                          ) : index === 2 ? (
                            <IconArrowUp size={20} />
                          ) : (
                            ""
                          )}
                        </ActionIcon>
                    </Tooltip>
                  ) : null}
                  <span>{section.title}</span>
                </Flex>
                <Tooltip label={t("tooltip.sectionSettings")}>
                  <ActionIcon
                    color="gray"
                    mx={5}
                    onClick={(e) => {
                      e.stopPropagation(); // Prevents toggling accordion
                      openSettingsModal(section);
                    }}
                  >
                    <IconSettings size={20} />
                  </ActionIcon>
                </Tooltip>
              </div>
            </Accordion.Control>
            {openSection === section.id && (
              <Accordion.Panel>
                <div style={{ padding: "8px 0" }}>
                  {section.questions?.map((question, index: number) => {
                    const difficultyLabel = index < 15 ? "Easy" : index < 30 ? "Medium" : "Hard";
                    const badgeColor = index < 15 ? "green" : index < 30 ? "yellow" : "red";
                    const isGroupStart = index % 15 === 0;
                    return (
                      <React.Fragment key={question.question_id}>
                        {/* Add a label before the first question of each group */}

                        {section?.questions?.length > 15 && isGroupStart && (
                          <Badge
                            color={badgeColor}
                            size="lg"
                            style={{
                              marginTop: index === 0 ? 0 : "10px",
                              marginBottom: "10px",
                            }}
                          >
                            {difficultyLabel}
                          </Badge>
                        )}

                        {/* Render the question */}
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            marginBottom: "10px",
                          }}
                        >
                          <Text
                            component="span"
                            variant="link"
                            onClick={() =>
                              onClick(
                                question.question_id,
                                section.id,
                                section.title,
                                section.sectionSlug,
                                index + 1,
                              )
                            }
                            className="link"
                            style={{
                              cursor: "pointer",
                            }}
                          >
                            {question?.question_text ? (
                              <Text display="flex" className="align-center">
                                <CheckIcon
                                  size={10}
                                  style={{ color: "green", marginRight: "8px" }}
                                />
                                <span>
                                  {t("checkIcon.text")} {index + 1}
                                </span>
                              </Text>
                            ) : (
                              <Text display="flex" className="align-center">
                                <IconX
                                  size={14}
                                  fontWeight="bold"
                                  style={{ color: "red", marginRight: "8px" }}
                                />
                                <span>
                                  {t("checkIcon.text")} {index + 1}
                                </span>
                              </Text>
                            )}
                          </Text>
                        </div>

                        {/* Add a line separator after every 15 questions */}
                        {(index + 1) % 15 === 0 && index + 1 !== section?.questions?.length && (
                          <hr style={{ margin: "10px 0", border: "1px solid #ddd" }} />
                        )}
                      </React.Fragment>
                    );
                  })}
                  {section.sectionSlug !== slugSecretKey.ANALYTICAL_WRITING ? (
                    <Button
                      color="blue"
                      onClick={() =>
                        onViewQuestions(
                          section.id,
                          section.title,
                          section.sectionSlug,
                          section?.questions[0]?.question_id,
                          index,
                        )
                      }
                    >
                      {t("buttons.viewAll.text")}
                    </Button>
                  ) : null}
                </div>
              </Accordion.Panel>
            )}
          </Accordion.Item>
        ))}
      </Accordion>
      {selectedSection && (
        <SettingsPanel
          isOpen={settingsOpen}
          onClose={() => setSettingsOpen(false)}
          selectedSection={selectedSection}
        />
      )}
    </div>
  );
}
