"use client";
import {
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Center,
  Checkbox,
  Container,
  Divider,
  Flex,
  Group,
  Loader,
  Stack,
  Text,
  Title,
  Tooltip,
} from "@mantine/core";
import { IconClock } from "@tabler/icons-react";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useState } from "react";

import { useBlockBrowserNavigation } from "@/components/Common/BlockBrowserNavigation";
import DualLogoHeader from "@/components/Common/DualLogoHeader";
import WarningAlertModal from "@/components/Common/Modals/WarningAlertModal";
import { USER_ROLE } from "@/constants";
import usePreventDuplicateTabs from "@/hooks/common/usePreventDuplicateTabs";
import { useUpdateScreenTime } from "@/hooks/exam/examUpdateScreenTime";
import { useGetExamByIdQuery, useStartExamMutation } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import arrowRightLong from "@/public/icons/arrow-right-long.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { WindowWithNextNav } from "@/types";
import { convertSecondsToHoursAndMinutes } from "@/utils";
import UtilLocalService from "@/utils/tools/localstorage";

import ExamErrorHandle from "../ExamErrorHandle";
import styles from "./style.module.css";

export default function StudentExamInstruction() {
  useBlockBrowserNavigation(true);
  const router = useRouter();
  const { examId } = useParams() as { examId: string };
  const { updateScreenTime } = useUpdateScreenTime();
  const t = useTranslations("generic");
  const tExam = useTranslations("exam");
  const tExamDerail = useTranslations("examDetail");
  const { role } = useAuth();
  const {
    data: examDetail,
    isLoading: isExamDataLoading,
    isFetching: isExamDataFetching,
    error,
  } = useGetExamByIdQuery(examId, role as string);
  const { mutateAsync: startExam, isPending: isExamStart } = useStartExamMutation();
  const isDuplicateTab = usePreventDuplicateTabs(examId);

  const [isChecked, setIsChecked] = useState(false);
  const adminStudentRoute = role === USER_ROLE.STUDENT ? paths.ROOT_EXAMS : paths.ROOT_ADMIN_EXAM;

  const examData = examDetail?.data;

  const items = [
    { title: "Exam Management", href: adminStudentRoute },
    { title: examData?.exam_name, active: true },
  ].map((item) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
        {item.title}
      </Anchor>
    ),
  );

  const handleExamStart = async (id: string | number) => {
    try {
      UtilLocalService.removeLocalStorage("redirect_after_reload_section");
      UtilLocalService.removeLocalStorage("redirect_after_reload");
      if (role === USER_ROLE.STUDENT) {
        UtilLocalService.setLocalStorage("is_visible_timer", "true");
        const data = await startExam({ id: id, is_terms_conditions_accepted: isChecked });
        if (data?.data) {
          UtilLocalService.setLocalStorage("student_exam_id", data?.data.student_exam_id);
          if (data?.data.student_exam_id) {
            updateScreenTime(data?.data.student_exam_id.toString());
          }
          (window as WindowWithNextNav).__allowNextNavigation__?.();
          router.push(
            `${paths.ROOT_STUDENT_PREVIEW_SECTION}/${data.data?.student_exam_section_id}/instructions`,
          );
        }
      } else {
        router.push(`${paths.ROOT_ADMIN_PREVIEW_SECTION}${id}/instructions`);
      }
    } catch (error) {
      console.error("Failed to start the exam:", error);
    }
  };

  if (isExamDataLoading || isExamDataFetching) {
    return (
      <Center h="50vh">
        <Loader type="oval" />
      </Center>
    );
  }

  const linkifyInstructionsText = () => {
    let message = t("messages.instructions.description");

    message = message.replace(/Smart with a Heart|Sherpa Prep/g, (matched) => {
      const href =
        matched === "Smart with a Heart"
          ? paths.SWAH_TERM_OF_SERVICE
          : paths.SHERPA_PREP_TERM_OF_SERVICE;

      return `<a
          href="${href}"
          target="_blank"
          rel="noopener noreferrer"
          style="color: #1971c2"
        >${matched}</a>`;
    });

    return message;
  };
  if (error) {
    return <ExamErrorHandle errorMsg={`${tExamDerail("error.lable")}`} />;
  }
  return (
    <Container size="xl" my="md">
      {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
        <Card mb="xl" p="sm">
          <Group justify="space-between" align="center" style={{ width: "100%" }}>
            <Breadcrumbs separatorMargin="xs" className="breadcrumbs-size">
              {items}
            </Breadcrumbs>
          </Group>
        </Card>
      )}
      <Box mx="auto" maw={1024} className={styles.instructions}>
        <Box bg={"#393736"} p="2px 8px">
          <Flex justify="space-between" align="center">
            <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
            <Flex maw={320} mx="end" align="center">
              <Tooltip
                label="Accept agreement to Continue to Exam"
                disabled={isChecked || role === USER_ROLE.SUPERADMIN}
              >
                <Button
                  className="btn-blue"
                  variant="filled"
                  color="blue"
                  onClick={() =>
                    handleExamStart(
                      role === USER_ROLE.STUDENT
                        ? examId
                        : examDetail?.data.sections[0].section_id || 0,
                    )
                  }
                  disabled={(role === USER_ROLE.STUDENT && !isChecked) || isExamStart}
                  rightSection={<Image src={arrowRightLong} width={20} height={20} alt="next" />}
                >
                  {role === USER_ROLE.STUDENT
                    ? t("buttons.continue")
                    : t("buttons.preview", { value: "exam" })}
                </Button>
              </Tooltip>
            </Flex>
          </Flex>
        </Box>
        <Card padding={30} radius="none" withBorder>
          <Box mih={682} pl={"9.070865%"} pr={"9.070865%"}>
            <Stack gap="sm">
              <Flex justify={"space-between"} align={"start"} gap={8}>
                <Text fw={800} size="xl">
                  {examData?.exam_name}
                </Text>
                <Box
                  style={{ display: "flex", flexDirection: "row", alignItems: "center", gap: 8 }}
                >
                  <IconClock size={24} />
                  <Text size="sm" c="dimmed" style={{ textWrap: "nowrap" }}>
                    Duration: {convertSecondsToHoursAndMinutes(examData?.exam_duration ?? 0)}
                  </Text>
                </Box>
              </Flex>
              <Divider my="xs" />

              <Title order={3}>Instructions</Title>

              <div
                style={{ fontSize: 18, lineHeight: 1.6 }}
                dangerouslySetInnerHTML={{ __html: examData?.guidelines || "" }}
              />

              <div style={{ fontStyle: "italic" }}>{`"${tExam("sectionNote.note")}"`}</div>
              {role === USER_ROLE.STUDENT && (
                <Checkbox
                  label={
                    <span
                      dangerouslySetInnerHTML={{
                        __html: linkifyInstructionsText(),
                      }}
                    />
                  }
                  checked={isChecked}
                  onChange={(event) => setIsChecked(event.currentTarget.checked)}
                  mt="lg"
                />
              )}
            </Stack>
          </Box>
        </Card>
      </Box>
      {role === USER_ROLE.STUDENT && (
        <WarningAlertModal
          isShow={isDuplicateTab}
          onClose={() => {}}
          description={t("messages.modal.duplicateTabWarning.description")}
          showButtons={false}
        />
      )}
    </Container>
  );
}
