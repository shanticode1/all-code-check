"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { ActionIcon, Anchor, Button, Flex, Text,TextInput, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconEye, IconEyeOff } from "@tabler/icons-react";
import { useRouter,useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React from "react";
import { useForm } from "react-hook-form";

import { LOCAL_VARIABLE } from "@/constants";
import { resetPasswordValidationSchema } from "@/constants/validationSchemas/reset-password";
import { useResetPasswordMutation } from "@/hooks/resetPassword";
import { paths } from "@/routes";
import { BUTTON_TYPES } from "@/types/button.types";
import { IResetPasswordFormValues } from "@/types/Login";

export default function ResetPasswordForm() {
  const [showNewPassword, setShowNewPassword] = React.useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);
  const t_reset = useTranslations("resetPassword");
  const t_generic = useTranslations("generic");
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<IResetPasswordFormValues>({
    defaultValues: { newPassword: "", confirmPassword: "" },
    resolver: yupResolver(resetPasswordValidationSchema),
  });
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const isReset = searchParams.get("is_reset");
  const router = useRouter()
  const { mutateAsync: resetPassword, isPending: isSending } = useResetPasswordMutation();
  const handleResetPassword = async (data: IResetPasswordFormValues) => {
    try {
      // Trim both fields
      const newPassword = data.newPassword.trim();
      const confirmPassword = data.confirmPassword.trim();

      // If either field is empty after trim, show error
      if (!newPassword) {
        // @ts-ignore
        errors.newPassword = { message: t_reset("messages.noSpacesAllowed") };
        return;
      }
      if (!confirmPassword) {
        // @ts-ignore
        errors.confirmPassword = { message: t_reset("messages.noSpacesAllowed") };
        return;
      }

      if (!token) {
        throw new Error(t_reset("messages.tokenNotFound"));
      }
      const response = await resetPassword({ password: newPassword, token });
      showNotification({
        title: t_generic("buttons.success"),
        message: response?.message,
        color: "green",
      });
      
      router.push(paths.ROOT_LOGIN);
    } catch (error) {
      showNotification({
        color: "red",
        title: t_generic("buttons.warning"),
        message: `${(error as Error).message}`,
      });
    }
  };
  return (
    <>
      <Title ta="center">{isReset === "true" ? t_reset("form.title") : t_reset("form.setPassword.title")}</Title>
      <form>
        <TextInput
          withAsterisk
          label={t_reset("form.newPassword.label")}
          placeholder={t_reset("form.newPassword.placeholder")}
          {...register("newPassword")}
          mt="md"
          error={errors.newPassword?.message}
          type={showNewPassword ? "text" : "password"}
           onCopy={(e) => {
                  e.preventDefault();
                }}
                onCut={(e) => {
                  e.preventDefault();
                }}
          rightSection={
            <ActionIcon
              variant="subtle"
              onClick={() => setShowNewPassword(!showNewPassword)}
              tabIndex={-1}
              aria-label={t_reset("togglePassword", {
                value: showConfirmPassword ? LOCAL_VARIABLE.Hide : LOCAL_VARIABLE.Show
              })}
            >
              {showNewPassword ? (
                <IconEyeOff size={18} color="#868e96" />
              ) : (
                <IconEye size={18} color="#868e96" />
              )}
            </ActionIcon>
          }
        />
        <TextInput
          withAsterisk
          label={t_reset("form.confirmNewPassword.label")}
          placeholder={t_reset("form.confirmNewPassword.placeholder")}
          {...register("confirmPassword")}
          mt="md"
          error={errors.confirmPassword?.message}
          type={showConfirmPassword ? "text" : "password"}
           onCopy={(e) => {
                  e.preventDefault();
                }}
                onCut={(e) => {
                  e.preventDefault();
                }}
          rightSection={
            <ActionIcon
              variant="subtle"
              onClick={() => setShowConfirmPassword((v) => !v)}
              tabIndex={-1}
              aria-label={t_reset("togglePassword", {
                value: showConfirmPassword ? LOCAL_VARIABLE.Hide : LOCAL_VARIABLE.Show
              })}
            >
              {showConfirmPassword ? (
                <IconEyeOff size={18} color="#868e96" />
              ) : (
                <IconEye size={18} color="#868e96" />
              )}
            </ActionIcon>
          }
        />
        <Flex mt="xl" gap="md">
          <Button
            type={BUTTON_TYPES.SUBMIT}
            onClick={handleSubmit(handleResetPassword)}
            disabled={isSending}
            fullWidth
          >
            {isReset === "true"? t_reset("form.buttons.reset") : t_reset("form.setPassword.buttons.text")}
          </Button>
        
        </Flex>
      </form>
      {isReset === "true" && <Text ta={"center"}>
        Remember your password ? <Anchor href="/login">Sign In</Anchor>
      </Text>}
    </>
  );
}
