"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { ActionIcon, Box, Button, Center, Group, Select, Text, TextInput, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconClock, IconRefresh } from "@tabler/icons-react";
import { useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";

import Loader from "@/components/Common/Loaders/Loader";
import { USER_ROLE } from "@/constants";
import { PARTNER_TYPE_OPTIONS } from "@/constants/auth";
import { otpSchema, sendOtpSchema } from "@/constants/validationSchemas/adminAuth";
import { useSendOtpMutation, useVerifyOtpMutation } from "@/hooks/auth/index";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { BUTTON_TYPES } from "@/types/button.types";
import { IOtpLoginFormValues, Step } from "@/types/Login";
import { decryptPayload } from "@/utils/tools/encryption";

import styles from "./student.module.css";

export default function StudentLogin() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const t = useTranslations("login");
  const t_generic = useTranslations("generic");
  const { isAuthorized, isLoading, role } = useAuth();
  const { mutateAsync: sendOtp, isPending: isSendingOtp } = useSendOtpMutation();
  const { mutateAsync: verifyOtp, isPending: isVerifyingOtp } = useVerifyOtpMutation();

  const [step, setStep] = useState<Step>(Step.SendOtp);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [otpTimer, setOtpTimer] = useState<number>(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [resendState, setResendState] = useState({ cooldown: 60, disabled: true });
  const resendTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const hasEnc = searchParams.has("encPayload");
  const hasEmailParam = searchParams.has("email");
  const hasPartnerParam = searchParams.has("partnerType");

  const disableEmail = hasEnc || hasEmailParam;

  const disablePartner = hasEnc || hasPartnerParam;

  const getResolverSchema = () => {
    switch (step) {
      case Step.SendOtp:
        return sendOtpSchema;
      case Step.VerifyOtp:
        return otpSchema;
    }
  };

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
    clearErrors,
  } = useForm<IOtpLoginFormValues>({
    resolver: yupResolver(getResolverSchema()),
    defaultValues: { email: "", partnerType: "", otp: "" },
  });

  const startOtpCountdown = () => {
    setOtpTimer(5 * 60);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setOtpTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const startResendCooldown = () => {
    setResendState({ cooldown: 60, disabled: true });
    if (resendTimerRef.current) clearInterval(resendTimerRef.current);
    resendTimerRef.current = setInterval(() => {
      setResendState((prev) => {
        const next = prev.cooldown - 1;
        if (next <= 0) {
          clearInterval(resendTimerRef.current!);
          return { cooldown: 0, disabled: false };
        }
        return { ...prev, cooldown: next };
      });
    }, 1000);
  };

  const initializeOtpFlowFromUrl = useCallback(async () => {
    setIsInitializing(true);

    const encryptedToken = searchParams.get("encPayload");
    const plainEmail = searchParams.get("email");
    const plainPartner = searchParams.get("partnerType");

    if (encryptedToken) {
      try {
        const { email, partnerType } = await decryptPayload(decodeURIComponent(encryptedToken));
        setValue("email", email);
        setValue("partnerType", partnerType);
        setStep(Step.SendOtp);
        startOtpCountdown();
        startResendCooldown();
      } catch {
        showNotification({
          title: t_generic("buttons.error"),
          message: t_generic("messages.error.invalidLink.label"),
          color: "red",
        });
      }
    } else {
      setValue("email", plainEmail ?? "");
      setValue("partnerType", plainPartner ?? "");
      setStep(Step.SendOtp);
      startOtpCountdown();
      startResendCooldown();
    }

    setIsInitializing(false);
  }, [searchParams, setValue]);

  useEffect(() => {
    initializeOtpFlowFromUrl();
  }, [initializeOtpFlowFromUrl]);

  useEffect(() => {
    return () => {
      if (resendTimerRef.current) clearInterval(resendTimerRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  useEffect(() => {
    if (isAuthorized && !isLoading) {
      const dest = role === USER_ROLE.STUDENT ? paths.ROOT_EXAMS : paths.ROOT_DASHBOARD;
      router.push(dest);
    }
  }, [isAuthorized, isLoading, router, role]);

  const [otpValue, email, partnerType] = watch(["otp", "email", "partnerType"]);
  const handleSendOtp = async ({ email, partnerType }: IOtpLoginFormValues) => {
    try {
      const { message } = await sendOtp({ email, partnerType });
      showNotification({
        title: t_generic("buttons.sent", {
          value: t("form.otp.label"),
        }),
        message,
        color: "green",
      });
      setStep(Step.VerifyOtp);
      startOtpCountdown();
      startResendCooldown();
    } catch (err) {
      showNotification({
        title: t_generic("buttons.error"),
        message: (err as Error).message,
        color: "red",
      });
    }
  };

  const handleVerifyOtp = async ({ email, partnerType, otp }: IOtpLoginFormValues) => {
    try {
      const { message } = await verifyOtp({ email, partnerType, otp });
      showNotification({ title: t_generic("buttons.verified"), message, color: "green" });
      router.push(paths.ROOT_EXAMS);
    } catch (err) {
      showNotification({
        title: t_generic("buttons.error"),
        message: (err as Error).message,
        color: "red",
      });
    }
  };

  const formattedOtpTimer = useMemo(() => {
    const m = Math.floor(otpTimer / 60);
    const s = otpTimer % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }, [otpTimer]);

  let timerColor: string;

  if (otpTimer > 60) {
    timerColor = "teal";
  } else if (otpTimer > 0) {
    timerColor = "orange";
  } else {
    timerColor = "red";
}

  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>, idx: number) => {
    const val = e.target.value.replace(/\D/, "");
    const chars = otpValue.split("");
    chars[idx] = val;
    setValue("otp", chars.join(""));
    if (val && idx < 5) {
      document.getElementById(`otp-${idx + 1}`)?.focus();
    }
  };

  const handleOtpKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, idx: number) => {
    if (e.key === "Backspace") {
      e.preventDefault();
      const chars = otpValue.split("");
      if (chars[idx]) {
        chars[idx] = "";
        setValue("otp", chars.join(""));
      } else if (idx > 0) {
        const prev = idx - 1;
        chars[prev] = "";
        setValue("otp", chars.join(""));
        document.getElementById(`otp-${prev}`)?.focus();
      }
    }
  };

  if (isInitializing) {
    return (
      <Center style={{ height: "40vh" }}>
        <Loader />
      </Center>
    );
  }

  return (
    <>
      <Title ta="center">{t("title")}</Title>
      <Text ta="center">{t("heading")}</Text>
      <form onSubmit={handleSubmit(step === Step.SendOtp ? handleSendOtp : handleVerifyOtp)}>
        <TextInput
          withAsterisk
          label={t("form.email.label")}
          placeholder={t("form.email.placeholder")}
          {...register("email")}
          error={errors.email?.message}
          mt="md"
          readOnly={disableEmail || step !== Step.SendOtp}
          disabled={disableEmail || step !== Step.SendOtp}
        />

        <Select
          withAsterisk
          label={t("form.partnerType.select.label")}
          placeholder={t("form.partnerType.select.placeholder")}
          data={PARTNER_TYPE_OPTIONS}
          value={partnerType}
          onChange={(val) => {
            setValue("partnerType", val || "");
            clearErrors("partnerType");
          }}
          error={errors.partnerType?.message}
          mt="md"
          disabled={disablePartner || step !== Step.SendOtp}
          readOnly={disablePartner || step !== Step.SendOtp}
        />

        {step === Step.VerifyOtp && (
          <>
            <Text size="sm" fw={500} mt="md" mb="xs">
              {t("form.otp.label")}
            </Text>
            <Group>
              {Array.from({ length: 6 }).map((_, i) => (
                <Box
                   
                  key={`otp-${i}`}
                  className={styles.otpBlock}>
                  <TextInput
                    id={`otp-${i}`}
                    value={otpValue[i] || ""}
                    onChange={(e) => handleOtpChange(e, i)}
                    onKeyDown={(e) => handleOtpKeyDown(e, i)}
                    className={styles.otpInput}
                    maxLength={1}
                    inputMode="numeric"
                  />
                </Box>
              ))}
              {errors.otp && (
                <Text size="xs" c="red" className={styles.otpError}>
                  {errors.otp.message}
                </Text>
              )}
            </Group>
            <Box
              mt="sm"
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                textAlign: "center",
              }}
            >
              <ActionIcon title="Time remaining" className={styles.timerIcon}>
                <IconClock size={24} stroke={2} />
              </ActionIcon>
              {otpTimer !== 0 && (
                <Text size="sm" className={styles.timerText} c={timerColor}>
                  {t("form.messages.otp.timer", {
                    timer: formattedOtpTimer,
                  })}
                </Text>
              )}

              {otpTimer === 0 && (
                <Text c="red" mt="xs">
                  {t("form.messages.otp.expired")}
                </Text>
              )}
            </Box>
            <Box
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                textAlign: "center",
              }}
            >
              <Group mt="sm">
                {resendState.cooldown > 0 ? (
                  <Text size="sm" c="gray">
                    {t("form.messages.otp.resendAvailable", {
                      timer: resendState.cooldown,
                    })}
                  </Text>
                ) : (
                  <>
                    <ActionIcon
                      variant="light"
                      disabled={resendState.disabled}
                      className={styles.resendIcon}
                      title="Resend OTP"
                      onClick={(e) => {
                        e.preventDefault();
                        handleSendOtp({
                          email,
                          partnerType,
                          otp: "",
                        });
                      }}
                    >
                      <IconRefresh size={24} />
                    </ActionIcon>
                    <Text size="sm" ml={5}>
                      {t("form.button.resend")}
                    </Text>
                  </>
                )}
              </Group>
            </Box>
          </>
        )}

        <Button
          type={BUTTON_TYPES.SUBMIT}
          fullWidth
          mt="xl"
          disabled={isSendingOtp || isVerifyingOtp}
        >
          {step === Step.SendOtp
            ? isSendingOtp
              ? t("form.loading.sendOtp")
              : t("form.button.sendOtp")
            : isVerifyingOtp
              ? t("form.loading.verify")
              : t("form.button.verify")}
        </Button>
      </form>
    </>
  );
}
