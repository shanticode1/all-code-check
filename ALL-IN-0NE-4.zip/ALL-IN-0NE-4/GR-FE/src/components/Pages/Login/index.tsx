"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { Anchor, Box, Button, PasswordInput, Text, TextInput, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { IconEye, IconEyeOff } from "@tabler/icons-react";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect } from "react";
import { useForm } from "react-hook-form";

import { USER_ROLE } from "@/constants";
import { roles } from "@/constants/common";
import { loginValidationSchema } from "@/constants/validationSchemas/adminAuth";
import { useLoginMutation } from "@/hooks/auth/index";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { BUTTON_TYPES } from "@/types/button.types";
import { ILoginFormValues } from "@/types/Login";

export default function AdminLogin() {
  const router = useRouter();
  const t = useTranslations("login");
  const t_generic = useTranslations("generic");
  const { isAuthorized, isLoading, role } = useAuth();
  const { mutateAsync: login, isPending: isLoggingIn } = useLoginMutation();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ILoginFormValues>({
    resolver: yupResolver(loginValidationSchema),
    defaultValues: { email: "", password: "" },
  });

  useEffect(() => {
    if (isAuthorized && !isLoading) {
      const dest = role === USER_ROLE.STUDENT ? paths.ROOT_EXAMS : paths.ROOT_DASHBOARD;
      router.push(dest);
    }
  }, [isAuthorized, isLoading, router, role]);

  const handlePasswordLogin = async (data: ILoginFormValues) => {
    try {
      const { email, password } = data;
      const { message, data: loginData } = await login({ email, password });
      showNotification({ title: t_generic("buttons.success"), message, color: "green" });
      if (
        loginData?.role === roles.SUPERADMIN ||
        loginData?.role === roles.ADMIN ||
        loginData?.role === roles.INSTRUCTOR
      ) {
        router.push(paths.ROOT_DASHBOARD);
      }
    } catch (error) {
      showNotification({ title: "Error", message: (error as Error).message, color: "red" });
    }
  };

  const getVisibilityToggleIcon = ({ reveal }: { reveal: boolean }) =>
    reveal ? <IconEye size={16} /> : <IconEyeOff size={16} />;

  return (
    <>
      <Title ta="center">{t("title")}</Title>
      <Text ta="center">{t("heading")}</Text>
      <form onSubmit={handleSubmit(handlePasswordLogin)}>
        <TextInput
          withAsterisk
          label={t("form.email.label")}
          placeholder={t("form.email.placeholder")}
          {...register("email")}
          error={errors.email?.message}
          mt="md"
        />
        <PasswordInput
          withAsterisk
          label={t("form.password.label")}
          placeholder={t("form.password.placeholder")}
          mt="md"
          {...register("password")}
          error={errors.password?.message}
          visibilityToggleIcon={getVisibilityToggleIcon}
          onCopy={(e) => {
            e.preventDefault();
          }}
          onCut={(e) => {
            e.preventDefault();
          }}
        />
        <Box mt="xs" mb="md" style={{ textAlign: "right" }}>
          <Anchor
            size="sm"
            href={paths.ROOT_FORGOT_PASSWORD}
            underline="always"
          >
            {t("form.forgotPassword.link.text")}
          </Anchor>
          <br />
          <Anchor
            size="sm"
            href={paths.ROOT_STUDENT_LOGIN}
            underline="always"
          >
            {t("form.forgotPassword.message.isStudentText")}
          </Anchor>
        </Box>
        <Button type={BUTTON_TYPES.SUBMIT} fullWidth mt="xl" disabled={isLoggingIn}>
          {isLoggingIn ? t("form.loading.login") : t("form.button.login")}
        </Button>
      </form>
    </>
  );
}
