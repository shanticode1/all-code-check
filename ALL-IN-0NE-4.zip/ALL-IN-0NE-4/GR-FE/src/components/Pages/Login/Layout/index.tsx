import { Card, Center, Stack,} from "@mantine/core";
import Image from "next/image";
import React from "react";

import logo from "@/public/smart-with-heart.svg";

function LoginLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <Center
      style={{
        height: "100vh",
        backgroundColor: "#f5f5f5",
      }}
    >
      <Card style={{ width: "450px" }} shadow="md" padding="xl" radius="md">
        <Stack>
          <Center>
            <Image
              src={logo}
              alt="DesignSparx logo"
              width={200}
              height={100}
              style={{ objectFit: "contain" }}
            />
          </Center>
          {children}
        </Stack>
      </Card>
    </Center>
  );
}

export default LoginLayout;
