"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button, Container, Grid, Paper, Select, Title } from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect } from "react";
import { useForm } from "react-hook-form";

import { USER_ROLE } from "@/constants";
import { Days } from "@/constants/setting";
import { retentionDaysValidationSchema } from "@/constants/validationSchemas/setting";
import {
  useGetRetentionQuery,
  useRetentionMutation,
  useUpdateRetentionMutation,
} from "@/hooks/setting";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { BUTTON_TYPES } from "@/types/button.types";
import { IRetentionDays } from "@/types/setting";

export default function RetentionDaysSetting() {
  const { role } = useAuth();
  const router = useRouter();

  const { data: examSchedulerSettingData } = useGetRetentionQuery();
  const { mutateAsync: add, isPending: isAdding } = useRetentionMutation();
  const { mutateAsync: update, isPending: isUpdating } = useUpdateRetentionMutation();
  const retention_id = examSchedulerSettingData
    ? examSchedulerSettingData?.data?.retention_id
    : null;

  const {
    handleSubmit: handleSettingSubmit,
    setValue,
    watch,
    clearErrors,
    formState: { errors },
  } = useForm<IRetentionDays>({
    defaultValues: {
      free_user_retention_days: examSchedulerSettingData?.data?.free_user_retention_days || null,
      paid_user_retention_days: examSchedulerSettingData?.data?.paid_user_retention_days || null,
    },
    resolver: yupResolver(retentionDaysValidationSchema),
  });
  const [selectedFreeDays, selectedPaidDays] = watch([
    "free_user_retention_days",
    "paid_user_retention_days",
  ]);
  const t = useTranslations("examScheduler");

  // Set form values from API response
  useEffect(() => {
    if (examSchedulerSettingData) {
      setValue(
        "free_user_retention_days",
        examSchedulerSettingData?.data?.free_user_retention_days,
      );
      setValue(
        "paid_user_retention_days",
        examSchedulerSettingData?.data?.paid_user_retention_days,
      );
    }
  }, [examSchedulerSettingData]);

  useEffect(() => {
    if (role !== USER_ROLE.SUPERADMIN) {
      router.push(paths.ROOT_DASHBOARD);
    }
  }, [role, router]);
  
  if (role !== USER_ROLE.SUPERADMIN) return null;

  const onUpdateRetentionDays = async (data: IRetentionDays) => {
    try {
      let messageText: string = "";

      const payload = {
        ...data,
        free_user_retention_days: Number(data.free_user_retention_days),
        paid_user_retention_days: Number(data.paid_user_retention_days),
      };
      if (!retention_id) {
        // Update existing data
        const addRes = await add(payload);
        const { message } = addRes;
        messageText = message;
        showNotification({
          title: "Success",
          message: messageText,
          color: "green",
        });
      } else {
        // Add API call or logic to save the days
        const updateRes = await update({
          retention_id: retention_id,
          input: payload,
        });
        const { message } = updateRes;
        messageText = message;
        showNotification({
          title: "Success",
          message: messageText,
          color: "green",
        });
      }
    } catch (error) {
      showNotification({
        title: "Error",
        message: `${(error as Error).message}`,
        color: "red",
      });
    }
  };

  return (
    <Container size="xl" my="lg">
      <Grid>
        {/* Update Profile Form */}
        <Grid.Col span={6}>
          <Paper p="md" shadow="sm">
            <Title order={4} mb="md">
              {t("settings.title")}
            </Title>
            <form onSubmit={handleSettingSubmit(onUpdateRetentionDays)}>
              <Select
                label={t("free.label")}
                placeholder={t("free.placeholder")}
                m={"20 0"}
                onChange={(v) => {
                  setValue("free_user_retention_days", v ? Number(v) : null);
                  clearErrors(["free_user_retention_days"]);
                }}
                data={Days}
                value={
                  selectedFreeDays !== null && selectedFreeDays !== undefined
                    ? String(selectedFreeDays)
                    : null
                }
                withAsterisk
                error={errors.free_user_retention_days?.message}
                allowDeselect={false}
              />
              <Select
                label={t("paid.label")}
                placeholder={t("paid.placeholder")}
                m={"20 0"}
                onChange={(v) => {
                  setValue("paid_user_retention_days", v ? Number(v) : null);
                  clearErrors(["free_user_retention_days"]);
                }}
                value={
                  selectedPaidDays !== null && selectedPaidDays !== undefined
                    ? String(selectedPaidDays)
                    : null
                }
                data={Days}
                withAsterisk
                error={errors.paid_user_retention_days?.message}
                allowDeselect={false}
              />
              <Button type={BUTTON_TYPES.SUBMIT} fullWidth mt="md" loading={isUpdating || isAdding}>
                {retention_id ? t("button.update.text") : t("button.save.text")}
              </Button>
            </form>
          </Paper>
        </Grid.Col>
      </Grid>
    </Container>
  );
}
