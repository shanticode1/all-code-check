"use client";

import {
  Anchor,
  Box,
  Breadcrumbs,
  Card,
  Center,
  Container,
  Grid,
  Group,
  Loader,
  Text,
  Title,
} from "@mantine/core";
import { useParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useCallback, useEffect, useMemo, useState } from "react";

import QuestionForm from "@/components/Pages/AddExams/Questions/QuestionForm";
import QuestionList from "@/components/Pages/AddExams/Questions/QuestionList";
import ExamSidebar from "@/components/Pages/ExamSideBar";
import { useGetExamByIdQuery, useGetQuestionByIdQuery } from "@/hooks/exam";
import { paths } from "@/routes";
import { IAddQuestionsFormValues, ISelectedContext } from "@/types/Exam/index";
import { truncateName } from "@/utils";

type ViewMode = "none" | "form" | "list";

export default function AddQuestions() {
  const { examId } = useParams() as unknown as { examId: number };
  const t = useTranslations("question");
  const { data: examData, isLoading: isExamDataLoading } = useGetExamByIdQuery(examId);

  const [selectedContext, setSelectedContext] = useState<ISelectedContext | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>("none");

  // Auto-select the first section and first question (if available) when examData is loaded.
  useEffect(() => {
    if (examData && !selectedContext) {
      const sections = examData?.data?.sections;
      if (sections && sections.length > 0) {
        const firstSection = sections[0];
        // If the first section has questions, auto-select the first question's id.
        const firstQuestionId =
          firstSection.questions && firstSection.questions.length > 0
            ? firstSection.questions[0].question_id
            : undefined;
        setSelectedContext({
          sectionId: firstSection.section_id,
          sectionName: firstSection.section_name,
          questionId: firstQuestionId,
          sectionSlug: firstSection.section_slug,
          questionNo: firstSection.question_no,
        });
        setViewMode("form");
      }
    }
  }, [examData, selectedContext]);

  const handleQuestionClick = useCallback(
    (
      questionId: number,
      sectionId: number,
      sectionName: string,
      sectionSlug: string,
      questionNo: number,
    ) => {
      setSelectedContext({ sectionId, sectionName, questionId, sectionSlug, questionNo });
      setViewMode("form");
    },
    [],
  );

  const handleViewQuestions = useCallback(
    (sectionId: number, sectionName: string, sectionSlug: string, questionId: number) => {
      setSelectedContext({ sectionId, sectionName, sectionSlug, questionId }); // need to call this to get the question list
      setViewMode("list");
    },
    [],
  );

  const { data: questionData, isLoading: isQuestionLoading } = useGetQuestionByIdQuery({
    exam_id: examId,
    section_id: selectedContext?.sectionId,
    question_id: selectedContext?.questionId,
  });

  const tableColumns = useMemo(
    () => [
      { accessor: "id", title: t("table.columns.sNo"), width: 80, textAlign: "center" },
      { accessor: "question_text", title: t("table.columns.question") },
      // { accessor: "difficulty_level", title: "Difficulty Level" },
    ],
    [],
  );

  const onSubmit = useCallback(
    (data: IAddQuestionsFormValues, editorValue: string) => {
      if (questionData) {
        console.log("Updating Question with data:", data, "and Editor Value:", editorValue);
        // Place update API call here.
      } else {
        console.log("Creating New Question with data:", data, "and Editor Value:", editorValue);
        // Place create API call here.
      }
    },
    [questionData],
  );

  const items = [
    { title: "Exam Management", href: paths.ROOT_ADMIN_EXAM },
    { title: truncateName(examData?.data.exam_name ?? "", 60), active: true },
  ].map((item, index) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
        {item.title}
      </Anchor>
    ),
  );

  return (
    <div>
      {!isExamDataLoading ? (
        <Container size="xxl" my="lg">
          <Card mb="xl" p="sm">
            <Group justify="space-between" align="center" style={{ width: "100%" }}>
              <Breadcrumbs separatorMargin="xs" className="breadcrumbs-size">
                {items}
              </Breadcrumbs>
            </Group>
          </Card>
          <Grid>
            <Grid.Col span={{ xxs: 3, xs: 4, md: 4, xl: 3 }}>
              <ExamSidebar
                examId={examId}
                examData={examData}
                onClick={handleQuestionClick}
                onViewQuestions={handleViewQuestions}
              />
            </Grid.Col>
            <Grid.Col span={{ xxs: 9, xs: 8, md: 8, xl: 9 }} className="tiny-editor">
              <Box style={{ flex: 1, position: "sticky", top: "80px", marginBlockStart:"50px" }}>
                {viewMode === "form" && selectedContext?.questionId && (
                  <>
                    <Title order={2} mb="lg" display="flex" style={{ gap: "10px" }}>
                      <Text fw="bold">{selectedContext.sectionName} :</Text>
                      <Text fw="bold">
                        {" "}
                        Question {selectedContext.questionNo ? selectedContext.questionNo : 1}
                      </Text>
                    </Title>
                    <QuestionForm
                      questionData={
                        questionData?.data
                          ? { ...questionData.data, answer_groups: questionData.data.answer_groups || null }
                          : null
                      }
                      isLoading={!!selectedContext?.questionId && isQuestionLoading}
                      onSubmit={onSubmit}
                      sectionSlug={selectedContext.sectionSlug}
                    />
                  </>
                )}
                {viewMode === "list" && selectedContext && (
                  <QuestionList
                    examData={examData}
                    sectionId={selectedContext.sectionId}
                    tableColumns={tableColumns}
                    sectionSlug={selectedContext.sectionSlug}
                    onClick={handleQuestionClick}
                  />
                )}
              </Box>
            </Grid.Col>
          </Grid>
        </Container>
      ) : (
        <Center style={{ height: "80vh" }}>
          <Loader type="oval" size="lg" />
        </Center>
      )}
    </div>
  );
}
