import {
  Box,
  Button,
  Center,
  Checkbox,
  Flex,
  Group,
  Loader,
  Radio,
  Text,
  TextInput,
} from "@mantine/core";
import { IconCheck, IconX } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React from "react";

import GuidelineDisplay from "@/components/Common/GuidelineDisplay";
import { QUESTION_LAYOUT, SINGLE_QUESTION_TYPES, USER_ROLE } from "@/constants";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { IAnswerInput } from "@/types/Exam/index";
import { IViewQuestionProps } from "@/types/Student/ViewQuestion";

import classes from "../PreviewSection/styles.module.css";

export default function ViewQuestion({
  currentQ,
  isLoading,
  analyticalWriting,
  selectAnswer,
  isQuantitiveSection,
}: Readonly<IViewQuestionProps>) {
  const AnswerChoice: IAnswerInput[] = currentQ?.AnswerChoice || [];
  const studentAnswerChoices: { answer_choice_id: number | null }[] =
    currentQ?.studentAnswerChoices || [];
  const tGeneric = useTranslations("generic");
  const { role } = useAuth();
  const renderMultipleSelection = () => {
    const studentPickedIds = studentAnswerChoices.map((s) => s?.answer_choice_id?.toString());

    return (
      <Box className={"answer-box single-selection"}>
        {currentQ?.passage_answer_instructions && (
          <Box className="answer-box">
            <Box
              dangerouslySetInnerHTML={{
                __html: currentQ?.passage_answer_instructions,
              }}
            />
          </Box>
        )}
        <Checkbox.Group
          size="sm"
          className={classes["radio-group"]}
          // @ts-expect-error ts(2349)
          value={studentPickedIds}
        >
          {AnswerChoice.map((opt) => {
            const idStr = opt.answer_choice_id!.toString();
            const isCorrect = !!opt.is_correct;
            const isStudentPick = studentPickedIds.includes(idStr);
            const showX = isStudentPick && !isCorrect;

            return (
              <Checkbox.Card
                key={idStr}
                value={idStr}
                checked={isStudentPick}
                className={classes.root}
                style={{ position: "relative", cursor: "default" }}
              >
                <Group wrap="nowrap" align="flex-start" style={{ display: "flex" }}>
                  <Flex gap={10} mt={7}>
                    <Box w={20} h={20} style={{ display: "flex", alignItems: "center" }}>
                      {isCorrect && <IconCheck size={18} color="green" />}
                      {showX && <IconX size={18} color="red" />}
                    </Box>
                    <Checkbox.Indicator />
                  </Flex>
                  <Box>
                    <Text className={classes.label}>
                      <span
                        dangerouslySetInnerHTML={{
                          __html: opt.option_text ?? "",
                        }}
                      />
                    </Text>
                  </Box>
                </Group>
              </Checkbox.Card>
            );
          })}
        </Checkbox.Group>
      </Box>
    );
  };
  /** SINGLE SELECTION **/
  const renderSingleSelection = () => {
    const studentPickedId = studentAnswerChoices[0]?.answer_choice_id?.toString() ?? "";

    return (
      <Box className={"answer-box single-selection"}>
        {currentQ?.passage_answer_instructions && (
          <Box className="answer-box passges-type" style={{ border: "none" }}>
            <Box
              dangerouslySetInnerHTML={{
                __html: currentQ?.passage_answer_instructions,
              }}
            />
          </Box>
        )}
        <Radio.Group size="sm" className={classes["radio-group"]} value={studentPickedId}>
          {AnswerChoice.map((opt) => {
            const idStr = opt.answer_choice_id!.toString();
            const isCorrect = !!opt.is_correct;
            const isStudentPick = studentPickedId === idStr;
            const showX = isStudentPick && !isCorrect;

            return (
              <Radio.Card
                key={idStr}
                value={idStr}
                checked={isStudentPick}
                className={classes.root}
                radius="md"
                style={{ position: "relative", paddingLeft: "40px", cursor: "default" }}
              >
                <Group wrap="nowrap" align="flex-start" className="times-font radio-group">
                  {(isCorrect || showX) && (
                    <Text
                      component="span"
                      style={{ position: "absolute", left: "10px", zIndex: 1, top: "10px" }}
                    >
                      {isCorrect && <IconCheck size={18} color="green" />}
                      {showX && <IconX size={18} color="red" />}
                    </Text>
                  )}
                  <Radio.Indicator />
                  <div>
                    <Text className={classes.label}>
                      <span dangerouslySetInnerHTML={{ __html: opt.option_text ?? "" }} />
                    </Text>
                  </div>
                </Group>
              </Radio.Card>
            );
          })}
        </Radio.Group>
      </Box>
    );
  };

  function highlightStudentText(passage: string, studentText: string): string {
    if (!studentText || studentText.trim() === "") return passage;

    const cleanedStudentText = studentText
      .replace(/^["']+|["']+$/g, "") // strip quotes
      .replace(/\s+/g, " ") // normalize whitespace
      .trim();

    // Create a DOM from the passage
    const parser = new DOMParser();
    const doc = parser.parseFromString(passage, "text/html");
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);

    let found = false;

    while (walker.nextNode()) {
      const node = walker.currentNode as Text;
      const text = node.nodeValue ?? "";

      const normalized = text.replace(/\s+/g, " ").trim();

      if (normalized.includes(cleanedStudentText)) {
        const highlightedHTML = text.replace(
          cleanedStudentText,
          `<mark style="background-color: yellow; font-weight: bold;">${cleanedStudentText}</mark>`,
        );

        const span = document.createElement("span");
        span.innerHTML = highlightedHTML;
        node.parentNode?.replaceChild(span, node);
        found = true;
        break;
      }
    }

    return found ? doc.body.innerHTML : passage;
  }

  const renderFillInTheBlank = () => {
    const type = currentQ?.question_type;
    const groupsMap: Record<number, IAnswerInput[]> = (AnswerChoice || []).reduce(
      (acc, opt) => {
        const grp = opt.answer_group ?? 0;
        if (!acc[grp]) acc[grp] = [];
        acc[grp].push(opt);
        return acc;
      },
      {} as Record<number, IAnswerInput[]>,
    );

    let blankCount = 1;
    if (type === "twoFillInTheBlank") blankCount = 2;
    else if (type === "threeFillInTheBlank") blankCount = 3;

    const columns: IAnswerInput[][] = [];
    for (let grp = 1; grp <= blankCount; grp++) {
      columns.push(groupsMap[grp] || []);
    }

    const studentMap: Record<number, string> = {};
    studentAnswerChoices.forEach((s) => {
      const picked = AnswerChoice.find((o) => o.answer_choice_id === s.answer_choice_id);
      if (picked) {
        studentMap[picked.answer_group ?? 0] = picked.answer_choice_id!.toString();
      }
    });

    return (
      <Group mt="md" align="start" justify="center" grow className="times-font">
        {columns.map((col, blankIndex) => {
          const groupNum = blankIndex + 1;
          const studentSelected = studentMap[groupNum] || "";

          return (
            <Box key={groupNum} className={classes["clickable-boxes"]}>
              <Text fw={600} mb="xs" style={{ textAlign: "center" }}>
                Blank ({["i", "ii", "iii"][blankIndex]})
              </Text>

              <Radio.Group
                name={`blank-${blankIndex}`}
                value={studentSelected}
                className={classes["radio-group"]}
              >
                {col.map((opt) => {
                  const idStr = opt.answer_choice_id!.toString();
                  const isCorrect = !!opt.is_correct;
                  const isStudentPick = studentSelected === idStr;
                  const showX = isStudentPick && !isCorrect;

                  return (
                    <Radio.Card
                      key={idStr}
                      value={idStr}
                      checked={isStudentPick}
                      disabled
                      className={classes.root}
                      radius="md"
                    >
                      <Group wrap="nowrap" align="flex-center" className="view-question-algin">
                        <Box w={20} h={20} style={{ display: "flex", alignItems: "center" }}>
                          {isCorrect && <IconCheck size={18} color="green" />}
                          {showX && <IconX size={18} color="red" />}
                        </Box>
                        <Box>
                          <Text className={classes.label}>
                            <span
                              dangerouslySetInnerHTML={{
                                __html: opt.option_text ?? "",
                              }}
                            />
                          </Text>
                        </Box>
                      </Group>
                    </Radio.Card>
                  );
                })}
              </Radio.Group>
            </Box>
          );
        })}
      </Group>
    );
  };

  const isFillInTheBlank = [
    "oneFillInTheBlank",
    "twoFillInTheBlank",
    "threeFillInTheBlank",
  ].includes(currentQ?.question_type ?? "");

  if (isLoading) {
    return (
      <Center style={{ height: "50vh" }}>
        <Loader type="oval" size="lg" />
      </Center>
    );
  }

  return (
    <Box
      className={`question-container ${
        currentQ?.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM && "question-container-vertical"
      }`}
    >
      {!isQuantitiveSection &&
        !analyticalWriting &&
        currentQ?.guidelines &&
        currentQ.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM && (
          <GuidelineDisplay guidelines={currentQ?.guidelines ?? tGeneric("message.noGuidelines")} />
        )}
      <Box
        className={
          currentQ?.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM
            ? "vertical-layout"
            : "horizontal-layout"
        }
      >
        {analyticalWriting ? (
          <>
            <Box style={{ width: "405.5px" }}>
              <Box className="guideline-box guideline-box-analytic">
                <Text>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: currentQ?.question_text ?? "No prompt available",
                    }}
                  ></span>
                </Text>
              </Box>

              <Box
                p="0 10.22px"
                onCopy={(e) => e.preventDefault()}
                onPaste={(e) => e.preventDefault()}
                onCut={(e) => e.preventDefault()}
                className="times-font"
              >
                <Box className="guideline-box guideline-box-analytic">
                  <Text>
                    <span>{currentQ?.guidelines ?? tGeneric("message.noGuidelines")}</span>
                  </Text>
                </Box>
              </Box>
            </Box>
            <Box
              ml="4px"
              style={{
                border: "1px solid #000",
                width: "608.5px",
                paddingBottom: "8px",
                backgroundColor: role === USER_ROLE.SUPERADMIN ? "#f5f5f5" : "inherit",
              }}
            >
              <Flex justify="flex-start" align="center" className="writing-buttons-container">
                <Button variant="default" className="writing-button" disabled>
                  {tGeneric("actionButtons.cut")}
                </Button>
                <Button variant="default" className="writing-button" disabled>
                  {tGeneric("actionButtons.paste")}
                </Button>
                <Button variant="default" className="writing-button" disabled>
                  {tGeneric("actionButtons.undo")}
                </Button>
                <Button variant="default" className="writing-button" disabled>
                  {tGeneric("actionButtons.redo")}
                </Button>
              </Flex>
              <textarea
                placeholder="Write your response here"
                className="analyticwriting-textarea"
                value={
                  selectAnswer?.[0]?.answer ? selectAnswer[0].answer : "No response submitted."
                }
                readOnly={true}
              />
            </Box>
          </>
        ) : (
          <>
            {isFillInTheBlank ? (
              <>
                <Box pos={"relative"} className="question-box">
                  {!isQuantitiveSection &&
                    !analyticalWriting &&
                    currentQ?.guidelines &&
                    currentQ.question_layout === QUESTION_LAYOUT.LEFTTORIGHT && (
                      <GuidelineDisplay
                        guidelines={currentQ?.guidelines ?? tGeneric("message.noGuidelines")}
                      />
                    )}
                  <Box
                    p="md"
                    mb="md"
                    onCopy={(e) => e.preventDefault()}
                    onPaste={(e) => e.preventDefault()}
                    onCut={(e) => e.preventDefault()}
                    className="times-font"
                  >
                    <Box
                      dangerouslySetInnerHTML={{
                        __html: currentQ?.question_text ?? "No question available",
                      }}
                      style={{ textAlign: "center" }}
                      className="times-font"
                    />
                  </Box>
                </Box>
                <Box className="answer-box">
                  {currentQ?.passage_answer_instructions && (
                    <Box
                      dangerouslySetInnerHTML={{
                        __html: currentQ?.passage_answer_instructions,
                      }}
                    />
                  )}
                  {renderFillInTheBlank()}
                </Box>
              </>
            ) : (
              <>
                <Box pos={"relative"} className="question-box">
                  {!isQuantitiveSection &&
                    !analyticalWriting &&
                    currentQ?.guidelines &&
                    currentQ.question_layout === QUESTION_LAYOUT.LEFTTORIGHT && (
                      <GuidelineDisplay
                        guidelines={currentQ?.guidelines ?? tGeneric("message.noGuidelines")}
                      />
                    )}
                  <Box
                    onCopy={(e) => e.preventDefault()}
                    onPaste={(e) => e.preventDefault()}
                    onCut={(e) => e.preventDefault()}
                    className="question-box-inner"
                  >
                    <Box className="times-font">
                      {currentQ?.question_type === "paragraph-sentence" ? (
                        <Box
                          dangerouslySetInnerHTML={{
                            __html: highlightStudentText(
                              currentQ?.question_text || "",
                              selectAnswer?.[0]?.answer ?? "",
                            ),
                          }}
                        />
                      ) : (
                        <Box
                          dangerouslySetInnerHTML={{
                            __html: currentQ?.question_text ?? "",
                          }}
                        />
                      )}
                    </Box>
                  </Box>
                </Box>
                {["multipleSelection", "paragraph"].includes(currentQ?.question_type ?? "") &&
                  renderMultipleSelection()}
                {SINGLE_QUESTION_TYPES.includes(currentQ?.question_type ?? "") &&
                  renderSingleSelection()}
                {currentQ?.question_type === "paragraph-sentence" &&
                  (() => {
                    const correctText = currentQ?.AnswerChoice?.[0]?.option_text ?? "";
                    return (
                      <Box className="answer-box">
                        {currentQ?.passage_answer_instructions && (
                          <Box
                            dangerouslySetInnerHTML={{
                              __html: currentQ?.passage_answer_instructions,
                            }}
                          />
                        )}
                        <Text fw={600} mt="sm" c="green">
                          {tGeneric("input.correctAnswerPlaceholder")}: {correctText}
                        </Text>
                      </Box>
                    );
                  })()}
                {currentQ?.question_type === "numericalEntry" && (
                  <Box className="answer-box">
                    {currentQ?.passage_answer_instructions && (
                      <Box
                        dangerouslySetInnerHTML={{
                          __html: currentQ?.passage_answer_instructions,
                        }}
                      />
                    )}
                    <Box style={{ display: "flex", alignItems: "center" }}>
                      <Box style={{ marginRight: 10, marginTop: 15 }}>
                        {currentQ?.AnswerChoice[0]?.answer_prefix}
                      </Box>
                      <TextInput
                        placeholder="Enter your answer"
                        mt="sm"
                        value={selectAnswer?.[0]?.answer ?? ""}
                        readOnly
                        className="times-font"
                        onCopy={(e) => e.preventDefault()}
                        onPaste={(e) => e.preventDefault()}
                        onCut={(e) => e.preventDefault()}
                        error
                        styles={{
                          input: {
                            borderColor:
                              selectAnswer?.[0]?.answer == currentQ?.AnswerChoice[0]?.option_text
                                ? "green"
                                : "red",
                            color: "black",
                          },
                        }}
                      />

                      <Box style={{ marginLeft: 10, marginTop: 15 }}>
                        {currentQ?.AnswerChoice[0]?.answer_suffix}
                      </Box>
                    </Box>
                    {/* Show correct answer below student's answer */}
                    <Box mt="md" w={"100%"}>
                      <Text fw={600} c={"green"}>
                        {tGeneric("input.correctAnswerPlaceholder")}:{" "}
                        {currentQ?.AnswerChoice[0]?.option_text ?? "N/A"}
                      </Text>
                    </Box>
                  </Box>
                )}
                {currentQ?.question_type === "fractionalEntry" && (
                  <Box className="answer-box">
                    <Flex align="center" mt="sm" direction="column">
                      {currentQ?.passage_answer_instructions && (
                        <Box className="answer-box" style={{ border: "none" }}>
                          <Box
                            dangerouslySetInnerHTML={{
                              __html: currentQ?.passage_answer_instructions,
                            }}
                          />
                        </Box>
                      )}
                      {(() => {
                        const studentAnswer = selectAnswer?.[0]?.answer ?? "";
                        const correctNum = currentQ?.AnswerChoice?.[0]?.option_text ?? "";
                        const correctDen = currentQ?.AnswerChoice?.[1]?.option_text ?? "";
                        const correctAnswer = `${correctNum}/${correctDen}`;
                        const isFullyCorrect = studentAnswer.trim() === correctAnswer.trim();

                        const studentNum = studentAnswer.split("/")[0] || "";
                        const studentDen = studentAnswer.split("/")[1] || "";

                        return (
                          <>
                            <Flex align="center" gap="xs">
                              <TextInput
                                placeholder="Num"
                                size="xs"
                                style={{ width: 100 }}
                                value={studentNum}
                                onKeyDown={(e) => {
                                  if (e.key.length === 1 && !/^\d$/.test(e.key)) {
                                    e.preventDefault();
                                  }
                                }}
                                onCopy={(e) => e.preventDefault()}
                                onPaste={(e) => e.preventDefault()}
                                onCut={(e) => e.preventDefault()}
                                styles={{
                                  input: {
                                    borderColor: studentAnswer == correctAnswer ? "green" : "red",
                                    color: "black",
                                  },
                                }}
                              />
                            </Flex>
                            <Box
                              my="xs"
                              style={{
                                width: 100,
                                height: 2,
                                backgroundColor: "#ccc",
                              }}
                            />
                            <Flex align="center" gap="xs">
                              <TextInput
                                placeholder="Den"
                                size="xs"
                                style={{ width: 100 }}
                                value={studentDen}
                                readOnly
                                styles={{
                                  input: {
                                    borderColor: studentAnswer == correctAnswer ? "green" : "red",
                                    color: "black",
                                  },
                                }}
                              />
                            </Flex>

                            <Box
                              mt="md"
                              style={{
                                display: "flex",
                                alignItems: "center",
                                gap: 8,
                                flexDirection: "column",
                              }}
                            >
                              {isFullyCorrect ? (
                                <Flex align="center" gap="sm">
                                  <IconCheck size={22} color="green" />
                                  <Text fw={600} c="green">
                                    {tGeneric("input.correctAnswerPlaceholder")}: {correctAnswer}
                                  </Text>
                                </Flex>
                              ) : (
                                <Flex align="center" gap="sm">
                                  <IconCheck size={22} color="green" />
                                  <Text fw={600} c="green">
                                    {tGeneric("input.correctAnswerPlaceholder")}: {correctAnswer}
                                  </Text>
                                </Flex>
                              )}
                            </Box>
                          </>
                        );
                      })()}
                    </Flex>
                  </Box>
                )}
              </>
            )}
          </>
        )}
        {currentQ?.instructions?.trim() &&
          !analyticalWriting &&
          currentQ?.question_layout === QUESTION_LAYOUT.LEFTTORIGHT && (
            <Box className="instructions-box-outer">
              <Box className="instructions-box">
                <Text>{currentQ?.instructions}</Text>
              </Box>
            </Box>
          )}
      </Box>
      {currentQ?.instructions?.trim() &&
        currentQ?.question_layout === QUESTION_LAYOUT.TOPTOBOTTOM && (
          <Box className={`instructions-box-outer ${analyticalWriting && "d-none"}`}>
            <Box className="instructions-box">
              <Text>{currentQ?.instructions}</Text>
            </Box>
          </Box>
        )}
    </Box>
  );
}
