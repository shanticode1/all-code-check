"use client";

import { Box, Button, Container, Divider, Flex, Group, Text } from "@mantine/core";
import { IconArrowLeft } from "@tabler/icons-react";
import Image from "next/image";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useRef } from "react";

import DualLogoHeader from "@/components/Common/DualLogoHeader";
import { ResponsiveVideoPlayer } from "@/components/Common/ResponsiveVideoPlayer";
import TimerDisplay from "@/components/Common/Timer";
import { USER_ROLE } from "@/constants";
import { useGetQuestionDetailsByIdQuery } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import PrevIcon from "@/public/icons/left-arrow.svg";
import NextIcon from "@/public/icons/right-arrow.svg";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";
import { extractEmbedUrl } from "@/utils";

import ViewQuestion from "./ViewQuestion";

export const Questions = () => {
  const t = useTranslations("question");
  const { questionId, id, studentId } = useParams() as {
    questionId: string;
    id: string;
    studentId: string;
  };
  const params = useSearchParams();
  const student_exam_section_id = params.get("student_exam_section_id");

  const router = useRouter();
  const { role } = useAuth();
  const videoSectionRef = useRef<HTMLDivElement | null>(null);
  const {
    data: QuestionData,
    isFetching: isQuestionFetching,
    error: QuestionError,
  } = useGetQuestionDetailsByIdQuery({
    questionId: questionId,
    role: role as string,
    student_exam_section_id: student_exam_section_id as string,
  });

  useEffect(() => {
    if (!QuestionError) return;

    const { status } = QuestionError as { status?: number };

    if (status === 404) {
      router.push(paths.ROOT_NOT_FOUND);
    }
  }, [QuestionError, QuestionData, router]);

  const handleNavigation = (questionId?: number) => {
    router.push(
      role === USER_ROLE.STUDENT
        ? `/exam/${id}/question/${questionId}?student_exam_section_id=${student_exam_section_id}`
        : `/admin/student/exams/${id}/detail/${studentId}/question/${questionId}?student_exam_section_id=${student_exam_section_id}`,
    );
  };

  // Updating video url
  const videoUrl = QuestionData?.data?.video_url; // we can test here to update direct url
  const embedUrl = videoUrl && extractEmbedUrl(videoUrl);

  return (
    <Container size="xl" my="lg">
      <Box mih={400} className="exam-preview-section">
        <Flex gap={"sm"} mb={"md"} justify={"start"}>
          <Button
            variant="default"
            onClick={() =>
              router.push(
                role === USER_ROLE.STUDENT
                  ? `/exam/${id}`
                  : `/admin/student/exams/${id}/detail/${studentId}`,
              )
            }
          >
            <IconArrowLeft size={16} style={{ marginRight: 8 }} />
            <Text size="sm">{t("buttons.go_to_history.text")}</Text>
          </Button>

          <Button
            variant="default"
            onClick={() => {
              videoSectionRef.current?.scrollIntoView({ behavior: "smooth" });
            }}
          >
            <Text size="sm">{t("buttons.go_to_bottom.text")}</Text>
          </Button>
        </Flex>
        <Box className="exam-header">
          <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
          <Box>
            <Group justify="space-between" gap={0}>
              <Button
                disabled={!QuestionData?.data?.prevId}
                onClick={() => handleNavigation(QuestionData?.data?.prevId)}
                variant="default"
                className="btn-blue"
                mr={3}
                ml={3}
                rightSection={<Image src={PrevIcon} width={20} height={20} alt="next" />}
              >
                Previous
              </Button>
              <Button
                disabled={!QuestionData?.data?.nextId}
                onClick={() => handleNavigation(QuestionData?.data?.nextId)}
                className="btn-blue"
                rightSection={<Image src={NextIcon} width={20} height={20} alt="next" />}
              >
                Next
              </Button>
            </Group>
          </Box>
        </Box>
        <Box
          className="exam-section-details"
          style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
        >
          <Box>
            <Text size="sm" c="black">
              <Text span size="sm" fw={700}>
                {QuestionData?.data?.section_name}
              </Text>{" "}
              | Question {QuestionData?.data?.currentQuestionNumber} of{" "}
              {QuestionData?.data?.totalCount}
            </Text>
          </Box>

          {/* Right side: Timer and Calculator icon */}
          <Box style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <TimerDisplay secondsRemaining={Number(QuestionData?.data?.time_taken ?? 0)} />
          </Box>
        </Box>

        <ViewQuestion
          currentQ={QuestionData?.data}
          analyticalWriting={
            QuestionData?.data?.section_slug === "analytical-writing"
          }
          isQuantitiveSection={
            !!QuestionData?.data?.section_slug?.includes("quantitative-reasoning")
          }
          isLoading={isQuestionFetching}
          selectAnswer={QuestionData?.data?.studentAnswerChoices}
        />

        <Divider my="md" />
        <ResponsiveVideoPlayer
          embedUrl={embedUrl}
          videoUrl={videoUrl}
          sectionRef={videoSectionRef}
          title={t("details.title")}
          t={t}
        />
      </Box>
    </Container>
  );
};
