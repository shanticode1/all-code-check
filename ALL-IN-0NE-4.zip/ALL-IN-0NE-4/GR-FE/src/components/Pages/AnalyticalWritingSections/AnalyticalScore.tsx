"use client";

import { yupResolver } from "@hookform/resolvers/yup";
import {
  Anchor,
  Box,
  Breadcrumbs,
  Button,
  Card,
  Container,
  Divider,
  Flex,
  Group,
  Paper,
  Select,
  Title,
} from "@mantine/core";
import { showNotification } from "@mantine/notifications";
import { useParams ,useRouter} from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";

import { ConfirmationModal } from "@/components/Common/Modals";
import { EVALUATION_SCORES } from "@/constants/exam";
import { scoreValidationSchema } from "@/constants/validationSchemas/adminAuth";
import { useUpdateAnalyticalScoreMutation } from "@/hooks/analyticalSection";
import { useGetQuestionDetailsByIdQuery } from "@/hooks/student/exam";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import { paths } from "@/routes";
import { AnalyticalScoringFormValues } from "@/types/analyticalSection";

import ViewQuestion from "../Questions/ViewQuestion";

export default function AnalyticalScoringSection() {
  const t = useTranslations("evaluation");
  const { role } = useAuth();
  const router = useRouter();
  const { questionId } = useParams() as { questionId: string };
  const [showModal, setShowModal] = useState(false);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<AnalyticalScoringFormValues>({
    resolver: yupResolver(scoreValidationSchema),
  });

  const { data: questionData, isFetching: isQuestionFetching , error: QuestionError} = useGetQuestionDetailsByIdQuery({
    questionId: questionId,
    role: role as string,
  });

  useEffect(() => {
    if (!QuestionError) return;

    const { status } = QuestionError as { status?: number };

    if (status === 404) {
      router.push(paths.ROOT_NOT_FOUND);
    }
  }, [QuestionError, questionData, router]);

  const { mutateAsync: updateAnalyticalScore, isPending: isAnalyticalScorePending} =
    useUpdateAnalyticalScoreMutation();

  const onSubmit = async (data: AnalyticalScoringFormValues) => {
    try {
      const { message } = await updateAnalyticalScore({
        examSectionId: questionData?.data?.student_exam_section_id || 0,
        totalScore: Number(data.score),
      });
      reset({ score: 0 });
      showNotification({
        title: "Success",
        message: message,
        color: "green",
      });
      router.push("/admin/analytical-evaluation");
    } catch (error) {
      const { message } = error as Error;
      showNotification({
        title: "Error",
        message: message,
        color: "red",
      });
    }
  };

  const items = [
    { title: t("breadcrumbs.analyticalWriting"), href: "/admin/analytical-evaluation" },
    { title: t("breadcrumbs.evaluation"), active: true },
  ].map((item, index) =>
    item.active ? (
      <span key={item.title}>{item.title}</span>
    ) : (
      <Anchor className="breadcrumbs-size" href={item.href} key={item.title}>
        {item.title}
      </Anchor>
    ),
  );

  return (
    <Container size="xl" my="lg">
      <Card mb="xl" p="sm">
        <Group justify="space-between" align="center" style={{ width: "100%" }}>
          <Breadcrumbs separatorMargin="xs" className="breadcrumbs-size">
            {items}
          </Breadcrumbs>
        </Group>
      </Card>
      <Paper p="xl">
        <Title size="xl">{t("title")}</Title>

        <Box py="xs">
          <ViewQuestion
            currentQ={questionData?.data}
            analyticalWriting={
              questionData?.data?.section_slug === "analytical-writing"
            }
            isLoading={isQuestionFetching}
            selectAnswer={questionData?.data?.studentAnswerChoices}
            isWarningShow={false}
            isQuantitiveSection={
              !!questionData?.data?.section_slug?.includes("quantitative-reasoning")
            }
          />
          <Divider mt="md" />
          <form
            onSubmit={handleSubmit(() => {
              setShowModal(true);
            })}
          >
            <Flex gap="md" direction={"row"}>
              <Box mt="md" miw={300}>
                <Controller
                  name="score"
                  control={control}
                  render={({ field }) => (
                    <Select
                      label={t("form.input.score.label")}
                      error={errors.score?.message}
                      data={EVALUATION_SCORES}
                      value={field.value?.toString() ?? ""}
                      onChange={(value) => {
                        field.onChange(parseFloat(value ?? "0"));
                      }}
                      allowDeselect={false}
                      placeholder="Select score"
                    />
                  )}
                />
              </Box>

              <Button
                type="submit"
                mt="40px"
                disabled={isAnalyticalScorePending}
                variant="gradient"
                gradient={{ from: "blue", to: "cyan", deg: 90 }}
              >
                {t("form.button.label")}
              </Button>
            </Flex>
            {showModal && (
              <ConfirmationModal
                opened={showModal}
                title={t("modal.title")}
                description={t("modal.description")}
                onCancel={() => setShowModal(false)}
                onConfirm={handleSubmit(onSubmit)}
                buttonText={t("modal.button.confirm")}
                buttonCancelText={t("modal.button.cancel")}
                disabled={isAnalyticalScorePending}
              />
            )}
          </form>
        </Box>
      </Paper>
    </Container>
  );
}
