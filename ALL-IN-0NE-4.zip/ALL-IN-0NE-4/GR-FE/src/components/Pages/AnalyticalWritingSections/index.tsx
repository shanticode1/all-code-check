"use client";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, CloseButton, Container, Flex, Group ,Paper, Tooltip } from "@mantine/core";
import { useDebouncedValue } from "@mantine/hooks";
import { DataTable } from "mantine-datatable";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

import FormDatePicker from "@/components/Common/FormDatePicker/FormDatePicker";
import SearchInput from "@/components/Common/SearchInput";
import SectionHeader from "@/components/Common/SectionHeader";
import { paginationConstants } from "@/constants/common";
import { dateRangeValidationSchema } from "@/constants/validationSchemas/adminAuth";
import { useGetAnalyticalQuery } from "@/hooks/analyticalSection";
import { FormValues, IAnalytialSectionData } from "@/types/analyticalSection";
import { formatDate, formatDateToUTCISOString ,truncateName} from "@/utils";

export default function AnalyticalWritingSection() {
  const t = useTranslations("evaluation");
  const tExamHistory = useTranslations("examHistory");
  const searchParams = useSearchParams();
  const searchQuery = searchParams.get("search") || "";
  const router = useRouter();
  const pathname = usePathname();
  const [search, setSearch] = useState(searchQuery);
  const [debouncedSearch] = useDebouncedValue(search.trim(), 500);
  const page = Number(searchParams.get("page") || paginationConstants.page);
  const pageSize = Number(searchParams.get("pageSize") || paginationConstants.limit);
  const sortBy = (searchParams.get("sortBy") as "asc" | "desc") || null;
  const orderBy = searchParams.get("orderBy") as keyof IAnalytialSectionData | null;
  const {
    control,
    watch,
    clearErrors,
    formState: { errors },
    reset,
  } = useForm<FormValues>({
    defaultValues: {
      startDate: null,
      endDate: null,
    },
    resolver: yupResolver(dateRangeValidationSchema),
  });
  const [startDate, endDate] = watch(["startDate", "endDate"]);

  const { data: analyticalData, isLoading: isAnalyticalLoading } = useGetAnalyticalQuery({
    page,
    limit: pageSize,
    startDate: startDate?formatDateToUTCISOString(startDate) :null,
    endDate: endDate ? formatDateToUTCISOString(endDate) : null,
    search: searchQuery || null,
    sortBy: sortBy ?? undefined,
    orderBy: orderBy ?? undefined,
  });

  const columns = [
    {
      accessor: "Exam Details",
      title: t("table.headers.examDetails"),
      ellipsis: true,
      // render: (row: IAnalytialSectionData) => <>{row.exam_name}</>,
      render: (row: IAnalytialSectionData) => {
        const examName = row.exam_name ?? "-";
        const truncatedName = truncateName(examName, 40);
        const shouldShowTooltip = examName.length > 40;

        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={examName}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedName : examName}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },
    {
      accessor: "student_name",
      title: t("table.headers.studentName"),
      render: (row: IAnalytialSectionData) => {
        const studentName = row.student_name?.replace(/\snull$/, "") || "";
        const truncatedName = truncateName(studentName, 40);
        const shouldShowTooltip = studentName.length > 30;

        return (
          <Tooltip
            multiline
            withArrow
            w={250}
            label={studentName}
            disabled={!shouldShowTooltip}
            position="top"
            offset={10}
            styles={{
              tooltip: {
                padding: "8px 12px",
                whiteSpace: "normal",
                wordBreak: "break-word",
              },
            }}
          >
            <Box>
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedName : studentName}
              </p>
            </Box>
          </Tooltip>
        );
      },
    },
    {
      accessor: "email",
      title: t("table.headers.email"),
      render: (row: IAnalytialSectionData) => {
        const email = row.email ?? "-";
        const truncatedEmail = truncateName(email, 40);
        const shouldShowTooltip = email.length > 30;

        return (
          <Tooltip
            multiline
            withArrow
            w={250}
            label={email}
            disabled={!shouldShowTooltip}
            position="top"
            offset={10}
            styles={{
              tooltip: {
                padding: "8px 12px",
                whiteSpace: "normal",
                wordBreak: "break-word",
              },
            }}
          >
            <Box>
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedEmail : email}
              </p>
            </Box>
          </Tooltip>
        );
      },
    },
    {
      accessor: "portal_type",
      title: t("table.headers.portalType"),
      render: (row: IAnalytialSectionData) => <>{row.partner_type ?? "-"}</>,
    },
    {
      accessor: "exam_date",
      title: t("table.headers.examDate"),
      sortable: true,
      render: (row: IAnalytialSectionData) => <>{formatDate(row.start_date)}</>,
    },
    {
      accessor: "Actions",
      title: t("table.headers.actions"),
      cellsStyle: () => ({ backgroundColor: "#fff" }),
      render: (row: IAnalytialSectionData) => (
        <Tooltip label="Evaluate Exam">
          <Button
            size="xs"
            variant="gradient"
            gradient={{ from: "yellow", to: "orange", deg: 90 }}
            onClick={() =>
              router.push(`/admin/analytical-evaluation/score/${row.student_question_id}`)
            }
          >
            {t("cards.button.title")}
          </Button>
        </Tooltip>
      ),
    },
  ];

  const updateQueryParams = (updates: Record<string, string | number | null>) => {
    const q = new URLSearchParams(searchParams.toString());

    Object.entries(updates).forEach(([key, value]) => {
      if (value == null) q.delete(key);
      else q.set(key, String(value));
    });

    router.replace(`${pathname}?${q.toString()}`);
  };

  const handleSortChange = ({ columnAccessor }: { columnAccessor: string }) => {
    if (orderBy === columnAccessor) {
      if (sortBy === "asc") {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "desc" });
      } else if (sortBy === "desc") {
        updateQueryParams({ orderBy: null, sortBy: null });
      } else {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
      }
    } else {
      updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
    }
  };
  useEffect(() => {
    updateQueryParams({
      search: debouncedSearch || null,
      page: 1,
      startDate: formatDateToUTCISOString(startDate),
      endDate: formatDateToUTCISOString(endDate),
    });
  }, [debouncedSearch, startDate, endDate]);

  const handleClearFilters = () => {
    updateQueryParams({ startDate: null, endDate: null, page: 1 });
    reset({
      startDate: null,
      endDate: null,
    });
    clearErrors();
  };
  const handlePageChange = (newPage: number) => {
    updateQueryParams({ page: newPage });
  };

  const handlePageSizeChange = (newPageSize: number) => {
    updateQueryParams({ pageSize: newPageSize, page: 1 });
  };
  return (
    <Container size="xxl" my="lg">
      <SectionHeader title={t("header.title")} />
      <Paper>
        <Box p={"sm"}>
          <form>
            <Flex justify="space-between" align="center" wrap="wrap">
              <Group gap="md" align="center">
                <Box style={{ width: "400px" }}>
                  <SearchInput
                    placeholder={tExamHistory("search.input.analyticalPlaceholder")}
                    handleChange={(e) => setSearch(e.currentTarget.value)}
                    value={search}
                    handleClear={() => {
                      setSearch("");
                      updateQueryParams({ search: null, page: 1 });
                      clearErrors("searchQuery");
                    }}
                  />
                </Box>
              </Group>
              <Box>
                <Group gap="md" align="center">
                  <FormDatePicker
                    name="startDate"
                    control={control}
                    placeholderKey={tExamHistory("datePicker.startDate.placeholder")}
                    errors={errors}
                    maxDate={endDate ?? new Date()}
                  />
                  <FormDatePicker
                    name="endDate"
                    control={control}
                    placeholderKey={tExamHistory("datePicker.endDate.placeholder")}
                    errors={errors}
                    minDate={startDate || undefined}
                    maxDate={new Date()}
                  />

                  <CloseButton
                    aria-label={t("form.button.clearFilter.label")}
                    onClick={handleClearFilters}
                    style={{ display: startDate || endDate ? undefined : "none" }}
                  />
                </Group>
              </Box>
            </Flex>
          </form>
        </Box>
        <DataTable
          records={analyticalData?.data?.data || []}
          columns={columns}
          minHeight={350}
          borderRadius="sm"
          highlightOnHover
          fetching={isAnalyticalLoading}
          loaderType="oval"
          striped={true}
          noRecordsText="No Exam found"
          verticalAlign="top"
          pinLastColumn
          className="data-table"
          totalRecords={analyticalData?.data?.total || 0}
          recordsPerPage={pageSize}
          page={page}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handlePageSizeChange}
          recordsPerPageOptions={
            Array.isArray(analyticalData?.data?.data) && analyticalData.data.data.length !== 0
              ? [5, 10, 20, 50]
              : []
          }
          c={{ dark: "#000", light: "#555" }}
          styles={{
            header: {
              backgroundColor: "#f0f0f0",
            },
          }}
          sortStatus={{
            columnAccessor: orderBy ?? "",
            direction: (sortBy) ?? "asc",
          }}
          onSortStatusChange={handleSortChange}
          withTableBorder={true}
        />
      </Paper>
    </Container>
  );
}
