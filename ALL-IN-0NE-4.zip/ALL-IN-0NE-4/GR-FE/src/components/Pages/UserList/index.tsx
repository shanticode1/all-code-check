//@ts-nocheck
"use client";
import {
  ActionIcon,
  Box,
  Button,
  Container,
  Group,
  Menu,
  Modal,
  Paper,
  Tooltip,
} from "@mantine/core";
import { useDebouncedValue } from "@mantine/hooks";
import { showNotification } from "@mantine/notifications";
import { IconChevronDown, IconEdit, IconPlus, IconTrash } from "@tabler/icons-react";
import { DataTable } from "mantine-datatable";
import { usePathname, useRouter ,useSearchParams} from "next/navigation";
import { useTranslations } from "next-intl";
import React, { JSX, useEffect, useState } from "react";

import { ConfirmationModal } from "@/components/Common/Modals";
import SearchInput from "@/components/Common/SearchInput";
import SectionHeader from "@/components/Common/SectionHeader";
import { commonButtons } from "@/constants";
import { useGetAllUserQuery } from "@/hooks";
import { useDeleteUserMutation, useUpdateUserMutation } from "@/hooks/user/Details";
import { IUserList } from "@/types/User";
import { truncateName } from "@/utils";

import AddUserForm from "../AddUserForm";

export default function UserList(): JSX.Element {
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const router = useRouter();
  const page = Number(searchParams.get("page") ?? 1);
  const pageSize = Number(searchParams.get("pageSize") ?? 10);
  const sortBy = (searchParams.get("sortBy") as "asc" | "desc") || null;
  const orderBy = searchParams.get("orderBy") as keyof IUserList | null;
  const [searchQuery, setSearchQuery] = useState<string>(searchParams.get("search") ?? "");
  const t = useTranslations("userDetails");
  const tGeneric = useTranslations("generic");

  const [debouncedSearchQuery] = useDebouncedValue(searchQuery.trim(), 500);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [userDetail, setUserDetail] = useState<IUserList | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const { mutateAsync: deleteUser } = useDeleteUserMutation();

  const {
    data: userData,
    isLoading: isUserListLoading,
    isFetching: isUserListFetching,
  } = useGetAllUserQuery({
    page,
    limit: pageSize,
    search: debouncedSearchQuery,
    sortBy: sortBy ?? undefined,
    orderBy: orderBy ?? undefined,
  });

  const { mutateAsync: updateUser } = useUpdateUserMutation();

  const handleDelete = async () => {
    if (selectedUserId) {
      const result = await deleteUser({ id: selectedUserId });
      if (result) {
        showNotification({
          color: "green",
          title: "Success",
          message: result.message,
        });
      }
      setShowDeleteModal(false);
      setSelectedUserId(null);
    }
  };

  const updateQueryParams = (updates: Record<string, string | number | null>) => {
    const q = new URLSearchParams(searchParams.toString().trim());

    Object.entries(updates).forEach(([key, value]) => {
      if (value == null) q.delete(key);
      else q.set(key, String(value));
    });

    router.replace(`${pathname}?${q.toString()}`);
  };

  useEffect(() => {
    updateQueryParams({ search: debouncedSearchQuery, page: 1 });
  }, [debouncedSearchQuery]);

  const handlePageChange = (newPage: number) => {
    updateQueryParams({ page: newPage });
  };

  const handlePageSizeChange = (newPageSize: number) => {
    updateQueryParams({ pageSize: newPageSize, page: 1 });
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setUserDetail(null);
  };

  const handleSortChange = ({ columnAccessor }: { columnAccessor: string }) => {
    if (orderBy === columnAccessor) {
      if (sortBy === "asc") {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "desc" });
      } else if (sortBy === "desc") {
        updateQueryParams({ orderBy: null, sortBy: null });
      } else {
        updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
      }
    } else {
      updateQueryParams({ orderBy: columnAccessor, sortBy: "asc" });
    }
  };
  const columns = [
    {
      accessor: "user_name",
      title: t("table.columns.title.name"),
      sortable: true,
      render: (row: IUserList) => {
        const fullName = `${row.first_name} ${row.last_name ?? ""}`.trim();
        const truncatedName = truncateName(fullName, 20);
        const shouldShowTooltip = fullName.length > 20;

        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={fullName}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncatedName : fullName}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },
    {
      accessor: "email",
      title: t("table.columns.title.email"),
      render: (row: IUserList) => {
        const email = row.email;
        const truncated = truncateName(email, 45);
        const shouldShowTooltip = email.length > 45;
        return (
          <Box>
            <Tooltip
              multiline
              withArrow
              w={250}
              label={email}
              disabled={!shouldShowTooltip}
              position="top"
              offset={10}
              styles={{
                tooltip: {
                  padding: "8px 12px",
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                },
              }}
            >
              <p style={{ margin: "0", color: "#212121" }}>
                {shouldShowTooltip ? truncated : email}
              </p>
            </Tooltip>
          </Box>
        );
      },
    },

    {
      accessor: "role",
      sortable: true,
      title: t("table.columns.title.role"),
    },

    {
      accessor: "status",
      title: t("table.columns.title.status"),
      render: (row: IUserList) => {
        const handleStatusChange = async (newStatus: "ACTIVE" | "INACTIVE") => {
          try {
            const updatedPayload = {
              first_name: row.first_name,
              last_name: row.last_name ?? null,
              email: row.email,
              role: row.role,
              is_active: newStatus === "ACTIVE",
            };
            const { message } = await updateUser({ id: row.user_id, input: updatedPayload });
            showNotification({
              color: "green",
              title: "Success",
              message: message,
            });
          } catch (error) {
            console.error("Status update failed", error);
          }
        };

        return (
          <Box style={{ width: "100px" }}>
            <Menu>
              <Menu.Target>
                <Box
                  style={{
                    cursor: "pointer",
                    padding: "4px 8px",
                    borderRadius: "4px",
                    textAlign: "center",
                    backgroundColor: row.is_active ? "#40c0571a" : "#fa52521f",
                    color: row.is_active ? "#40c057" : "#fa5252",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  {row.is_active
                    ? t("table.columns.status.active")
                    : t("table.columns.status.inactive")}
                  <IconChevronDown size={14} style={{ marginLeft: "8px" }} />
                </Box>
              </Menu.Target>
              <Menu.Dropdown p="0" w="100">
                {!row.is_active && (
                  <Menu.Item onClick={() => handleStatusChange("ACTIVE")}>
                    {t("table.columns.status.active")}
                  </Menu.Item>
                )}
                {row.is_active && (
                  <Menu.Item onClick={() => handleStatusChange("INACTIVE")}>
                    {t("table.columns.status.inactive")}
                  </Menu.Item>
                )}
              </Menu.Dropdown>
            </Menu>
          </Box>
        );
      },
    },
    {
      accessor: "actions",
      title: "Actions",
      cellsStyle: () => ({ backgroundColor: "#fff" }),
      render: (row: IUserList) => (
        <Box style={{ display: "flex", gap: "2px" }}>
          <Tooltip label="Edit">
            <ActionIcon
              color="blue"
              onClick={() => {
                setUserDetail(row);
                setIsModalOpen(true);
              }}
            >
              <IconEdit size={16} />
            </ActionIcon>
          </Tooltip>
          <Tooltip label="Delete">
            <ActionIcon
              color="red"
              onClick={() => {
                setSelectedUserId(Number(row.user_id));
                setShowDeleteModal(true);
              }}
            >
              <IconTrash size={16} />
            </ActionIcon>
          </Tooltip>
        </Box>
      ),
    },
  ];

  return (
    <Container size="xxl" my="lg">
      <SectionHeader title={t("title")}>
        <Button
          variant="default"
          onClick={() => setIsModalOpen(true)}
          leftSection={<IconPlus size={14} />}
          size="md"
        >
          {tGeneric("buttons.add", { value: commonButtons.user })}
        </Button>
      </SectionHeader>
      <Paper>
        <Box p={"sm"} flex={true}>
          <Group justify="space-between">
            <Group gap="md" align="center">
              <Box style={{ width: "400px" }}>
                <SearchInput
                  handleChange={(e) => setSearchQuery(e.currentTarget.value)}
                  placeholder="Search by name or email"
                  value={searchQuery}
                  handleClear={() => {
                    setSearchQuery("");
                    updateQueryParams({ search: "", page: 1 });
                  }}
                />
              </Box>
            </Group>
          </Group>
        </Box>
        <DataTable
          records={userData?.data?.users}
          columns={columns}
          withTableBorder={false}
          withColumnBorders={false}
          borderRadius="sm"
          highlightOnHover
          fetching={isUserListLoading || isUserListFetching}
          loaderType="oval"
          striped
          noRecordsText="No User records found"
          verticalAlign="top"
          pinLastColumn
          className="data-table"
          totalRecords={userData?.data?.total || 0}
          recordsPerPage={pageSize}
          page={page}
          onPageChange={handlePageChange}
          onRecordsPerPageChange={handlePageSizeChange}
          recordsPerPageOptions={userData?.data.users.length !=0?[5, 10, 20, 50]:undefined}
          minHeight={350}
          c={{ dark: "#000", light: "#555" }}
          styles={{
            header: {
              backgroundColor: "#f0f0f0",
            },
          }}
          sortStatus={{
            columnAccessor: orderBy ?? "",
            direction: (sortBy) ?? "asc",
          }}
          onSortStatusChange={handleSortChange}
        />
      </Paper>
      {showDeleteModal && (
        <ConfirmationModal
          opened={showDeleteModal}
          title={t("confirmDelete.title")}
          description={
            <span>
              {t("confirmDelete.message")}
              <br />
              {t("confirmDelete.description")}
            </span>
          }
          onCancel={() => setShowDeleteModal(false)}
          onConfirm={handleDelete}
          buttonText={t("confirmDelete.delete")}
          buttonCancelText={t("confirmDelete.cancel")}
        />
      )}

      <Modal
        opened={isModalOpen}
        onClose={handleCloseModal}
        size="lg"
        title={userDetail?.user_id ? t("edit.modal.title") : t("create.modal.title")}
      >
        <AddUserForm handleClose={handleCloseModal} userDetail={userDetail} />
      </Modal>
    </Container>
  );
}
