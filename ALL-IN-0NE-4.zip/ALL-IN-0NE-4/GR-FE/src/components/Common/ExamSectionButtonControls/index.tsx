import { Box, Button, Checkbox, Flex, Group, Select } from "@mantine/core";
import Image from "next/image";
import React from "react";

import { USER_ROLE } from "@/constants";
import { sectionsSlug } from "@/constants/section";
import { ExamSectionButtonControlsProps } from "@/types";

const ExamSectionButtonControls = ({
    role,
    selectedSectionId,
    allSections,
    handleSectionChange,
    handleHelpSection,
    handleExitSection,
    handleNavigateToSectionQuestions,
    handleExit,
    handlePrevious,
    handleNext,
    handleNavigateToSection,
    handleUpdatemark,
    isSaving,
    isExamDataLoading,
    isQuestionMarked,
    calculatorPermitted,
    opened,
    setOpened,
    isQuestionFetching,
    questionIds,
    currentIndex,
    analyticalWriting,
    sectionSlug,
    t,
    icons,
}: ExamSectionButtonControlsProps) => {
    const {
        HelpIcon,
        ExitIcon,
        CalculatorIcon,
        BookmarkIcon,
        PrevIcon,
        NextIcon,
    } = icons;
    return (
        <Box>
            <Group justify="space-between" gap={0}>
                {[USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                    <Select
                        placeholder={t("section.select.placeholder")}
                        value={Array.isArray(selectedSectionId) ? selectedSectionId[0] : selectedSectionId}
                        onChange={(value) => {
                            if (value) handleSectionChange(value);
                        }}
                        data={allSections?.map((section: { section_id: number; section_name: string }) => ({
                            value: section.section_id.toString(),
                            label: section.section_name,
                        }))}
                        style={{ width: "250px", marginRight: "5px" }}
                        disabled={isExamDataLoading}
                    />
                )}
                {!analyticalWriting && ![USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                    <>
                        <Button
                            variant="default"
                            disabled={isSaving}
                            onClick={handleHelpSection}
                            color="#ffffff"
                            mr={3}
                            className="btn-blue btn-utility"
                            rightSection={<Image src={HelpIcon} width={20} height={20} alt="next" />}
                        >
                            {" "}
                            {t("buttons.helpSection.label")}
                        </Button>
                        {![USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                            <Button
                                variant="default"
                                disabled={isSaving}
                                onClick={handleExitSection}
                                color="#ffffff"
                                className="btn-blue btn-exit"
                                mr={3}
                                rightSection={<Image src={ExitIcon} width={13} height={20} alt="next" />}
                            >
                                {t("buttons.exitSection.label")}
                            </Button>
                        )}
                    </>
                )}
                {calculatorPermitted && (
                    <Button
                        variant="default"
                        disabled={isSaving}
                        className="btn-blue btn-utility"
                        onClick={() => setOpened(!opened)}
                        rightSection={<Image src={CalculatorIcon} width={16} alt="next" />}
                    >
                        {t("calculator.title")}
                    </Button>
                )}
                {sectionSlug !== sectionsSlug.ANALYTICAL_WRITING &&
                    ![USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                        <Box display={"flex"} miw={70} style={{ justifyContent: "center" }}>
                            <Box className="btn-blue btn-utility">
                                <label
                                    htmlFor="checkbox-marked"
                                    style={{
                                        cursor: "pointer",
                                        color: "#fff",
                                        fontSize: "14px",
                                        fontWeight: 600,
                                        textAlign: "center",
                                        lineHeight: "20px",
                                    }}
                                >
                                    {isQuestionMarked ? t("checkbox.markedLabel") : t("checkbox.label")}
                                </label>
                                <Checkbox
                                    disabled={isSaving}
                                    label={""}
                                    checked={isQuestionMarked}
                                    onChange={(event) => handleUpdatemark(event.currentTarget.checked)}
                                    id="checkbox-marked"
                                    styles={{
                                        input: {
                                            borderRadius: 4, // set to any value (e.g., 0, 4, 8)
                                            backgroundColor: "#ffffff10", // ⬅️ dynamic background
                                            borderColor: "#9A9A9A",
                                            transition: "background-color 0.3s ease",
                                        },
                                        icon: {
                                            transition: "transform 0.3s ease",
                                            transform: isQuestionMarked
                                                ? "scale(1.5) translateX(3px)"
                                                : "scale(1) translateX(0px)",
                                        },
                                    }}
                                />
                            </Box>
                        </Box>
                    )}
                {!analyticalWriting && ![USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                    <Box miw={70}>
                        <Button
                            disabled={isSaving}
                            variant="default"
                            onClick={handleNavigateToSectionQuestions}
                            className="btn-blue btn-utility"
                            rightSection={<Image src={BookmarkIcon} width={20} height={20} alt="next" />}
                        >
                            {t("buttons.questionNavigator.label")}
                        </Button>
                    </Box>
                )}
                <Flex>
                    {[USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                        <Button
                            variant="default"
                            onClick={handleExit}
                            disabled={isSaving}
                            className="btn-blue btn-exit"
                            rightSection={<Image src={PrevIcon} width={20} height={20} alt="next" />}
                        >
                            {t("buttons.exit.label")}
                        </Button>
                    )}
                    {!analyticalWriting ? (
                        <>
                            <Button
                                variant="default"
                                disabled={isSaving || currentIndex === 0}
                                onClick={handlePrevious}
                                className="btn-blue"
                                mr={3}
                                ml={3}
                                rightSection={<Image src={PrevIcon} width={20} height={20} alt="next" />}
                            >
                                {" "}
                                {t("buttons.previous.label")}
                            </Button>
                            {currentIndex === questionIds?.length - 1 ? (
                                <Button
                                    onClick={() => {
                                        if (role === USER_ROLE.STUDENT) {
                                            handleNavigateToSection();
                                        }
                                        handleNext();
                                    }}
                                    disabled={isSaving || isQuestionFetching}
                                    className="btn-blue"
                                    rightSection={<Image src={NextIcon} width={20} height={20} alt="next" />}
                                >
                                    {t("buttons.next.label")}
                                </Button>
                            ) : (
                                <Button
                                    disabled={isSaving}
                                    onClick={handleNext || isQuestionFetching}
                                    className="btn-blue"
                                    rightSection={<Image src={NextIcon} width={20} height={20} alt="next" />}
                                >
                                    {t("buttons.next.label")}
                                </Button>
                            )}
                        </>
                    ) : (
                        ![USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role) && (
                            <Button
                                onClick={() => {
                                    handleNavigateToSection();
                                    handleNext();
                                }}
                                disabled={isSaving || isQuestionFetching}
                                className="btn-blue"
                                rightSection={<Image src={NextIcon} width={20} height={20} alt="next" />}
                            >
                                {t("buttons.next.label")}
                            </Button>
                        )
                    )}
                </Flex>
            </Group>
        </Box>
    );
};

export default ExamSectionButtonControls;
