import { Box, Text } from "@mantine/core";
import { useTranslations } from "next-intl";
import React from "react";

import { GuidelineDisplayProps } from "@/types";

const GuidelineDisplay: React.FC<GuidelineDisplayProps> = ({ guidelines }) => {
  const t = useTranslations("preview");
  return (
    <Box className="guideline-box-outer">
      <Box className="guideline-box">
        <Text>
          <span>{guidelines ?? t("messages.noGuidelines")}</span>
        </Text>
      </Box>
    </Box>
  );
};

export default GuidelineDisplay;
