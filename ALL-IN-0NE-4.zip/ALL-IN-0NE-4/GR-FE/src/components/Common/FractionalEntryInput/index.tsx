import { Box, Flex, TextInput } from "@mantine/core";
import React from "react";

import { allowedKeys } from "@/constants";
import { FractionalEntryInputProps } from "@/types";

const FractionalEntryInput = ({
  numeratorValue,
  denominatorValue,
  onNumeratorChange,
  onDenominatorChange,
  isSaving,
  currentQ,
}: FractionalEntryInputProps) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const value = input.value;
    const selectionStart = input.selectionStart ?? 0;
    const selectionEnd = input.selectionEnd ?? 0;

    if (allowedKeys.includes(e.key)) return;

    if (e.key === "-") {
      if (selectionStart !== 0 || value.includes("-")) e.preventDefault();
      return;
    }

    if (!/^\d$/.test(e.key)) {
      e.preventDefault();
      return;
    }

    const digitCount = value.replace("-", "").length;
    const isReplacing = selectionStart !== selectionEnd;
    if (digitCount >= 4 && !isReplacing) {
      e.preventDefault();
    }
  };

  return (
    <>
      <Flex align="center" mt="sm" direction="column">
        {currentQ?.passage_answer_instructions && (
          <Box className="answer-box" style={{ border: "none" }}>
            <Box
              dangerouslySetInnerHTML={{
                __html: currentQ?.passage_answer_instructions,
              }}
            />
          </Box>
        )}
        {/* Numerator */}
        <TextInput
          placeholder="Num"
          size="xs"
          style={{ width: 100 }}
          value={numeratorValue}
          onChange={(e) => {
            const value = e.target.value;
            const regex = /^-?(0|[1-9]\d{0,3})?$/;
            if (!regex.test(value)) return;
            onNumeratorChange(value);
          }}
          onKeyDown={handleKeyDown}
          onCopy={(e) => e.preventDefault()}
          onPaste={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          disabled={isSaving}
          maxLength={5}
        />

        <Box
          my="xs"
          style={{
            width: 60,
            height: 2,
            backgroundColor: "#ccc",
          }}
        />

        {/* Denominator */}
        <TextInput
          placeholder="Den"
          size="xs"
          style={{ width: 100 }}
          value={denominatorValue}
          onChange={(e) => {
            const value = e.target.value;
            const regex = /^-?\d{0,4}$/;
            if (!regex.test(value)) return;
            const numeric = parseInt(value, 10);
            if (numeric === 0) return;
            onDenominatorChange(value);
          }}
          onKeyDown={handleKeyDown}
          onCopy={(e) => e.preventDefault()}
          onPaste={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          disabled={isSaving}
          maxLength={5}
        />
      </Flex>
    </>
  );
};

export default FractionalEntryInput;
