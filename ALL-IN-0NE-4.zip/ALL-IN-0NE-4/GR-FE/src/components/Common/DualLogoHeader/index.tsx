import { Box, Flex } from "@mantine/core";
import Image from "next/image";
import { useTranslations } from "next-intl";
import React from "react";

import { DualLogoProps } from "@/types";

const DualLogoHeader = ({ logo, sherpaPreplogo }: DualLogoProps) => {
    const t = useTranslations("generic");
    return (
        <Box>
            <Flex justify="space-between" align="center">
                <Box style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <Box
                        style={{
                            backgroundColor: "#fff",
                            height: 50,
                            borderRadius: "4px",
                        }}
                        pl={2}
                    >
                        <Image
                            src={sherpaPreplogo}
                            alt={t("logos.sherpaPrep")}
                            width={150}
                            height={50}
                            style={{ objectFit: "contain", marginRight: "10px" }}
                        />
                    </Box>
                    <Box
                        style={{
                            backgroundColor: "#fff",
                            height: 50,
                            borderRadius: "4px",
                        }}
                    >
                        <Image
                            src={logo}
                            alt={t("logos.smartWithAHeart")}
                            width={150}
                            height={50}
                            style={{ objectFit: "contain", marginRight: "10px" }}
                        />
                    </Box>
                </Box>
            </Flex>
        </Box>
    );
};

export default DualLogoHeader;
