import { Box } from "@mantine/core";
import React from "react";

import { ExamHeaderProps } from "@/types";

import DualLogoHeader from "../DualLogoHeader";
import ExamSectionButtonControls from "../ExamSectionButtonControls";

const ExamHeader: React.FC<ExamHeaderProps> = ({
  logo,
  sherpaPreplogo,
  role,
  selectedSectionId,
  allSections,
  handleSectionChange,
  handleHelpSection,
  handleExitSection,
  handleNavigateToSectionQuestions,
  handleExit,
  handlePrevious,
  handleNext,
  handleNavigateToSection,
  handleUpdatemark,
  isSaving,
  isExamDataLoading,
  isQuestionFetching,
  questionIds,
  currentIndex,
  isQuestionMarked,
  calculatorPermitted,
  opened,
  setOpened,
  analyticalWriting,
  sectionSlug,
  t,
  icons,
}) => {
  return (
    <Box className="exam-header">
      <DualLogoHeader logo={logo} sherpaPreplogo={sherpaPreplogo} />
      <ExamSectionButtonControls
        role={role}
        selectedSectionId={selectedSectionId}
        allSections={allSections}
        handleSectionChange={handleSectionChange}
        handleHelpSection={handleHelpSection}
        handleExitSection={handleExitSection}
        handleNavigateToSectionQuestions={handleNavigateToSectionQuestions}
        handleExit={handleExit}
        handlePrevious={handlePrevious}
        handleNext={handleNext}
        handleNavigateToSection={handleNavigateToSection}
        handleUpdatemark={handleUpdatemark}
        isSaving={isSaving}
        isExamDataLoading={isExamDataLoading}
        isQuestionFetching={isQuestionFetching}
        questionIds={questionIds}
        currentIndex={currentIndex}
        isQuestionMarked={isQuestionMarked}
        calculatorPermitted={calculatorPermitted}
        opened={opened}
        setOpened={setOpened}
        analyticalWriting={analyticalWriting}
        sectionSlug={sectionSlug}
        t={t}
        icons={icons}
      />
    </Box>
  );
};

export default ExamHeader;
