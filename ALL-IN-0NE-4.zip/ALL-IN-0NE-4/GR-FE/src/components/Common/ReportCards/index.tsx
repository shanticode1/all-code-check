import { Box, Card, Grid, Progress, Text } from "@mantine/core";
import React from "react";

import { ReportCardProps } from "@/types/Exam/ExamHistory";

export const ReportCards = ({ label, value, min, max }: ReportCardProps) => {
    const unitPercent = 100 / (max - min);
    const percentage = (value - min) * unitPercent;

    return (
        <Grid.Col span={{ sm: 6, md: 6, lg: 3 }} key={label}>
            <Card
                withBorder
                p="xs"
                bg="#cff7fd"
                shadow="none"
                h={150}
                style={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "10px",
                    borderRadius: "4px",
                    borderBottom: "4px solid #10b2cb",
                }}
            >
                <Box  px={"md"} >
                    <Text size="md" style={{ textAlign: "center" }}>
                        {label}
                    </Text>
                </Box>
                <Box pos="relative" w="100%" mt="sm">
                    
                    <Box pos="relative" mt={4}>
                        <Progress value={percentage} color="#87CEEB" size="xl" radius="xs" />
                        <Box
                            pos="absolute"
                            left={`${percentage}%`}
                            top={-6}
                            h="130%"
                            style={{
                                transform: "translateX(-50%)",
                                width: "2px",
                                backgroundColor: "black",
                                zIndex: 2,
                            }}
                        />
                        <Box
                            pos="absolute"
                            left={`${percentage}%`}
                            style={{
                                transform: "translateX(-50%)",
                                background: "#b45309",
                                color: "white",
                                padding: "2px 6px",
                                borderRadius: "4px",
                                fontSize: "12px",
                                top: -30,
                                zIndex: 3,
                                fontWeight: 600,
                            }}
                        >
                            {value}
                        </Box>
                    </Box>
                    <Box
                        style={{
                            display: "flex",
                            justifyContent: "space-between",
                            fontSize: 12,
                            color: "#555",
                        }}
                    >
                        <Text fw="600" size="sm">{min}</Text>
                        <Text fw="600" size="sm">{max}</Text>
                    </Box>
                </Box>
            </Card>
        </Grid.Col>
    );
};
