"use client";

import { Button, Flex, Modal } from "@mantine/core";
import { useTranslations } from "next-intl";
import React from "react";
import { SetStateAction, useEffect, useState } from "react";

import CommonEditor from "@/components/Common/Editor/Editor";

interface EquationEditorModalProps {
  opened: boolean;
  type: "prefix" | "suffix";
  value: string;
  onClose: () => void;
  onSave: (content: string) => void;
  setIsPrefixDisabled: React.Dispatch<React.SetStateAction<boolean>>;
  setIsSuffixDisabled: React.Dispatch<React.SetStateAction<boolean>>;
}

const EquationEditorModal = ({
  opened,
  type,
  value,
  onClose,
  onSave,
  setIsPrefixDisabled,
  setIsSuffixDisabled,
}: EquationEditorModalProps) => {
  const [content, setContent] = useState(value);
  const t = useTranslations("answer");

  useEffect(() => {
    setContent(value);
  }, [value]);

  return (
    <Modal
      opened={opened}
      onClose={onClose}
      title={type === "prefix" ? t("editor.editPrefix") : t("editor.editSuffix")}
      size="lg"
      centered
    >
      <CommonEditor
        guidelines={content}
        placeholder={t("editor.placeholder", { type })}
        height={300}
        onContentChange={(val: SetStateAction<string>) => {
          setContent(val);
          setIsPrefixDisabled(!!val);
          setIsSuffixDisabled(!!val);
        }}
      />

      <Flex gap="md" justify="flex-end" mt="md">
        <Button variant="light" onClick={onClose}>
          {t("editor.cancel")}
        </Button>
        <Button
          onClick={() => {
            onSave(content);
            onClose();
          }}
        >
          {t("editor.save")}
        </Button>
      </Flex>
    </Modal>
  );
};

export default EquationEditorModal;
