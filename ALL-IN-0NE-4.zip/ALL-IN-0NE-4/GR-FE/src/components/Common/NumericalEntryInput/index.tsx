import { Box, TextInput } from "@mantine/core";
import React from "react";

import { NumericalEntryInputProps } from "@/types";

const NumericalEntryInput = ({
  prefix,
  suffix,
  value,
  onChange,
  isSaving,
  currentQ,
  t,
}: NumericalEntryInputProps) => {
  const handleInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = event.target.value;

    // 1. Allow only digits, '-', and '.'
    let sanitized = inputValue.replace(/[^0-9.-]/g, "");

    // 2. Handle '-' only at the beginning
    let isNegative = false;
    if (sanitized.startsWith("-")) {
      isNegative = true;
      sanitized = sanitized.slice(1).replace(/-/g, ""); // Remove other '-'s
    } else {
      sanitized = sanitized.replace(/-/g, "");
    }

    // 3. Handle single '.'
    const parts = sanitized.split(".");
    const hasDot = parts.length > 1;
    let intPart = parts[0].replace(/\D/g, "");
    let decPart = parts[1]?.replace(/\D/g, "") || "";

    // 4. Limit total digits to 8
    const totalDigits = (intPart + decPart).slice(0, 8);
    intPart = totalDigits.slice(0, intPart.length);
    decPart = totalDigits.slice(intPart.length);

    // 5. Rebuild the final string
    let result = (isNegative ? "-" : "") + intPart;
    if (hasDot && (decPart.length > 0 || inputValue.endsWith("."))) {
      result += "." + decPart;
    }

    // 6. Optional cleanup for edge cases
    if (result === "-") result = "-";
    if (result === "-.") result = "-";

    onChange(result);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    const currentValue = input.value;

    if (e.key === "-") {
      const cursorAtStart = input.selectionStart === 0;
      const alreadyHasMinus = currentValue.includes("-");
      if (!cursorAtStart || alreadyHasMinus) {
        e.preventDefault();
      }
    }

    if (e.key === "." && currentValue.includes(".")) {
      e.preventDefault();
    }
  };

  return (
    <>
      <Box className="answer-box">
        {currentQ?.passage_answer_instructions && (
          <Box
            dangerouslySetInnerHTML={{
              __html: currentQ?.passage_answer_instructions,
            }}
          />
        )}
        <Box style={{ display: "flex", alignItems: "center", marginTop: 8 }}>
          {/* <Box style={{ marginRight: 10, marginTop: 15 }}>{prefix}</Box> */}
          <Box
            style={{ marginRight: 10, marginTop: 15 }}
            dangerouslySetInnerHTML={{ __html: prefix || "" }}
          />

          <TextInput
            placeholder={t("input.numericEntryPlaceholder")}
            mt="sm"
            value={value}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            onCopy={(e) => e.preventDefault()}
            onPaste={(e) => e.preventDefault()}
            onCut={(e) => e.preventDefault()}
            disabled={isSaving}
            className="times-font"
          />
          {/* <Box style={{ marginLeft: 10, marginTop: 15 }}>{suffix}</Box> */}
          <Box
            style={{ marginLeft: 10, marginTop: 15 }}
            className="ans-image"
            dangerouslySetInnerHTML={{ __html: suffix || "" }}
          />
        </Box>
      </Box>
    </>
  );
};

export default NumericalEntryInput;
