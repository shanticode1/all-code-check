import { Box, Text } from "@mantine/core";

import { ResponsiveVideoPlayerProps } from "@/types/Student/ViewQuestion";

export const ResponsiveVideoPlayer = ({
    embedUrl,
    videoUrl,
    sectionRef,
    title,
    t
}: ResponsiveVideoPlayerProps) => {

    return (
        <Box ref={sectionRef} mt="xxl" pt="sm" mb="xl">
            <Text fw={600} mb="xl" size="lg">
                {title ?? t("details.video.title")}
            </Text>

            <Box
                style={{
                    position: "relative",
                    paddingBottom: "56.25%",
                    height: 0,
                    overflow: "hidden",
                    borderRadius: 8,
                    maxWidth: "80%",
                    margin: "0 auto",
                    border: "2px solid #e8edf2",
                }}
            >
                {embedUrl ? (
                    <iframe
                        src={embedUrl}
                        title={t("details.video.title")}
                        style={{
                            position: "absolute",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            border: 0,
                        }}
                        allowFullScreen
                    />
                ) : (
                    <video
                        key={videoUrl}
                        controls
                        style={{
                            position: "absolute",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                        }}
                    >
                        {videoUrl && (
                            <source
                                src={videoUrl}
                                type={`video/${videoUrl.split(".").pop()}`}
                            />
                        )}
                        <track
                            kind="captions"
                            src="captions.vtt"
                            srcLang="en"
                            label="English"
                            default
                        />
                        {t("messages.noSupport")}
                    </video>
                )}
            </Box>
        </Box>
    );
};
