import { Card, Table, Text } from "@mantine/core";
import Link from "next/link";
import { useTranslations } from "next-intl";
import React from "react";

import { USER_ROLE } from "@/constants";
import { ADMIN_QUESTION_LINK, STUDENT_QUESTION_LINK } from "@/routes";
import { CommonTableProps, IScoreLabelType } from "@/types/CommonTable";
import { formatTime, getQuestionTypeLabel } from "@/utils";
import UtilLocalService from "@/utils/tools/localstorage";

export const ExamRecordsTable: React.FC<CommonTableProps> = ({
  data,
  title,
  role,
  examId,
  studentId,
  isAnalyticalWring,
}) => {
  const t = useTranslations("examDetail");
  function getScoreLabel(item: IScoreLabelType, t: Function) {
    if (item.analyticalWritingScore !== undefined) {
      return item.analyticalWritingScore !== null
        ? t("score.labels.markAlloted")
        : t("score.labels.pending");
    }
    if (item.is_attended) {
      return item.is_correct ? t("score.labels.right") : t("score.labels.wrong");
    }
    if (item.is_visited) {
      return t("score.labels.omitted");
    }
    return t("score.labels.notEncountered");
  }

  const handleOnclick = (sectionId: number) => {
    UtilLocalService.setLocalStorage("sectionId", String(sectionId));
  };

  return (
    <Card mb="xs" p="xs">
      <Text fw={600} size="md" mb="sm">
        {title}
      </Text>

      <Table striped highlightOnHover withTableBorder withColumnBorders>
        <Table.Thead>
          <Table.Tr>
            <Table.Th className="score-table-head">{t("table.question")}</Table.Th>
            <Table.Th className="score-table-head">{t("table.questionType")}</Table.Th>
            <Table.Th className="score-table-head">{t("table.category")}</Table.Th>
            {!isAnalyticalWring && (
              <Table.Th className="score-table-head">{t("table.difficulty")}</Table.Th>
            )}
            <Table.Th className="score-table-head">{t("table.answer")}</Table.Th>
            <Table.Th className="score-table-head">{t("table.time")}</Table.Th>
          </Table.Tr>
        </Table.Thead>
        <Table.Tbody>
          {data.map((item, index) => (
            <Table.Tr key={item.student_question_id}>
              <Table.Td className="question-column">
                <Link
                  className="question-table-link"
                  onClick={() => handleOnclick(item.student_exam_section_id)}
                  href={
                    role === USER_ROLE.STUDENT
                      ? STUDENT_QUESTION_LINK({
                          examId: String(examId),
                          student_question_id: item.student_question_id,
                          student_exam_section_id: item.student_exam_section_id,
                        })
                      : ADMIN_QUESTION_LINK({
                          examId: String(examId),
                          studentId: String(studentId),
                          student_question_id: item.student_question_id,
                          student_exam_section_id: item.student_exam_section_id,
                        })
                  }
                >
                  {index + 1}
                </Link>
              </Table.Td>
              <Table.Td className="question-type">
                {getQuestionTypeLabel(item.question?.question_type ?? null)}
              </Table.Td>
              <Table.Td className="question-category">
                {item.question?.questionCategory?.length
                  ? item.question.questionCategory?.map((qc) => qc.category.title).join(", ")
                  : "-"}
              </Table.Td>
              {!isAnalyticalWring && (
                <Table.Td>{item.question?.numeric_difficulty_level ?? "-"}</Table.Td>
              )}
              <Table.Td>{getScoreLabel(item, t)}</Table.Td>
              <Table.Td>{formatTime(item.time_taken || 0)}</Table.Td>
            </Table.Tr>
          ))}
        </Table.Tbody>
      </Table>
    </Card>
  );
};
