import { Box } from "@mantine/core";
import React from "react";

import { QUESTION_LAYOUT } from "@/constants";
import { FillInTheBlankInputProps } from "@/types";

import GuidelineDisplay from "../GuidelineDisplay";

const FillInTheBlankInput: React.FC<FillInTheBlankInputProps> = ({
  isQuantitiveSection,
  analyticalWriting,
  currentQ,
  renderFillInTheBlank,
}) => {
  return (
    <>
      <Box pos={"relative"} className="question-box">
        {!isQuantitiveSection &&
          !analyticalWriting &&
          currentQ?.guidelines &&
          currentQ.question_layout === QUESTION_LAYOUT.LEFTTORIGHT && (
            <GuidelineDisplay guidelines={currentQ?.guidelines ?? "No guidelines available"} />
          )}
        <Box
          p="md"
          mb="md"
          onCopy={(e) => e.preventDefault()}
          onPaste={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          className="times-font"
        >
          <Box
            dangerouslySetInnerHTML={{
              __html: currentQ?.question_text || "No question available",
            }}
            style={{ textAlign: "center" }}
            className="times-font"
          />
        </Box>
      </Box>

      {renderFillInTheBlank()}
    </>
  );
};
export default FillInTheBlankInput;
