import { Box, Text } from "@mantine/core";
import React from "react";

import TimerDisplay from "@/components/Common/Timer/index";
import { USER_ROLE } from "@/constants";
import { SectionProps } from "@/types";

const ExamTimeAndSectionDetails: React.FC<SectionProps> = ({
  role,
  sectionNumber,
  currentQ,
  currentIndex,
  questionIds,
  selectedSectionId,
  initialTimeLimit,
  handleSubmitSection,
  t,
}) => {
  const sectionDisplay = [USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role)
    ? sectionNumber
    : (currentQ?.display_order ?? "-");

  return (
    <Box className="exam-section-details">
      <Box>
        <Text size="sm" c="black">
          <Text span size="sm" fw={700}>
            {t("other.section")} {sectionDisplay} of 5
          </Text>{" "}
          | {t("other.question")} {currentIndex + 1} of {questionIds.length}
        </Text>
      </Box>
      <Box>
        <TimerDisplay
          selectedSectionId={String(selectedSectionId)}
          initialTimeLimit={initialTimeLimit}
          handleSubmitSection={handleSubmitSection}
        />
      </Box>
    </Box>
  );
};

export default ExamTimeAndSectionDetails;
