import { Box, Group, Radio, Text } from "@mantine/core";
import React from "react";

import { SingleSelectionInputProps } from "@/types";
import { IAnswerInput } from "@/types/Exam/index";

import classes from "../../Pages/PreviewSection/styles.module.css";

const SingleSelectionInput: React.FC<SingleSelectionInputProps> = ({
  currentQ,
  selectAnswer,
  isSaving,
  handleAnserChoices,
}) => {
  return (
    <Box className="answer-box single-selection">
      <Box className="answer-instructions-box mb-2">
        {currentQ?.passage_answer_instructions && (
          <Box
            dangerouslySetInnerHTML={{
              __html: currentQ?.passage_answer_instructions,
            }}
          />
        )}
      </Box>
      <Radio.Group
        size="sm"
        className={classes["radio-group"]}
        onChange={(value) => {
          const current = selectAnswer?.[0]?.answer_choice_id?.toString();
          if (value === current) {
            handleAnserChoices("", 0, "");
          } else {
            handleAnserChoices(value, 0, "");
          }
        }}
      >
        {currentQ?.AnswerChoice?.map((opt: IAnswerInput, i: number) => {
          const val = opt.answer_choice_id?.toString() ?? `${i}`;
          return (
            <Radio.Card
              key={val}
              className={classes.root}
              radius="0"
              value={val}
              checked={selectAnswer?.[0]?.answer_choice_id?.toString() === val}
              disabled={isSaving}
              style={{ cursor: isSaving ? "not-allowed" : "pointer" }}
            >
              <Group wrap="nowrap" align="flex-start" className="times-font radio-group">
                <Radio.Indicator className={classes.customRadioIndicator} />
                <Text className={classes.label}>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: opt.option_text ?? "",
                    }}
                  />
                </Text>
              </Group>
            </Radio.Card>
          );
        })}
      </Radio.Group>
    </Box>
  );
};

export default SingleSelectionInput;
