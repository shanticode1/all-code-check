"use client";

import { DateTimePicker, DateTimePickerProps } from "@mantine/dates";
import React from "react";
import { Control,Controller } from "react-hook-form";

interface RHFDateTimeFieldProps extends DateTimePickerProps {
  name: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  control: Control<{ [key: string]: any }>;
}

const DateTimeField = ({ name, control, ...others }: RHFDateTimeFieldProps) => {
  return (
    <Controller
      control={control}
      name={name}
      render={({ field, fieldState }) => (
        <DateTimePicker
          label="Pick date and time"
          placeholder="Pick date and time"
          {...others}
          value={field.value}
          onChange={field.onChange}
          error={fieldState.error?.message}
        />
      )}
    />
  );
};

export default DateTimeField;
