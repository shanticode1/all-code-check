import { DatePickerInput } from "@mantine/dates";
import React from "react";
import { Controller } from "react-hook-form";

import { FormDatePickerProps } from "@/types";

const FormDatePicker: React.FC<FormDatePickerProps> = ({
  name, control, placeholderKey, errors, disabled, minDate, isRequired, label, isClearable ,maxDate }) => {
    return (
    <Controller
      name={name}
      control={control}
      render={({ field }) => (
        <DatePickerInput
          label={label}
          {...field}
          placeholder={placeholderKey}
          onChange={(date) => {
            field.onChange(date);
          }}
          error={typeof errors?.[name]?.message === "string" ? errors[name]?.message : undefined}
          disabled={disabled}
          minDate={minDate}
          maxDate={maxDate}
          withAsterisk={isRequired}
          clearable={isClearable}
        />
      )}
    />
  );
};

export default FormDatePicker;
