"use client";
import { AppShell, Divider, Flex, NavLink, Stack } from "@mantine/core";
import {
  IconBook,
  IconBrain,
  IconFileExport,
  IconHome,
  IconSchool,
  IconSettings,
  IconUserHexagon,
} from "@tabler/icons-react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useTranslations } from "next-intl";
import React from "react";

import { USER_ROLE } from "@/constants";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import logo from "@/public/smart-heart transparent-cropped.png";
import { paths } from "@/routes";

export default function Sidebar() {
  const t = useTranslations("sidebar");
  const pathname = usePathname();

  const { role } = useAuth();

  const isStudent = typeof role === "string" && role.includes("Student");

  return (
    <AppShell.Navbar p="xs">
      <Flex justify="center" align="center">
        <Image
          src={logo}
          alt="DesignSparx logo"
          width={200}
          height={100}
          style={{ objectFit: "contain" }}
        />
      </Flex>
      <Divider my="md" />
      <Stack gap="sm">
        {isStudent ? (
          <>
            {/* Student-specific navigation */}
            <NavLink
              component={Link}
              href={paths.ROOT_DASHBOARD}
              active={pathname.includes(paths.ROOT_DASHBOARD)}
              label={t("navLink.labels.dashboard")}
              leftSection={
                <IconHome
                  size={24}
                  color={pathname.includes(paths.ROOT_DASHBOARD) ? "white" : "#abb8c3"}
                />
              }
              bg={pathname.includes(paths.ROOT_DASHBOARD) ? "#3e6494" : ""}
              color={pathname.includes(paths.ROOT_DASHBOARD) ? "white" : "#abb8c3"}
              className="nav-link"
            />
            <NavLink
              component={Link}
              href={paths.ROOT_EXAMS}
              active={pathname === paths.ROOT_EXAMS}
              label={t("navLink.labels.exams")}
              leftSection={
                <IconSchool size={24} color={pathname === paths.ROOT_EXAMS ? "white" : "#abb8c3"} />
              }
              bg={pathname === paths.ROOT_EXAMS ? "#3e6494" : ""}
              color={pathname === paths.ROOT_EXAMS ? "white" : "#abb8c3"}
              className="nav-link"
            />
            <NavLink
              component={Link}
              href={paths.ROOT_EXAMS_HISTORY}
              active={pathname === paths.ROOT_EXAMS_HISTORY}
              label={t("navLink.labels.examsHistory")}
              leftSection={
                <IconBook
                  size={24}
                  color={pathname.includes(paths.ROOT_EXAMS_HISTORY) ? "white" : "#abb8c3"}
                />
              }
              bg={pathname === paths.ROOT_EXAMS_HISTORY ? "#3e6494" : ""}
              color={pathname === paths.ROOT_EXAMS_HISTORY ? "white" : "#abb8c3"}
              className="nav-link"
            />
          </>
        ) : (
          <>
            {/* Admin-specific navigation */}
            <NavLink
              component={Link}
              href={paths.ROOT_DASHBOARD}
              active={pathname.includes(paths.ROOT_DASHBOARD)}
              label={t("navLink.labels.dashboard")}
              leftSection={
                <IconHome
                  size={24}
                  color={pathname.includes(paths.ROOT_DASHBOARD) ? "white" : "#abb8c3"}
                />
              }
              bg={pathname.includes(paths.ROOT_DASHBOARD) ? "#3e6494" : ""}
              color={pathname.includes(paths.ROOT_DASHBOARD) ? "white" : "#abb8c3"}
              className="nav-link"
            />
            {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
              <NavLink
                component={Link}
                href={paths.ROOT_ADMIN_EXAM}
                active={pathname.includes(paths.ROOT_ADMIN_EXAM)}
                label={t("navLink.labels.examManagement")}
                leftSection={
                  <IconSchool
                    size={24}
                    color={pathname.includes(paths.ROOT_ADMIN_EXAM) ? "white" : "#abb8c3"}
                  />
                }
                bg={pathname.includes(paths.ROOT_ADMIN_EXAM) ? "#3e6494" : ""}
                color={pathname.includes(paths.ROOT_ADMIN_EXAM) ? "white" : "#abb8c3"}
                className="nav-link"
              />
            )}
            <NavLink
              component={Link}
              href="/admin/student"
              active={pathname.includes("/admin/student")}
              label={t("navLink.labels.studentManagement")}
              leftSection={
                <IconUserHexagon
                  size={24}
                  color={pathname.includes("/admin/student") ? "white" : "#abb8c3"}
                />
              }
              bg={pathname.includes("/admin/student") ? "#3e6494" : ""}
              color={pathname.includes("/admin/student") ? "white" : "#abb8c3"}
              className="nav-link"
            />
            {role === USER_ROLE.SUPERADMIN && (
              <NavLink
                component={Link}
                href="/admin/user"
                active={pathname.includes("/admin/user")}
                label={t("navLink.labels.userManagement")}
                leftSection={
                  <IconUserHexagon
                    size={24}
                    color={pathname.includes("/admin/user") ? "white" : "#abb8c3"}
                  />
                }
                bg={pathname.includes("/admin/user") ? "#3e6494" : ""}
                color={pathname.includes("/admin/user") ? "white" : "#abb8c3"}
                className="nav-link"
              />
            )}

            <NavLink
              component={Link}
              href={paths.ROOT_ANALYTICAL_WRITING}
              active={pathname.includes(paths.ROOT_ANALYTICAL_WRITING)}
              label={t("navLink.labels.analyticalEvaluation")}
              leftSection={
                <IconBrain
                  size={24}
                  color={pathname.includes(paths.ROOT_ANALYTICAL_WRITING) ? "white" : "#abb8c3"}
                />
              }
              bg={pathname.includes(paths.ROOT_ANALYTICAL_WRITING) ? "#3e6494" : ""}
              color={pathname.includes(paths.ROOT_ANALYTICAL_WRITING) ? "white" : "#abb8c3"}
              className="nav-link"
            />
            {(role === USER_ROLE.SUPERADMIN || role === USER_ROLE.ADMIN) && (
              <NavLink
                component={Link}
                href={paths.ROOT_EXPORT_EXAM_HISTORY}
                active={pathname.includes(paths.ROOT_EXPORT_EXAM_HISTORY)}
                label={t("navLink.labels.exportExamHistory")}
                leftSection={
                  <IconFileExport
                    size={24}
                    color={pathname.includes(paths.ROOT_EXPORT_EXAM_HISTORY) ? "white" : "#abb8c3"}
                  />
                }
                bg={pathname.includes(paths.ROOT_EXPORT_EXAM_HISTORY) ? "#3e6494" : ""}
                color={pathname.includes(paths.ROOT_EXPORT_EXAM_HISTORY) ? "white" : "#abb8c3"}
                className="nav-link"
              />
            )}
            {role === USER_ROLE.SUPERADMIN && (
              <NavLink
                component={Link}
                href={paths.ROOT_SETTING}
                active={pathname.includes(paths.ROOT_SETTING)}
                label={t("navLink.labels.setting")}
                leftSection={
                  <IconSettings
                    size={24}
                    color={pathname.includes(paths.ROOT_SETTING) ? "white" : "#abb8c3"}
                  />
                }
                bg={pathname.includes(paths.ROOT_SETTING) ? "#3e6494" : ""}
                color={pathname.includes(paths.ROOT_SETTING) ? "white" : "#abb8c3"}
                className="nav-link"
              />
            )}
          </>
        )}
      </Stack>
    </AppShell.Navbar>
  );
}
