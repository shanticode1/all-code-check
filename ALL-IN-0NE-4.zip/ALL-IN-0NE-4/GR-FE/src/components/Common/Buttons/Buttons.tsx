import { Button, ButtonProps } from "@mantine/core";
import React from "react";

type ButtonsProps = ButtonProps;

const Buttons = ({ ...others }: ButtonsProps) => {
  return (
    <Button variant="filled" {...others}>
      {others.children || "Button"}
    </Button>
  );
};

export default Buttons;
