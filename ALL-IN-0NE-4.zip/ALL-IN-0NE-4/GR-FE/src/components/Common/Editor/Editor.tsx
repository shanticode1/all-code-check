"use client";

import tinymce from "tinymce/tinymce";
tinymce.baseURL = "/tinymce";

import "tinymce/themes/silver";
import "tinymce/icons/default";
import "tinymce/plugins/advlist";
import "tinymce/plugins/autolink";
import "tinymce/plugins/lists";
import "tinymce/plugins/link";
import "tinymce/plugins/image";
import "tinymce/plugins/charmap";
import "tinymce/plugins/preview";
import "tinymce/plugins/anchor";
import "tinymce/plugins/searchreplace";
import "tinymce/plugins/visualblocks";
import "tinymce/plugins/code";
import "tinymce/plugins/fullscreen";
import "tinymce/plugins/insertdatetime";
import "tinymce/plugins/media";
import "tinymce/plugins/table";
import "tinymce/plugins/help";
import "tinymce/plugins/wordcount";

import dynamic from "next/dynamic";
import React, { forwardRef, useCallback, useImperativeHandle, useMemo, useRef } from "react";
import type { Editor as TinyMCEEditor } from "tinymce";

import { useUploadImageMutation } from "@/hooks/file-upload";
import { CommonEditorProps, PastePostProcessEvent, TinyBlobInfo } from "@/types";

const Editor = dynamic(() => import("@tinymce/tinymce-react").then((mod) => mod.Editor), {
  ssr: false,
});

export interface CommonEditorHandle {
  getContent: () => string;
}

const EQN_EDITOR_SRC = "/tinymce/plugins/eqneditor/plugin.js";

const IMAGE_MIME_EXTENSION_MAP: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/svg+xml": "svg",
};

const getExtensionFromMime = (mime: string) => {
  if (!mime) return "bin";
  return IMAGE_MIME_EXTENSION_MAP[mime] ?? mime.split("/")[1]?.replace("+xml", "") ?? "bin";
};

const buildImageFileName = (mime: string, providedName?: string) => {
  if (providedName?.trim()) return providedName.trim();
  const extension = getExtensionFromMime(mime);
  return `editor-image-${Date.now()}.${extension}`;
};

const tinymceConfig = {
  menubar: "format",
  branding: false,
  statusbar: false,

  /* ---------- PASTE SETTINGS ---------- */
  paste_as_text: true,
  paste_strip_class_attributes: "all",
  paste_remove_styles: true,
  paste_remove_spans: true,
  paste_data_images: true,
  file_picker_types: "image",
  automatic_uploads: true,
  images_file_types: "jpg,jpeg,png,webp",

  // remove unwanted tags but keep images
  paste_preprocess: function (_: unknown, args: { content: string }) {
    const div = document.createElement("div");
    div.innerHTML = args.content;

    const removeTags = ["h1", "h2", "h3", "h4", "h5", "h6", "span", "strong", "b"];

    removeTags.forEach((tag) => {
      div.querySelectorAll(tag).forEach((el) => {
        const parent = el.parentNode;
        while (el.firstChild) {
          parent?.insertBefore(el.firstChild, el);
        }
        parent?.removeChild(el);
      });
    });

    div.querySelectorAll("*").forEach((el) => {
      el.removeAttribute("style");
      el.removeAttribute("data-mce-style");
      el.removeAttribute("class");
    });

    args.content = div.innerHTML;
  },

  external_plugins: {
    eqneditor: EQN_EDITOR_SRC,
  },

  plugins: [
    "advlist",
    "autolink",
    "lists",
    "link",
    "image",
    "charmap",
    "preview",
    "anchor",
    "searchreplace",
    "visualblocks",
    "code",
    "fullscreen",
    "insertdatetime",
    "media",
    "table",
    "help",
    "wordcount",
    "eqneditor",
  ],

  /* ---------- TOOLBAR ---------- */

  toolbar:
    "bold italic underline forecolor backcolor eqneditor | " +
    "alignleft aligncenter alignright alignjustify | " +
    "bullist numlist outdent indent | table | image | removeformat | clearContent",

  /* ---------- FONTS ---------- */

  font_family_formats:
    "Times New Roman='Times New Roman',Times,serif;" +
    "Poppins=Poppins,sans-serif;" +
    "Helvetica=Helvetica,sans-serif;" +
    "Arial=Arial,sans-serif;" +
    "Verdana=Verdana,Geneva,sans-serif;",

  font_size_formats: "8px 10px 12px 14px 16px 18px 20px 24px 36px 48px",

  menu: {
    format: {
      title: "Format",
      items: "fontfamily fontsize blocks | subscript superscript",
    },
  },

  /* ---------- EDITOR STYLE ---------- */

  skin_url: "/tinymce/skins/ui/oxide",
  content_css: "/tinymce/skins/content/default/content.css",

  content_style: `
    body {
      font-family: "Times New Roman", Times, serif;
      font-size: 18px;
    }
  `,

  /* ---------- SETUP ---------- */

  setup: function (editor: TinyMCEEditor) {
    editor.on("init", () => {
      editor.getBody().style.fontFamily = '"Times New Roman", Times, serif';
    });

    editor.on("PastePostProcess", function (e: PastePostProcessEvent) {
      const div = document.createElement("div");
      div.innerHTML = e.node.innerHTML;

      const removeTags = ["h1", "h2", "h3", "h4", "h5", "h6", "span", "strong", "b"];

      removeTags.forEach((tag) => {
        div.querySelectorAll(tag).forEach((el) => {
          const parent = el.parentNode;
          while (el.firstChild) {
            parent?.insertBefore(el.firstChild, el);
          }
          parent?.removeChild(el);
        });
      });

      div.querySelectorAll("*").forEach((el) => {
        el.removeAttribute("style");
        el.removeAttribute("data-mce-style");
        el.removeAttribute("class");
      });

      e.node.innerHTML = div.innerHTML;
    });

    editor.ui.registry.addButton("clearContent", {
      text: "Clear",
      icon: "remove",
      tooltip: "Clear all content",
      onAction: () => editor.setContent(""),
    });
  },
};

const CommonEditor = forwardRef<CommonEditorHandle, CommonEditorProps>(
  ({ placeholder = "Start writing here..", onContentChange, guidelines, height }, ref) => {
    const editorRef = useRef<TinyMCEEditor | null>(null);
    const { mutateAsync: uploadImage } = useUploadImageMutation();

    const imagesUploadHandler = useCallback(
      async (blobInfo: TinyBlobInfo) => {
        try {
          const blob = blobInfo.blob();
          const mime = blob.type || "application/octet-stream";
          const fileName = buildImageFileName(mime, blobInfo.filename?.());

          const result = await uploadImage({
            file: blob,
            fileName,
            contentType: mime,
            fileSize: blob.size,
          });

          const blobUri = blobInfo.blobUri?.();
          const editor = editorRef.current;
          if (editor && blobUri) {
            const images = editor.getBody().querySelectorAll("img");
            images.forEach((img) => {
              const currentSrc = img.getAttribute("src");
              if (currentSrc === blobUri || img.src === blobUri) {
                img.setAttribute("src", result.url);
              }
            });
          }

          return result.url;
        } catch (error) {
          console.error("TinyMCE image upload failed:", error);
          const message = error instanceof Error ? error.message : "Image upload failed";
          throw new Error(message);
        }
      },
      [uploadImage],
    );

    const editorInit = useMemo(
      () => ({
        ...tinymceConfig,
        height: height || 500,
        placeholder,
        images_upload_handler: imagesUploadHandler,
      }),
      [height, placeholder, imagesUploadHandler],
    );

    useImperativeHandle(ref, () => ({
      getContent: () => editorRef.current?.getContent() || "",
    }));

    return (
      <Editor
        value={guidelines}
        onInit={(_, editor: TinyMCEEditor) => {
          editorRef.current = editor;
        }}
        init={editorInit}
        onEditorChange={(content) => {
          if (onContentChange) {
            onContentChange(content);
          }
        }}
      />
    );
  },
);

CommonEditor.displayName = "CommonEditor";

export default CommonEditor;
