import * as CommonEditor from "./Editor";

export default CommonEditor;
