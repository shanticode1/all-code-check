import { Box } from "@mantine/core";
import { useTranslations } from "next-intl";
import React from "react";

import { QUESTION_LAYOUT, SINGLE_QUESTION_TYPES } from "@/constants";
import { QUESTION_TYPE } from "@/constants/questions";
import { QuestionsRenderProps } from "@/types";

import AnalyticalQuestion from "../AnalyticalQuestion";
import FillInTheBlankInput from "../FillInTheBlankInput";
import FractionalEntryInput from "../FractionalEntryInput";
import GuidelineDisplay from "../GuidelineDisplay";
import NumericalEntryInput from "../NumericalEntryInput";
import SingleSelectionInput from "../SingleSelectionInput";

const QuestionRenderer: React.FC<QuestionsRenderProps> = ({
  analyticalWriting,
  isFillInTheBlank,
  isQuantitiveSection,
  currentQ,
  sanitizedHTML,
  selectAnswer,
  isSaving,
  renderFillInTheBlank,
  renderMultipleSelection,
  handleAnserChoices,
  handleSentenceClick,
  text,
  role,
  textareaRef,
  buttonState,
  history,
  redoStack,
  handleCut,
  handlePaste,
  handleUndo,
  handleRedo,
  handleKeyDown,
  setEditorState,
  getNumAndDemValueFromAnswer,
}) => {
  const t = useTranslations("preview");
  if (analyticalWriting) {
    return (
      <AnalyticalQuestion
        currentQ={currentQ}
        text={text}
        role={role}
        textareaRef={textareaRef}
        buttonState={buttonState}
        history={history}
        redoStack={redoStack}
        handleCut={handleCut}
        handlePaste={handlePaste}
        handleUndo={handleUndo}
        handleRedo={handleRedo}
        handleKeyDown={handleKeyDown}
        handleAnserChoices={handleAnserChoices}
        setEditorState={setEditorState}
        t={t}
      />
    );
  }

  if (isFillInTheBlank) {
    return (
      <FillInTheBlankInput
        isQuantitiveSection={isQuantitiveSection}
        analyticalWriting={analyticalWriting}
        currentQ={currentQ}
        renderFillInTheBlank={renderFillInTheBlank}
      />
    );
  }

  return (
    <>
      <Box pos={"relative"} className="question-box">
        {!isQuantitiveSection &&
          !analyticalWriting &&
          currentQ?.guidelines &&
          currentQ.question_layout === QUESTION_LAYOUT.LEFTTORIGHT && (
            <GuidelineDisplay guidelines={currentQ?.guidelines ?? t("messages.noGuidelines")} />
          )}
        <Box
          onCopy={(e) => e.preventDefault()}
          onPaste={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          className="question-box-inner"
        >
          <Box
            dangerouslySetInnerHTML={{ __html: sanitizedHTML }}
            onClick={handleSentenceClick}
            className="times-font"
          />
        </Box>
      </Box>

      {["multipleSelection", "paragraph"].includes(currentQ?.question_type || "") &&
        renderMultipleSelection()}

      {SINGLE_QUESTION_TYPES.includes(currentQ?.question_type || "") && (
        <SingleSelectionInput
          currentQ={currentQ}
          selectAnswer={selectAnswer}
          isSaving={isSaving}
          handleAnserChoices={handleAnserChoices}
        />
      )}

      {currentQ?.question_type === QUESTION_TYPE.PARAGRAPH_SENTENCE &&
        currentQ?.passage_answer_instructions && (
          <Box className="answer-box passage-type" style={{ border: "0" }}>
            <Box
              dangerouslySetInnerHTML={{
                __html: currentQ.passage_answer_instructions,
              }}
            />
          </Box>
        )}

      {currentQ?.question_type === QUESTION_TYPE.NUMERICAL_ENTRY && (
        <NumericalEntryInput
          currentQ={currentQ}
          prefix={currentQ?.AnswerChoice[0]?.answer_prefix ?? undefined}
          suffix={currentQ?.AnswerChoice[0]?.answer_suffix ?? undefined}
          value={selectAnswer?.[0]?.answer || ""}
          onChange={(val) => handleAnserChoices(val, 0, "textInput")}
          isSaving={isSaving}
          t={t}
        />
      )}

      {currentQ?.question_type === QUESTION_TYPE.FRACTIONAL_ENTRY && (
        <FractionalEntryInput
          numeratorValue={
            selectAnswer?.[0]?.numerator ??
            getNumAndDemValueFromAnswer(selectAnswer?.[0]?.answer).numerator
          }
          denominatorValue={
            selectAnswer?.[0]?.denominator ??
            getNumAndDemValueFromAnswer(selectAnswer?.[0]?.answer).denominator
          }
          onNumeratorChange={(val) => handleAnserChoices(val, 0, "numerator")}
          onDenominatorChange={(val) => handleAnserChoices(val, 0, "denominator")}
          isSaving={isSaving}
          currentQ={currentQ}
        />
      )}
    </>
  );
};

export default QuestionRenderer;
