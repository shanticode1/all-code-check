import { Box, Button, Card, Group, Stack, Text } from "@mantine/core";
import React from "react";

import { IScoreCardProps } from "@/types/Exam/index";

export const ScoreCard: React.FC<IScoreCardProps> = ({
  math,
  verbal,
  total,
  date,
  testType,
  message,
  buttonText,
  scoreColor,
}) => {
  return (
    <Card shadow="sm" p="lg" radius="md" withBorder mb="md">
      <Group align="start" gap="lg">
        <Group gap="xl">
          <Stack gap="xs">
            <Text fw={600}>Math</Text>
            <Text fw={600}>Verbal</Text>
            <Text fw={600}>Total Score</Text>
          </Stack>

          {/* Scores column */}
          <Stack gap="xs">
            <Box
              w={50}
              h={30}
              bg={scoreColor}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "8px",
              }}
            >
              <Text size="sm" fw={600}>
                {math}
              </Text>
            </Box>
            <Box
              w={50}
              h={30}
              bg={scoreColor}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "8px",
              }}
            >
              <Text size="sm" fw={600}>
                {verbal}
              </Text>
            </Box>
            <Box
              w={50}
              h={30}
              bg={scoreColor}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "8px",
              }}
            >
              <Text size="sm" fw={600}>
                {total}
              </Text>
            </Box>
          </Stack>
        </Group>

        {/* Right side: Date, Test Type, Message and Button */}
        <Stack gap={4} align="flex-start">
          <Text fw={600}>{date}</Text>
          <Text size="xs" c="dimmed">
            {testType}
          </Text>
          <Text size="xs" c="dimmed">
            {message}
          </Text>
          <Button size="xs" variant="default" mt="xs">
            {buttonText}
          </Button>
        </Stack>
      </Group>
    </Card>
  );
};
