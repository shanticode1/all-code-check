import { CloseButton, Input } from "@mantine/core";
import { IconSearch } from "@tabler/icons-react";
import React from "react";

import type { ISearchProps } from "@/types";

const SearchInput: React.FC<ISearchProps> = ({
  placeholder = "Search...",
  className,
  value,
  handleChange,
  handleClear,
  ...props
}) => {
  return (
    <Input
      className={className}
      placeholder={placeholder}
      value={value}
      onChange={handleChange}
      leftSection={<IconSearch size={16} />}
      leftSectionPointerEvents="none"
      rightSection={
        <CloseButton
          onClick={handleClear}
          aria-label="Clear search"
          style={{ visibility: value ? "visible" : "hidden" }}
        />
      }
      rightSectionPointerEvents="all"
      {...props}
    />
  );
};

export default SearchInput;
