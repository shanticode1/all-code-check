import { Box, Button, Grid, Modal, Text, TextInput } from "@mantine/core";
import { IconAlertTriangleFilled } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import { CalculatorProps } from "@/types";

export default function Calculator({ showTransfer = false, onTransfer }: Readonly<CalculatorProps>) {
  const [display, setDisplay] = useState("0");
  const [fullExpression, setFullExpression] = useState("0"); // new state
  const [liveResult, setLiveResult] = useState("");
  const [memory, setMemory] = useState(0);
  const [memoryFlag, setMemoryFlag] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const t_calculator = useTranslations("calculator");
  const [isResultDisplayed, setIsResultDisplayed] = useState(false);
  const [operatorClicked, setOperatorClicked] = useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [lastPressed, setLastPressed] = useState<string>("");
  const [openParensCount, setOpenParensCount] = useState<number>(0);

  const evaluateExpression = (expr: string): string => {
    try {
      expr = expr.replace(/÷/g, "/").replace(/×/g, "*");

      // Remove trailing operators
      expr = expr.replace(/[+\-*/]+$/, "");

      // Handle unmatched brackets: remove excess "("
      const open = (expr.match(/\(/g) || []).length;
      const close = (expr.match(/\)/g) || []).length;
      if (open > close) {
        expr = expr + ")".repeat(open - close); // OR: expr = expr.replace(/\(+$/, "");
      }

      const cleanExpr = expr.replace(/[^-()\d/*+.]/g, "");

      const result = new Function(`return (${cleanExpr})`)();

      if (
        typeof result === "number" &&
        !isNaN(result) &&
        result !== Infinity &&
        result !== -Infinity
      ) {
        if (Math.abs(result) < 1) {
          return result.toFixed(8).replace(/\.?0+$/, "");
        } else {
          const str = parseFloat(result.toPrecision(8)).toString();
          const digitsOnly = str.replace(/\D/g, "");
          return digitsOnly.length <= 8 ? str : "Error";
        }
      }

      return "Error";
    } catch {
      return "Error";
    }
  };

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    const valid = /^[\d+\-*/.()]*$/.test(fullExpression);
    if (!valid) {
      setLiveResult("Error");
      return;
    }
    const result = evaluateExpression(fullExpression);
    if (result === "Error") {
      setLiveResult("Error");
    } else {
      setLiveResult(result);
    }
  }, [display]);

  const handleClick = (value: string) => {
    if (display === "Error" && value !== "C") return;
    const ops = "+-*/.";

    if (["MR", "MC", "M+"].includes(value)) {
      switch (value) {
        case "MC":
          setMemory(0);
          setMemoryFlag(false);
          break;
        case "MR": {
          let memStr = memory.toString();
          // Remove '-' and '.' to count only digits
          const digitCount = memStr.replace(/\D/g, "").length;
          if (digitCount <= 8) {
            if (memStr.endsWith(".0")) {
              memStr = memStr.slice(0, -2);
            }
            setDisplay(memStr);
            setFullExpression(memStr);
          } else {
            setDisplay("Error");
            setFullExpression("Error");
            // Remove trailing unnecessary ".0" for integers like 5.0 → 5
          }
          break;
        }
        case "M+": {
          const current = parseFloat(display);
          if (!isNaN(current)) {
            setMemory((prev) => prev + current);
            setMemoryFlag(true);
          }
          break;
        }
      }
      return;
    }

    switch (value) {
      case "C":
        setDisplay("0");
        setFullExpression("0");
        setLiveResult("");
        setIsResultDisplayed(false);
        setOperatorClicked(false);
        setLastPressed("");
        setOpenParensCount(0);
        break;
      case "CE":
        setDisplay((prev) => {
          const match = prev.match(/^(.*?)([+\-*/])?([0-9.]+)?$/);
          if (!match) return "0";

          const [before, op] = match;

          if (before && op) {
            return before + op;
          } else {
            return "0";
          }
        });

        setFullExpression((prev) => {
          const trimmed = prev.trim();

          // Case: number followed by operator and another number (e.g., 5 * 6)
          const match = trimmed.match(/^(.*?[+\-*/])([0-9.]+)$/);
          if (match) {
            return match[1]; // keep "5*"
          }

          // Case: ends with operator (e.g., 5*)
          const opMatch = trimmed.match(/^(.+)[+\-*/]$/);
          if (opMatch) {
            return opMatch[1]; // remove trailing operator
          }

          // Case: only a number
          const onlyNumber = trimmed.match(/^([0-9.]+)$/);
          if (onlyNumber) {
            return "0";
          }

          return "0";
        });

        setIsResultDisplayed(false);
        break;
      case "=": {
        const expression = fullExpression;

        const result = evaluateExpression(expression);

        if (result === "Error") {
          setDisplay("Error");
          setLiveResult("Error");
        } else {
          setDisplay(result);
          setLiveResult(result);
          setIsResultDisplayed(true);
          setFullExpression(result);
        }

        break;
      }
      case "±":
        setDisplay((prev) => {
          // Match number inside (
          const parenMatch = prev.match(/\((-?\d*\.?\d+)\)$/);
          if (parenMatch) {
            const original = parenMatch[1];
            const toggled = original.startsWith("-") ? original.slice(1) : "-" + original;
            return prev.replace(/\((-?\d*\.?\d+)\)$/, `(${toggled}`);
          }

          const justOpenParenMatch = prev.match(/\(\d*\.?\d+$/);
          if (justOpenParenMatch) {
            const number = justOpenParenMatch[0].slice(1); // remove (
            return `(-${number}`;
          }

          // Just a number
          const num = parseFloat(prev);
          if (!isNaN(num)) {
            return (-num).toString();
          }

          return prev;
        });

        setFullExpression((prev) => {
          // Case 1: Already wrapped in (number) → toggle sign inside
          const parenMatch = prev.match(/\((-?\d*\.?\d+)\)$/);
          if (parenMatch) {
            const original = parenMatch[1];
            const toggled = original.startsWith("-") ? original.slice(1) : "-" + original;
            return prev.replace(/\((-?\d*\.?\d+)\)$/, `(${toggled})`);
          }

          // Case 2: Just typed (9 or (3 → make it (-9), not ((-9))
          const match = prev.match(/(\()(\d*\.?\d+)$/);
          if (match) {
            const [num] = match;
            const toggled = (-parseFloat(num)).toString(); // ❗ no extra ()
            return prev.replace(/\(\d*\.?\d+$/, `(${toggled}`);
          }

          // Case 3: Normal number at end
          const plainMatch = prev.match(/(-?\d*\.?\d+)(?!.*\d)/);
          if (!plainMatch) return prev;

          const lastNumber = plainMatch[1];
          const index = prev.lastIndexOf(lastNumber);
          const toggled = (-parseFloat(lastNumber)).toString();
          const updated = prev.slice(0, index) + toggled + prev.slice(index + lastNumber.length);

          return updated;
        });

        setIsResultDisplayed(false);
        break;

      case ".":
        setDisplay((prev) => {
          const lastOpIndex = Math.max(
            prev.lastIndexOf("+"),
            prev.lastIndexOf("-"),
            prev.lastIndexOf("*"),
            prev.lastIndexOf("/"),
            prev.lastIndexOf("("),
            prev.lastIndexOf(")"),
          );
          const currentSegment = prev.slice(lastOpIndex + 1);
          if (currentSegment.includes(".")) return prev;
          const next = operatorClicked || isResultDisplayed || prev === "0" ? "0." : prev + ".";
          const digitCount = next.replace(/\D/g, "").length;
          return digitCount <= 8 ? next : prev;
        });
        setFullExpression((prev) => {
          const lastOpIndex = Math.max(
            prev.lastIndexOf("+"),
            prev.lastIndexOf("-"),
            prev.lastIndexOf("*"),
            prev.lastIndexOf("/"),
            prev.lastIndexOf("("),
            prev.lastIndexOf(")"),
          );
          const currentSegment = prev.slice(lastOpIndex + 1);
          if (currentSegment.includes(".")) return prev; // prevent multiple dots
          return prev + ".";
        });
        setOperatorClicked(false);
        setIsResultDisplayed(false);
        return;
      case "√": {
        try {
          // Match the last number segment (e.g. "4", "3.5", etc.)
          const match = fullExpression.match(/([0-9.]+)(?!.*[0-9.])/);
          if (!match) throw new Error("Invalid");

          const lastNumber = match[1];
          const index = fullExpression.lastIndexOf(lastNumber);
          const parsed = parseFloat(lastNumber);

          // 👇 Get char just before the last number segment
          const charBefore = fullExpression[index - 1] || "";

          // ✅ Determine if it's a true negative (like -4, -1234)
          const isTrueNegative =
            charBefore === "-" && !/[0-9)]/.test(fullExpression[index - 2] || "");

          if (isNaN(parsed) || parsed < 0 || isTrueNegative) {
            throw new Error("Negative not allowed");
          }

          const sqrtVal = Math.sqrt(parsed);
          const sqrtStr = sqrtVal.toString();
          const [intPart, decPart = ""] = sqrtStr.split(".");
          const intDigits = intPart.length;

          if (intDigits > 8) throw new Error("Too many digits");

          const allowedDecimals = 8 - intDigits;
          const trimmed = decPart.slice(0, allowedDecimals);
          const final = trimmed ? `${intPart}.${trimmed}` : intPart;

          setDisplay(final);
          const updatedExpr =
            fullExpression.slice(0, index) +
            final +
            fullExpression.slice(index + lastNumber.length);
          setFullExpression(updatedExpr);
          setIsResultDisplayed(true);
        } catch {
          setDisplay("Error");
          setFullExpression("Error");
          setIsResultDisplayed(true);
        }
        break;
      }

      default:
        if (ops.includes(value)) {
          setOperatorClicked(true);
          setIsResultDisplayed(false);
          setFullExpression((prev) => {
            const lastChar = prev.slice(-1);
            if (ops.includes(lastChar)) {
              return prev.slice(0, -1) + value; // replace last operator with new one
            }
            return prev + value;
          });

          return;
        }
        if (isResultDisplayed) {
          setIsResultDisplayed(false);
        }
        setDisplay((prev) => {
          const next = operatorClicked || isResultDisplayed || prev === "0" ? value : prev + value;
          const digitCount = next.replace(/\D/g, "").length;
          if (digitCount > 8) return prev;
          return next;
        });

        setFullExpression((prev) => {
          const operators = ["+", "-", "*", "/", "(", ")"];
          const hasOperator = operators.some((op) => prev.includes(op));

          // If there's no operator and the previous value is a number (result), reset with current value
          if (!hasOperator && isResultDisplayed) {
            return value;
          }

          const lastOpIndex = Math.max(
            prev.lastIndexOf("+"),
            prev.lastIndexOf("-"),
            prev.lastIndexOf("*"),
            prev.lastIndexOf("/"),
            prev.lastIndexOf("("),
            prev.lastIndexOf(")"),
          );

          const currentSegment = prev.slice(lastOpIndex + 1);
          const digitCount = currentSegment.replace(/\D/g, "").length;

          // Allow max 8 digits in current segment
          if (/^\d$/.test(value) && digitCount >= 8) {
            return prev;
          }

          // Handle leading zero or fresh start
          if (prev === "0") return value;

          return prev + value;
        });

        if (value === "(") {
          setOpenParensCount((prev) => prev + 1);
        }

        if (value === ")") {
          if (lastPressed === "(") {
            setFullExpression("0");
            setDisplay("0");
            setOpenParensCount(0);
            setLiveResult("");
            setIsResultDisplayed(false);
            setLastPressed(")");
            return;
          }
          setOpenParensCount((prev) => Math.max(prev - 1, 0));
        }

        setLastPressed(value);
        setOperatorClicked(false);
        break;
    }
  };
  const buttons = [
    [
      { label: "MR", class: "btn-calc-action" },
      { label: "MC", class: "btn-calc-action" },
      { label: "M+", class: "btn-calc-action" },
      { label: "(", class: "btn-functional" },
      { label: ")", class: "btn-functional" },
    ],
    [
      { label: "7", class: "btn-calc-digit" },
      { label: "8", class: "btn-calc-digit" },
      { label: "9", class: "btn-calc-digit" },
      { label: "/", class: "btn-functional" },
      { label: "C", class: "btn-calc-action-secondary" },
    ],
    [
      { label: "4", class: "btn-calc-digit" },
      { label: "5", class: "btn-calc-digit" },
      { label: "6", class: "btn-calc-digit" },
      { label: "*", class: "btn-functional" },
      { label: "CE", class: "btn-calc-action-secondary" },
    ],
    [
      { label: "1", class: "btn-calc-digit" },
      { label: "2", class: "btn-calc-digit" },
      { label: "3", class: "btn-calc-digit" },
      { label: "-", class: "btn-functional" },
      { label: "√", class: "btn-functional" },
    ],
    [
      { label: "±", class: "btn-functional" },
      { label: "0", class: "btn-calc-digit" },
      { label: ".", class: "btn-calc-digit" },
      { label: "+", class: "btn-functional" },
      { label: "=", class: "btn-calc-action" },
    ],
  ];
  function formatLabel(label: string) {
    if (label === "*") return "×";
    if (label === "/") return "÷";
    return label;
  }
  
  return (
    <Box>
      <TextInput
        ref={inputRef}
        leftSection={memoryFlag ? <span style={{ fontWeight: "bold" }}>M</span> : null}
        value={display}
        onChange={(e) => {
          let value = e.currentTarget.value;
          value = value.replace(/[^0-9+\-*/().]/g, "");

          if (value.startsWith("0") && value.length > 1 && !value.startsWith("0.")) {
            value = value.replace(/^0+/, "");
            if (value === "") value = "0";
          }

          const digitCount = value.replace(/\D/g, "").length;
          if (digitCount <= 8) {
            setDisplay(value || "0");
          }
        }}
        size="lg"
        mb="sm"
        styles={{
          input: {
            textAlign: "right",
            fontWeight: "bold",
            caretColor: "transparent",
            userSelect: "none",
          },
        }}
        onKeyDown={(e) => {
          if (display === "Error") {
            e.preventDefault(); // Stop all keys
            return;
          }
          const allowedKeys = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
          const allowedOps = ["+", "-", "*", "/", ".", "(", ")", "Enter", "Backspace", "Delete"];

          // Numbers
          if (allowedKeys.includes(e.key)) {
            e.preventDefault();
            if (display === "0" || isResultDisplayed) {
              setDisplay(e.key);
              setFullExpression(e.key);
              setIsResultDisplayed(false);
            } else {
              handleClick(e.key);
            }
            return;
          }

          // Operators and symbols
          if (allowedOps.includes(e.key)) {
            e.preventDefault();

            if (e.key === "Enter") {
              handleClick("=");
            } else if (e.key === "Backspace") {
              setDisplay((prev) => (prev.length > 1 ? prev.slice(0, -1) : "0"));
              setFullExpression((prev) => (prev.length > 1 ? prev.slice(0, -1) : "0"));
            } else if (e.key === "Delete") {
              setDisplay("0");
              setFullExpression("0");
            } else {
              handleClick(e.key);
            }
            return;
          }

          // Prevent all other keys
          e.preventDefault();
        }}
      />

      <Grid gutter="2px">
        {buttons.flat().map((btn) => (
          <Grid.Col span={12 / 5} m={0} p={"2px"}>
            <Button
              className={btn.class}
              disabled={
                (btn.label === "(" && lastPressed === "(") ||
                (btn.label === ")" && openParensCount === 0)
              }
              styles={{
                root: {
                  fontWeight: "400",
                  minWidth: "40px",
                  minHeight: "40px",
                  padding: "4px",
                  fontSize: "18px",
                  borderRadius: "4px",
                  border: "1px solid transparent",
                  boxShadow:
                    "inset -1px -1px 0 #a7a4a9, inset -1px 1px 0 #edf1f5, inset 1px -1px 0 #edf1f5, inset 1px 1px 0 #a7a4a9;",
                },
              }}
              onClick={() => handleClick(btn.label)}
            >
              {formatLabel(btn.label)}
            </Button>
          </Grid.Col>
        ))}
      </Grid>

      <Button
        mt="md"
        fullWidth
        disabled={!showTransfer}
        style={{
          backgroundColor: "#47565e",
          color: "#d7d7d7",
          fontWeight: "bold",
          fontSize: "21px",
          borderRadius: "4px",
          minHeight: "42px",
        }}
        onClick={() => {
          const isInvalidTransfer = !liveResult || liveResult === "Error" || display === "Error";
          if (isInvalidTransfer) {
            setShowModal(true);
            return;
          }
          let cleanDisplay = display.trim();
          // Remove surrounding parentheses if any (like "(9)" or "9)")
          if (/^\(+[0-9.]+\)*$/.test(cleanDisplay)) {
            cleanDisplay = cleanDisplay.replace(/[()]/g, "");
          }
          // Remove trailing dots (e.g., "9." → "9")
          cleanDisplay = cleanDisplay.replace(/\.$/, "");

          if (onTransfer) {
            setDisplay(cleanDisplay);
            onTransfer(cleanDisplay);
          }
        }}
      >
        {t_calculator("button")}
      </Button>

      <Modal
        opened={showModal}
        onClose={() => {}}
        withCloseButton={false}
        closeOnClickOutside={false}
        closeOnEscape={false}
        styles={{
          content: {
            padding: 0,
            borderRadius: 8,
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
            width: 360,
          },
          header: { display: "none" },
          body: { padding: 0 },
        }}
      >
        <Box
          bg="#fff3cd"
          px="md"
          py={12}
          style={{
            borderBottom: "1px solid #f0c36d",
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <IconAlertTriangleFilled size={18} color="#856404" />
          <Text fw={700} size="sm" c="#856404">
            {t_calculator("heading")}
          </Text>
        </Box>
        <Box px="md" py="md" bg="white">
          <Text size="sm" c="dimmed">
            {t_calculator("body")}
          </Text>

          <Box mt="md" style={{ display: "flex", justifyContent: "flex-end" }}>
            <Button
              variant="filled"
              color="blue"
              size="xs"
              onClick={() => setShowModal(false)}
              style={{ minWidth: 60 }}
            >
              OK
            </Button>
          </Box>
        </Box>
      </Modal>
    </Box>
  );
}
