import { Flex, Grid, TextInput } from "@mantine/core";
import React from "react";

import { IParagraphInputProps } from "@/types/answer.types";
import { IAnswerInput } from "@/types/Exam/ViewExam";

export default function FractionalInput({
  handleAnswerChoices,
  answerChoice,
}: Readonly<IParagraphInputProps>) {
  const blockNonDigits = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key.length === 1 && !/^[a-zA-Z0-9-+]$/.test(e.key)) {
      e.preventDefault();
    }
    if (e.key === "-") {
      const isAtStart = e.currentTarget.selectionStart === 0;
      const alreadyHasMinus = e.currentTarget.value.includes("-");
      if (!isAtStart || alreadyHasMinus) {
        e.preventDefault();
      }
    }
  };
  return (
    <Grid.Col span={12}>
      {answerChoice.map((fraction: IAnswerInput, index: number) => (
        <div
          key={fraction.questionId}
          style={{
            display: "flex",
            gap: "10px",
            alignItems: "center",
            marginBottom: "10px",
            position: "relative",
          }}
        >
          <Flex direction="column" style={{ flex: 1, gap: "5px" }}>
            <TextInput
              label={index === 0 ? "Numerator" : "Denominator"}
              placeholder="Enter a whole number"
              inputMode="numeric"
              pattern="-?[0-9]{1,4}"
              onKeyDown={blockNonDigits}
              onChange={(e) => {
                let value = e.target.value;

                // Only allow up to 4 digits, with optional leading minus (total length max 5)
                if (value.startsWith("-")) {
                  value =
                    "-" +
                    value
                      .slice(1)
                      .replace(/\D/g, "")
                      .slice(0, 4);
                  if (value.length > 5) value = value.slice(0, 5); // "-1234"
                } else {
                  value = value.replace(/\D/g, "").slice(0, 4);
                }

                if (index === 1 && /^-?0+$/.test(value)) {
                  return;
                }

                handleAnswerChoices(value.toLowerCase(), index);
              }}
              onPaste={(e) => {
                e.preventDefault();
                const pasted = e.clipboardData.getData("text");
                let sanitized = pasted;

                // Only allow up to 4 digits, with optional leading minus (total length max 5)
                if (sanitized.startsWith("-")) {
                  sanitized =
                    "-" +
                    sanitized
                      .slice(1)
                      .replace(/\D/g, "")
                      .slice(0, 4);
                  if (sanitized.length > 5) sanitized = sanitized.slice(0, 5); // "-1234"
                } else {
                  sanitized = sanitized.replace(/\D/g, "").slice(0, 4); // "1234"
                }

                // Prevent denominator from being zero
                if (index === 1 && (sanitized === "0" || sanitized === "-0")) {
                  return;
                }
                handleAnswerChoices(sanitized, index);
              }}
              onCopy={(e) => e.preventDefault()}
              onCut={(e) => e.preventDefault()}
              value={fraction.option_text ?? ""}
              style={{ flex: 1 }}
            />
            {answerChoice[index]?.error && (
              <p style={{ color: "red", fontSize: "14px", margin: 0 }}>
                {answerChoice[index].error}
              </p>
            )}
          </Flex>
        </div>
      ))}
    </Grid.Col>
  );
}
