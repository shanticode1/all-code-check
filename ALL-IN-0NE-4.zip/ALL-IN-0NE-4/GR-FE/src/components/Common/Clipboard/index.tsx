import { Button,Flex } from "@mantine/core";
import React from "react";

import { CLIPBOARD_ACTION } from "@/constants";
import { ClipboardButtonGroupProps } from "@/types";

const Clipboard: React.FC<ClipboardButtonGroupProps> = ({
  onCut,
  onPaste,
  onUndo,
  onRedo,
  disablePaste = false,
  disableUndo = false,
  disableRedo = false,
  labels = {},
}) => {
  return (
    <Flex justify="flex-start" align="center" className="writing-buttons-container">
      <Button variant="default" className="writing-button" onClick={onCut}>
        {labels.cut || CLIPBOARD_ACTION.CUT}
      </Button>
      <Button
        variant="default"
        className="writing-button"
        onClick={onPaste}
        disabled={disablePaste}
      >
        {labels.paste || CLIPBOARD_ACTION.PASTE}
      </Button>
      <Button
        variant="default"
        className="writing-button"
        onClick={onUndo}
        disabled={disableUndo}
      >
        {labels.undo || CLIPBOARD_ACTION.UNDO}
      </Button>
      <Button
        variant="default"
        className="writing-button"
        onClick={onRedo}
        disabled={disableRedo}
      >
        {labels.redo || CLIPBOARD_ACTION.REDO}
      </Button>
    </Flex>
  );
};

export default Clipboard;
