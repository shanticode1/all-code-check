"use client";
import {
  ActionIcon,
  AppShell,
  Avatar,
  Button,
  Flex,
  Group,
  Menu,
  Tooltip,
  useMantineTheme,
} from "@mantine/core";
import { notifications } from "@mantine/notifications";
import { IconSquareRoundedChevronLeft, IconSquareRoundedChevronRight } from "@tabler/icons-react";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { useTranslations } from "next-intl";
import React, { useEffect, useState } from "react";

import { USER_ROLE } from "@/constants";
import { useLogoutMutation } from "@/hooks/auth";
import { useAuth } from "@/lib/Contexts/AuthProvider";
import sherpaPreplogo from "@/public/sharp-logo-white.png";
import logo from "@/public/smart-with-heart-logo.jpg";
import { paths } from "@/routes";

import { ConfirmationModal } from "../Modals";

interface HeaderProps {
  onToggleSidebar: () => void;
  sidebarOpen: boolean;
  setSidebarOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

export default function Header({ onToggleSidebar, sidebarOpen, setSidebarOpen }: Readonly<HeaderProps>) {
  const router = useRouter();
  const { mutateAsync: logout } = useLogoutMutation();
  const theme = useMantineTheme();
  const { userData, role } = useAuth();
  const pathname = usePathname();
  const isSidebarDisabled = role === USER_ROLE.STUDENT && pathname.includes("/exams/");
  const [showWarningModal, setShowWarningModal] = useState(false);
  const t = useTranslations("generic");

  useEffect(() => {
    if (isSidebarDisabled) {
      setSidebarOpen(false);
    }
  }, [isSidebarDisabled]);

  const handleProfileClick = () => {
    if (pathname.includes("/exams/section/") && role === USER_ROLE.STUDENT) {
      setShowWarningModal(true);
      return;
    }
    if (
      userData?.role === USER_ROLE.SUPERADMIN ||
      userData?.role === USER_ROLE.ADMIN ||
      userData?.role === USER_ROLE.INSTRUCTOR
    ) {
      router.push("/admin/profile");
    } else if (userData?.role === USER_ROLE.STUDENT) {
      router.push("/profile");
    }
  };

  const confirmLeave = () => {
    setShowWarningModal(false);
    router.push(paths.ROOT_PROFILE);
  };

  const handleLogout = async () => {
    await logout();
    if (
      role === USER_ROLE.SUPERADMIN ||
      role === USER_ROLE.ADMIN ||
      role === USER_ROLE.INSTRUCTOR
    ) {
      router.push(paths.ROOT_LOGIN);
    } else {
      router.push(paths.ROOT_STUDENT_LOGIN);
    }
    notifications.show({
      title: "Success",
      message: "You have successfully logged out.",
      color: "green",
    });
  };

  return (
    <AppShell.Header
      p="xs"
      style={{
        height: 60,
        backgroundColor: theme.white,
        boxShadow: theme.shadows.sm,
        display: isSidebarDisabled ? "none" : "block",
      }}
    >
      <Flex gap="sm" align="center" justify="space-between">
        <Group align="center">
          <ActionIcon onClick={onToggleSidebar} disabled={isSidebarDisabled} size="lg">
            {sidebarOpen ? (
              <IconSquareRoundedChevronLeft size={28} />
            ) : (
              <IconSquareRoundedChevronRight size={28} />
            )}
          </ActionIcon>
          <Image
            src={sherpaPreplogo}
            alt="Sherpa Prep logo"
            width={140}
            height={40}
            style={{ objectFit: "contain", marginLeft: 10 }}
          />
          {!sidebarOpen && (
            <Image
              src={logo}
              alt="DesignSparx logo"
              width={140}
              height={40}
              style={{ objectFit: "contain" }}
            />
          )}
        </Group>
        <Group align="center">
          <Menu shadow="md" width={200}>
            <Menu.Target>
              <Tooltip
                label={
                  role === USER_ROLE.STUDENT ? (
                    <div>
                      <div>{userData?.name}</div>
                      <div style={{ fontSize: 12, fontWeight: 800 }}>{userData?.email}</div>
                    </div>
                  ) : (
                    "Profile Settings"
                  )
                }
                multiline
                withArrow
              >
                <div>
                  <Avatar
                    radius="xl"
                    style={{
                      cursor: role === USER_ROLE.STUDENT ? "not-allowed" : "pointer",
                      opacity: role === USER_ROLE.STUDENT ? 0.6 : 1,
                    }}
                    onClick={role === USER_ROLE.STUDENT ? undefined : handleProfileClick}
                  />
                </div>
              </Tooltip>
            </Menu.Target>
          </Menu>
          {/* )} */}
          <Button onClick={handleLogout} variant="outline" color="red" style={{ marginLeft: 10 }}>
            {t("header.menu.button.Logout")}
          </Button>
        </Group>
        {showWarningModal && (
          <ConfirmationModal
            opened={showWarningModal}
            title={t("header.modal.title")}
            description={t("header.modal.description")}
            onCancel={() => setShowWarningModal(false)}
            onConfirm={confirmLeave}
          />
        )}
      </Flex>
    </AppShell.Header>
  );
}
