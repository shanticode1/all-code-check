import { ActionIcon, Box, Flex, Paper } from "@mantine/core";
import { IconX } from "@tabler/icons-react";
import React from "react";
import Draggable from "react-draggable";

import { USER_ROLE } from "@/constants";
import { CalculatorProps } from "@/types/exam";

import Calculator from "../Calculator/Calculator";

const DraggableCalculator: React.FC<CalculatorProps> = ({
  opened,
  setOpened,
  draggableRef,
  currentQ,
  role,
  handleAnserChoices,
}) => {
  if (!opened) return null;

  return (
    <Draggable handle=".drag-handle" nodeRef={draggableRef}>
      <Paper
        ref={draggableRef}
        style={{
          position: "fixed",
          top: 120,
          right: 30,
          zIndex: 1000,
          width: 250,
        }}
        radius="md"
        shadow="md"
        className="calculator-box"
      >
        <Box
          className="drag-handle"
          px="sm"
          py={4}
          style={{
            cursor: "move",
            borderTopLeftRadius: 8,
            borderTopRightRadius: 8,
          }}
        >
          <Flex justify="end" align="center">
            <ActionIcon
              variant="light"
              color="#444"
              size="sm"
              onClick={() => setOpened(false)}
              title="Close Calculator"
              style={{
                border: "1px solid #444444",
                borderRadius: "0",
                backgroundColor: "transparent",
              }}
            >
              <IconX size={30} />
            </ActionIcon>
          </Flex>
        </Box>

        <Box p="sm" py={0} bg="#d3d3d3">
          <Calculator
            showTransfer={
              currentQ?.question_type === "numericalEntry" && role === USER_ROLE.STUDENT
            }
            onTransfer={(calcValue: string) => {
              handleAnserChoices(calcValue, 0, "textInput");
            }}
          />
        </Box>
      </Paper>
    </Draggable>
  );
};

export default DraggableCalculator;
