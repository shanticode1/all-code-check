import { Button, Flex, Grid, TextInput } from "@mantine/core";
import { IconSquareXFilled } from "@tabler/icons-react";
import React from "react";

import { IParagraphInputProps } from "@/types/answer.types";
import { IAnswerInput } from "@/types/Exam/ViewExam";

export default function ParagraphInput({
  handleAnswerChoices,
  answerChoice,
}: Readonly<IParagraphInputProps>) {
  return (
    <Grid.Col span={12}>
      {answerChoice.map((paragraph: IAnswerInput, index: number) => (
        <div
          key={paragraph.questionId}
          style={{
            display: "flex",
            gap: "10px",
            alignItems: "center",
            marginBottom: "10px",
            position: "relative",
          }}
        >
          <Flex direction="column" style={{ flex: 1, gap: "5px" }}>
            <TextInput
              label={`Paragraph ${index + 1}`}
              placeholder="Enter the paragraph text"
              value={paragraph.option_text ?? ""}
              onChange={(e) => {
                handleAnswerChoices(e.target.value, index);
              }}
              style={{ flex: 1 }}
            />
            {answerChoice[index]?.error && (
              <p style={{ color: "red", fontSize: "14px", margin: 0 }}>
                {answerChoice[index].error}
              </p>
            )}
          </Flex>
          {/* Remove Button (Disabled if only one input remains) */}
          <Button
            variant="transparent"
            size="xs"
            color="red"
            disabled={answerChoice?.length === 1}
            onClick={() => handleAnswerChoices("", index, "removeOption")}
            className="remove-option-button"
            style={{ right: "-10px", top: "10px" }}
          >
            <IconSquareXFilled size={25} />
          </Button>
        </div>
      ))}
    </Grid.Col>
  );
}
