import { Text } from "@mantine/core";
import { IconClock } from "@tabler/icons-react";
import { usePathname } from "next/navigation";
import React, { memo, useEffect, useState } from "react";

import useSectionTimer from "@/hooks/common/useSectionTimer";
import { TimerDisplayProps } from "@/types";
import { formatTime } from "@/utils";
import UtilLocalService from "@/utils/tools/localstorage";

const TimerDisplay = ({ secondsRemaining ,selectedSectionId ,initialTimeLimit ,handleSubmitSection}: TimerDisplayProps) => {
  const [isVisible, setIsVisible] = useState<boolean>(() => {
    const stored = UtilLocalService.getLocalStorage("is_visible_timer");
    return stored === null ? true : stored === "true"; // stored is string
  });
  
  const pathname = usePathname();
  const showOnlySecondsRemaining = /^\/exam\/[^/]+\/question\/[^/]+$/.test(pathname);
  const { timer } = useSectionTimer(selectedSectionId ?? "", initialTimeLimit ?? null);
  useEffect(() => {
    if (timer=== 0) {
      handleSubmitSection && handleSubmitSection();
    }
  }, [timer]);
  const toggleTimerVisibility = () => {
    const newValue = !isVisible;
    setIsVisible(newValue);
    UtilLocalService.setLocalStorage("is_visible_timer", newValue.toString());
  };
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "end",
        minWidth: 100,
        gap: 10,
      }}
    >
      {isVisible && (
        <div style={{ display: "flex", alignItems: "center" }}>
          <IconClock size={20} />
          <Text component="span" pl="sm" fw={700}>
            {formatTime(showOnlySecondsRemaining ? secondsRemaining ?? 0 : secondsRemaining ?? timer ?? 0)}
          </Text>
        </div>
      )}
      <Text span size="sm" fw={700} onClick={toggleTimerVisibility} style={{ cursor: "pointer" }}>
        {isVisible ? "Hide Timer" : "Show Timer"}
      </Text>
    </div>
  );
};

export default memo(TimerDisplay);
