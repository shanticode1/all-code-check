import { Box, Text } from "@mantine/core";
import React from "react";

import { USER_ROLE } from "@/constants";
import { AnalyticalProps, EditorState } from "@/types";

import Clipboard from "../Clipboard";

const AnalyticalQuestion: React.FC<AnalyticalProps> = ({
  currentQ,
  text,
  role,
  textareaRef,
  buttonState,
  history,
  redoStack,
  handleCut,
  handlePaste,
  handleUndo,
  handleRedo,
  handleKeyDown,
  handleAnserChoices,
  setEditorState,
  t
}) => {
  return (
    <>
      <Box style={{ width: "405.5px" }}>
        <Box className="guideline-box guideline-box-analytic">
          <Text>
            <span
              dangerouslySetInnerHTML={{
                __html: currentQ?.question_text || t("messages.noPrompt"),
              }}
            ></span>
          </Text>
        </Box>
        <Box
          p="0 10.22px"
          onCopy={(e) => e.preventDefault()}
          onPaste={(e) => e.preventDefault()}
          onCut={(e) => e.preventDefault()}
          className="times-font"
        >
          <Text>
            <span>{currentQ?.guidelines ?? t("messages.noGuidelines")}</span>
          </Text>
        </Box>
      </Box>

      <Box
        ml="4px"
        style={{
          border: "1px solid #000",
          width: "608.5px",
          paddingBottom: "8px",
          backgroundColor: [USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role)
            ? "#f5f5f5"
            : "inherit",
        }}
      >
        <Clipboard
          onCut={handleCut}
          onPaste={handlePaste}
          onUndo={handleUndo}
          onRedo={handleRedo}
          disablePaste={!buttonState.paste}
          disableUndo={history.length === 0}
          disableRedo={redoStack.length === 0}
        />

        {!([USER_ROLE.SUPERADMIN, USER_ROLE.ADMIN].includes(role)) ? (
          <textarea
            ref={textareaRef}
            placeholder={t("input.analyticalWritingPlaceholder")}
            className="analyticwriting-textarea"
            value={text}
            onSelect={(e) => {
              const target = e.target as HTMLTextAreaElement;
              setEditorState((prev: EditorState) => ({
                ...prev,
                selection: [target.selectionStart, target.selectionEnd],
              }));
            }}
            onChange={(e) => {
              const value = e.target.value;
              setEditorState((prev: EditorState) => ({
                ...prev,
                text: value,
                history: [...prev.history, prev.text],
                redoStack: [],
                buttonState: {
                  ...prev.buttonState,
                  cut: value.length > 0,
                },
              }));
              handleAnserChoices(value, 0, "textInput");
            }}
            onCopy={(e) => e.preventDefault()}
            onPaste={(e) => e.preventDefault()}
            onCut={(e) => e.preventDefault()}
            onKeyDown={handleKeyDown}
          />
        ) : (
          <Text p="sm" className="no-response">
            {text || t("messages.noResponse")}
          </Text>
        )}
      </Box>
    </>
  );
};

export default AnalyticalQuestion;
