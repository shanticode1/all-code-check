import { Box, Flex, Table, Text } from "@mantine/core";
import React from "react";

import { CommonTableProps } from "@/types/section.types"


export function SectionTable<T>({ title, data, columns, section }: Readonly<CommonTableProps<T>>) {
  return (
    <div style={{ marginBottom: "2rem" }}>
      {title && (
        <Box mb="sm">
          <Flex direction={"row"}>
            <Box miw="20%">
              <Text fw={600} size="md">
                {title}
              </Text>
            </Box>
            {section === "analytical-writing" && (
              <>
                <Box miw="40%" pl="10px">
                  <Text fw={600} size="sm">
                    Category
                  </Text>
                </Box>
                <Box miw="30%" pl="20px">
                  <Text fw={600} size="sm">
                    Status
                  </Text>
                </Box>
                <Box miw="10%">
                  <Text fw={600} size="sm">
                    Duration
                  </Text>
                </Box>
              </>
            )}
          </Flex>
        </Box>
      )}

      <Table striped withTableBorder highlightOnHover>
        <colgroup>
          <col style={{ width: "20%" }} />
          <col style={{ width: "30%" }} />
          <col style={{ width: "30%" }} />
          <col style={{ width: "20%" }} />
        </colgroup>
        <Table.Thead>
        <Table.Tr>
          <Table.Th>Number</Table.Th>
          <Table.Th></Table.Th>
          <Table.Th>Status</Table.Th>
          <Table.Th>Marked</Table.Th>
        </Table.Tr>
      </Table.Thead>
        <Table.Tbody>
          {data?.map((item, idx) => (
            <Table.Tr key={idx}>
              {columns?.map((col, colIdx) => (
                <Table.Td key={col.title}>{col.render(item, idx)}</Table.Td>
              ))}
            </Table.Tr>
          ))}
        </Table.Tbody>
      </Table>
    </div>
  );
}
