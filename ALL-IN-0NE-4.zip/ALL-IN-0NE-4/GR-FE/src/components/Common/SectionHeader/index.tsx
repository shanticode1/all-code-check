import { Box, Text } from "@mantine/core";
import React from "react";

import { SectionHeaderProps } from "@/types/section.types";


const SectionHeader: React.FC<SectionHeaderProps> = ({ title, children }) => {
    return (
        <Box
            p="xs"
            bg={"#3e6494"}
            w="100%"
            display="flex"
            style={{
                borderTopLeftRadius: "8px",
                borderTopRightRadius: "8px",
                minHeight: "60px",
                alignItems: "center",
                justifyContent: "space-between"
            }}
        >
            <Text size="md" c="white" fw={600}>
                {title}
            </Text>
            {children}
        </Box>
    );
};

export default SectionHeader;