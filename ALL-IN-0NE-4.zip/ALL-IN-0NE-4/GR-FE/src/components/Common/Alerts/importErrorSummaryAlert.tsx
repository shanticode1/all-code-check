import { Alert, Container, List, ThemeIcon,Title } from '@mantine/core';
import { IconAlertCircle, IconAlertTriangle } from '@tabler/icons-react';
import React,{ FC } from 'react';

interface ImportErrorSummaryProps {
  errorMessages: string[] | undefined;
  handleEmptyErrorSummary: () => void;
}
const ImportErrorSummary: FC<ImportErrorSummaryProps> = ({
  errorMessages,
  handleEmptyErrorSummary
}) => {
  return (
    <Container size="sm" py="xl"  mt="md">
      <Title  style={{ color: 'red' }} mb="md">
        Import Failed
        <ThemeIcon color="yellow" size={12} radius="xl" style={{ marginBottom: '20px',cursor:'pointer',position: "absolute" }} title="Please review and correct the following data,Re-upload it.">
          <IconAlertCircle color='yellow' size={14} />
        </ThemeIcon>
      </Title>
      <Alert 
        icon={<IconAlertTriangle size={20} />} 
        title="Data Validation Errors" 
        color="red" 
        radius="md" 
        withCloseButton 
        onClick={() => handleEmptyErrorSummary()}
      >
        <List spacing="sm" size="sm" withPadding> 
          {errorMessages?.map((msg, index) => (
        <List.Item
          key={msg + index}
          icon={
            <ThemeIcon color="red" size={20} radius="xl">
          <IconAlertTriangle size={14} />
            </ThemeIcon>
          }
        >
          {msg}
        </List.Item>
          ))}
        </List>
      </Alert>
    </Container>
  );
}

export default ImportErrorSummary;
