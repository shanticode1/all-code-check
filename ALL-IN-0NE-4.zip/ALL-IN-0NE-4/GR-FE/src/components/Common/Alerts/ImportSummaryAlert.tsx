
import { List, Paper,Text, ThemeIcon } from '@mantine/core';
import { IconAlertCircle, IconInfoCircle } from '@tabler/icons-react';
import { useTranslations } from 'next-intl';
import React, { FC } from 'react';

import type { ImportSummaryProps } from '@/types/Profile';

const ImportSummary: FC<ImportSummaryProps> = ({
  summary
}) => {
  const t = useTranslations('generic');
  return (
    <Paper shadow="xs" p="md" withBorder mt="md">
      <Text size="xl" fw={700} mb="sm">
        {t('file.importText.text')}
      </Text>

      <Text c="green" fw={500}>
        ✅  {t('file.importText.created')}: {summary.created}
      </Text>

      <Text c="red" fw={500}>
        ❌ {t('file.importText.failed')}: {summary.failed}
      </Text>

      {summary.failedDetails.length > 0 && (
        <>
          <Text mt="md" fw={500} c="red">{t('file.importText.failedDetails')}:
            <ThemeIcon color="yellow" size={12} radius="xl" style={{ marginBottom: '20px', cursor: 'pointer', position: "absolute" }} title="Please review and correct the following data,Re-upload it.">
              <IconAlertCircle color='yellow' size={14} />
            </ThemeIcon></Text>
          <List
            icon={<ThemeIcon color="red" size={20}><IconAlertCircle size={16} /></ThemeIcon>}
            spacing="xs"
          >
            {summary.failedDetails.map((detail) => (
              <List.Item key={detail.index}>
                {JSON.stringify(detail)}
              </List.Item>
            ))}
          </List>
        </>
      )}

      {summary.alreadyExists.length > 0 && (
        <>
          <Text mt="md" fw={500} c="orange">{t('file.importText.alreadyExists')}:
            <ThemeIcon color="yellow" size={12} radius="xl" style={{ marginBottom: '20px', cursor: 'pointer', position: "absolute" }} title="Please review and correct the following data,Re-upload it.">
              <IconAlertCircle color='yellow' size={14} />
            </ThemeIcon>
          </Text>
          <List
            icon={<ThemeIcon color="orange" size={20}><IconInfoCircle size={16} /></ThemeIcon>}
            spacing="xs"
          >
            {summary.alreadyExists.map((entry) => (
              <List.Item key={entry.email}>
                {entry.email}
              </List.Item>
            ))}
          </List>
        </>
      )}
    </Paper>
  );
};

export default ImportSummary;
