"use client";
import { Box, Button, Divider, Grid, Group, List, Modal, Progress, Text } from "@mantine/core";
import { IconDownload } from "@tabler/icons-react";
import Image from "next/image";
import { useTranslations } from "next-intl";
import React, { FC, useEffect, useRef, useState } from "react";

import {
  ALLOWED_FILE_TYPES,
  FILE_CHUNK_LIMIT,
  IGNORE_FIELDS,
  INVALID_DATE_RANGE_ERROR,
  MAX_FILE_SIZE_LIMIT,
  MAX_LENGTH,
  REQUIRED_DATA_INFO_UPLOAD_STUDENT,
  REQUIRED_DATA_NOTE,
  TEMPLATE_UPLOAD_INSTRUCTIONS,
  TEMPLATE_UPLOAD_NOTES,
  UPLOAD_STEPS,
  USER_HEADS_TEXT,
  USERS_COLUMNS,
} from "@/constants";
import { accessTypeConstants } from "@/constants/exam";
import fileImg from "@/public/import.svg";
import { BUTTON_TYPES } from "@/types/button.types";
import { IImportSummary, UserSubscription } from "@/types/Profile";
import { getFileSizeInMB } from "@/utils";
import { getCurrentProgress, parseCSVFile, parseExcelFile } from "@/utils/tools/csv-export";

import ImportErrorSummary from "../Alerts/importErrorSummaryAlert";
import ImportSummary from "../Alerts/ImportSummaryAlert";
import classes from "./Modals.module.css";

interface UploadFileModalProps {
  opened: boolean;
  onCancel: () => void;
  handleFileSubmit: (value: UserSubscription[]) => void;
  isImportPending: boolean;
  uploadError: string;
  setUploadError: (value: string) => void;
  sampleFile: string;
  formattedMessage?: IImportSummary;
  setFormattedMessage?: (value: IImportSummary | undefined) => void;
}

const UploadFileModal: FC<UploadFileModalProps> = ({
  opened,
  onCancel,
  handleFileSubmit,
  isImportPending,
  uploadError,
  setUploadError,
  sampleFile,
  formattedMessage,
  setFormattedMessage,
}) => {
  const t = useTranslations("generic");
  const inputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState("");
  const [fileErrors, setFileErrors] = useState<string[] | undefined>();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (formattedMessage) {
      setSelectedFile(null);
    }
  }, [formattedMessage]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    setUploadError("");
    setError("");
    setFileErrors?.([]);
    setProgress?.(0);
    setFormattedMessage?.(undefined);

    const droppedFile = e.dataTransfer.files?.[0];
    if (!droppedFile) return;

    const isValidFile = ALLOWED_FILE_TYPES.some((ext) =>
      droppedFile.name.toLowerCase().endsWith(ext),
    );

    if (!isValidFile) {
      setError(t("message.error.typeText"));
      setSelectedFile(null);
      return;
    }

    const fileSizeInMB = getFileSizeInMB(droppedFile);
    if (Number(fileSizeInMB) >= Number(MAX_FILE_SIZE_LIMIT)) {
      setError(t("message.error.sizeText"));
      setSelectedFile(null);
      return;
    }

    // ✅ Always set the file even if it’s the same
    setSelectedFile(droppedFile);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUploadError("");
    setDragActive(false);
    setFileErrors([]);
    setProgress(0);
    setError("");
    if (setFormattedMessage) {
      setFormattedMessage(undefined);
    }

    // Check if a file is selected
    const file = e.target.files?.[0];
    if (!file) return;
    // Check file type (MIME) or file name
    const isValidFile = ALLOWED_FILE_TYPES.some((ext) => file.name.toLowerCase().endsWith(ext));
    if (!isValidFile) {
      setError(t("message.error.typeText"));
      setSelectedFile(null);
      return;
    }
    const fileSizeInMB = getFileSizeInMB(file);
    if (Number(fileSizeInMB) >= 5) {
      setError(t("message.error.sizeText"));
      setSelectedFile(null);
      e.target.value = ""; // ✅ Reset input to allow re-uploading same file
      return;
    }
    setSelectedFile(file);
    setUploadError("");
    setError("");
    e.target.value = ""; // ✅ Reset input to allow re-uploading same file
  };

  const parseFile = async (values: File) => {
    let chunkNo = 1;
    const rowSignatures = new Set<string>();
    const duplicateRowIndices: number[] = [];
    // ✅ Report all errors
    const errors: string[] = [];
    let parsedRows;
    const fileName = values.name.toLowerCase();
    if (fileName.endsWith(".csv")) {
      parsedRows = await parseCSVFile(values);
    } else if (fileName.endsWith(".xls") || fileName.endsWith(".xlsx")) {
      parsedRows = await parseExcelFile(values);
    } else {
      return Promise.reject(new Error("Unsupported file format"));
    }
    // ✅ Header validation
    const headers = Object.keys(parsedRows[0] ?? {});
    const missingHeaders = USERS_COLUMNS.filter((col) => !headers.includes(col));
    if (missingHeaders.length > 0) {
      errors.push(`Missing header column(s): ${missingHeaders}`);
    }

    // ✅ Restrict headers to only allowed USER_HEADS
    const USER_HEADS = USER_HEADS_TEXT; // Define allowed headers
    const extraHeaders = headers.filter((header) => !USER_HEADS.includes(header));
    if (extraHeaders.length > 0) {
      errors.push(`Extra header column(s) found: ${extraHeaders.join(", ")}`);
    }

    // ✅ Check for missing required fields
    const invalidRows = parsedRows
      .map((row, index) => {
        const missingFields = USERS_COLUMNS.filter((col) => {
          if (
            row["Subscription Status"]?.toString().trim() === "Free" &&
            (col === "Subscription Start Date" || col === "Subscription End Date")
          ) {
            return false;
          }
          return !(col in row) || row[col] === null || row[col].toString().trim() === "";
        });

        // Check Subscription Start Date and Subscription End Date if Subscription Status is 'Paid'
        if (row["Subscription Status"]?.toString().trim().toLocaleLowerCase() === "Paid".trim().toLocaleLowerCase()) {
          ["Subscription Start Date", "Subscription End Date"].forEach((field) => {
            if (!row[field] || row[field].toString().trim() === "") {
              missingFields.push(field);
            }
          });
        }

        return missingFields.length ? { row: index + 1, missingFields } : null;
      })
      .filter(Boolean);
    if (invalidRows.length > 0) {
      const errorMessages = invalidRows
        .map((r) => `Row ${r!.row} is missing required columns- ${r!.missingFields.join(", ")}`)
        .join("; ");
      errors.push(`Missing header column(s): ${errorMessages}`);

      // return;
    }

    // ✅ Validate Subscription End Date is greater than Subscription Start Date if Subscription Status is 'Paid'
    const invalidDateRangeRows = parsedRows
      .map((row, index) => {
        if (row["Subscription Status"]?.toString().trim().toLocaleLowerCase() === accessTypeConstants.PAID.trim().toLocaleLowerCase()) {
          const startDate = new Date(row["Subscription Start Date"]?.toString().trim());
          const endDate = new Date(row["Subscription End Date"]?.toString().trim());
          if (endDate <= startDate) {
            return index + 1;
          }
        }
        return null;
      })
      .filter(Boolean);

    //  dynamic error message
    if (invalidDateRangeRows.length > 0) {
      errors.push(INVALID_DATE_RANGE_ERROR(invalidDateRangeRows.filter((row) => row !== null)));
    }

    // ✅ Duplicate row check
    parsedRows.forEach((row, index) => {
      const signature = JSON.stringify(row);
      if (rowSignatures.has(signature)) {
        duplicateRowIndices.push(index + 1);
      } else {
        rowSignatures.add(signature);
      }
    });

    const duplicateValuesAcrossRows: string[] = [];
    const valueMap = new Map<string, number>();

    parsedRows.forEach((row, index) => {
      const values = Object.entries(row)
        .filter(([key]) => !IGNORE_FIELDS.includes(key)) // Ignore specified keys
        .map(([, value]) => value?.toString().trim());

      values.forEach((val) => {
        if (typeof val === "string" && val) {
          if (valueMap.has(val)) {
            duplicateValuesAcrossRows.push(`Row ${index + 1} → duplicate value : ${val}`);
          } else {
            valueMap.set(val, index + 1);
          }
        }
      });
    });

    // ✅ Validate date format for Subscription Start Date and Subscription End Date
    const dateFields = ["Subscription Start Date", "Subscription End Date"];
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    const invalidDateRows = parsedRows
      .map((row, index) => {
        if (row["Subscription Status"]?.toString().trim().toLowerCase() === "Paid".trim().toLocaleLowerCase()) {
          const invalidFields = dateFields.filter((field) => {
            const value = row[field]?.toString().trim();
            return !value || !dateRegex.test(value);
          });
          return invalidFields.length ? { row: index + 1, invalidFields } : null;
        }
        return null;
      })
      .filter(Boolean);

    if (invalidDateRows.length > 0) {
      const errorMessages = invalidDateRows
        .map((r) => `Invalid date format in row ${r!.row}: ${r!.invalidFields.join(", ")}`)
        .join("; ");
      errors.push(errorMessages);
    }

    // ✅ Validate email format
    const emailField = "Email";
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    const invalidEmailRows = parsedRows
      .map((row, index) => {
        const email = row[emailField]?.toString().trim();
        return email && !emailRegex.test(email) ? index + 1 : null;
      })
      .filter(Boolean);

    if (invalidEmailRows.length > 0) {
      errors.push(`Invalid email format in row(s): ${invalidEmailRows.join(", ")}`);
    }

    // ✅ Validate First Name and Last Name length
    const nameFields = ["First Name", "Last Name"];
    const longNameRows = parsedRows
      .map((row, index) => {
        const invalidFields = nameFields.filter((field) => {
          const value = row[field]?.toString().trim();
          return value && value.length > MAX_LENGTH;
        });
        return invalidFields.length ? { row: index + 1, invalidFields } : null;
      })
      .filter(Boolean);

    if (longNameRows.length > 0) {
      const errorMessages = longNameRows
        .map(
          (r) =>
            `Name exceeds ${MAX_LENGTH} characters in row ${r!.row}: ${r!.invalidFields.join(", ")}`,
        )
        .join("; ");
      errors.push(errorMessages);
    }

    // ✅ Validate First Name and Last Name contain only letters
    const nameValidationRegex = /^[A-Za-z]+$/;
    const invalidNameRows = parsedRows
      .map((row, index) => {
        const invalidFields = nameFields.filter((field) => {
          const value = row[field]?.toString().trim();
          return value && !nameValidationRegex.test(value);
        });
        return invalidFields.length ? { row: index + 1, invalidFields } : null;
      })
      .filter(Boolean);

    if (invalidNameRows.length > 0) {
      const errorMessages = invalidNameRows
        .map(
          (r) =>
            `Invalid characters in name fields in row ${r!.row}: ${r!.invalidFields.join(", ")}`,
        )
        .join("; ");
      errors.push(errorMessages);
    }

    // ✅ Validate email length
    const longEmailRows = parsedRows
      .map((row, index) => {
        const email = row[emailField]?.toString().trim();
        return email && email.length > MAX_LENGTH ? index + 1 : null;
      })
      .filter(Boolean);

    if (longEmailRows.length > 0) {
      errors.push(
        `Email address exceeds ${MAX_LENGTH} characters in row(s): ${longEmailRows.join(", ")}`,
      );
    }

    // ✅ Validate Subscription Status field
    const validStatuses = ["Paid", "Free"];
    const invalidStatusRows = parsedRows
      .map((row, index) => {
        const status = row["Subscription Status"]?.toString().trim();
        return status && !validStatuses.includes(status) ? index + 1 : null;
      })
      .filter(Boolean);

    if (invalidStatusRows.length > 0) {
      errors.push(`Invalid Subscription Status in row(s): ${invalidStatusRows.join(", ")}`);
    }

    // ✅ Report all errors

    if (duplicateRowIndices.length) {
      errors.push(`Duplicate row(s) found at position(s): ${duplicateRowIndices}`);
    }

    if (duplicateValuesAcrossRows.length) {
      errors.push(`${duplicateValuesAcrossRows}`);
    }

    if (errors.length) {
      setSelectedFile(null);
      setFileErrors(errors);
      return;
    }

    // Calculate total chunk count
    let continueProcessing = true;
    // Send chunks to API sequentially

    for (let i = 0; i < parsedRows.length && continueProcessing; i += FILE_CHUNK_LIMIT) {
      const chunk = parsedRows.slice(i, i + FILE_CHUNK_LIMIT);
      setProgress(getCurrentProgress(chunkNo, FILE_CHUNK_LIMIT, chunk));
      if (continueProcessing) {
        try {
          handleFileSubmit(chunk);
        } catch (error) {
          console.error("Error while processing file chunk:", error);
          continueProcessing = false;
        }

        chunkNo++;
      }
    }
  };

  const saveUploadedFile = async () => {
    setProgress(0);
    if (selectedFile) {
      setError("");
      parseFile(selectedFile);
      // Simulate upload progress
      const interval = setInterval(() => {
        setProgress((old) => {
          if (old >= 100) {
            clearInterval(interval);
            return 100;
          }
          return old + 10;
        });
      }, 300);
    } else {
      setError(t("message.error.text"));
      return false;
    }
  };

  const handleDownloadSample = () => {
    const link = document.createElement("a");
    link.href = sampleFile;
    link.download = "student-sample.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCancelModal = () => {
    setSelectedFile(null);
    onCancel();
    setError("");
    setFileErrors([]);
    setUploadError("");
    setProgress(0);
    setDragActive(false);
  };

  const handleEmptyErrorSummary = () => {
    setFileErrors([]);
    setUploadError("");
    if (setFormattedMessage) {
      setFormattedMessage(undefined);
    }
  };
  return (
    <Modal size="70%" opened={opened} onClose={onCancel} centered title={t("modal.title.text")}>
      <Grid>
        <Grid.Col span={6}>
          <Box p={15}>
            {/* upload file */}
            <form>
              <Box
                className={`${classes.uploadContainer} ${dragActive ? classes.active : ""}`}
                onClick={() => inputRef.current?.click()}
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
              >
                <Image className={classes.uploadImage} src={fileImg} alt="Upload Icon" width={64} />
                <Button className={classes.browseButton} color="green" mt="sm">
                  {t("file.browseText.text")}
                </Button>
                <Text className={classes.orText} size="sm" mt="xs" c="dimmed">
                  {t("file.orText.text")}
                </Text>
                <Text className={classes.dragText} size="sm" mt={4} fw={500} c="blue">
                  {t("file.dragText.text")}
                </Text>
                <Text className={classes.hintText} size="xs" mt={4} c="gray">
                  {t("file.limitText.text")}
                </Text>
                <input
                  type="file"
                  ref={inputRef}
                  accept=".csv,.xls,.xlsx"
                  hidden
                  onChange={handleFileChange}
                />
                {selectedFile && (
                  <Text size="sm" mt="md" fw={500} c="gray">
                    Selected File:{" "}
                    <Text span c="black">
                      {selectedFile?.name}
                    </Text>
                  </Text>
                )}
              </Box>
              {uploadError && (
                <p style={{ color: "red", fontSize: "14px", marginTop: "5px" }}>{uploadError}</p>
              )}
              {error && <p style={{ color: "red", fontSize: "14px", marginTop: "5px" }}>{error}</p>}

              {formattedMessage && <ImportSummary summary={formattedMessage} />}
              {fileErrors && fileErrors.length > 0 && (
                <ImportErrorSummary
                  errorMessages={fileErrors}
                  handleEmptyErrorSummary={handleEmptyErrorSummary}
                />
              )}

              {/* Submit Button */}
              <Group justify="space-between">
                <Button
                  size="sm"
                  mt={20}
                  leftSection={<IconDownload size={18} />}
                  onClick={handleDownloadSample}
                  variant="filled"
                >
                  {t("button.download.text")}
                </Button>
                <Box>
                  <Button type="button" mt="md" variant="default" onClick={handleCancelModal}>
                    {t("button.cancel.text")}
                  </Button>
                  <Button
                    type={BUTTON_TYPES.BUTTON}
                    mt="md"
                    ml="lg"
                    disabled={isImportPending || !selectedFile || !!formattedMessage?.created}
                    onClick={saveUploadedFile}
                  >
                    Import File
                  </Button>
                </Box>
              </Group>

              {isImportPending && (
                <Box mt={20} style={{ position: "relative" }}>
                  <Progress value={progress} size="lg" transitionDuration={200} />
                  <Text
                    size="sm"
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                    }}
                  >
                    {`${progress}%`}
                  </Text>
                </Box>
              )}
            </form>
          </Box>
        </Grid.Col>
        <Grid.Col span={6}>
          <Box p="lg" bg={"#f0defe"} bd={"1px solid #0000002d"} mt="md" fz="sm">
            <Text fw="600">Guidelines for import file:</Text>
            <Divider my="sm" />

            <Box pb="md">
              <Text fw="600">Steps:</Text>
              {UPLOAD_STEPS}
              <List fz="sm" mt="xs">
                {TEMPLATE_UPLOAD_INSTRUCTIONS.map((item, index) => (
                  <List.Item key={index}>{item}</List.Item>
                ))}
              </List>
            </Box>
            <Box pb="md">
              <Text fw="600">Note:</Text>
              <List fz="sm" mt="xs">
                {TEMPLATE_UPLOAD_NOTES.map((note, index) => (
                  <List.Item key={index}>{note}</List.Item>
                ))}
              </List>
            </Box>
            <Box pb="md">
              <Text fw="600">{REQUIRED_DATA_NOTE}</Text>
              <List fz="sm" mt="xs">
                {REQUIRED_DATA_INFO_UPLOAD_STUDENT.map((item, index) => (
                  <List.Item key={index}>
                    <strong>{item.label}:</strong> {item.description}
                  </List.Item>
                ))}
              </List>
            </Box>
          </Box>
        </Grid.Col>
      </Grid>
    </Modal>
  );
};

export default UploadFileModal;
