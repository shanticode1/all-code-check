import ConfirmationModal from "./ConfirmationModal";
import UploadFileModal from "./UploadFileModal";

export { ConfirmationModal, UploadFileModal };
