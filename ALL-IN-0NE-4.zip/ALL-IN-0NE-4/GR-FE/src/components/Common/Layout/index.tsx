"use client";
import { AppShell, useMantineTheme } from "@mantine/core";
import { usePathname } from "next/navigation";
import React, { useState } from "react";

import AuthGate from "@/components/Auth/AuthGate";
import Header from "@/components/Common/Header";
import Sidebar from "@/components/Common/SideBar";
import { USER_ROLE } from "@/constants";
import { roles } from "@/constants/common";
import { useAuth } from "@/lib/Contexts/AuthProvider";

export default function Layout({ children }: Readonly<{ children: React.ReactNode }>) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const theme = useMantineTheme();
  const { role } = useAuth();
  const pathname = usePathname();
  const isSidebarDisabled = role === USER_ROLE.STUDENT && pathname.includes("/exams/");

  const handleToggleSidebar = () => {
    setSidebarOpen((prev) => !prev);
  };

  return (
    <AuthGate allowedRoles={[roles.SUPERADMIN, roles.STUDENT, roles.ADMIN, roles.INSTRUCTOR]}>
      <AppShell
        layout="alt"
        navbar={
          sidebarOpen
            ? {
                width: 250,
                breakpoint: "sm",
                collapsed: { mobile: true },
              }
            : undefined
        }
        header={{ height: 60 }}
        padding="md"
        style={{ backgroundColor: theme.colors.gray[1] }}
      >
        <Header
          onToggleSidebar={handleToggleSidebar}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
        />
        {sidebarOpen && (
          <AppShell.Navbar p="md">
            <Sidebar />
          </AppShell.Navbar>
        )}

        <AppShell.Main style={isSidebarDisabled ? { paddingTop: "10px" } : undefined}>
          {children}
        </AppShell.Main>
      </AppShell>
    </AuthGate>
  );
}
