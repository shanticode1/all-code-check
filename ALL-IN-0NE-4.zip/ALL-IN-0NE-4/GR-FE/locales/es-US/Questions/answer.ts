const answer = {
  title: "Answer Choices",
  input: {
    labels: {
      suffix: "Suffix",
      prefix: "Prefix",
    },
    answer: {
      answer: "Answer",
      placeholder: "Enter the answer",
    },
  },
  buttons: {
    addMore: "Add More",
  },
  editor: {
    openFor: "Open Editor for {type}",
    editPrefix: "Edit Prefix",
    editSuffix: "Edit Suffix",
    placeholder: "Enter {type} text here...",
    cancel: "Cancel",
    save: "Save",
  },
};
export default { answer };
