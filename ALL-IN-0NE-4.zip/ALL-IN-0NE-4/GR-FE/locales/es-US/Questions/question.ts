const question = {
  form: {
    questionType: {
      select: {
        label: "Question Type:",
        placeholder: "Select a type",
      },
    },
    category: {
      select: {
        label: "Category:",
        placeholder: "Select a Category",
      },
    },
    difficultyLevel: {
      select: {
        label: "Difficulty Level:",
        placeholder: "Select a difficulty level",
      },
    },
    numericDifficultyLevel: {
      select: {
        label: "Numeric Difficulty Level:",
        placeholder: "Select a numeric difficulty level",
      },
    },
    video: {
      title:"Select Explanation Video",
      label: "Explanation Video:",
      placeholder: "Example: www.youtube.com",
      tooltip: {
        message: {
          importNote: "Import video URL by clicking on the button below.",
          httpDomain: "Video URL must start with http:// or https://",
          validData: "and be a valid video URL else video will not be available.",
        },
      },
      button: {
        text: "Import Video URL",
      },
    },
    guidelines: {
      label: "Guidelines",
      placeholder: "Start writing your guidelines here",
    },
    answerPrompt: {
      label: "Answer Prompt",
      placeholder: "Start writing your Answer Prompt here",
    },
    instruction: {
      label: "Instructions",
      placeholder: "Start writing your Instructions here",
    },
    question: {
      label: "Question",
      placeholder: "Enter Question",
    },
    questionLayout: {
      select: {
        label: "Question Layout",
        placeholder: "Select Question Layout",
      },
    },
    buttons: {
      add: {
        text: "Add Question",
      },
      update: {
        text: "Update Question",
      },
      cancel: {
        text: "Cancel",
      },
    },
    editor: {
      placeholder: "Start writing here...",
    },
    answer: {
      instruction: {
        label: "Answer Instructions",
        placeholder: "Start writing your answer instructions here"
      }
    }
  },
  table: {
    columns: {
      sNo: "S.No.",
      question: "Question",
    },
  },
  messages: {
    noVideo: " No video available",
    noSupport: "Your browser does not support the video tag.",
    duplicateAnswer: "Duplicate answer {value} is not allowed. Please enter a different value.",
    validNumericNumber: "Please enter a valid numeric value.",
  },
  details: {
    title:"Video Explanation",
    video: {
      title: "YouTube video explanation",
    },
  },
  buttons: {
    go_to_history: {
      text: "Go to Score Reports",
    },
    go_to_bottom: {
      text: "View Video Explanation",
    },
  },
  errorMessages: {
    onlyNumberDecimalAllow: "Only numbers and a decimal point are allowed.",
    canNotEndWithDecimal: "Number cannot end with a decimal point.",
    allowedDigit: "Maximum 8 digits allowed (excluding decimal point and minus sign).",
    characterNotAllowed: "Characters are not allowed in Answer. Please enter a number or decimal",
    answerTextRequired: "Answer text is required",
    questionTextRequired: "Question text is required",
    minusUsedAtBegnining: "Minus sign '-' can only be used at the beginning of the number.",
    markedOneCOrrectAns:"At least one answer must be marked as correct."
  }
};
export default { question };
