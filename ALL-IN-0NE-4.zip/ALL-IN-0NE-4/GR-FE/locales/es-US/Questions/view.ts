const view = {
    examDetails: {
        text: "Exam Details"
    },
    studentDetails: {
        text: "Student Details"
    },
    attemptedDate: {
        text: "Exam Attempted Date"
    },
    answer: {
        text: "Answer"
    }
}
export default { view }