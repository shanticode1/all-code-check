const section = {
    sections: {
        name: {
            analyticalWriting: "Analytical Writing",
            verbalReasoning: "Verbal Reasoning",
            QuantitativeReasoning: "Quantitative Reasoning"
        }
    },
    score:{
        card:{
            totalScore: "Total Score"
        },
        buttons:{
            text: "See Result Details"
        }
    },
    endSection: {
        title: "Section Finished",
        description: "You have finished this section and now will begin the next one.",
        continue: "Continue",
        otherDescription: "You have reached the end of this section. You have time remaining to review. As long as there is time remaining, you can check your work. Once you leave this section, you WILL NOT be able to return to it.",
        select: "Select",
        review: "Review",
        goTBack: "to go back to the review section.",
        return: "Return",
        goToQuestion: " to go to the last questions in the section.",
        toProceed: "to proceed."
    }
}

export default { section };