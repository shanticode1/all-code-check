const profile = {
    admin: {
        title: "Admin Profile",
    },
    student: {
        title: "Student Profile",
    },
    title: "Profile Setting",
    updateProfile: {
        form: {
            title: "Update Profile",
            firstName: {
                label: "First Name",
                placeholder: "Enter your first name"
            },
            lastName: {
                label: "Last Name",
                placeholder: "Enter your last name"
            },
            email: {
                label: "Email",
                placeholder: "Enter your email"
            },
            button: {
                text: "Update Profile"
            }
        }
    },
    changePassword: {
        form: {
            title: "Change Password",
            currentPassword: {
                label: "Current Password",
                placeholder: "Enter your current password"
            },  
            newPassword: {
                label: "New Password",
                placeholder: "Enter your new password"
            },
            confirmPassword: {
                label: "Confirm New Password",
                placeholder: "Confirm your new password"
            }
        },
        button: {
            text: "Change Password"
        }

    }

}
export default { profile };