const examScheduler = {
  settings: {
    title: "Settings",
  },
  free: {
    label: "Free Students Retention Days For Sherpa Preps Student",
    placeholder: "Enter retention days",
  },
  paid: {
    label: "Paid Students Retention Days For Sherpa Preps Student",
    placeholder: "Enter retention days",
  },
  button: {
    save: {
      text: "Save",
    },
    update: {
      text: "Update",
    },
  },
};
export default { examScheduler };
