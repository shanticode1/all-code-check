const generic = {
  buttons: {
    cancel: "Cancel",
    save: "Save",
    continue: "Continue",
    next: "Next",
    previous: "Previous",
    start: "Start {value}",
    finish: "Finish",
    submit: "Submit",
    confirm: "Confirm",
    attempt: "Attempt {value}",
    preview: "Preview {value}",
    update: "Update {value}",
    add: "Add {value}",
    filter: "Filter",
    search: "Search",
    success: "Success",
    error: "Error",
    warning: "Warning",
    info: "Info",
    close: "Close",
    delete: "Delete",
    edit: "Edit",
    view: "View",
    clearAll: "Clear All",
    sent: "{value} Sent",
    resend: "Resend {value}",
    verified: "Verified",
    unverified: "Unverified",
    ok: "OK",
    review: "Review",
    return: "Return",
    select: "Select",
    exit: "Exit",
    toProceed: "to proceed."
  },
  header: {
    menu: {
      button: {
        Logout: "Logout",
      },
    },
    modal: {
      title: "Are you sure you want to leave?",
      description: "If you go back now, your current answers may not be saved.",
    },
  },
  messages: {
    success: {
      title: "Success",
      description: "Your changes have been saved successfully.",
    },
    error: {
      general: {
        title: "Error",
        label: "Unable to Load Instructions",
        description: "Please try again later or contact support.",
      },
      invalidLink: {
        title: "Error",
        label: "Invalid or Expired Link",
        description: "Please try again later or contact support.",
      },
      modal: {
        title: "Oops!",
        button: "Go to Exams"
      }
    },
    instructions: {
      description:
        "I have read and agree to the Smart with a Heart or Sherpa Prep terms of use, as applicable.",
    },
    modal: {
      duplicateTabWarning: {
        description:
          "You already have this exam open in another browser tab. To prevent lost answers or timer conflicts, please close this tab or return to the original tab. Avoid back and forward navigation.",
      },
    },
  },
  button: {
    download: {
      text: " Download Sample Template",
    },
    submit: {
      text: "Save",
    },
    cancel: {
      text: "Cancel",
    },
    import: {
      text: "Import Students",
    },
  },
  modal: {
    title: {
      text: "Upload File",
    },
    confirmation: {
      original: "Original Exam",
      newExam: "New Exam",
    }
  },
  file: {
    browseText: {
      text: "Browse File to import",
    },
    orText: {
      text: "or",
    },
    dragText: {
      text: "Drag and drop here",
    },
    limitText: {
      text: " Maximum size limit of 5MB",
    },
    importText: {
      text: "Import Summary",
      created: "Created",
      failed: "Failed",
      failedDetails: "Failed Details",
      alreadyExists: "Already Exists",
    },
  },
  message: {
    error: {
      text: "File is required",
      typeText: "Only allows xlsx, xls, or csv files.",
    },
    noGuidelines: "No guidelines available",
  },
  actionButtons:{
    cut:"Cut",
    copy:"Copy",
    paste:"Paste",
    redo:"Redo",
    undo:"Undo"
  },
  input: {
    correctAnswerPlaceholder: "Correct Answer",
  },
  logos: {
    sherpaPrep: "Sherpa Prep Logo",
    smartWithAHeart: "Smart with a Heart Logo"
  }
};
export default { generic };
