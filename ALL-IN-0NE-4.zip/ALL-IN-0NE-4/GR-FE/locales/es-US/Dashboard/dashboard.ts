const dashboard = {
  title: "Dashboard",
  cards: {
    title: {
      totalStudent: "Total Students Enrolled",
      activeExam: "Active Exams",
      totalExams: "Total Exams",
      activestudent: "Total Active Students",
      smartWithHeartStudent: "Total SWAHT Students",
      sherpaPrepStudent: "Total Sherpa Students",
      paidStudent: "Students on Paid Plans",
      freeStudent: "Total Free Students  ",
    },
  },
  tooltips: {
    labels: {
      totalExams: "Total number of distinct exams created in the system.",
      totalStudents: "Total number of students registered on the platform.",
      totalActiveExams: "All active exams are accessible to students on their portal.",
      totalActiveStudents: "Total number of free and paid students logged in past 30 days ",
      totalSmartWithHeartStudent:
        "Total number of Smart with heart paid students logged in past 30 days ",
      totalSherpaPrepStudent:
        "Total number of Sherpa Prep paid students logged in past 30 days ",
      totalPaidStudent: "Students currently on a paid subscription plan.",
      totalFreeStudent: "Total number of free students logged in past 30 days ",
    },
  },
  student: {
    greetingTitle: "Good to See <br/> You Again!",
    greetingSubtitle: "Stay focused, stay consistent. Your GRE journey continues—let’s unlock your full potential today.",
    card: {
      title: "Your GRE Dashboard at a Glance",
      welcomeText: "Welcome to your all-in-one GRE preparation hub!",
      text: "We’ve created a practice test platform that fully replicates the experience of taking a timed, fully adaptive",
      examTabInstruction: "just click on the “Exams” tab to the left, and select the exam you’d like to take.",
      sortDescription: "Please note: The analytical writing section of the exam will need to be individually scored by an instructor. If you’re a Smart with a Heart or Sherpa Prep student, you’re welcome to send us your essay via email to receive a score. Just reach out to"
    },
    email: {
      smartWithHeart: "info@smartwithaheart.org",
      sherpaPrep: "info@sherpaprep.com"
    },
    goodLuck: "Good luck!"
  },
  filters: {
    week: "Week",
    month: "Month",
    days: "Days",
    year: "Year"
  },
  messages: {
    welcome: "Welcome aboard!",
  }
};
export default { dashboard };
