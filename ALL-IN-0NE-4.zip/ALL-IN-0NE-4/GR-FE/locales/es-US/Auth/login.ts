const login = {
  title: "Welcome back!",
  heading: "Login to your account",
  form: {
    title: "Login",
    email: {
      label: "Email",
      placeholder: "Enter your email",
    },
    password: {
      label: "Password",
      placeholder: "Enter your password",
    },
    otp: {
      label: "Please enter OTP",
      placeholder: "Enter OTP",
    },
    partnerType: {
      select: {
        label: "Partner Type",
        placeholder: "Select partner type",
      },
    },
    button: {
      login: "Login",
      sendOtp: "Send OTP",
      verify: "Verify & Login",
      resend: "Resend OTP",
    },
    loading: {
      login: "Logging in...",
      sendOtp: "Sending OTP...",
      verify: "Verifying...",
    },
    messages: {
      otp: {
        expired: "OTP expired. Please resend to get a new code.",
        timer: "OTP is getting expired in {timer}",
        resendAvailable: "Resend available in {timer}s",
      },
    },
    forgotPassword: {
      title: "Forgot Password",
      link: {
        text: "Forgot Password?"
      },
      buttons: {
        send: "Send Reset Password Link",
        cancel: "Cancel"
      },
      message:{
        text: "A reset password link has been sent to your registerd email.",
        description: "You can follow that link to reset your password.",
        isStudentText: "If student? click here to login"
      },
      rememberPassword: "Remember your password ?",
      signIn: "Sign In"
    },
  },
};

export default { login };
