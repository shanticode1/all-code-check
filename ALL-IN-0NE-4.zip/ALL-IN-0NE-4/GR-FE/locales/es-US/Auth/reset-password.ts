const resetPassword = {
    form: {
        title: "Reset Password",
        description: "Please enter your new password below.",
        newPassword: {
            label: "New Password",
            placeholder: "Enter your new password"
        },
        confirmNewPassword: {
            label: "Confirm New Password",
            placeholder: "Re-enter your new password"
        },
        buttons: {
            reset: "Reset Password",
            cancel: "Cancel"
        },
        setPassword: {
            title: "Set Password",
            buttons: {
                text: "Set Password",
            },
        }
    },
    messages: {
        tokenNotFound: "Token is missing in the query parameters.",
        noSpacesAllowed: "Spaces are not allowed."
    },
    togglePassword: "{value} Password"
};

export default { resetPassword };
