const examHistory = {
  title: "Score Reports",
  messages: {
    noHistoryFound: "No exam history available.",
    dateCanNotBeSame: "Start date and end date cannot be the same",
    endDateAfterStart: "End date must be later than start date",
    noDataForDownload: "No exam data available to download.",
    noResultFoundForSearch: "No results found for your search.",
    noExamFound: "No Exams Found",
  },
  breadcrumbs: {
    studentManagement: "Student Management",
    studentName: "Student Name",
  },
  buttons: {
    downloadCSV: "Download CSV",
  },
  datePicker: {
    startDate: {
      placeholder: "Filter by start date",
    },
    endDate: {
      placeholder: "Filter by end date",
    },
    useRange: {
      label: "Use Date Range Picker",
    },
  },
  exportHistory: {
    title: "Export Exam History",
    buttonTitle: "Export",
  },
  search: {
    input: {
      placeholder: "Search by student name, email or exam name",
      studentSearchPlaceholder: "Search by exam name",
      analyticalPlaceholder: "Search by exam name, student name or email",
    },
    button: {
      text: "Search",
    },
  },
  table: {
    headers: {
      examDetails: "Exam Detail",
      studentName: "Student Name",
      studentEmail: "Student Email",
      examDate: "Exam Date",
      analyticalWriting: "Analytical Writing",
      quantitativeReasoning: "Quantitative Reasoning",
      verbalReasoning: "Verbal Reasoning",
      totalScore: "Total Score",
      actions: "Actions",
    },
    noDataFound: "No data found for the selected filters.",
  },
};
export default { examHistory };
