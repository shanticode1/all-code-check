const evaluation = {
  title: "Analytical Writing Scoring",
  cards: {
    name: {
      title: "Student Name:",
    },
    examName: {
      title: "Exam Name:",
    },
    date: {
      title: "Start Date:",
    },
    button: {
      title: "Evaluate",
    },
  },
  breadcrumbs: {
    analyticalWriting: "Analytical Writing Management",
    evaluation: "Evaluation",
  },
  form: {
    input: {
      score: {
        label: "Score (0 - 6)",
        placeholder: "Enter score",
      },
    },
    button: {
      label: "Submit Score",
      clearFilter: {
        label: "Clear Filter"
      }
    },
    messages: {
      scoreLessThanZero: "Score can't be less than 0",
      scoreMoreThanSix: "Score can't be more than 6",
    },
  },
  modal: {
    title: "Confirmation",
    description: " Are you sure you want to Submit Score?",
    button: {
      confirm: "Submit Score",
      cancel: "Cancel"
    }
  },
  table : {
    headers: {
      examDetails: "Exam Details",
      studentName: "Student Name",
      email: "Email",
      portalType: "Portal Type",
      examDate: "Exam Date",
      actions: "Actions",
    }
  },
  header: {
    title: "Analytical Evaluation"
  }
};
export default { evaluation };
