const startExam = {
    modal: {
        warning: {
            title: "Are you sure you want to leave this page?",
            description: "If you go back now, your current answers may not be saved.",
        },
        success: {
            text: "You have successfully completed the exam. Your answers are being submitted.",
            button: {
                text: "Please wait while we redirect you..."
            },
            completed: {
                text: "Exam Completed"
            },
            timesUp: "Time's Up!"
        }

    },
    buttons:{
        return:"Return",
        goToQuestion:"Go to Question"
    }

}
export default { startExam }