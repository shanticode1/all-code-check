const calculator = {
  heading: "Unable to transfer",
  body: `"Error" display will not be transferred.`,
  button: "Transfer Display",
};
export default { calculator };
