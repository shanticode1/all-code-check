const exam = {
  title:" Exam Management",
  form: {
    title: {
      add: {
        label: "Add Exam",
      },
      update: {
        label: "Update Exam",
      },
    },
    labels: {
      examName: "Exam Name",
      accessType: "Access Type",
      guidelinesAndInstructions: "Guidelines & Instructions",
      verbalPanulty: "Penalty Per Mistake Verbal",
      quantPanulty: "Penalty Per Mistake Quant",
    },
    inputs: {
      placeholder: {
        examName: "Enter exam name",
        accessType: "Select access type",
        guidelinesAndInstructions: "Start writing here...",
        verbalPanulty: "Enter penalty per mistake verbal",
        quantPanulty: "Enter penalty per mistake quant",
      },
    },
  },
  buttons: {
    add: "Add Exam",
    update: "Update Exam",
    download: "Download",
    isdownload: "Downloading..."
  },
  table: {
    columns: {
      examName: "Exam Name",
      examType: "Exam Type",
      registeredStudent: "Registered Student",
      attemptedStudent: "Attempted Students",
      createdDate: "Created Date",
      status: "Status",
      accessType: "Access Type",
      actions: "Actions",
    },
  },
  filters: {
    text:"Filter",
    accessType: {
      placeholder: "Filter by Access Type",
    },
    status: {
      placeholder: "Filter by Status",
    },
  },
  exam_setting: {
    title: "Section Settings",
    labels: {
      sectionName: "Section Name",
      timeLimit: "Time Duration (In seconds)",
      sectionInstructions: "Section Instructions",
    },
    inputs: {
      placeholder: {
        sectionName: "Enter section name",
        timeLimit: "Enter time in seconds",
        sectionInstructions: "Start writing here...",
      },
    },
  },
  exam_instructions: {
    title: "Exam Instructions",
  },
  messages: {
    tooltip: {
      label: {
        disablePreview: "Preview is disabled for this exam",
        notAddedQuestion: "You have not added any questions yet",
        preview: "Preview",
        disableEdit: "You can’t edit active exams. To make changes",
        setExamStatus: "Please set the exam status to Inactive.",
        examDetails: "Exam Details",
        inProgressExam: "Exam in progress. Please refresh in a few minutes to update the status.",
        notDeleteExam: 'Active exams cannot be deleted or deactivated.',
        ongoingExam: "The exam is currently in progress. Please refresh the page after 10 minutes, after which you will be able to perform active and inactive actions."
      },
    },
    noExamFound: "No Exam found",
    guidelinesRequired: {
      label: "Please enter guidelines and instructions"
    }
  },
  modal: {
    confirmation: {
      activeDescription:
        "Are you sure you want to activate this exam?.<br/>Once activated, the exam will be visible to students.",
      inActiveDescription:
        "Are you sure you want to deactivate this exam?.<br/> Once deactivated, the exam will no longer be visible to students",
      deleteExamDscription: "Are you sure you want to delete this exam?<br/> This will permanently remove the exam and all its associated data.This action cannot be undone.",
      deactivateExamDescription: "Are you sure you want to deactivate this exam?<br/> Students will no longer be able to view or attempt it.<br/> This exam data will be hidden from all admin roles and will not be available for editing.",
      copyExamDescription: "You're about to create a copy of this exam.<br/> This will duplicate the exam along with all its section settings, questions, and answer choices.",
      confirmText: "Do you want to proceed with duplicating this exam?",
      title: {
        active: "Activate Exam",
        inActive: "Deactivate Exam",
        delete:"Delete Exam",
        Deactivate:"Confirm Deactivation",
        copy:"Copy Exam"
      },
      buttons: {
        active: "Yes, Activate",
        inActive: "Yes, Deactivate",
        delete: "Yes , Delete",
        copy: "Yes, Copy",
      },
    },
    tooltips: {
      delete: "Delete",
      deactivate: "Deactivate",
      edit: "Edit",
      preview: "Preview"
    }
  },
  status: {
    active: "Active",
    inactive: "Inactive",
  },
  sectionNote:{
    note:"The actual GRE contains several additional instruction and preliminary pages that are not replicated here, including copyright information, test-center rules, etc. We recommend that you take one or more of the ETS PowerPrep practice tests to try out the full experience before you take your actual test."
  },
  search: {
    placeholder: "Search by exam"
  }
};

export default { exam };
