const examDetail = {
  score: {
    cards: {
      sections: {
        analyticalWriting: {
          label: "Analytical Writing",
        },
        verbalReasoning: {
          label: "Verbal Reasoning",
        },
        quantitativeReasoning: {
          label: "Quantitative Reasoning",
        },
        totalScore: {
          label: "Total Score",
        },
      },
    },
    labels: {
      markAlloted: "Marks allotted",
      pending: "Evaluation pending",
      right: "Right",
      wrong: "Wrong",
      omitted: "Omitted",
      notEncountered: "Not Encountered",
      notAnswered: "Not Answered",
    },
  },
  report: {
    table: {
      columns: {
        question: "Question",
        questionType: "Question Type",
        category: "Category",
        difficulty: "Difficulty",
        answer: "Answer",
        time: "Time",
      },
    },
  },
  messages: {
    noQuestion: "No questions available",
  },
  error: {
    lable: "This exam is no longer active or available.",
  },
  table: {
    question: "Question",
    questionType: "Question Type",
    category: "Category",
    difficulty: "Difficulty",
    answer: "Answer",
    time: "Time",
  },
  help: {
    card: {
      text: "Duration",
      title: "Instructions"
    },
    tabs: "{value} Instructions"
  },
  note: {
    text: "Note",
    message: "Click on the Question ID to view detailed information about that specific question."
  }
};
export default { examDetail };
