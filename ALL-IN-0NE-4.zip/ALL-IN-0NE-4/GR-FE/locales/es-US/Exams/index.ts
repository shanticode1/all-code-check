export { default as exam } from './exams';
export { default as examHistory } from './examHistory';
export { default as evaluation } from './evaluation';
export { default as startExam } from './startExam';
export { default as preview } from './preview';
export { default as examDetail } from './examDetail';
export { default as calculator } from './calculator';
export {default as instruction} from './instruction';