const instruction = {
    title: "Navigating Through the Test",
    keyboardHelp: {
        intro: "During this test, you can use the mouse OR the keyboard to move through the screens.",
        standardKeys: "You can use the following standard keys on the keyboard:",
        tabTitle: "Tab",
        tabDescription: "Press the Tab key to move from one selectable element on the page to the next. The current selectable element will be indicated by a thin blue border.",
        selectableExamples: "Examples of selectable elements:",
        exampleButtons: "Buttons on the menu toolbar",
        exampleOptions: "Answer options for test questions",
        shiftTabDescription: "Press the Shift and Tab keys to reverse direction through the selectable elements.",
        spacebarDescription: "Press the spacebar key to select an element. Press the spacebar key again to deselect the element.",
        arrowKeysDescription: "Use the up and down arrows to scroll vertically.",
        shift: "Shift",
        spacebar: "Spacebar",
        up: "Up",
        down: "Down"
    }
}

export default { instruction }