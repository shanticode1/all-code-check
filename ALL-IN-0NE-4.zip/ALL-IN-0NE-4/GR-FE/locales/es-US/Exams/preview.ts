const preview = {
  section: {
    select: {
      placeholder: "Choose a section",
    },
  },
  calculator: {
    title: "Calc",
  },
  buttons: {
    exit: {
      label: "Exit Preview",
    },
    next: {
      label: "Next",
    },
    endSection: {
      label: "End Section",
    },
    questionNavigator: {
      label: "Review", //Question Navigator
    },
    previous: {
      label: "Back",
    },
    exitSection: {
      label: "Exit Section",
    },
    helpSection: {
      label: "Help",
    },
  },
  text: {
    reviewSection: {
      label:
        "This page presents information about questions in the current section. You may sort the questions by Number, Status, and Marked.The question you were on is selected and highlighted by default.Questions you have encountered have a status of Answered, Incomplete, or Not Answered.An Incomplete status indicates you have selected more or fewer options than the question requires.Questions you have not encountered have a status of Not Encountered.Marked questions are indicated with a ✔. To return to the question you were on, select Return.To go to a different question, select that question and select Go to Question. You will be unable to go to questions that have a status of Not Encountered.",
    },
  },
  checkbox: {
    label: "Mark",
    markedLabel: "Marked",
  },
  tooltip: {
    label: {
      attempted: "Attempted",
      notAttempted: "Not Attempted",
      correctAnswered: "Correct Answered",
      wrongAnswered: "Wrong Answered",
      marked: "Marked",
    },
  },
  messages: {
    noGuidelines: "No guidelines available",
    noQuestion: "No question available",
    noResponse:"No response submitted.",
    noPrompt: "No prompt available",
  },
  input: {
    numericEntryPlaceholder: "Enter your answer",
    analyticalWritingPlaceholder: "Write your response here",
  },
  other:{
    section:"Section",
    question:"Question",
    reviewSection: "Review Section",
    sortingText: "Rows Sorted by Number in"
  },
  endTest: {
    card: {
      title: "End Test",
      sessionComplete: "Your test session is now complete."
    },
  }
};
export default { preview };
