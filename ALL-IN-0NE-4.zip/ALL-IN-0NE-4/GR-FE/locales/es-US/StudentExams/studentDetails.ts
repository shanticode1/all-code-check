const studentDetails = {
  title: "Student Management",
  messages: {
    noResultFoundForSearch: "No results found for your search.",
    noUserFound: "No exams found.",
  },
  table: {
    columns: {
      title: {
        name: "Student Name",
        email: "Email",
        portalName: "Portal Name",
        accessType: "Access Type",
        actions: "Actions",
        status: "Status",
        subscriptionStartDate: "Subscription Start Date",
        subscriptionEndDate: "Subscription End Date",
        createdDate: "Created Date",
        lastloginDate : "Last Login"
      },
      image: {
        accessType: {
          alt: "Smart With Heart",
        },
      },
      render: {
        accessType: {
          paid: "Paid",
        },
      },
      status: {
        active: "Active",
        inactive: "Inactive",
      },
    },
  },
  create: {
    form: {
      firstName: {
        label: "First Name",
        placeholder: "Enter first name",
      },
      lastName: {
        label: "Last Name",
        placeholder: "Enter last name",
      },
      email: {
        label: "Email",
        placeholder: "Enter email",
      },
      password: {
        label: "Password",
        placeholder: "Enter Password",
      },
      partnerType: {
        label: "Partner Type",
        placeholder: "Select partner type",
      },
      subscriptionStatus: {
        label: "Subscription Status",
        placeholder: "Enter subscription status",
      },
      subscriptionStartDate: {
        label: "Subscription Start Date",
        placeholder: "Select subscription start date",
      },
      subscriptionEndDate: {
        label: "Subscription End Date",
        placeholder: "Select subscription end date",
      },
    },
    subscription_status: {
      active: "ACTIVE",
      inactive: "INACTIVE",
    },
    modal: {
      title: "Add Student",
    },
  },
  edit: {
    modal: {
      title: "Update Student",
    },
  },
  search: {
    placeholder: "Search by name or email",
  },
  confirmDelete: {
    title: "Delete Student",
    message: "Are you sure you want to delete this student?",
    description:
      "This action will permanently erase all exam records linked to the student and cannot be undone.",
    cancel: "Cancel",
    delete: "Yes, Delete",
  },
  message: {
    idRequired: "Student ID is required to update the student.",
    studentNotFound: "Student not found.",
  },
  button: {
    import: {
      text: "Import Students",
    },
  },
  partnerType: {
    sherpaPrep: "Sherpa Prep",
    smartWithHeart: "Smart With Heart",
  },
  exam: {
    table: {
      columns: {
        title: {
          examName: "Exam Name",
          examType: "Exam Type",
          action: "Action"
        }
      }
    },
    button: {
      start: "Start Exam"
    }
  }
};
export default { studentDetails };
