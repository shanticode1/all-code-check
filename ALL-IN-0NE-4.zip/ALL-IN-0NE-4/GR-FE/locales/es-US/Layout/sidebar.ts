const sidebar = {
  navLink: {
    labels: {
      dashboard: "Dashboard",
      exams: "Exams",
      examsHistory: "Score Reports",
      studentExams: "Student Exams",
      studentManagement: "Student Management",
      userManagement: "User Management",
      examManagement: "Exam Management",
      analyticalEvaluation: "Analytical Evaluation",
      exportExamHistory: "Export Exam History",
      setting: "Settings",
    },
  },
  examSideBar: {
    buttons: {
      viewAll: {
        text: "View All",
      },
    },
    checkIcon: {
      text: "Question",
    },
    tooltip: {
      sectionSettings: "Section Settings"
    }
  },
};
export default { sidebar };
