const header = {
    menu: {
        button: {
            Logout: "Logout"
        }
    },
    modal: {
        title: "Are you sure you want to leave?",
        description: "If you go back now, your current answers may not be saved.",
    }
}
export default { header }