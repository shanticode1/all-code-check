const userDetails = {
  title: "User Management",
  table: {
    columns: {
      title: {
        name: "Name",
        email: "Email",
        role: "Role",
        actions: "Actions",
        status: "Status",
      },
      image: {
        accessType: {
          alt: "Smart With Heart",
        },
      },
      render: {
        accessType: {
          paid: "Paid",
        },
      },
      status: {
        active: "Active",
        inactive: "Inactive",
      },
    },
  },
  create: {
    form: {
      firstName: {
        label: "First Name",
        placeholder: "Enter first name",
      },
      lastName: {
        label: "Last Name",
        placeholder: "Enter last name",
      },
      email: {
        label: "Email",
        placeholder: "Enter email",
      },
      password: {
        label: "Password",
        placeholder: "Enter Password",
      },
      role: {
        label: "Role",
        placeholder: "Select Role",
      },
    },
    subscription_status: {
      active: "ACTIVE",
      inactive: "INACTIVE",
    },
    modal: {
      title: "Add User",
    },
  },
  edit: {
    modal: {
      title: "Update User",
    },
  },
  search: {
    placeholder: "Search by name or email",
  },
  confirmDelete: {
    title: "Delete User",
    message: "Are you sure you want to delete this user?",
    description: "",
    cancel: "Cancel",
    delete: "Yes, Delete",
  },
  message: {
    idRequired: "User ID is required to update the user.",
  },
};
export default { userDetails };
