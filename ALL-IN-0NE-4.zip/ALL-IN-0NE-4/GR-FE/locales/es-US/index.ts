import { login, resetPassword } from "./Auth";
import { dashboard } from "./Dashboard";
import { evaluation, exam, examDetail, examHistory, preview, startExam, calculator, instruction } from "./Exams";
import { generic } from "./Generic";
import { header, sidebar } from "./Layout";
import { profile } from "./Profile";
import { answer, question, view } from "./Questions";
import { section } from "./Sections";
import { examScheduler } from "./setting";
import { studentDetails } from "./StudentExams";
import { userDetails } from "./UserDetails";

const enUS = {
  ...exam,
  ...section,
  ...dashboard,
  ...generic,
  ...studentDetails,
  ...userDetails,
  ...examHistory,
  ...evaluation,
  ...calculator,
  ...profile,
  ...sidebar,
  ...header,
  ...question,
  ...startExam,
  ...preview,
  ...view,
  ...examDetail,
  ...examScheduler,
  ...login,
  ...resetPassword,
  ...instruction,
  ...answer
};

export default enUS;
